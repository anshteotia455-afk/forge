import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.forge.fitness",
  appName: "FORGE",
  webDir: "out",
  android: {
    backgroundColor: "#0a0b0d",
    allowMixedContent: false,
  },
  server: {
    androidScheme: "https",
  },
};

export default config;
