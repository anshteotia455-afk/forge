FORGE for Windows v2.3 — data persistence fix

1. Extract this folder anywhere (Desktop is fine).
2. Double-click FORGE.exe.
3. SmartScreen may warn (unsigned independent build): More info > Run anyway.
4. Closing minimizes to the system tray so workout alarms keep firing.
   Right-click the tray icon > Quit to fully close FORGE.

WHY THIS VERSION: earlier builds used a random local port, so your entries
looked lost after every restart. This build uses a stable port, so everything
you log is saved permanently in %APPDATA%\FORGE.

Updating: replace this folder with a newer version. Your data is stored
separately in %APPDATA%\FORGE and survives updates.

All features work offline. Use Profile > Data to export/import backups.
