/**
 * FORGE: patch Capacitor's WebViewLocalServer so route processors receive the
 * real requested path instead of a hardcoded "/index.html".
 *
 * Without this, every document request (hard reload at /planner, MPA fallback)
 * serves the home page on Android. The patch lives in node_modules, so npm
 * reinstalls revert it — run this script before any Android build:
 *
 *     node scripts/patch-capacitor-routing.mjs
 *
 * Idempotent: exits 0 if already applied.
 */
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const target = join(
  root,
  "node_modules/@capacitor/android/capacitor/src/main/java/com/getcapacitor/WebViewLocalServer.java"
);

if (!existsSync(target)) {
  console.error("[forge-patch] Capacitor source not found — run npm install first.");
  process.exit(1);
}

const stock = `                    ProcessedRoute processedRoute = bridge.getRouteProcessor().process(this.basePath, "/index.html");`;
const patched = `                    // FORGE patch: pass the real requested path instead of a hardcoded
                    // "/index.html", so /planner/ resolves to /planner/index.html
                    // rather than always loading the home page.
                    ProcessedRoute processedRoute = bridge.getRouteProcessor().process(this.basePath, path);`;

const source = readFileSync(target, "utf8");

// Marker check (indentation/comments may vary between applies).
if (source.includes("process(this.basePath, path)")) {
  console.log("[forge-patch] already applied ✓");
  process.exit(0);
}
if (!source.includes(stock)) {
  console.error("[forge-patch] expected stock line not found — Capacitor version may have changed.");
  process.exit(1);
}

writeFileSync(target, source.replace(stock, patched));
console.log("[forge-patch] applied ✓");
