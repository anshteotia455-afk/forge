const { app, BrowserWindow, dialog, Menu, Tray, nativeImage, shell } = require("electron");
const path = require("path");
const fs = require("fs");
const http = require("http");

// Stable identity: replacing the app folder keeps %APPDATA%/FORGE untouched.
app.setName("FORGE");
app.setAppUserModelId("com.forge.fitness");

let mainWindow = null;
let tray = null;
let quitting = false;
let serverUrl = null;

/* --------------------------------------------------------------------------
 * Next.js static export references assets with absolute paths like
 * "/_next/static/…". Under the file:// protocol those resolve to the drive
 * root and nothing loads — the classic Electron black screen. Serving the
 * bundle from a tiny localhost HTTP server makes every absolute path resolve
 * correctly, exactly like a browser.
 * ------------------------------------------------------------------------ */

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".txt": "text/plain; charset=utf-8",
  ".map": "application/json; charset=utf-8",
};

// LOCALSTORAGE IS KEYED BY ORIGIN — the port must never change between
// launches or every entry appears lost on restart. Fixed high ports, first
// free one wins (single-instance lock already prevents two FORGE copies).
const PORTS = [47321, 47322, 47323, 47324, 47325];

function startServer() {
  return new Promise((resolve, reject) => {
    const root = path.join(__dirname, "public");

    const handler = (req, res) => {
      try {
        const urlPath = decodeURIComponent((req.url || "/").split("?")[0]);
        let filePath = path.normalize(path.join(root, urlPath));

        // Never let a request escape the bundled folder.
        if (!filePath.startsWith(root)) {
          res.writeHead(403);
          res.end("Forbidden");
          return;
        }

        // Directory or clean route → index.html (trailingSlash export layout).
        if (fs.existsSync(filePath) && fs.statSync(filePath).isDirectory()) {
          filePath = path.join(filePath, "index.html");
        } else if (!fs.existsSync(filePath)) {
          const asHtml = `${filePath}.html`;
          const asDir = path.join(filePath, "index.html");
          if (fs.existsSync(asHtml)) filePath = asHtml;
          else if (fs.existsSync(asDir)) filePath = asDir;
          else filePath = path.join(root, "index.html"); // SPA-style fallback
        }

        const data = fs.readFileSync(filePath);
        const ext = path.extname(filePath).toLowerCase();
        res.writeHead(200, {
          "Content-Type": MIME[ext] || "application/octet-stream",
          "Cache-Control": "no-cache",
        });
        res.end(data);
      } catch {
        res.writeHead(404);
        res.end("Not found");
      }
    };

    let attempt = 0;
    const listen = () => {
      const server = http.createServer(handler);
      server.once("error", (err) => {
        if (err.code === "EADDRINUSE" && attempt < PORTS.length - 1) {
          attempt += 1;
          listen();
        } else {
          reject(err);
        }
      });
      // Loopback only — never exposed to the network.
      server.listen(PORTS[attempt], "127.0.0.1", () => {
        resolve(`http://127.0.0.1:${PORTS[attempt]}`);
      });
    };
    listen();
  });
}

function createWindow() {
  const iconPath = path.join(__dirname, "public", "icons", "icon-192.png");
  mainWindow = new BrowserWindow({
    width: 480,
    height: 900,
    minWidth: 390,
    minHeight: 700,
    backgroundColor: "#0a0b0d",
    title: "FORGE",
    icon: iconPath,
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false, // reminders keep ticking while minimized
    },
  });

  mainWindow.loadURL(serverUrl);
  mainWindow.once("ready-to-show", () => mainWindow.show());

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("http://127.0.0.1")) return { action: "allow" };
    if (url.startsWith("http://") || url.startsWith("https://")) shell.openExternal(url);
    return { action: "deny" };
  });

  // External http(s) navigations (e.g. video demos) open in the real browser.
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (!url.startsWith(serverUrl)) {
      event.preventDefault();
      shell.openExternal(url);
    }
  });

  mainWindow.on("close", (event) => {
    if (!quitting) {
      event.preventDefault();
      mainWindow.hide();
    }
  });
}

function createTray() {
  const iconPath = path.join(__dirname, "public", "icons", "icon-192.png");
  const icon = nativeImage.createFromPath(iconPath).resize({ width: 20, height: 20 });
  tray = new Tray(icon);
  tray.setToolTip("FORGE — Home Fitness OS");
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: "Open FORGE", click: () => { mainWindow.show(); mainWindow.focus(); } },
      { type: "separator" },
      { label: "Quit", click: () => { quitting = true; app.quit(); } },
    ])
  );
  tray.on("double-click", () => {
    mainWindow.show();
    mainWindow.focus();
  });
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    }
  });

  app.whenReady().then(async () => {
    try {
      serverUrl = await startServer();
    } catch (err) {
      dialog.showErrorBox(
        "FORGE couldn't start",
        "Ports 47321–47325 are all unavailable. Close any other FORGE window and try again."
      );
      app.quit();
      return;
    }
    createWindow();
    createTray();
  });
}

app.on("window-all-closed", () => {
  // Stay alive in the tray so workout reminders still fire.
});

app.on("before-quit", () => {
  quitting = true;
});
