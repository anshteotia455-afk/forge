import type { NextConfig } from "next";

/**
 * Normal builds retain API routes and PostgreSQL sync. MOBILE_BUILD creates
 * a static bundle for Capacitor; the build script temporarily removes API
 * route handlers because an APK has no local Node.js server.
 */
const mobile = process.env.MOBILE_BUILD === "1";

const nextConfig: NextConfig = {
  ...(mobile ? { output: "export" as const, trailingSlash: true } : {}),
  images: mobile ? { unoptimized: true } : undefined,
};

export default nextConfig;
