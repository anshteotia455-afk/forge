"use client";

import { ArrowLeft, Check, Lock, Pencil, Plus, Shield, Sparkles, Share2, Trash2, Zap } from "lucide-react";
import { useRouter } from "next/navigation";
import { useT } from "@/lib/i18n";
import { useMemo, useState } from "react";
import { ProGate, useAccess } from "@/components/paywall";
import { LineChart } from "@/components/chart";
import { shareMonthlyCard } from "@/lib/share";
import { Chip, Reveal, Ring, Sheet, Stepper } from "@/components/ui";
import { AchCategory, RANKS, summarize } from "@/lib/achievements";
import { EXERCISES } from "@/lib/data";
import {
  addDays,
  bwFactorOf,
  calcTargets,
  dateKey,
  DEFAULT_HYDRATION,
  e1rm,
  isLoadable,
  loadModeOf,
  nextTarget,
  parseKey,
  personalRecords,
  setLoad,
  vesselsForGoal,
} from "@/lib/engine";
import { targetHeadline, targetNote, wIn, wOut, wUnit } from "@/lib/units";
import { plateausOf, type Plateau } from "@/lib/training";
import {
  FEATS,
  LEVELS,
  LiftDef,
  rateFeat,
  skillClass,
  strengthClass,
} from "@/lib/standards";
import { Challenge, ChallengeMetric, useStore } from "@/lib/store";

const CATS: (AchCategory | "All")[] = [
  "All",
  "Training",
  "Consistency",
  "Strength",
  "Skills",
  "Nutrition",
  "Body",
];

const METRIC_LABELS: Record<ChallengeMetric, string> = {
  workouts: "workouts",
  minutes: "minutes trained",
  sets: "sets",
  "water-days": "full water days",
  "protein-days": "high-protein days",
};

const DEFAULT_TARGETS: Record<ChallengeMetric, number> = {
  workouts: 12,
  minutes: 1500,
  sets: 150,
  "water-days": 20,
  "protein-days": 20,
};

export default function RanksPage() {
  const t = useT();
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const router = useRouter();
  const logs = useStore((s) => s.logs);
  const meals = useStore((s) => s.meals);
  const weights = useStore((s) => s.weights);
  const measurements = useStore((s) => s.measurements);
  const water = useStore((s) => s.water);
  const skillProgress = useStore((s) => s.skillProgress);
  const checkins = useStore((s) => s.checkins);
  const hydration = useStore((s) => s.hydration) ?? DEFAULT_HYDRATION;

  const profile = useStore((s) => s.profile);

  const [cat, setCat] = useState<AchCategory | "All">("All");
  const [tab, setTab] = useState<"xp" | "standards">("xp");
  const [quickOpen, setQuickOpen] = useState(false);
  const plateaus = useMemo(() => plateausOf(logs), [logs]);
  const challenges = useStore((s) => s.challenges);
  const addChallenge = useStore((s) => s.addChallenge);
  const removeChallenge = useStore((s) => s.removeChallenge);
  const [chSheet, setChSheet] = useState(false);
  const [chDraft, setChDraft] = useState<{
    name: string;
    metric: ChallengeMetric;
    target: number;
    days: number;
  }>({ name: "", metric: "workouts", target: 12, days: 30 });
  const targets = profile ? calcTargets(profile) : null;

  // ---- Monthly report stats ----
  const monthKey = dateKey().slice(0, 7);
  const monthLogs = logs.filter((l) => l.date.startsWith(monthKey));
  const monthSets = monthLogs.reduce((a, l) => a + l.setsDone, 0);
  const monthMinutes = monthLogs.reduce((a, l) => a + l.minutes, 0);
  const monthVolume = Math.round(
    wOut(monthLogs.reduce((a, l) => a + (l.volumeKg ?? 0), 0), sys)
  );
  const waterNeed = vesselsForGoal(hydration);
  const monthWaterDays = Object.entries(water).filter(
    ([d, n]) => d.startsWith(monthKey) && n >= waterNeed
  ).length;
  const monthPrs = personalRecords(logs, 100).filter((r) => r.date.startsWith(monthKey)).length;
  const exCount = new Map<string, number>();
  for (const l of monthLogs) {
    for (const d of l.detail ?? []) exCount.set(d.name, (exCount.get(d.name) ?? 0) + 1);
  }
  const topExercise =
    [...exCount].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
  const monthLabel = new Date().toLocaleDateString(undefined, {
    month: "long",
    year: "numeric",
  });

  const progressOf = (c: Challenge) => {
    const end = dateKey(addDays(parseKey(c.start), c.days - 1));
    const todayKey = dateKey();
    const effEnd = end < todayKey ? end : todayKey;
    const inRange = (d: string) => d >= c.start && d <= effEnd;
    let value = 0;
    if (c.metric === "workouts") {
      value = logs.filter((l) => inRange(l.date)).length;
    } else if (c.metric === "minutes") {
      value = logs.filter((l) => inRange(l.date)).reduce((a, l) => a + l.minutes, 0);
    } else if (c.metric === "sets") {
      value = logs.filter((l) => inRange(l.date)).reduce((a, l) => a + l.setsDone, 0);
    } else if (c.metric === "water-days") {
      const need = vesselsForGoal(hydration);
      const days = new Set<string>();
      for (const [d, n] of Object.entries(water)) {
        if (inRange(d) && n >= need) days.add(d);
      }
      value = days.size;
    } else if (c.metric === "protein-days" && targets) {
      const byDate = new Map<string, number>();
      for (const m of meals) {
        if (inRange(m.date)) byDate.set(m.date, (byDate.get(m.date) ?? 0) + m.p * m.qty);
      }
      value = [...byDate.values()].filter((v) => v >= targets.protein * 0.9).length;
    }
    const ended = end < todayKey;
    const daysLeft = Math.max(
      0,
      Math.ceil((parseKey(end).getTime() - parseKey(todayKey).getTime()) / 86400000)
    );
    return {
      value,
      pct: Math.min(1, value / Math.max(1, c.target)),
      daysLeft,
      ended,
    };
  };
  const access = useAccess();
  const [editLift, setEditLift] = useState<LiftDef | null>(null);

  const sum = useMemo(
    () => summarize({ logs, meals, weights, measurements, water, skillProgress, hydration, checkins }),
    [logs, meals, weights, measurements, water, skillProgress, hydration, checkins]
  );

  const bodyweight = weights[0]?.kg ?? profile?.weightKg ?? 70;
  const sex = profile?.sex ?? "male";
  const strength = useMemo(
    () => strengthClass(logs, bodyweight, sex),
    [logs, bodyweight, sex]
  );
  const feats = useMemo(() => FEATS.map((f) => rateFeat(logs, f, sex)), [logs, sex]);
  const skills = useMemo(() => skillClass(skillProgress), [skillProgress]);

  const { rank, next, progress, xpToNext } = sum.rank;
  const xp = sum.xp;
  const shown = sum.achievements.filter((a) => cat === "All" || a.category === cat);
  const pctDone = Math.round((sum.unlocked.length / sum.achievements.length) * 100);

  return (
    <div className="flex flex-col gap-4">
      {/* Header */}
      <Reveal>
        <div className="flex items-center gap-3 pt-1">
          <button
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-2)]"
            onClick={() => router.back()}
            aria-label="Back"
          >
            <ArrowLeft size={16} />
          </button>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--volt)]">{t("pg.ranksEyebrow")}
          </p>
            <h1 className="font-display text-[28px] uppercase leading-none tracking-wide">{t("pg.ranksTitle")}
          </h1>
          </div>
        </div>
      </Reveal>

      {/* Tabs */}
      <Reveal>
        <div className="flex gap-1 rounded-2xl border border-[var(--line)] bg-[var(--surface-2)] p-1">
          {(
            [
              { v: "xp" as const, l: "XP & Badges" },
              { v: "standards" as const, l: "Strength Standards" },
            ]
          ).map((t) => (
            <button
              key={t.v}
              onClick={() => setTab(t.v)}
              className={`flex-1 rounded-xl px-2 py-2.5 text-[12px] font-bold transition-all ${
                tab === t.v ? "bg-[var(--volt)] text-[#0b0c0e]" : "text-[var(--muted)]"
              }`}
            >
              {t.l}
            </button>
          ))}
        </div>
      </Reveal>

      {tab === "standards" ? (
        access.isPro ? (
        <StandardsView
          strength={strength}
          feats={feats}
          skills={skills}
          bodyweight={bodyweight}
          onQuickLog={() => setQuickOpen(true)}
          onEditLift={(lift) => setEditLift(lift)}
          plateaus={plateaus}
        />
        ) : (
          <ProGate feature="standards">
            <div className="card p-6 text-center">
              <p className="font-display text-2xl uppercase tracking-wide">Intermediate</p>
              <p className="mt-2 text-[12px] text-[var(--muted)]">
                Squat 1.75× · Bench 1.4× · Deadlift 2.1× bodyweight
              </p>
              <div className="mt-4 flex flex-col gap-2">
                {["Squat", "Bench Press", "Deadlift", "Weighted Pull-Up"].map((n) => (
                  <div key={n} className="flex items-center gap-2">
                    <span className="flex-1 text-left text-[12px] font-bold">{n}</span>
                    <div className="h-1.5 w-24 overflow-hidden rounded-full bg-white/10">
                      <div className="h-full w-2/3 rounded-full bg-[var(--volt)]" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </ProGate>
        )
      ) : (
      <>
      {/* Rank hero */}
      <Reveal>
        <div
          className="card relative overflow-hidden p-6 text-center"
          style={{ boxShadow: `0 20px 60px -30px ${rank.glow}` }}
        >
          <div
            className="pointer-events-none absolute left-1/2 top-0 h-48 w-48 -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl"
            style={{ background: rank.glow }}
          />
          <div className="relative flex flex-col items-center gap-3">
            <Ring size={148} stroke={10} value={progress} color={rank.color}>
              <div className="flex flex-col items-center">
                <Shield size={26} style={{ color: rank.color }} />
                <p className="font-display mt-1 text-xl uppercase leading-none tracking-wide">
                  {rank.name}
                </p>
                <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-[var(--muted)]">
                  Tier {rank.tier}
                </p>
              </div>
            </Ring>
            <p className="tabular font-display text-3xl leading-none" style={{ color: rank.color }}>
              {xp.total.toLocaleString()} <span className="text-base text-[var(--muted)]">XP</span>
            </p>
            {next ? (
              <p className="text-[12px] text-[var(--muted)]">
                <span className="tabular font-bold text-[var(--text)]">{xpToNext.toLocaleString()}</span>{" "}
                XP to <span className="font-bold" style={{ color: next.color }}>{next.name}</span>
              </p>
            ) : (
              <p className="text-[12px] font-bold text-[var(--volt)]">
                Max rank reached — you are a Legend.
              </p>
            )}
          </div>
        </div>
      </Reveal>

      {/* XP breakdown */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Where your XP came from
            </p>
            <Zap size={14} className="text-[var(--volt)]" />
          </div>
          <div className="flex flex-col gap-2">
            {[
              { l: "Workouts completed", v: xp.fromWorkouts, c: "var(--volt)" },
              { l: "Sets logged", v: xp.fromSets, c: "var(--aqua)" },
              { l: "Volume lifted", v: xp.fromVolume, c: "var(--ember)" },
              { l: "Nutrition tracking", v: xp.fromNutrition, c: "#b98cff" },
              { l: "Habits (weigh-ins, water)", v: xp.fromHabits, c: "#5cd6ff" },
              { l: "Skill stages", v: xp.fromSkills, c: "#7de2a8" },
              { l: "Achievement bonuses", v: xp.fromAchievements, c: "#ffc740" },
            ].map((row) => {
              const pct = xp.total ? (row.v / xp.total) * 100 : 0;
              return (
                <div key={row.l}>
                  <div className="mb-1 flex items-baseline justify-between text-[11px]">
                    <span className="text-[var(--muted)]">{row.l}</span>
                    <span className="tabular font-bold">{row.v.toLocaleString()}</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{ width: `${pct}%`, background: row.c }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Reveal>

      {/* Closest unlocks */}
      {sum.nextUp.length > 0 && (
        <Reveal>
          <div className="card p-5">
            <div className="mb-3 flex items-center justify-between">
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
                Closest unlocks
              </p>
              <Sparkles size={14} className="text-[var(--volt)]" />
            </div>
            <div className="flex flex-col gap-3">
              {sum.nextUp.map((a) => (
                <div key={a.id} className="flex items-center gap-3">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-lg grayscale">
                    {a.icon}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-bold">{a.name}</p>
                    <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                      <div
                        className="h-full rounded-full bg-[var(--volt)] transition-all duration-700"
                        style={{ width: `${a.pct * 100}%` }}
                      />
                    </div>
                  </div>
                  <span className="tabular shrink-0 text-[11px] font-bold text-[var(--muted)]">
                    {Math.min(a.value, a.target).toLocaleString()}/{a.target.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      )}

      {/* Rank ladder */}
      <Reveal>
        <div className="card p-5">
          <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
            Rank ladder
          </p>
          <div className="flex flex-col gap-1.5">
            {RANKS.map((r) => {
              const reached = xp.total >= r.minXp;
              const current = r.id === rank.id;
              return (
                <div
                  key={r.id}
                  className={`flex items-center gap-3 rounded-xl px-3 py-2.5 transition-all ${
                    current ? "bg-[var(--surface-2)] ring-1 ring-[var(--line-strong)]" : ""
                  }`}
                >
                  <Shield
                    size={16}
                    style={{ color: reached ? r.color : "var(--muted)" }}
                    className={reached ? "" : "opacity-40"}
                  />
                  <span
                    className={`flex-1 text-[13px] font-bold ${reached ? "" : "text-[var(--muted)]"}`}
                    style={reached ? { color: r.color } : undefined}
                  >
                    {r.name}
                    <span className="ml-1.5 text-[10px] font-semibold text-[var(--muted)]">
                      Tier {r.tier}
                    </span>
                  </span>
                  {current && (
                    <span className="rounded-full bg-[var(--volt)] px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider text-[#0b0c0e]">
                      You
                    </span>
                  )}
                  <span className="tabular text-[11px] font-semibold text-[var(--muted)]">
                    {r.minXp.toLocaleString()}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </Reveal>

      {/* Monthly report */}
      <Reveal>
        <button
          className="btn btn-ghost h-11 w-full text-sm"
          onClick={() => {
            void shareMonthlyCard({
              month: monthLabel,
              sessions: monthLogs.length,
              minutes: monthMinutes,
              sets: monthSets,
              volume: monthVolume,
              volumeUnit: wUnit(sys),
              waterDays: monthWaterDays,
              prs: monthPrs,
              rankName: sum.rank.rank.name,
              rankTier: sum.rank.rank.tier,
              rankColor: sum.rank.rank.color,
              topExercise,
            });
          }}
        >
          <Share2 size={15} /> Share {monthLabel} report card
        </button>
      </Reveal>

      {/* Challenges */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Challenges
            </p>
            <button
              className="chip chip-on !px-3 !py-1.5 text-[11px] font-bold"
              onClick={() => setChSheet(true)}
            >
              <Plus size={12} strokeWidth={3} /> New
            </button>
          </div>

          {challenges.length === 0 ? (
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">
              Set a self-made goal — 12 workouts in 30 days, 20 full water days — and watch the
              bar fill up as you go.
            </p>
          ) : (
            <div className="flex flex-col gap-3">
              {challenges.map((c) => {
                const p = progressOf(c);
                const done = p.pct >= 1;
                return (
                  <div key={c.id} className="card-2 p-3.5">
                    <div className="flex items-center gap-2">
                      <p className="min-w-0 flex-1 truncate text-[13px] font-bold">{c.name}</p>
                      {done ? (
                        <span className="rounded-full bg-[var(--volt)] px-2 py-0.5 text-[9px] font-extrabold uppercase text-[#0b0c0e]">
                          Done 🎉
                        </span>
                      ) : p.ended ? (
                        <span className="text-[9px] font-bold uppercase text-[var(--muted)]">
                          Ended
                        </span>
                      ) : (
                        <span className="tabular text-[10px] font-bold text-[var(--muted)]">
                          {p.daysLeft}d left
                        </span>
                      )}
                      <button
                        className="text-[var(--muted)] active:text-[var(--red)]"
                        onClick={() => removeChallenge(c.id)}
                        aria-label="Delete challenge"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{
                          width: `${p.pct * 100}%`,
                          background: done ? "var(--volt)" : "var(--aqua)",
                        }}
                      />
                    </div>
                    <p className="tabular mt-1.5 text-[10px] text-[var(--muted)]">
                      {p.value.toLocaleString()} / {c.target.toLocaleString()}{" "}
                      {METRIC_LABELS[c.metric]} · {c.days} days
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </Reveal>

      {/* Badges */}
      <Reveal>
        <div>
          <div className="mb-2 flex items-baseline justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Achievements
            </p>
            <span className="tabular text-[11px] font-bold text-[var(--volt)]">
              {sum.unlocked.length}/{sum.achievements.length} · {pctDone}%
            </span>
          </div>
          <div className="no-scrollbar -mx-4 mb-3 flex gap-1.5 overflow-x-auto px-4">
            {CATS.map((c) => (
              <button
                key={c}
                className={`chip shrink-0 !py-1.5 text-[11px] font-bold ${cat === c ? "chip-on" : ""}`}
                onClick={() => setCat(c)}
              >
                {c}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            {shown.map((a) => (
              <div
                key={a.id}
                className={`card relative overflow-hidden p-3.5 ${a.unlocked ? "" : "opacity-85"}`}
                style={
                  a.unlocked
                    ? { borderColor: "rgba(205,248,63,0.35)", background: "rgba(205,248,63,0.04)" }
                    : undefined
                }
              >
                <div className="flex items-start justify-between">
                  <span className={`text-2xl ${a.unlocked ? "" : "opacity-35 grayscale"}`}>
                    {a.icon}
                  </span>
                  {a.unlocked ? (
                    <span className="grid h-5 w-5 place-items-center rounded-full bg-[var(--volt)] text-[#0b0c0e]">
                      <Check size={11} strokeWidth={4} />
                    </span>
                  ) : (
                    <Lock size={13} className="text-[var(--muted)]" />
                  )}
                </div>
                <p className="mt-2 text-[12px] font-extrabold leading-tight">{a.name}</p>
                <p className="mt-0.5 text-[10px] leading-snug text-[var(--muted)]">{a.desc}</p>
                {!a.unlocked && (
                  <div className="mt-2">
                    <div className="h-1 overflow-hidden rounded-full bg-white/[0.07]">
                      <div
                        className="h-full rounded-full bg-[var(--volt)]"
                        style={{ width: `${a.pct * 100}%` }}
                      />
                    </div>
                    <p className="tabular mt-1 text-[9px] font-bold text-[var(--muted)]">
                      {Math.min(a.value, a.target).toLocaleString()} / {a.target.toLocaleString()}
                    </p>
                  </div>
                )}
                <p
                  className={`tabular mt-2 text-[9px] font-extrabold uppercase tracking-wider ${
                    a.unlocked ? "text-[var(--volt)]" : "text-[var(--muted)]"
                  }`}
                >
                  +{a.points} XP
                </p>
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      <p className="pb-2 text-center text-[10px] leading-relaxed text-[var(--muted)]">
        XP is calculated from your full logged history —
        <br />
        it restores automatically on any device.
      </p>
      </>
      )}

      <QuickLogSheet open={quickOpen} onClose={() => setQuickOpen(false)} />
      <LiftHistorySheet lift={editLift} onClose={() => setEditLift(null)} />

      {/* New challenge */}
      <Sheet
        open={chSheet}
        onClose={() => setChSheet(false)}
        title="New challenge"
      >
        <div className="flex flex-col gap-4">
          <input
            className="field"
            placeholder={`${chDraft.target} ${METRIC_LABELS[chDraft.metric]} in ${chDraft.days} days`}
            value={chDraft.name}
            onChange={(e) => setChDraft({ ...chDraft, name: e.target.value })}
          />

          <div>
            <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
              Track
            </p>
            <div className="flex flex-wrap gap-1.5">
              {(Object.keys(METRIC_LABELS) as ChallengeMetric[]).map((m) => (
                <Chip
                  key={m}
                  active={chDraft.metric === m}
                  onClick={() =>
                    setChDraft({ ...chDraft, metric: m, target: DEFAULT_TARGETS[m] })
                  }
                >
                  {METRIC_LABELS[m]}
                </Chip>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
                Target
              </label>
              <input
                className="field text-center"
                type="number"
                inputMode="numeric"
                min={1}
                value={chDraft.target}
                onChange={(e) =>
                  setChDraft({ ...chDraft, target: Math.max(1, Number(e.target.value) || 1) })
                }
              />
            </div>
            <div>
              <p className="mb-1.5 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
                Duration
              </p>
              <div className="flex gap-1.5">
                {[7, 30, 90].map((d) => (
                  <button
                    key={d}
                    className={`chip flex-1 justify-center !px-2 ${chDraft.days === d ? "chip-on" : ""}`}
                    onClick={() => setChDraft({ ...chDraft, days: d })}
                  >
                    {d}d
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            className="btn btn-volt h-12 w-full"
            onClick={() => {
              addChallenge({
                name:
                  chDraft.name.trim() ||
                  `${chDraft.target} ${METRIC_LABELS[chDraft.metric]} in ${chDraft.days} days`,
                metric: chDraft.metric,
                target: chDraft.target,
                start: dateKey(),
                days: chDraft.days,
              });
              setChSheet(false);
              setChDraft({ name: "", metric: "workouts", target: 12, days: 30 });
            }}
          >
            Start challenge
          </button>
        </div>
      </Sheet>
    </div>
  );
}

/* --------------------------- Quick log lift ---------------------------- */

interface QuickSet {
  kg: number;
  reps: number;
}

function QuickLogSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const quickLogLift = useStore((s) => s.quickLogLift);
  const profile = useStore((s) => s.profile);
  const weights = useStore((s) => s.weights);
  const logs = useStore((s) => s.logs);
  const customExercises = useStore((s) => s.customExercises);

  const bodyweight = weights[0]?.kg ?? profile?.weightKg ?? 70;

  // Every exercise that can carry load, plus all bodyweight benchmark moves
  const options = useMemo(() => {
    const featIds = new Set(FEATS.flatMap((f) => f.exerciseIds));
    const all = [...customExercises, ...EXERCISES];
    return all
      .filter((e) => isLoadable(e) || featIds.has(e.id))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [customExercises]);

  const [exId, setExId] = useState<string>("bb-squat");
  const [sets, setSets] = useState<QuickSet[]>([{ kg: wOut(20, sys), reps: 5 }]);
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  const ex = options.find((e) => e.id === exId) ?? options[0];
  const isTimed = ex?.kind === "time";
  const loadable = ex ? isLoadable(ex) : true;
  const mode = ex ? loadModeOf(ex) : "external";
  const added = mode === "added";

  const best = useMemo(() => {
    if (!ex) return 0;
    let b = 0;
    for (const l of logs)
      for (const d of l.detail ?? [])
        if (d.exerciseId === ex.id)
          for (const s of d.sets) {
            if (!s.done || !s.reps) continue;
            const load = setLoad(s);
            if (load > 0) b = Math.max(b, e1rm(load, s.reps));
          }
    return Math.round(b * 10) / 10;
  }, [logs, ex]);

  const target = useMemo(() => (ex ? nextTarget(logs, ex) : null), [logs, ex]);

  const bwf = ex ? bwFactorOf(ex) : 0;
  const projected = sets.reduce((m, s) => {
    if (s.reps <= 0) return m;
    const load = added ? bodyweight * bwf + wIn(s.kg, sys) : wIn(s.kg, sys);
    return load > 0 ? Math.max(m, e1rm(load, s.reps)) : m;
  }, 0);

  const save = () => {
    if (!ex) return;
    quickLogLift({
      exerciseId: ex.id,
      name: ex.name,
      sets: sets.map((s) => ({
        kg: loadable ? wIn(s.kg, sys) : null,
        reps: isTimed ? null : s.reps,
        sec: isTimed ? s.reps : null,
        mode,
        bwf,
      })),
      bodyweightKg: bodyweight,
    });
    setSavedMsg(`${ex.name} logged · ${sets.length} set${sets.length > 1 ? "s" : ""}`);
    setSets([{ kg: sets[0]?.kg ?? wOut(20, sys), reps: sets[0]?.reps ?? 5 }]);
    setTimeout(() => setSavedMsg(null), 2600);
  };

  return (
    <Sheet open={open} onClose={onClose} title="Log a lift">
      <div className="flex flex-col gap-4">
        <p className="text-[12px] leading-relaxed text-[var(--muted)]">
          Record a lift you already did. It feeds your PRs, strength standards, volume and XP —
          no full workout needed.
        </p>

        <div>
          <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Exercise
          </label>
          <select
            className="field"
            value={exId}
            onChange={(e) => {
              setExId(e.target.value);
              setSavedMsg(null);
            }}
          >
            {options.map((o) => (
              <option key={o.id} value={o.id} style={{ background: "#121419" }}>
                {o.name}
              </option>
            ))}
          </select>
          {best > 0 && (
            <p className="tabular mt-1.5 text-[11px] text-[var(--muted)]">
              {added ? "Best effective 1RM: " : "Current best est. 1RM: "}
              <span className="font-bold text-[var(--volt)]">{wOut(best, sys)} {wUnit(sys)}</span>
            </p>
          )}
          {target && (
            <p className="mt-1 text-[11px] font-semibold text-[var(--aqua)]">
              Next: {targetHeadline(target, sys)}
              <span className="text-[var(--muted)]"> — {targetNote(target, sys)}</span>
            </p>
          )}
        </div>

        {/* Sets */}
        <div className="flex flex-col gap-2">
          <p className="text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">Sets</p>
          {sets.map((s, i) => (
            <div key={i} className="card-2 flex items-center gap-2 p-2.5">
              <span className="tabular w-5 shrink-0 text-[11px] font-extrabold text-[var(--volt)]">
                {i + 1}
              </span>
              {loadable && (
                <div className="flex min-w-0 flex-1 flex-col gap-1">
                  <span className="text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                    {added ? "+" : ""}{wUnit(sys)}
                  </span>
                  <input
                    className="field !px-2 !py-1.5 text-center text-sm"
                    type="number"
                    inputMode="decimal"
                    step={sys === "metric" ? 2.5 : 5}
                    value={s.kg}
                    onChange={(e) =>
                      setSets(sets.map((x, j) => (j === i ? { ...x, kg: Number(e.target.value) } : x)))
                    }
                  />
                </div>
              )}
              <div className="flex min-w-0 flex-1 flex-col gap-1">
                <span className="text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                  {isTimed ? "seconds" : "reps"}
                </span>
                <input
                  className="field !px-2 !py-1.5 text-center text-sm"
                  type="number"
                  inputMode="numeric"
                  value={s.reps}
                  onChange={(e) =>
                    setSets(sets.map((x, j) => (j === i ? { ...x, reps: Number(e.target.value) } : x)))
                  }
                />
              </div>
              {sets.length > 1 && (
                <button
                  className="mt-4 shrink-0 text-[var(--muted)] active:text-[var(--red)]"
                  onClick={() => setSets(sets.filter((_, j) => j !== i))}
                  aria-label="Remove set"
                >
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          ))}
          <button
            className="btn btn-ghost h-10 w-full text-[12px]"
            onClick={() => setSets([...sets, { ...(sets[sets.length - 1] ?? { kg: 20, reps: 5 }) }])}
          >
            <Plus size={14} /> Add set
          </button>
        </div>

        {loadable && projected > 0 && (
          <div className="card-2 p-3.5 text-center">
            <p className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">
              {added ? "Effective 1RM (bodyweight + added)" : "Estimated 1RM from these sets"}
            </p>
            <p className="tabular font-display mt-1 text-3xl text-[var(--volt)]">
              {Math.round(wOut(projected, sys))} {wUnit(sys)}
            </p>
            {projected > best && best > 0 && (
              <p className="mt-1 text-[11px] font-bold text-[var(--volt)]">
                New personal record 🎉
              </p>
            )}
          </div>
        )}

        {savedMsg && (
          <p className="anim-fade-up flex items-center justify-center gap-1.5 text-[12px] font-bold text-[var(--volt)]">
            <Check size={14} strokeWidth={3} /> {savedMsg}
          </p>
        )}

        <button className="btn btn-volt h-13 w-full py-3.5 text-base" onClick={save}>
          <Check size={17} strokeWidth={3} /> Save lift
        </button>
      </div>
    </Sheet>
  );
}

/* -------------------------- Standards view ---------------------------- */

function StandardsView({
  strength,
  feats,
  skills,
  bodyweight,
  onQuickLog,
  onEditLift,
  plateaus,
}: {
  strength: ReturnType<typeof strengthClass>;
  feats: ReturnType<typeof rateFeat>[];
  skills: ReturnType<typeof skillClass>;
  bodyweight: number;
  onQuickLog: () => void;
  onEditLift: (lift: LiftDef) => void;
  plateaus: Plateau[];
}) {
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  return (
    <>
      {/* Quick log CTA */}
      <Reveal>
        <button className="btn btn-volt h-13 w-full py-3.5 text-base" onClick={onQuickLog}>
          <Plus size={18} strokeWidth={3} /> Log a lift
        </button>
      </Reveal>

      {/* Overall class */}
      <Reveal>
        <div
          className="card p-5 text-center"
          style={{ boxShadow: `0 20px 60px -34px ${strength.level.color}` }}
        >
          <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
            Overall strength class
          </p>
          <p
            className="font-display mt-2 text-[44px] uppercase leading-none tracking-wide"
            style={{ color: strength.level.color }}
          >
            {strength.level.name}
          </p>
          <p className="mt-1.5 text-[12px] text-[var(--muted)]">{strength.level.blurb}</p>
          <div className="mt-3 flex items-center justify-center gap-1.5">
            {LEVELS.map((l, i) => (
              <span
                key={l.id}
                className="h-1.5 flex-1 rounded-full transition-all"
                style={{
                  background: i <= Math.round(strength.score) ? strength.level.color : "rgba(255,255,255,0.08)",
                  maxWidth: 48,
                }}
              />
            ))}
          </div>
          <p className="tabular mt-2.5 text-[11px] text-[var(--muted)]">
            {strength.tested.length > 0
              ? `Based on ${strength.tested.length} tested lift${strength.tested.length > 1 ? "s" : ""} at ${wOut(bodyweight, sys)} ${wUnit(sys)} bodyweight`
              : "Log weighted sets to get rated"}
          </p>
        </div>
      </Reveal>

      {/* Strongest / weakest */}
      {strength.strongest && strength.weakest && strength.strongest.lift.id !== strength.weakest.lift.id && (
        <Reveal>
          <div className="grid grid-cols-2 gap-3">
            <div className="card p-4">
              <p className="text-[9px] font-bold uppercase tracking-[0.18em] text-[var(--volt)]">
                Strongest
              </p>
              <p className="mt-1 text-sm font-extrabold">{strength.strongest.lift.name}</p>
              <p className="tabular text-[11px] text-[var(--muted)]">
                {strength.strongest.ratio}× bodyweight
              </p>
            </div>
            <div className="card p-4">
              <p className="text-[9px] font-bold uppercase tracking-[0.18em] text-[var(--ember)]">
                Focus next
              </p>
              <p className="mt-1 text-sm font-extrabold">{strength.weakest.lift.name}</p>
              <p className="tabular text-[11px] text-[var(--muted)]">
                {strength.weakest.ratio}× bodyweight
              </p>
            </div>
          </div>
        </Reveal>
      )}

      {/* Per-lift ratings */}
      <Reveal>
        <div className="card p-5">
          <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
            Lift standards
          </p>
          <div className="flex flex-col gap-3.5">
            {strength.ratings.map((r) => (
              <button
                key={r.lift.id}
                className="w-full text-left"
                onClick={() => onEditLift(r.lift)}
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-base">{r.lift.icon}</span>
                  <span className="flex-1 text-[13px] font-bold">
                    {r.lift.name}
                    {r.tested && <Pencil size={10} className="ml-1.5 inline text-[var(--muted)]" />}
                  </span>
                  {r.tested ? (
                    <>
                      <span className="tabular text-[11px] font-semibold text-[var(--muted)]">
                        {wOut(r.best1rm, sys)} {wUnit(sys)} · {r.ratio}×
                      </span>
                      <span
                        className="rounded-full px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider"
                        style={{ background: `${r.level.color}22`, color: r.level.color }}
                      >
                        {r.level.name}
                      </span>
                    </>
                  ) : (
                    <span className="text-[10px] font-semibold text-[var(--muted)]">Not tested</span>
                  )}
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{
                      width: `${((r.levelIndex + r.progress) / LEVELS.length) * 100}%`,
                      background: r.level.color,
                    }}
                  />
                </div>
                {r.tested && r.next && (
                  <p className="tabular mt-1 text-[10px] text-[var(--muted)]">
                    +{wOut(r.toNextKg, sys)} {wUnit(sys)} to {r.next.name}
                  </p>
                )}
              </button>
            ))}
          </div>
          <p className="mt-3 border-t border-[var(--line)] pt-3 text-[10px] leading-relaxed text-[var(--muted)]">
            Ratings use your best estimated 1RM ÷ bodyweight. Tap any lift to review, correct or
            delete the sets behind it.
          </p>
        </div>
      </Reveal>

      {plateaus.length > 0 && (
        <Reveal>
          <div className="card p-5" style={{ borderColor: "rgba(255,122,47,0.3)" }}>
            <div className="mb-3 flex items-center justify-between">
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
                Plateau breaker
              </p>
              <span className="text-[10px] font-bold text-[var(--ember)]">
                {plateaus.length} stall{plateaus.length > 1 ? "s" : ""} detected
              </span>
            </div>
            <div className="flex flex-col gap-2.5">
              {plateaus.map((pl) => (
                <div key={pl.exerciseId} className="card-2 p-3.5">
                  <div className="flex items-baseline justify-between gap-2">
                    <p className="text-[13px] font-bold">{pl.name}</p>
                    <span className="tabular shrink-0 text-[11px] font-bold text-[var(--muted)]">
                      {wOut(pl.bestKg, sys)} {wUnit(sys)} · {pl.stuckSessions} sessions stuck
                    </span>
                  </div>
                  <p className="mt-1.5 text-[11px] leading-snug text-[var(--ember)]">
                    {pl.suggestion}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      )}

      {/* Bodyweight feats */}
      <Reveal>
        <div className="card p-5">
          <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
            Bodyweight benchmarks
          </p>
          <div className="flex flex-col gap-3.5">
            {feats.map((f) => (
              <div key={f.feat.id}>
                <div className="flex items-center gap-2.5">
                  <span className="text-base">{f.feat.icon}</span>
                  <span className="flex-1 text-[13px] font-bold">{f.feat.name}</span>
                  {f.tested ? (
                    <>
                      <span className="tabular text-[11px] font-semibold text-[var(--muted)]">
                        {f.best}
                        {f.feat.unit === "sec" ? "s" : " reps"}
                      </span>
                      <span
                        className="rounded-full px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider"
                        style={{ background: `${f.level.color}22`, color: f.level.color }}
                      >
                        {f.level.name}
                      </span>
                    </>
                  ) : (
                    <span className="text-[10px] font-semibold text-[var(--muted)]">Not tested</span>
                  )}
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{
                      width: `${((f.levelIndex + f.progress) / LEVELS.length) * 100}%`,
                      background: f.level.color,
                    }}
                  />
                </div>
                {f.tested && f.next && (
                  <p className="tabular mt-1 text-[10px] text-[var(--muted)]">
                    +{f.toNext}
                    {f.feat.unit === "sec" ? "s" : " reps"} to {f.next.name}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      {/* Skill class */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Skill class
            </p>
            <span
              className="rounded-full px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider"
              style={{ background: `${skills.level.color}22`, color: skills.level.color }}
            >
              {skills.level.name}
            </span>
          </div>
          <p className="tabular mb-3 text-[12px] text-[var(--muted)]">
            <span className="font-bold text-[var(--text)]">{skills.stagesDone}</span> /
            {skills.stagesTotal} stages · {skills.mastered} skill
            {skills.mastered === 1 ? "" : "s"} mastered
          </p>
          <div className="flex flex-col gap-2">
            {skills.perSkill.map((s) => (
              <div key={s.id} className="flex items-center gap-2.5">
                <span className="w-5 text-sm">{s.icon}</span>
                <span className="w-28 shrink-0 truncate text-[11px] font-semibold">{s.name}</span>
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/[0.07]">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${(s.done / s.total) * 100}%`, background: s.color }}
                  />
                </div>
                <span className="tabular w-8 text-right text-[10px] font-bold text-[var(--muted)]">
                  {s.done}/{s.total}
                </span>
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      {/* Level legend */}
      <Reveal>
        <div className="card p-5">
          <p className="mb-2.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
            The ladder
          </p>
          <div className="flex flex-col gap-1.5">
            {LEVELS.map((l) => (
              <div key={l.id} className="flex items-center gap-2.5">
                <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: l.color }} />
                <span className="w-24 shrink-0 text-[12px] font-bold" style={{ color: l.color }}>
                  {l.name}
                </span>
                <span className="text-[11px] text-[var(--muted)]">{l.blurb}</span>
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      <p className="pb-2 text-center text-[10px] leading-relaxed text-[var(--muted)]">
        Standards adapt to your bodyweight and profile —
        <br />
        get stronger or lighter and your class climbs.
      </p>
    </>
  );
}

/* --------------------- Lift history: edit & delete --------------------- */

function LiftHistorySheet({ lift, onClose }: { lift: LiftDef | null; onClose: () => void }) {
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const logs = useStore((s) => s.logs);
  const editLoggedSet = useStore((s) => s.editLoggedSet);
  const deleteLoggedSet = useStore((s) => s.deleteLoggedSet);
  const clearExerciseHistory = useStore((s) => s.clearExerciseHistory);
  const profile = useStore((s) => s.profile);
  const weights = useStore((s) => s.weights);
  const [confirmClear, setConfirmClear] = useState(false);

  const bodyweight = weights[0]?.kg ?? profile?.weightKg ?? 70;

  // every recorded set for the exercises behind this lift, newest first
  const entries = useMemo(() => {
    if (!lift) return [];
    const rows: {
      logId: string;
      date: string;
      exerciseId: string;
      name: string;
      setIdx: number;
      kg: number;
      reps: number;
      mode: "external" | "added";
      e1rm: number;
    }[] = [];
    for (const l of logs) {
      for (const d of l.detail ?? []) {
        if (!lift.matches.includes(d.exerciseId)) continue;
        d.sets.forEach((st, i) => {
          if (!st.done || !st.reps) return;
          const load = setLoad(st, bodyweight);
          rows.push({
            logId: l.id,
            date: l.date,
            exerciseId: d.exerciseId,
            name: d.name,
            setIdx: i,
            kg: st.kg ?? 0,
            reps: st.reps,
            mode: st.mode === "added" ? "added" : "external",
            e1rm: Math.round(e1rm(load, st.reps)),
          });
        });
      }
    }
    return rows.sort((a, b) => b.e1rm - a.e1rm);
  }, [logs, lift, bodyweight]);

  // One point per session: the best estimated 1RM that day, in display units.
  const chart = useMemo(() => {
    const byDate = new Map<string, number>();
    for (const e of entries) {
      byDate.set(e.date, Math.max(byDate.get(e.date) ?? 0, e.e1rm));
    }
    return [...byDate.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, v]) => ({
        label: new Date(date + "T00:00").toLocaleDateString(undefined, {
          day: "numeric",
          month: "short",
        }),
        value: Math.round(wOut(v, sys) * 10) / 10,
      }));
  }, [entries, sys]);

  if (!lift) return null;
  const best = entries[0];

  return (
    <Sheet open onClose={onClose} title={lift.name}>
      <div className="flex flex-col gap-4">
        {entries.length === 0 ? (
          <p className="py-4 text-center text-[12px] leading-relaxed text-[var(--muted)]">
            No sets recorded for this lift yet. Use <b>Log a lift</b> or enter weights during a
            workout.
          </p>
        ) : (
          <>
            {chart.length >= 2 && (
              <div className="card-2 p-3.5">
                <p className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.16em] text-[var(--muted)]">
                  Est. 1RM trend ({wUnit(sys)})
                </p>
                <LineChart points={chart} />
                <p className="mt-1.5 text-[10px] text-[var(--muted)]">
                  {chart.length} session{chart.length > 1 ? "s" : ""} · best lifts pull this line up
                </p>
              </div>
            )}
            <div className="card-2 p-4 text-center">
              <p className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">
                Current best — drives your rating
              </p>
              <p className="tabular font-display mt-1 text-3xl text-[var(--volt)]">
                {wOut(best.e1rm, sys)} {wUnit(sys)}
              </p>
              <p className="tabular mt-1 text-[11px] text-[var(--muted)]">
                from {best.mode === "added" ? "+" : ""}
                {best.mode === "added" ? "+" : ""}{wOut(best.kg, sys)} {wUnit(sys)} × {best.reps} on{" "}
                {new Date(best.date + "T00:00").toLocaleDateString(undefined, {
                  day: "numeric",
                  month: "short",
                })}
              </p>
            </div>

            <p className="text-[11px] leading-relaxed text-[var(--muted)]">
              Your rating always uses your <b>heaviest</b> set, so a mistyped entry sticks until you
              fix it here. Edit the numbers or delete the set — everything recalculates instantly.
            </p>

            <div className="flex flex-col gap-2">
              {entries.map((e) => (
                <div
                  key={`${e.logId}-${e.exerciseId}-${e.setIdx}`}
                  className={`card-2 p-3 ${e === best ? "ring-1 ring-[var(--volt)]" : ""}`}
                >
                  <div className="mb-2 flex items-center gap-2">
                    <span className="min-w-0 flex-1 truncate text-[12px] font-bold">
                      {e.name}
                      {e === best && (
                        <span className="ml-1.5 rounded-full bg-[rgba(205,248,63,0.15)] px-1.5 py-0.5 text-[9px] font-extrabold uppercase text-[var(--volt)]">
                          best
                        </span>
                      )}
                    </span>
                    <span className="tabular text-[10px] text-[var(--muted)]">
                      {new Date(e.date + "T00:00").toLocaleDateString(undefined, {
                        day: "numeric",
                        month: "short",
                      })}
                    </span>
                    <button
                      className="shrink-0 text-[var(--muted)] active:text-[var(--red)]"
                      onClick={() => deleteLoggedSet(e.logId, e.exerciseId, e.setIdx)}
                      aria-label="Delete this set"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <div className="flex items-end gap-2">
                    <div className="flex-1">
                      <label className="mb-1 block text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                        {e.mode === "added" ? "+" : ""}{wUnit(sys)}
                      </label>
                      <input
                        className="field !px-2 !py-1.5 text-center text-sm"
                        type="number"
                        inputMode="decimal"
                        step={sys === "metric" ? 2.5 : 5}
                        value={wOut(e.kg, sys)}
                        onChange={(ev) =>
                          editLoggedSet(e.logId, e.exerciseId, e.setIdx, {
                            kg: wIn(Number(ev.target.value), sys),
                          })
                        }
                      />
                    </div>
                    <div className="flex-1">
                      <label className="mb-1 block text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                        reps
                      </label>
                      <input
                        className="field !px-2 !py-1.5 text-center text-sm"
                        type="number"
                        inputMode="numeric"
                        value={e.reps}
                        onChange={(ev) =>
                          editLoggedSet(e.logId, e.exerciseId, e.setIdx, {
                            reps: Number(ev.target.value),
                          })
                        }
                      />
                    </div>
                    <div className="flex-1 text-center">
                      <p className="mb-1 text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                        1RM
                      </p>
                      <p className="tabular py-1.5 text-sm font-extrabold text-[var(--volt)]">
                        {wOut(e.e1rm, sys)}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {confirmClear ? (
              <div className="grid grid-cols-2 gap-3">
                <button className="btn btn-ghost h-11 text-sm" onClick={() => setConfirmClear(false)}>
                  Cancel
                </button>
                <button
                  className="btn btn-danger h-11 text-sm"
                  onClick={() => {
                    lift.matches.forEach((id) => clearExerciseHistory(id));
                    setConfirmClear(false);
                    onClose();
                  }}
                >
                  Delete all
                </button>
              </div>
            ) : (
              <button
                className="btn btn-danger h-11 w-full text-sm"
                onClick={() => setConfirmClear(true)}
              >
                <Trash2 size={14} /> Clear all {lift.name} history
              </button>
            )}
          </>
        )}

        <button className="btn btn-volt h-12 w-full" onClick={onClose}>
          <Check size={16} strokeWidth={3} /> Done
        </button>
      </div>
    </Sheet>
  );
}
