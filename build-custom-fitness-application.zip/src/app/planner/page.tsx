"use client";

import {
  ArrowLeft,
  ArrowRight,
  BedDouble,
  CalendarPlus,
  Check,
  ChevronDown,
  ChevronUp,
  Dumbbell,
  Link2,
  Pencil,
  Plus,
  Search,
  Timer,
  Trash2,
  Unlink,
  X,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useT } from "@/lib/i18n";
import { useMemo, useState } from "react";
import { PaywallSheet, ProBadge, useAccess } from "@/components/paywall";
import { Chip, Empty, Reveal, Segmented, Sheet, Stepper } from "@/components/ui";
import { FREE_LIMITS } from "@/lib/billing";
import { EQUIPMENT, EquipmentId, Exercise, EXERCISES, MUSCLES, MUSCLE_LABEL, Muscle } from "@/lib/data";
import { doableWith, findSubstitute, missingGear } from "@/lib/substitute";
import {
  displayDate,
  generateWorkout,
  PlannedItem,
  totalSets,
  uid,
  weekDates,
} from "@/lib/engine";
import { rampStateOf, trainingStatusOf } from "@/lib/readiness-profile";
import { SPLITS, SplitTemplate, WEEKDAY_LABELS } from "@/lib/splits";
import { Routine, useStore } from "@/lib/store";

export default function PlannerPage() {
  const t = useT();
  const router = useRouter();
  const routines = useStore((s) => s.routines);
  const schedule = useStore((s) => s.schedule);
  const assignDay = useStore((s) => s.assignDay);
  const upsertRoutine = useStore((s) => s.upsertRoutine);
  const deleteRoutine = useStore((s) => s.deleteRoutine);
  const logs = useStore((s) => s.logs);
  const customExercises = useStore((s) => s.customExercises);
  const equipment = useStore((s) => s.equipment);
  const profile = useStore((s) => s.profile);
  const assignDayRaw = useStore((s) => s.assignDay);

  const [weekOffset, setWeekOffset] = useState(0);
  const [daySheet, setDaySheet] = useState<string | null>(null);
  const [editor, setEditor] = useState<Routine | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [split, setSplit] = useState<SplitTemplate | null>(null);
  const trainingStatus = trainingStatusOf(profile?.lastWorkoutGap);
  const ramp = rampStateOf(trainingStatus, logs.length);

  // Only recommend splits the user's inventory can actually support.
  const available = new Set(equipment);
  const splitFits = (sp: SplitTemplate) =>
    (sp.requires ?? []).every((r) => available.has(r));
  const splitGear = (sp: SplitTemplate) =>
    (sp.requires ?? [])
      .map((r) => EQUIPMENT.find((e) => e.id === r)?.label ?? r)
      .join(", ");
  const recSplit = SPLITS.find((s) => s.id === trainingStatus.splitId);
  const effectiveRecId =
    recSplit && splitFits(recSplit) ? recSplit.id : (SPLITS.find(splitFits)?.id ?? null);
  // Doable splits first (the recommendation leading), gear-blocked ones last.
  const orderedSplits = [...SPLITS].sort((a, b) => {
    const fa = splitFits(a) ? 0 : 1;
    const fb = splitFits(b) ? 0 : 1;
    if (fa !== fb) return fa - fb;
    const ra = a.id === effectiveRecId ? 0 : 1;
    const rb = b.id === effectiveRecId ? 0 : 1;
    return ra - rb;
  });
  const [payOpen, setPayOpen] = useState(false);
  const access = useAccess();
  const atRoutineLimit = !access.isPro && routines.length >= FREE_LIMITS.routines;
  const [appliedMsg, setAppliedMsg] = useState<string | null>(null);

  /** Creates routines per day-type (reusing same-named ones) and assigns the week. */
  const applySplit = (tpl: SplitTemplate, offset: number) => {
    const days = weekDates(offset);
    let created = 0;
    let reused = 0;
    days.forEach((d, i) => {
      const day = tpl.days[i];
      if (!day) {
        assignDayRaw(d.key, "rest");
        return;
      }
      let routine = routines.find((r) => r.name === day.label);
      if (!routine) {
        const gen = generateWorkout(
          {
            equipment,
            muscles: day.muscles,
            minutes: tpl.minutes,
            level: 2,
            custom: customExercises,
          },
          Math.floor(Math.random() * 999999),
          profile?.weightKg ?? 70
        );
        routine = {
          id: uid(),
          name: day.label,
          createdAt: new Date().toISOString(),
          items: gen.items.map((it) => ({
            exerciseId: it.ex.id,
            sets: it.sets,
            reps: it.reps,
            sec: it.sec,
            rest: it.rest,
          })),
        };
        upsertRoutine(routine);
        created += 1;
      } else {
        reused += 1;
      }
      assignDayRaw(d.key, routine.id);
    });
    const weekLabel = offset === 0 ? "this week" : offset === 1 ? "next week" : "that week";
    setAppliedMsg(
      `${tpl.name} applied to ${weekLabel} · ${created} new routine${created === 1 ? "" : "s"}` +
        (reused ? ` · ${reused} reused` : "")
    );
    setWeekOffset(offset);
    setSplit(null);
  };

  const week = weekDates(weekOffset);
  const routineById = useMemo(() => new Map(routines.map((r) => [r.id, r])), [routines]);
  const loggedDays = useMemo(() => new Set(logs.map((l) => l.date)), [logs]);
  const allEx = useMemo(() => [...customExercises, ...EXERCISES], [customExercises]);

  const openEditor = (r?: Routine) =>
    setEditor(
      r
        ? { ...r, items: r.items.map((i) => ({ ...i })) }
        : { id: uid(), name: "", items: [], createdAt: new Date().toISOString() }
    );

  const dayAssignment = daySheet ? schedule[daySheet] : undefined;
  const dayRoutine =
    dayAssignment && dayAssignment !== "rest" ? routineById.get(dayAssignment) : null;

  return (
    <div className="flex flex-col gap-4">
      <Reveal>
        <div className="pt-1">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--aqua)]">{t("pg.plannerEyebrow")}
          </p>
          <h1 className="font-display mt-1 text-[32px] uppercase leading-none tracking-wide">{t("pg.plannerTitle")}
          </h1>
        </div>
      </Reveal>

      {/* Week strip */}
      <Reveal>
        <div className="card p-4">
          <div className="mb-3 flex items-center justify-between">
            <button
              className="grid h-8 w-8 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-2)]"
              onClick={() => setWeekOffset((o) => o - 1)}
              aria-label="Previous week"
            >
              <ArrowLeft size={14} />
            </button>
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-[var(--muted)]">
              {weekOffset === 0
                ? "This week"
                : weekOffset === 1
                  ? "Next week"
                  : `${week[0].date.toLocaleDateString(undefined, { month: "short", day: "numeric" })} – ${week[6].date.toLocaleDateString(undefined, { month: "short", day: "numeric" })}`}
            </p>
            <button
              className="grid h-8 w-8 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-2)]"
              onClick={() => setWeekOffset((o) => o + 1)}
              aria-label="Next week"
            >
              <ArrowRight size={14} />
            </button>
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {week.map((d) => {
              const a = schedule[d.key];
              const r = a && a !== "rest" ? routineById.get(a) : null;
              const done = loggedDays.has(d.key);
              return (
                <button
                  key={d.key}
                  onClick={() => setDaySheet(d.key)}
                  className={`flex flex-col items-center gap-1 rounded-2xl border px-1 py-2.5 transition-all ${
                    d.isToday
                      ? "border-[var(--volt)] bg-[rgba(205,248,63,0.07)]"
                      : "border-[var(--line)] bg-[var(--surface-2)]"
                  }`}
                >
                  <span className="text-[9px] font-bold uppercase text-[var(--muted)]">{d.dow}</span>
                  <span
                    className={`tabular text-sm font-extrabold ${d.isToday ? "text-[var(--volt)]" : ""}`}
                  >
                    {d.num}
                  </span>
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${
                      done
                        ? "bg-[var(--volt)]"
                        : a === "rest"
                          ? "bg-[var(--ember)]"
                          : r
                            ? "bg-[var(--aqua)]"
                            : "bg-white/10"
                    }`}
                  />
                  <span className="w-full truncate text-center text-[8px] font-semibold uppercase tracking-wide text-[var(--muted)]">
                    {done ? "done" : a === "rest" ? "rest" : r ? r.name.split(" ")[0] : "—"}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="mt-3 flex items-center gap-4 text-[10px] font-semibold text-[var(--muted)]">
            <span className="flex items-center gap-1.5">
              <span className="dot bg-[var(--volt)]" /> Done
            </span>
            <span className="flex items-center gap-1.5">
              <span className="dot bg-[var(--aqua)]" /> Planned
            </span>
            <span className="flex items-center gap-1.5">
              <span className="dot bg-[var(--ember)]" /> Rest
            </span>
          </div>
        </div>
      </Reveal>

      {/* Applied banner */}
      {appliedMsg && (
        <div className="anim-fade-up flex items-center gap-2.5 rounded-2xl border border-[rgba(205,248,63,0.3)] bg-[rgba(205,248,63,0.06)] px-4 py-3">
          <Check size={15} className="shrink-0 text-[var(--volt)]" strokeWidth={3} />
          <p className="flex-1 text-[12px] font-semibold leading-snug text-[var(--text)]">{appliedMsg}</p>
          <button
            className="text-[var(--muted)]"
            onClick={() => setAppliedMsg(null)}
            aria-label="Dismiss"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Split templates rail */}
      <Reveal delay={30}>
        <section>
          <div className="mb-2 flex items-baseline justify-between">
            <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Weekly splits — plan in one tap {!access.isPro && <ProBadge />}
            </p>
            <span className="text-[10px] font-semibold text-[var(--muted)]">
              {ramp.active ? `${trainingStatus.weeklySessions}×/week suggested` : "Full training"}
            </span>
          </div>
          <div className="no-scrollbar -mx-4 flex gap-2.5 overflow-x-auto px-4 pb-1">
            {orderedSplits.map((s) => (
              <button
                key={s.id}
                onClick={() => (access.isPro ? setSplit(s) : setPayOpen(true))}
                className="card shrink-0 p-3.5 text-left transition-all active:scale-[0.97]"
                style={{ width: 168 }}
              >
                <div className="flex items-start justify-between gap-1">
                  <p className="font-display text-[17px] uppercase leading-tight tracking-wide">
                    {s.name}
                  </p>
                  {s.id === effectiveRecId ? (
                    <span className="shrink-0 rounded-full bg-[var(--volt)] px-1.5 py-0.5 text-[8px] font-extrabold uppercase tracking-wider text-[#0b0c0e]">
                      For you
                    </span>
                  ) : !splitFits(s) ? (
                    <span className="shrink-0 rounded-full bg-[rgba(255,199,64,0.15)] px-1.5 py-0.5 text-[8px] font-extrabold uppercase tracking-wider text-[#ffc740]">
                      Needs {splitGear(s)}
                    </span>
                  ) : null}
                </div>
                <p className="mt-1 line-clamp-2 h-8 text-[10px] leading-snug text-[var(--muted)]">
                  {s.blurb}
                </p>
                <div className="mt-2 flex gap-1">
                  {s.days.map((d, i) => (
                    <span
                      key={i}
                      className={`h-5 flex-1 rounded-[3px] ${
                        d ? "bg-[var(--volt)]" : "bg-white/[0.07]"
                      }`}
                    />
                  ))}
                </div>
                <p className="mt-1.5 text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                  {s.days.filter(Boolean).length} sessions · {s.minutes} min
                </p>
              </button>
            ))}
          </div>
        </section>
      </Reveal>

      {/* Routines */}
      <Reveal delay={50}>
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
            My routines
          </p>
          <button
            className="chip chip-on !px-3 !py-1.5 text-[11px] font-bold"
            onClick={() => (atRoutineLimit ? setPayOpen(true) : openEditor())}
          >
            <Plus size={13} strokeWidth={3} /> New
          </button>
        </div>
      </Reveal>

      {routines.length === 0 ? (
        <Reveal delay={80}>
          <Empty
            icon={Dumbbell}
            title="No routines yet"
            body="Build one by hand or let the generator compose it from your equipment."
          >
            <button className="btn btn-volt h-11 px-5 text-sm" onClick={() => router.push("/generator")}>
              Open generator
            </button>
          </Empty>
        </Reveal>
      ) : (
        <div className="flex flex-col gap-3">
          {routines.map((r, i) => (
            <Reveal key={r.id} delay={i * 50}>
              <div className="card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-[15px] font-extrabold">{r.name}</p>
                    <p className="mt-0.5 text-[11px] text-[var(--muted)]">
                      {r.items.length} moves · {totalSets(r.items)} sets
                    </p>
                  </div>
                  <div className="flex gap-1.5">
                    <button
                      className="grid h-8 w-8 place-items-center rounded-full bg-[var(--surface-2)] text-[var(--muted)]"
                      onClick={() => openEditor(r)}
                      aria-label="Edit routine"
                    >
                      <Pencil size={13} />
                    </button>
                    <button
                      className="grid h-8 w-8 place-items-center rounded-full bg-[var(--surface-2)] text-[var(--muted)]"
                      onClick={() => setConfirmDelete(r.id)}
                      aria-label="Delete routine"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {r.items.slice(0, 6).map((it, j) => {
                    const ex = allEx.find((e) => e.id === it.exerciseId);
                    return (
                      <span
                        key={j}
                        className="rounded-full bg-white/[0.06] px-2.5 py-1 text-[10px] font-semibold text-[var(--muted)]"
                      >
                        {ex?.name ?? it.exerciseId}
                      </span>
                    );
                  })}
                  {r.items.length > 6 && (
                    <span className="rounded-full bg-white/[0.06] px-2.5 py-1 text-[10px] font-semibold text-[var(--muted)]">
                      +{r.items.length - 6} more
                    </span>
                  )}
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      )}

      {/* Assign day sheet */}
      <Sheet
        open={daySheet !== null}
        onClose={() => setDaySheet(null)}
        title={daySheet ? displayDate(daySheet) : "Plan day"}
      >
        <div className="flex flex-col gap-2">
          {dayRoutine && (
            <div className="card-2 mb-2 flex items-center gap-2.5 p-3">
              <Check size={15} className="text-[var(--volt)]" />
              <p className="text-sm font-semibold">Currently: {dayRoutine.name}</p>
            </div>
          )}
          {routines.map((r) => (
            <button
              key={r.id}
              className={`btn h-12 justify-start gap-3 px-4 text-left text-sm ${
                dayAssignment === r.id ? "btn-volt" : "btn-ghost"
              }`}
              onClick={() => {
                if (daySheet) assignDay(daySheet, r.id);
                setDaySheet(null);
              }}
            >
              <Dumbbell size={16} />
              <span className="min-w-0 flex-1 truncate">{r.name}</span>
              <span className="tabular text-[11px] opacity-70">{r.items.length} moves</span>
            </button>
          ))}
          <button
            className={`btn h-12 justify-start gap-3 px-4 text-left text-sm ${
              dayAssignment === "rest" ? "btn-volt" : "btn-ghost"
            }`}
            onClick={() => {
              if (daySheet) assignDay(daySheet, "rest");
              setDaySheet(null);
            }}
          >
            <BedDouble size={16} /> Rest day
          </button>
          <button
            className="btn btn-ghost h-12 justify-start gap-3 px-4 text-sm"
            onClick={() => {
              setDaySheet(null);
              router.push("/generator");
            }}
          >
            <Plus size={16} /> Generate a fresh session
          </button>
          {dayAssignment && (
            <button
              className="btn btn-danger h-11 text-sm"
              onClick={() => {
                if (daySheet) assignDay(daySheet, null);
                setDaySheet(null);
              }}
            >
              Clear this day
            </button>
          )}
          {routines.length === 0 && (
            <p className="py-2 text-center text-[12px] text-[var(--muted)]">
              Create a routine below or generate one first.
            </p>
          )}
        </div>
      </Sheet>

      {/* Routine editor (mounted only while editing so local state stays clean) */}
      {editor && (
        <RoutineEditor
          key={editor.id + editor.createdAt}
          routine={editor}
          onClose={() => setEditor(null)}
          onSave={(r) => {
            upsertRoutine(r);
            setEditor(null);
          }}
        />
      )}

      {!access.isPro && (
        <p className="-mt-1 text-center text-[10px] text-[var(--muted)]">
          Free plan: {routines.length}/{FREE_LIMITS.routines} routines saved
        </p>
      )}

      <PaywallSheet open={payOpen} onClose={() => setPayOpen(false)} feature={atRoutineLimit ? "unlimitedRoutines" : "splits"} />

      {/* Split preview sheet */}
      <Sheet open={split !== null} onClose={() => setSplit(null)} title={split?.name ?? "Split"}>
        {split && (
          <div className="flex flex-col gap-4">
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">
              {split.blurb}. Each day gets a fresh session built from your equipment and routine
              library — rest days stay free. Applying replaces the target week&apos;s plan.
            </p>

            {!splitFits(split) &&
              (() => {
                const alt = SPLITS.find((x) => x.id !== split.id && splitFits(x));
                return (
                  <div className="rounded-2xl border border-[rgba(255,199,64,0.35)] bg-[rgba(255,199,64,0.05)] p-3.5">
                    <p className="text-[12px] font-bold text-[#ffc740]">
                      Missing gear: {splitGear(split)}
                    </p>
                    <p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">
                      This split is built around that equipment. Applying it would substitute
                      equivalent conditioning from the gear you do own.
                    </p>
                    {alt && (
                      <button
                        className="btn btn-ghost mt-2.5 h-9 w-full text-[12px]"
                        onClick={() => setSplit(alt)}
                      >
                        Try {alt.name} instead — fits your gear
                      </button>
                    )}
                  </div>
                );
              })()}

            <div className="card-2 divide-y divide-[var(--line)] overflow-hidden">
              {split.days.map((d, i) => (
                <div key={i} className="flex items-center gap-3 px-4 py-2.5">
                  <span
                    className={`w-9 text-[10px] font-extrabold uppercase tracking-wider ${
                      d ? "text-[var(--volt)]" : "text-[var(--muted)]"
                    }`}
                  >
                    {WEEKDAY_LABELS[i]}
                  </span>
                  {d ? (
                    <>
                      <span className="min-w-0 flex-1 truncate text-[13px] font-bold">{d.label}</span>
                      <span className="text-[10px] uppercase tracking-wide text-[var(--muted)]">
                        {d.muscles[0] === "full" ? "all muscles" : d.muscles.join(" · ")}
                      </span>
                    </>
                  ) : (
                    <span className="flex-1 text-[13px] font-medium text-[var(--muted)]">Rest</span>
                  )}
                </div>
              ))}
            </div>

            {(() => {
              const day = split.days.find((d): d is NonNullable<typeof d> => Boolean(d));
              if (!day) return null;
              const sample = generateWorkout(
                { equipment, muscles: day.muscles, minutes: split.minutes, level: 2, custom: customExercises },
                4242,
                profile?.weightKg ?? 70
              );
              return (
                <div className="card-2 p-3.5">
                  <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[var(--muted)]">
                    Sample {day.label} — from your inventory only
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {sample.items.slice(0, 6).map((it, k) => (
                      <span
                        key={k}
                        className="rounded-full bg-[var(--surface-3)] px-2.5 py-1 text-[10px] font-semibold"
                      >
                        {it.ex.name}
                      </span>
                    ))}
                    {sample.items.length > 6 && (
                      <span className="rounded-full bg-white/[0.06] px-2.5 py-1 text-[10px] font-semibold text-[var(--muted)]">
                        +{sample.items.length - 6} more
                      </span>
                    )}
                  </div>
                  <p className="mt-2 text-[10px] leading-relaxed text-[var(--muted)]">
                    Every move above is doable with the equipment you own — nothing here needs gear
                    you don&apos;t have.
                  </p>
                </div>
              );
            })()}

            <div className="grid grid-cols-2 gap-3">
              <button className="btn btn-volt h-12 text-sm" onClick={() => applySplit(split, 0)}>
                <CalendarPlus size={16} /> This week
              </button>
              <button className="btn btn-ghost h-12 text-sm" onClick={() => applySplit(split, 1)}>
                Next week
              </button>
            </div>
            <p className="-mt-1 text-center text-[10px] text-[var(--muted)]">
              {split.days.filter(Boolean).length} sessions · ~{split.minutes} min per session
            </p>
          </div>
        )}
      </Sheet>

      {/* Delete confirm */}
      <Sheet
        open={confirmDelete !== null}
        onClose={() => setConfirmDelete(null)}
        title="Delete routine?"
      >
        <p className="text-sm text-[var(--muted)]">
          It will also be removed from any scheduled days. This cannot be undone.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button className="btn btn-ghost h-12" onClick={() => setConfirmDelete(null)}>
            Keep it
          </button>
          <button
            className="btn btn-danger h-12"
            onClick={() => {
              if (confirmDelete) deleteRoutine(confirmDelete);
              setConfirmDelete(null);
            }}
          >
            Delete
          </button>
        </div>
      </Sheet>
    </div>
  );
}

/* ------------------------- Routine editor sheet ------------------------- */

function RoutineEditor({
  routine,
  onClose,
  onSave,
}: {
  routine: Routine;
  onClose: () => void;
  onSave: (r: Routine) => void;
}) {
  const [r, setR] = useState<Routine>(routine);
  const [query, setQuery] = useState("");
  const [muscle, setMuscle] = useState<Muscle | "any">("any");
  const [pickerOpen, setPickerOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const customExercises = useStore((s) => s.customExercises);
  const addCustomExercise = useStore((s) => s.addCustomExercise);
  const removeCustomExercise = useStore((s) => s.removeCustomExercise);
  const allEx = useMemo(() => [...customExercises, ...EXERCISES], [customExercises]);
  const equipment = useStore((s) => s.equipment);
  const available = useMemo(() => new Set(equipment), [equipment]);
  const [swapNote, setSwapNote] = useState<string | null>(null);

  const addExercise = (exerciseId: string) => {
    const ex = allEx.find((e) => e.id === exerciseId);
    if (!ex) return;
    const item: PlannedItem = {
      exerciseId,
      sets: 3,
      reps: ex.kind === "reps" ? (ex.reps ?? 12) : null,
      sec: ex.kind === "time" ? (ex.sec ?? 30) : null,
      rest: 45,
    };
    setR({ ...r, items: [...r.items, item] });
    setSwapNote(null);
  };

  /** Unavailable exercises add their best substitute instead, with a note. */
  const handlePick = (ex: Exercise) => {
    if (doableWith(ex, available)) {
      addExercise(ex.id);
      return;
    }
    const labels = missingGear(ex, available)
      .map((id) => EQUIPMENT.find((e) => e.id === id)?.label ?? id)
      .join(", ");
    const sub = findSubstitute(ex, available);
    if (sub) {
      addExercise(sub.id);
      setSwapNote(`${ex.name} needs ${labels} — added ${sub.name} instead.`);
    } else {
      setSwapNote(`${ex.name} needs ${labels}, and no alternative fits your gear.`);
    }
  };

  const move = (idx: number, dir: -1 | 1) => {
    const items = r.items.slice();
    const t = idx + dir;
    if (t < 0 || t >= items.length) return;
    const a = items[idx];
    items[idx] = items[t];
    items[t] = a;
    setR({ ...r, items });
  };

  const patchItem = (idx: number, patch: Partial<PlannedItem>) => {
    setR({ ...r, items: r.items.map((x, j) => (j === idx ? { ...x, ...patch } : x)) });
  };

  /** Pair an exercise with the next one (superset); repeat to build circuits. */
  const toggleLink = (i: number) => {
    const items = r.items.map((x) => ({ ...x }));
    const cur = items[i];
    const nxt = items[i + 1];
    if (!nxt) return;
    const linked = cur.group != null && cur.group === nxt.group;
    if (linked) {
      delete cur.group; // unlink; any remaining members keep their run intact
    } else {
      const g = cur.group ?? nxt.group ?? Math.max(0, ...items.map((x) => x.group ?? 0)) + 1;
      cur.group = g;
      nxt.group = g;
    }
    setR({ ...r, items });
  };

  const filtered = allEx
    .filter(
      (e) =>
        (muscle === "any" || e.muscles.includes(muscle)) &&
        e.name.toLowerCase().includes(query.trim().toLowerCase())
    )
    .sort(
      (a, b) => (doableWith(a, available) ? 0 : 1) - (doableWith(b, available) ? 0 : 1)
    );

  return (
    <Sheet open onClose={onClose} title={routine.name ? "Edit routine" : "New routine"}>
      <div className="flex flex-col gap-4">
        <input
          className="field font-semibold"
          placeholder="Routine name — e.g. Upper Body A"
          value={r.name}
          onChange={(e) => setR({ ...r, name: e.target.value })}
        />

        <div className="flex flex-col gap-2">
          {r.items.length === 0 && (
            <p className="rounded-xl border border-dashed border-[var(--line-strong)] p-4 text-center text-[12px] text-[var(--muted)]">
              Empty for now — add moves from the library below.
            </p>
          )}
          {r.items.map((it, i) => {
            const ex = allEx.find((e) => e.id === it.exerciseId);
            if (!ex) return null;
            const linkedPrev = i > 0 && it.group != null && r.items[i - 1].group === it.group;
            const linkedNext =
              i < r.items.length - 1 && it.group != null && r.items[i + 1].group === it.group;
            return (
              <div key={`${it.exerciseId}-${i}`} className="card-2 p-3">
                <div className="flex items-center gap-1.5">
                  <p className="tabular w-5 text-[11px] font-extrabold text-[var(--volt)]">
                    {String(i + 1).padStart(2, "0")}
                  </p>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold">{ex.name}</p>
                    {(linkedPrev || linkedNext) && (
                      <span className="mt-0.5 inline-block rounded-full bg-[rgba(92,214,255,0.14)] px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-[var(--aqua)]">
                        {linkedPrev && linkedNext ? "Circuit" : linkedNext ? "Superset →" : "← Superset"}
                      </span>
                    )}
                  </div>
                  {i < r.items.length - 1 && (
                    <button
                      className="grid h-7 w-7 place-items-center rounded-full bg-[var(--surface-3)] text-[var(--aqua)]"
                      onClick={() => toggleLink(i)}
                      aria-label="Toggle superset with next exercise"
                      title="Superset with the next move — tap again to unlink"
                    >
                      {linkedNext ? <Unlink size={13} /> : <Link2 size={13} />}
                    </button>
                  )}
                  <button
                    className="grid h-7 w-7 place-items-center rounded-full bg-[var(--surface-3)] text-[var(--muted)]"
                    onClick={() => move(i, -1)}
                    aria-label="Move up"
                  >
                    <ChevronUp size={13} />
                  </button>
                  <button
                    className="grid h-7 w-7 place-items-center rounded-full bg-[var(--surface-3)] text-[var(--muted)]"
                    onClick={() => move(i, 1)}
                    aria-label="Move down"
                  >
                    <ChevronDown size={13} />
                  </button>
                  <button
                    className="grid h-7 w-7 place-items-center rounded-full bg-[var(--surface-3)] text-[var(--muted)]"
                    onClick={() => setR({ ...r, items: r.items.filter((_, j) => j !== i) })}
                    aria-label="Remove"
                  >
                    <X size={13} />
                  </button>
                </div>
                <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-2 text-[11px] font-semibold text-[var(--muted)]">
                  <span className="flex items-center gap-1.5">
                    Sets
                    <Stepper value={it.sets} min={1} max={8} onChange={(v) => patchItem(i, { sets: v })} />
                  </span>
                  {it.reps !== null && (
                    <span className="flex items-center gap-1.5">
                      Reps
                      <Stepper value={it.reps} min={1} max={50} onChange={(v) => patchItem(i, { reps: v })} />
                    </span>
                  )}
                  {it.sec !== null && (
                    <span className="flex items-center gap-1.5">
                      <Timer size={12} />
                      <Stepper value={it.sec} min={10} max={180} step={5} onChange={(v) => patchItem(i, { sec: v })} />
                      s
                    </span>
                  )}
                  <span className="flex items-center gap-1.5">
                    Rest
                    <Stepper value={it.rest} min={15} max={180} step={15} onChange={(v) => patchItem(i, { rest: v })} />
                    s
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        <button className="btn btn-ghost h-11 w-full text-sm" onClick={() => setPickerOpen((o) => !o)}>
          <Plus size={15} /> {pickerOpen ? "Hide exercise library" : "Add exercises"}
        </button>

        {pickerOpen && (
          <div className="anim-fade-up flex flex-col gap-3">
            <div className="relative">
              <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
              <input
                className="field !py-2.5 !pl-9 text-sm"
                placeholder="Search moves…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-1">
              <Chip active={muscle === "any"} onClick={() => setMuscle("any")}>
                All
              </Chip>
              {MUSCLES.filter((m) => m.id !== "full").map((m) => (
                <Chip key={m.id} active={muscle === m.id} onClick={() => setMuscle(m.id)}>
                  {m.label}
                </Chip>
              ))}
            </div>
            <button
              className="btn btn-ghost h-10 w-full text-[12px]"
              onClick={() => setCreateOpen(true)}
            >
              <Plus size={14} /> Create your own move
            </button>
            {swapNote && (
              <p className="rounded-xl border border-[rgba(255,199,64,0.3)] bg-[rgba(255,199,64,0.06)] px-3 py-2 text-[11px] font-semibold text-[#ffc740]">
                {swapNote}
              </p>
            )}
            <div className="card-2 no-scrollbar max-h-[30dvh] divide-y divide-[var(--line)] overflow-y-auto">
              {filtered.map((e) => {
                const added = r.items.filter((i) => i.exerciseId === e.id).length;
                const ok = doableWith(e, available);
                const need = ok ? "" : missingGear(e, available).map((id) => EQUIPMENT.find((x) => x.id === id)?.label ?? id).join(", ");
                return (
                  <div key={e.id} className={`flex w-full items-center gap-2 px-3.5 py-2.5 ${ok ? "" : "opacity-70"}`}>
                    <button className="flex min-w-0 flex-1 items-center gap-3 text-left" onClick={() => handlePick(e)}>
                      <div className="min-w-0 flex-1">
                        <p className={`truncate text-[13px] font-semibold ${ok ? "" : "text-[var(--muted)]"}`}>
                          {e.name}
                          {e.custom && (
                            <span className="ml-1.5 rounded bg-[rgba(205,248,63,0.15)] px-1.5 py-0.5 text-[9px] font-bold uppercase text-[var(--volt)]">
                              mine
                            </span>
                          )}
                        </p>
                        <p className="text-[10px] uppercase tracking-wide text-[var(--muted)]">
                          {e.muscles.slice(0, 2).map((m) => MUSCLE_LABEL[m]).join(" · ")}
                          {!ok && <span className="ml-1 font-bold text-[var(--ember)]">· needs {need}</span>}
                        </p>
                      </div>
                      {added > 0 && (
                        <span className="rounded-full bg-[rgba(205,248,63,0.15)] px-2 py-0.5 text-[10px] font-bold text-[var(--volt)]">
                          ×{added}
                        </span>
                      )}
                      <Plus size={15} className="shrink-0 text-[var(--volt)]" />
                    </button>
                    {e.custom && (
                      <button
                        className="shrink-0 text-[var(--muted)] active:text-[var(--red)]"
                        onClick={() => removeCustomExercise(e.id)}
                        aria-label="Delete custom exercise"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                );
              })}
              {filtered.length === 0 && (
                <p className="px-4 py-5 text-center text-[12px] text-[var(--muted)]">
                  No moves found — create your own above.
                </p>
              )}
            </div>
          </div>
        )}

        {createOpen && (
          <CustomExerciseSheet
            onClose={() => setCreateOpen(false)}
            onCreate={(draft) => {
              const ex = addCustomExercise(draft);
              addExercise(ex.id);
              setCreateOpen(false);
            }}
          />
        )}

        <button
          className="btn btn-volt w-full py-3.5 text-base"
          onClick={() => onSave({ ...r, name: r.name.trim() || "Untitled routine" })}
        >
          <Check size={17} strokeWidth={3} /> Save routine
        </button>
      </div>
    </Sheet>
  );
}

/* ----------------------- Custom exercise creator ---------------------- */

function CustomExerciseSheet({
  onClose,
  onCreate,
}: {
  onClose: () => void;
  onCreate: (draft: Omit<Exercise, "id" | "custom">) => void;
}) {
  const [name, setName] = useState("");
  const [muscle, setMuscle] = useState<Muscle>("core");
  const [kind, setKind] = useState<"reps" | "time">("reps");
  const [target, setTarget] = useState(12);
  const [equip, setEquip] = useState<EquipmentId>("bodyweight");
  const [cue, setCue] = useState("");

  const save = () => {
    if (name.trim().length < 2) return;
    onCreate({
      name: name.trim(),
      muscles: [muscle],
      equipment: [equip],
      level: 2,
      kind,
      reps: kind === "reps" ? target : undefined,
      sec: kind === "time" ? target : undefined,
      met: 5,
      cue: cue.trim() || "Stay controlled — quality over speed.",
    });
  };

  return (
    <Sheet open onClose={onClose} title="Create a move">
      <div className="flex flex-col gap-4">
        <input
          className="field font-semibold"
          placeholder="Exercise name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <div>
          <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">Muscle</p>
          <div className="flex flex-wrap gap-2">
            {MUSCLES.filter((m) => m.id !== "full").map((m) => (
              <Chip key={m.id} active={muscle === m.id} onClick={() => setMuscle(m.id)}>
                {m.label}
              </Chip>
            ))}
          </div>
        </div>
        <div>
          <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">Tracks</p>
          <Segmented
            value={kind}
            onChange={(v) => {
              setKind(v);
              setTarget(v === "reps" ? 12 : 30);
            }}
            options={[
              { value: "reps" as const, label: "Reps" },
              { value: "time" as const, label: "Time (sec)" },
            ]}
          />
        </div>
        <div>
          <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Target {kind === "reps" ? "reps" : "seconds"}
          </p>
          <input
            className="field"
            type="number"
            inputMode="numeric"
            value={target}
            onChange={(e) => setTarget(Number(e.target.value) || 1)}
          />
        </div>
        <div>
          <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">Equipment</p>
          <div className="flex flex-wrap gap-2">
            {EQUIPMENT.map((e) => (
              <Chip key={e.id} active={equip === e.id} onClick={() => setEquip(e.id)}>
                {e.label}
              </Chip>
            ))}
          </div>
        </div>
        <input
          className="field"
          placeholder="Coaching cue (optional)"
          value={cue}
          onChange={(e) => setCue(e.target.value)}
        />
        <button className={`btn h-12 w-full ${name.trim().length >= 2 ? "btn-volt" : "btn-ghost opacity-50"}`} onClick={save}>
          <Check size={16} strokeWidth={3} /> Create & add
        </button>
      </div>
    </Sheet>
  );
}
