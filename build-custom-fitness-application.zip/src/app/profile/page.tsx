"use client";

import {
  Activity,
  ArrowLeft,
  ArrowRight,
  BellRing,
  Calculator,
  Camera,
  Crown,
  Check,
  CloudCheck,
  CloudOff,
  Download,
  Dumbbell,
  LogOut,
  Flag,
  HeartPulse,
  History,
  Images,
  Medal,
  Music,
  RefreshCw,
  Ruler,
  Scale,
  Shapes,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Smartphone,
  Target,
  Trash2,
  TrendingDown,
  TrendingUp,
  Upload,
  UserPlus,
  UserRound,
  Vibrate,
  Volume2,
  Weight,
  X,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useT } from "@/lib/i18n";
import { useEffect, useMemo, useRef, useState } from "react";
import { EquipmentPicker } from "@/components/equipment-picker";
import { AuthSheet } from "@/components/auth-sheet";
import { PaywallSheet, ProBadge, ProGate, useAccess } from "@/components/paywall";
import {
  BUNDLED_MOBILE,
  loadSession,
  logout as doLogout,
  switchAccount,
  type AuthSession,
} from "@/lib/auth";
import { hashPin } from "@/lib/lock";
import { summarize } from "@/lib/achievements";
import {
  BODY_TYPES,
  bodyTypePlan,
  type BodyType,
  rampStateOf,
  TRAINING_GAPS,
  trainingStatusOf,
  type TrainingGap,
} from "@/lib/readiness-profile";
import { Chip, Reveal, Segmented, Sheet, Stepper } from "@/components/ui";
import { EQUIPMENT } from "@/lib/data";
import { heightLabel, lIn, lOut, lUnit, type UnitSystem, wIn, wOut, wUnit } from "@/lib/units";
import {
  ACTIVITY_LEVELS,
  calcTargets,
  dateKey,
  DEFAULT_HYDRATION,
  fatCategory,
  Goal,
  navyBodyFat,
  personalRecords,
  PLATE_SIZES,
  platesFor,
  Sex,
} from "@/lib/engine";
import { addPhoto, deletePhoto, fileToDataUrl, listPhotos, ProgressPhoto } from "@/lib/photos";
import {
  chooseNativeRingtone,
  deleteCustomTone,
  isNativeAndroid,
  previewRingtone,
  saveCustomTone,
  stopRingtone,
  TONES,
  type RingtoneId,
} from "@/lib/ringtone";
import { DEFAULT_LOADOUT, syncNow, useStore } from "@/lib/store";

/* ------------------------------ Wizard ------------------------------ */

interface Draft {
  name: string;
  sex: Sex;
  age: number;
  heightCm: number;
  weightKg: number;
  activity: number;
  goal: Goal;
  lastWorkoutGap: TrainingGap;
  bodyType: BodyType;
  goalWeightKg: number;
}

const STEP_META = [
  { icon: UserRound, label: "You" },
  { icon: Ruler, label: "Body" },
  { icon: Shapes, label: "Build" },
  { icon: History, label: "History" },
  { icon: Activity, label: "Lifestyle" },
  { icon: Flag, label: "Goal" },
  { icon: Dumbbell, label: "Gear" },
  { icon: Target, label: "Targets" },
];

function NumField({
  label,
  value,
  set,
  min,
  max,
  unit,
}: {
  label: string;
  value: number;
  set: (v: number) => void;
  min: number;
  max: number;
  unit: string;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
        {label} <span className="text-[var(--volt)]">({unit})</span>
      </label>
      <input
        className="field font-display !text-2xl tracking-wide"
        type="number"
        inputMode="decimal"
        value={value}
        min={min}
        max={max}
        onChange={(e) => set(Number(e.target.value))}
      />
    </div>
  );
}

function Wizard({ onDone }: { onDone: () => void }) {
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const setUnitSystem = useStore((s) => s.setUnitSystem);
  const appLock = useStore((s) => s.appLock);
  const setAppLock = useStore((s) => s.setAppLock);
  const setAppUnlocked = useStore((s) => s.setAppUnlocked);
  const lang = useStore((s) => s.lang);
  const setLang = useStore((s) => s.setLang);
  const importSnapshot = useStore((s) => s.importSnapshot);
  const [pinInput, setPinInput] = useState("");
  const [pinMsg, setPinMsg] = useState<string | null>(null);
  const profile = useStore((s) => s.profile);
  const equipment = useStore((s) => s.equipment);
  const toggleEquipment = useStore((s) => s.toggleEquipment);
  const setProfile = useStore((s) => s.setProfile);

  const [step, setStep] = useState(0);
  const [d, setD] = useState<Draft>({
    name: profile?.name ?? "",
    sex: profile?.sex ?? "male",
    age: profile?.age ?? 25,
    heightCm: profile?.heightCm ?? 170,
    weightKg: profile?.weightKg ?? 70,
    activity: profile?.activity ?? 1.375,
    goal: profile?.goal ?? "maintain",
    lastWorkoutGap: profile?.lastWorkoutGap ?? "months3",
    bodyType: profile?.bodyType ?? "unsure",
    goalWeightKg: profile?.goalWeightKg ?? 0,
  });

  const targets = calcTargets(d);

  const canNext =
    step === 0
      ? d.name.trim().length >= 2 && d.age >= 10 && d.age <= 100
      : step === 1
        ? d.heightCm >= 120 && d.heightCm <= 230 && d.weightKg >= 30 && d.weightKg <= 250
        : true;

  const finish = () => {
    setProfile({
      ...d,
      name: d.name.trim(),
      onboarded: true,
      trainingStartedAt: profile?.trainingStartedAt ?? new Date().toISOString(),
    });
    void syncNow(true);
    onDone();
  };

  return (
    <div className="flex min-h-[70dvh] flex-col gap-5 pt-1">
      {/* Progress */}
      <div>
        <div className="flex items-center justify-between">
          <p className="font-display text-2xl uppercase tracking-wide">
            {step === 0 ? "Who are you?" : step === 7 ? "Your targets" : STEP_META[step].label}
          </p>
          <span className="tabular text-[11px] font-bold text-[var(--muted)]">
            {step + 1} / {STEP_META.length}
          </span>
        </div>
        <div className="mt-2.5 flex gap-1">
          {STEP_META.map((_, i) => (
            <span
              key={i}
              className={`h-1 flex-1 rounded-full transition-all ${i <= step ? "bg-[var(--volt)]" : "bg-white/10"}`}
            />
          ))}
        </div>
      </div>

      <div key={step} className="anim-fade-up flex flex-1 flex-col gap-4">
        {step === 0 && (
          <>
            <div>
              <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
                First name
              </label>
              <input
                className="field"
                placeholder="Your name"
                value={d.name}
                onChange={(e) => setD({ ...d, name: e.target.value })}
              />
            </div>
            <div>
              <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
                Biological sex
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(["male", "female"] as const).map((s) => (
                  <button
                    key={s}
                    className={`btn h-12 capitalize ${d.sex === s ? "btn-volt" : "btn-ghost"}`}
                    onClick={() => setD({ ...d, sex: s })}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <NumField label="Age" value={d.age} set={(v) => setD({ ...d, age: v })} min={10} max={100} unit="years" />
            <p className="text-[11px] leading-relaxed text-[var(--muted)]">
              Used with your body stats for the Mifflin–St Jeor equation — the standard for
              accurate calorie targets.
            </p>
          </>
        )}

        {step === 1 && (
          <>
            <NumField label="Height" value={lOut(d.heightCm, sys)} set={(v) => setD({ ...d, heightCm: lIn(v, sys) })} min={lOut(120, sys)} max={lOut(230, sys)} unit={lUnit(sys)} />
            <NumField label="Weight" value={wOut(d.weightKg, sys)} set={(v) => setD({ ...d, weightKg: wIn(v, sys) })} min={wOut(30, sys)} max={wOut(250, sys)} unit={wUnit(sys)} />
            <div className="card-2 flex items-center gap-3 p-4">
              <Scale size={18} className="shrink-0 text-[var(--volt)]" />
              <p className="text-[12px] leading-relaxed text-[var(--muted)]">
                BMI preview:{" "}
                <span className="tabular font-bold text-[var(--text)]">
                  {(d.weightKg / Math.pow(d.heightCm / 100, 2)).toFixed(1)}
                </span>{" "}
                — update weight anytime as you progress.
              </p>
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">
              Pick the build that sounds most like you. This is a starting tendency, not a label —
              FORGE adapts as your logged data builds up.
            </p>
            <div className="flex flex-col gap-2">
              {BODY_TYPES.map((b) => (
                <button
                  key={b.id}
                  className={`card flex items-center gap-3 p-4 text-left transition-all ${
                    d.bodyType === b.id ? "border-[var(--volt)] bg-[rgba(205,248,63,0.06)]" : ""
                  }`}
                  onClick={() => setD({ ...d, bodyType: b.id })}
                >
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-lg">
                    {b.icon}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold">{b.label}</p>
                    <p className="text-[11px] leading-snug text-[var(--muted)]">{b.hint}</p>
                  </div>
                  {d.bodyType === b.id && <Check size={17} className="text-[var(--volt)]" strokeWidth={3} />}
                </button>
              ))}
            </div>
            <div className="card-2 p-4">
              <p className="text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
                How this is used
              </p>
              <p className="mt-1.5 text-[12px] leading-relaxed text-[var(--muted)]">
                {bodyTypePlan(d.bodyType).training}
              </p>
              <p className="tabular mt-2 text-[11px] text-[var(--muted)]">
                Default rep range{" "}
                <b className="text-[var(--text)]">
                  {bodyTypePlan(d.bodyType).repRange[0]}–{bodyTypePlan(d.bodyType).repRange[1]}
                </b>{" "}
                · rest <b className="text-[var(--text)]">{bodyTypePlan(d.bodyType).restSec}s</b> · cardio{" "}
                <b className="text-[var(--text)]">{bodyTypePlan(d.bodyType).cardioPerWeek}×/week</b>
              </p>
            </div>
          </>
        )}

        {step === 3 && (
          <>
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">
              When did you last train properly? This sets how hard your first weeks should be, so
              you come back strong instead of injured.
            </p>
            <div className="flex flex-col gap-2">
              {TRAINING_GAPS.map((g) => (
                <button
                  key={g.id}
                  className={`card flex items-center gap-3 p-3.5 text-left transition-all ${
                    d.lastWorkoutGap === g.id ? "border-[var(--volt)] bg-[rgba(205,248,63,0.06)]" : ""
                  }`}
                  onClick={() => setD({ ...d, lastWorkoutGap: g.id })}
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-bold">{g.label}</p>
                    <p className="text-[11px] leading-snug text-[var(--muted)]">{g.hint}</p>
                  </div>
                  {d.lastWorkoutGap === g.id && (
                    <Check size={16} className="shrink-0 text-[var(--volt)]" strokeWidth={3} />
                  )}
                </button>
              ))}
            </div>
            {(() => {
              const st = trainingStatusOf(d.lastWorkoutGap);
              return (
                <div className="card-2 p-4">
                  <p className="font-display text-lg uppercase tracking-wide">{st.headline}</p>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-[var(--muted)]">
                    {st.guidance}
                  </p>
                  <div className="mt-3 grid grid-cols-3 gap-2">
                    {[
                      { l: "Start at", v: st.startLevel === 1 ? "Starter" : st.startLevel === 2 ? "Solid" : "Savage" },
                      { l: "Volume", v: `${st.startVolumePct}%` },
                      { l: "Sessions", v: `${st.weeklySessions}/wk` },
                    ].map((x) => (
                      <div key={x.l} className="rounded-xl bg-[var(--surface-3)] p-2.5 text-center">
                        <p className="text-[12px] font-extrabold">{x.v}</p>
                        <p className="text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                          {x.l}
                        </p>
                      </div>
                    ))}
                  </div>
                  {st.caution && (
                    <p className="mt-3 flex items-start gap-1.5 text-[11px] leading-relaxed text-[var(--ember)]">
                      <ShieldAlert size={13} className="mt-0.5 shrink-0" />
                      <span>{st.caution}</span>
                    </p>
                  )}
                </div>
              );
            })()}
          </>
        )}

        {step === 4 && (
          <div className="flex flex-col gap-2">
            {ACTIVITY_LEVELS.map((a) => (
              <button
                key={a.value}
                className={`card flex items-center gap-3 p-4 text-left transition-all ${
                  d.activity === a.value ? "border-[var(--volt)] bg-[rgba(205,248,63,0.06)]" : ""
                }`}
                onClick={() => setD({ ...d, activity: a.value })}
              >
                <div
                  className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${
                    d.activity === a.value ? "bg-[var(--volt)] text-[#0b0c0e]" : "bg-[var(--surface-2)] text-[var(--muted)]"
                  }`}
                >
                  <Activity size={16} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold">{a.label}</p>
                  <p className="text-[11px] text-[var(--muted)]">{a.hint}</p>
                </div>
                {d.activity === a.value && <Check size={17} className="text-[var(--volt)]" strokeWidth={3} />}
              </button>
            ))}
          </div>
        )}

        {step === 5 && (
          <div className="flex flex-col gap-2">
            {(
              [
                { id: "lose", label: "Lose fat", hint: `−500 kcal/day · ~${wOut(0.5, sys)} ${wUnit(sys)} a week`, icon: TrendingDown },
                { id: "maintain", label: "Maintain", hint: "Stay at your current weight", icon: HeartPulse },
                { id: "gain", label: "Build muscle", hint: "+300 kcal lean surplus", icon: TrendingUp },
              ] as const
            ).map((g) => (
              <button
                key={g.id}
                className={`card flex items-center gap-3 p-4 text-left transition-all ${
                  d.goal === g.id ? "border-[var(--volt)] bg-[rgba(205,248,63,0.06)]" : ""
                }`}
                onClick={() => setD({ ...d, goal: g.id })}
              >
                <div
                  className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${
                    d.goal === g.id ? "bg-[var(--volt)] text-[#0b0c0e]" : "bg-[var(--surface-2)] text-[var(--muted)]"
                  }`}
                >
                  <g.icon size={16} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold">{g.label}</p>
                  <p className="text-[11px] text-[var(--muted)]">{g.hint}</p>
                </div>
                {d.goal === g.id && <Check size={17} className="text-[var(--volt)]" strokeWidth={3} />}
              </button>
            ))}

            {d.goal !== "maintain" && (
              <div className="mt-1">
                <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
                  Goal weight ({wUnit(sys)})
                </label>
                <input
                  className="field font-display !text-2xl tracking-wide"
                  type="number"
                  inputMode="decimal"
                  value={d.goalWeightKg ? wOut(d.goalWeightKg, sys) : ""}
                  onChange={(e) =>
                    setD({ ...d, goalWeightKg: wIn(Number(e.target.value), sys) })
                  }
                  placeholder={wUnit(sys)}
                />
                <p className="mt-1.5 text-[10px] leading-relaxed text-[var(--muted)]">
                  We project the date you&apos;ll reach it from your weight trend and intake.
                </p>
              </div>
            )}
          </div>
        )}

        {step === 6 && (
          <>
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">
              Tap everything you have at home — from dumbbells to a boxing bag. The generator only
              uses what you own.
            </p>
            <EquipmentPicker compact />
          </>
        )}

        {step === 7 && (
          <div className="flex flex-col gap-4">
            <div className="card p-5 text-center">
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
                Daily calorie target
              </p>
              <p className="font-display tabular mt-2 text-6xl leading-none text-[var(--volt)]">
                {targets.calories}
              </p>
              <p className="mt-2 text-[11px] text-[var(--muted)]">
                {targets.maintenance} maintenance {targets.delta !== 0 && `· ${targets.delta > 0 ? "+" : ""}${targets.delta}`}
              </p>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { l: "Protein", v: targets.protein, c: "var(--volt)" },
                { l: "Carbs", v: targets.carbs, c: "var(--aqua)" },
                { l: "Fat", v: targets.fat, c: "var(--ember)" },
              ].map((m) => (
                <div key={m.l} className="card p-3.5 text-center">
                  <span className="dot mx-auto mb-2" style={{ background: m.c }} />
                  <p className="font-display tabular text-2xl">{m.v}g</p>
                  <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">{m.l}</p>
                </div>
              ))}
            </div>
            <div className="card-2 p-4 text-[12px] leading-relaxed text-[var(--muted)]">
              Resting <span className="tabular font-bold text-[var(--text)]">{targets.bmr} kcal</span> ·
              Mifflin–St Jeor, × {d.activity} activity, rebalanced for{" "}
              {d.goal === "lose" ? "fat loss" : d.goal === "gain" ? "muscle gain" : "maintenance"}.
            </div>
          </div>
        )}
      </div>

      {/* Nav */}
      <div className="flex gap-3">
        {step > 0 && (
          <button className="btn btn-ghost h-13 w-14 py-3.5" onClick={() => setStep((s) => s - 1)} aria-label="Back">
            <ArrowLeft size={17} />
          </button>
        )}
        <button
          className={`btn h-13 flex-1 py-3.5 text-base ${canNext ? "btn-volt" : "btn-ghost opacity-50"}`}
          onClick={() => {
            if (!canNext) return;
            if (step < STEP_META.length - 1) setStep(step + 1);
            else finish();
          }}
        >
          {step === STEP_META.length - 1 ? (
            <>
              <Check size={18} strokeWidth={3} /> Start forging
            </>
          ) : (
            <>
              Continue <ArrowRight size={17} />
            </>
          )}
        </button>
      </div>
    </div>
  );
}

/* --------------------------- Profile page --------------------------- */

export default function ProfilePage() {
  const t = useT();
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const profile = useStore((s) => s.profile);
  const equipment = useStore((s) => s.equipment);
  const toggleEquipment = useStore((s) => s.toggleEquipment);
  const syncStatus = useStore((s) => s.syncStatus);
  const lastSyncedAt = useStore((s) => s.lastSyncedAt);
  const setUnitSystem = useStore((s) => s.setUnitSystem);
  const appLock = useStore((s) => s.appLock);
  const setAppLock = useStore((s) => s.setAppLock);
  const setAppUnlocked = useStore((s) => s.setAppUnlocked);
  const [pinInput, setPinInput] = useState("");
  const [pinMsg, setPinMsg] = useState<string | null>(null);
  const lang = useStore((s) => s.lang);
  const setLang = useStore((s) => s.setLang);
  const importSnapshot = useStore((s) => s.importSnapshot);
  const resetAll = useStore((s) => s.resetAll);
  const snapshot = useStore((s) => s.snapshot);
  const logs = useStore((s) => s.logs);
  const measurements = useStore((s) => s.measurements);
  const logMeasurement = useStore((s) => s.logMeasurement);
  const reminder = useStore((s) => s.reminder);
  const setReminder = useStore((s) => s.setReminder);

  const [editing, setEditing] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [importMsg, setImportMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const importRef = useRef<HTMLInputElement>(null);
  const [measureOpen, setMeasureOpen] = useState(false);
  const [platesOpen, setPlatesOpen] = useState(false);
  const [reminderOpen, setReminderOpen] = useState(false);
  const [notifDenied, setNotifDenied] = useState(false);
  const [photos, setPhotos] = useState<ProgressPhoto[]>([]);
  const [photosOpen, setPhotosOpen] = useState(false);
  const [loadoutOpen, setLoadoutOpen] = useState(false);
  const [payOpen, setPayOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [session, setSession] = useState<AuthSession | null>(null);
  const [confirmLogout, setConfirmLogout] = useState(false);
  const access = useAccess();

  useEffect(() => {
    setSession(loadSession());
  }, [authOpen]);
  const weights = useStore((s) => s.weights);
  const loadout = useStore((s) => s.loadout) ?? DEFAULT_LOADOUT;
  const plateCount = Object.values(loadout.plates ?? {}).reduce((a, b) => a + b, 0);
  const router = useRouter();
  const water = useStore((s) => s.water);
  const meals = useStore((s) => s.meals);
  const skillProgress = useStore((s) => s.skillProgress);
  const checkins = useStore((s) => s.checkins);
  const hydration = useStore((s) => s.hydration) ?? DEFAULT_HYDRATION;
  const progression = useMemo(
    () => summarize({ logs, meals, weights, measurements, water, skillProgress, hydration, checkins }),
    [logs, meals, weights, measurements, water, skillProgress, hydration, checkins]
  );

  const refreshPhotos = async () => {
    try {
      setPhotos(await listPhotos());
    } catch {
      /* indexeddb unavailable */
    }
  };

  useEffect(() => {
    void refreshPhotos();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const bodyPlan = bodyTypePlan(profile?.bodyType);
  const trainingStatus = trainingStatusOf(profile?.lastWorkoutGap);
  const ramp = rampStateOf(trainingStatus, logs.length);

  const records = personalRecords(logs, 6);

  const measureField = (key: "waist" | "chest" | "arm" | "thigh" | "neck" | "hip") => {
    const withVal = measurements.filter((m) => m[key] !== undefined);
    const latest = withVal[0]?.[key];
    const prev = withVal[1]?.[key];
    const delta = latest !== undefined && prev !== undefined ? Math.round((latest - prev) * 10) / 10 : null;
    return { latest, delta };
  };

  const waistCm = measureField("waist").latest;
  const neckCm = measureField("neck").latest;
  const hipCm = measureField("hip").latest;
  const bodyFat =
    profile && waistCm && neckCm
      ? navyBodyFat(profile.sex, { heightCm: profile.heightCm, waistCm, neckCm, hipCm })
      : null;

  const toggleReminder = async () => {
    if (!reminder.enabled) {
      if (!isNativeAndroid() && typeof Notification !== "undefined") {
        const perm = await Notification.requestPermission();
        if (perm !== "granted") {
          setNotifDenied(true);
          return;
        }
      }
      setNotifDenied(false);
      setReminder({ enabled: true });
    } else {
      setReminder({ enabled: false });
    }
  };

  if (!profile?.onboarded || editing) {
    return <Wizard onDone={() => setEditing(false)} />;
  }

  const targets = calcTargets(profile);
  const eqLabels = EQUIPMENT.filter((e) => equipment.includes(e.id)).map((e) => e.label);

  const importData = async (file?: File) => {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      const res = importSnapshot(parsed);
      setImportMsg(
        res.ok
          ? { ok: true, text: "Backup imported — everything is restored." }
          : { ok: false, text: res.error ?? "Invalid backup file." }
      );
    } catch {
      setImportMsg({ ok: false, text: "That file isn't valid JSON." });
    } finally {
      if (importRef.current) importRef.current.value = "";
    }
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify(snapshot(), null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `forge-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col gap-4">
      <Reveal>
        <div className="flex items-end justify-between pt-1">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--volt)]">{t("pg.profileEyebrow")}</p>
            <h1 className="font-display mt-1 text-[32px] uppercase leading-none tracking-wide">
              {profile.name}
            </h1>
          </div>
          <button className="chip !px-3 !py-1.5 text-[11px] font-bold" onClick={() => setEditing(true)}>
            Edit
          </button>
        </div>
      </Reveal>

      {/* Account */}
      <Reveal>
        {session ? (
          <div className="card p-4">
            <div className="flex items-center gap-3">
              <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-[var(--volt)]">
                <UserRound size={19} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold">
                  {session.user.displayName || session.user.email.split("@")[0]}
                </p>
                <p className="truncate text-[11px] text-[var(--muted)]">{session.user.email}</p>
              </div>
              <span className="flex shrink-0 items-center gap-1 rounded-full bg-[rgba(205,248,63,0.14)] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[var(--volt)]">
                <CloudCheck size={11} /> Backed up
              </span>
            </div>
            {confirmLogout ? (
              <div className="mt-3 border-t border-[var(--line)] pt-3">
                <p className="mb-2.5 text-[11px] leading-relaxed text-[var(--muted)]">
                  Your data stays saved on this device and will come back when you log in again.
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button className="btn btn-ghost h-10 text-[12px]" onClick={() => setConfirmLogout(false)}>
                    Cancel
                  </button>
                  <button
                    className="btn btn-danger h-10 text-[12px]"
                    onClick={async () => {
                      switchAccount(session.user.id, null);
                      await doLogout();
                      window.location.reload();
                    }}
                  >
                    <LogOut size={13} /> Log out
                  </button>
                </div>
              </div>
            ) : (
              <button
                className="btn btn-ghost mt-3 h-10 w-full text-[12px]"
                onClick={() => setConfirmLogout(true)}
              >
                <LogOut size={13} /> Log out
              </button>
            )}
          </div>
        ) : BUNDLED_MOBILE ? (
          <div className="card flex w-full items-center gap-3 p-4">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[rgba(205,248,63,0.14)] text-[var(--volt)]">
              <ShieldCheck size={19} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">Saved on this phone</p>
              <p className="text-[11px] leading-snug text-[var(--muted)]">
                All workouts, meals and progress work offline in private app storage
              </p>
            </div>
            <Check size={16} className="shrink-0 text-[var(--volt)]" strokeWidth={3} />
          </div>
        ) : (
          <button className="card flex w-full items-center gap-3 p-4 text-left" onClick={() => setAuthOpen(true)}>
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--volt)] text-[#0b0c0e]">
              <UserPlus size={19} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">Save your progress</p>
              <p className="text-[11px] leading-snug text-[var(--muted)]">
                Create a free account so you never lose your data
              </p>
            </div>
            <ArrowRight size={16} className="text-[var(--muted)]" />
          </button>
        )}
      </Reveal>

      {/* App lock */}
      <Reveal delay={18}>
        <div className="card p-4">
          <div className="flex items-center gap-3">
            <div
              className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${
                appLock.enabled ? "bg-[var(--volt)] text-[#0b0c0e]" : "bg-[var(--surface-2)] text-[var(--muted)]"
              }`}
            >
              <Shield size={19} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">App lock</p>
              <p className="text-[11px] leading-snug text-[var(--muted)]">
                PIN at launch — keeps logs, photos and notes private
              </p>
            </div>
            <button
              className={`h-9 shrink-0 rounded-full px-4 text-[12px] font-extrabold ${
                appLock.enabled
                  ? "bg-[var(--surface-2)] text-[var(--muted)]"
                  : "bg-[var(--volt)] text-[#0b0c0e]"
              }`}
              onClick={() => {
                if (appLock.enabled) {
                  setAppLock({ enabled: false, pinHash: "" });
                  setPinMsg(null);
                } else if (pinInput.length >= 4) {
                  void hashPin(pinInput).then((h) => {
                    setAppLock({ enabled: true, pinHash: h });
                    setPinInput("");
                    setPinMsg("App lock enabled");
                  });
                } else {
                  setPinMsg("Choose a 4–6 digit PIN below first");
                }
              }}
            >
              {appLock.enabled ? "ON" : "OFF"}
            </button>
          </div>

          {(!appLock.enabled || pinInput.length > 0) && (
            <div className="mt-3 border-t border-[var(--line)] pt-3">
              <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
                {appLock.enabled ? "Change PIN" : "Set PIN (4–6 digits)"}
              </label>
              <div className="flex gap-2">
                <input
                  className="field text-center font-bold tracking-[0.4em]"
                  type="password"
                  inputMode="numeric"
                  maxLength={6}
                  placeholder="••••"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ""))}
                />
                <button
                  className={`btn h-11 shrink-0 px-5 text-sm ${
                    pinInput.length >= 4 ? "btn-volt" : "btn-ghost opacity-50"
                  }`}
                  disabled={pinInput.length < 4}
                  onClick={() => {
                    void hashPin(pinInput).then((h) => {
                      setAppLock({ enabled: true, pinHash: h });
                      setPinInput("");
                      setPinMsg("PIN saved");
                    });
                  }}
                >
                  Save
                </button>
              </div>
              {pinMsg && (
                <p className="mt-2 text-[11px] font-bold text-[var(--volt)]">{pinMsg}</p>
              )}
            </div>
          )}

          {appLock.enabled && (
            <button
              className="btn btn-ghost mt-3 h-10 w-full text-[12px]"
              onClick={() => setAppUnlocked(false)}
            >
              Lock now
            </button>
          )}
        </div>
      </Reveal>

      {/* Units */}
      <Reveal delay={20}>
        <div className="card p-4">
          <div className="mb-3 flex items-center justify-between gap-3">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Units
            </p>
            <span className="text-right text-[9px] leading-tight text-[var(--muted)]">
              weight · height · lifts · measurements
            </span>
          </div>
          <Segmented
            value={sys}
            onChange={(v) => setUnitSystem(v as UnitSystem)}
            options={[
              { value: "metric", label: "kg · cm" },
              { value: "imperial", label: "lb · in" },
            ]}
          />
        </div>
      </Reveal>

      {/* Language */}
      <Reveal delay={16}>
        <div className="card flex items-center gap-3 p-4">
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-[var(--aqua)]">
            <span className="text-[15px] font-extrabold">अ</span>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold">{t("profile.language")}</p>
            <p className="text-[11px] text-[var(--muted)]">{t("profile.languageHint")}</p>
          </div>
          <div className="flex shrink-0 gap-1 rounded-xl border border-[var(--line)] bg-[var(--surface-2)] p-1">
            {(["en", "hi"] as const).map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                className={`rounded-lg px-3 py-1.5 text-[11px] font-bold transition-all ${
                  lang === l ? "bg-[var(--volt)] text-[#0b0c0e]" : "text-[var(--muted)]"
                }`}
              >
                {l === "en" ? "English" : "हिंदी"}
              </button>
            ))}
          </div>
        </div>
      </Reveal>

      {/* Body stats */}
      <Reveal>
        <div className="card grid grid-cols-4 divide-x divide-[var(--line)] p-4">
          {[
            { l: "Age", v: String(profile.age) },
            { l: "Height", v: heightLabel(profile.heightCm, sys) },
            { l: "Weight", v: `${wOut(profile.weightKg, sys)} ${wUnit(sys)}` },
            { l: "Goal", v: profile.goal === "lose" ? "Cut" : profile.goal === "gain" ? "Build" : "Hold" },
          ].map((s) => (
            <div key={s.l} className="px-1 text-center">
              <p className="font-display tabular text-lg leading-tight">{s.v}</p>
              <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">{s.l}</p>
            </div>
          ))}
        </div>
      </Reveal>

      {/* Training plan from history + body type */}
      <Reveal delay={30}>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              My training plan
            </p>
            <button className="text-[11px] font-bold text-[var(--volt)]" onClick={() => setEditing(true)}>
              Change
            </button>
          </div>

          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-lg">
              {BODY_TYPES.find((b) => b.id === (profile.bodyType ?? "unsure"))?.icon}
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[13px] font-bold">{bodyPlan.label}</p>
              <p className="tabular text-[11px] text-[var(--muted)]">
                {bodyPlan.repRange[0]}–{bodyPlan.repRange[1]} reps · {bodyPlan.restSec}s rest ·{" "}
                {bodyPlan.cardioPerWeek}× cardio
              </p>
            </div>
          </div>

          <div className="mt-3 border-t border-[var(--line)] pt-3">
            <div className="flex items-baseline justify-between">
              <p className="text-[12px] font-bold">{trainingStatus.headline}</p>
              <span className="tabular text-[10px] font-bold text-[var(--muted)]">
                {TRAINING_GAPS.find((g) => g.id === (profile.lastWorkoutGap ?? "months3"))?.label}
              </span>
            </div>
            {ramp.active ? (
              <>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/[0.08]">
                  <div
                    className="h-full rounded-full bg-[var(--volt)] transition-all duration-700"
                    style={{ width: `${Math.max(4, ramp.progress * 100)}%` }}
                  />
                </div>
                <p className="tabular mt-1.5 text-[11px] text-[var(--muted)]">{ramp.message}</p>
              </>
            ) : (
              <p className="mt-1.5 text-[11px] text-[var(--volt)]">{ramp.message}</p>
            )}
            <p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">
              {bodyPlan.nutrition}
            </p>
          </div>
        </div>
      </Reveal>

      {/* Targets */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Daily targets
            </p>
            <Target size={14} className="text-[var(--volt)]" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="card-2 p-4">
              <p className="font-display tabular text-3xl text-[var(--volt)]">{targets.calories}</p>
              <p className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">
                kcal / day
              </p>
            </div>
            <div className="card-2 flex flex-col justify-center gap-1 p-4 text-[12px]">
              <p className="tabular flex justify-between">
                <span className="text-[var(--muted)]">Protein</span>
                <b>{targets.protein}g</b>
              </p>
              <p className="tabular flex justify-between">
                <span className="text-[var(--muted)]">Carbs</span>
                <b>{targets.carbs}g</b>
              </p>
              <p className="tabular flex justify-between">
                <span className="text-[var(--muted)]">Fat</span>
                <b>{targets.fat}g</b>
              </p>
            </div>
          </div>
          <p className="mt-3 text-[11px] leading-relaxed text-[var(--muted)]">
            BMR <span className="tabular font-semibold text-[var(--text)]">{targets.bmr}</span> kcal ·
            Maintenance{" "}
            <span className="tabular font-semibold text-[var(--text)]">{targets.maintenance}</span> kcal via
            Mifflin–St Jeor × {profile.activity}.
          </p>
        </div>
      </Reveal>

      {/* Equipment */}
      <Reveal delay={40}>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              My equipment
            </p>
            <span className="tabular text-[10px] font-bold text-[var(--volt)]">
              {equipment.length} items
            </span>
          </div>
          <EquipmentPicker compact />
        </div>
      </Reveal>

      {/* Loadout */}
      <Reveal delay={42}>
        <button className="card flex w-full items-center gap-3 p-4 text-left" onClick={() => setLoadoutOpen(true)}>
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-[var(--volt)]">
            <Weight size={19} />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold">My weights & plates</p>
            <p className="truncate text-[11px] text-[var(--muted)]">
              {loadout.barKg}kg bar · {plateCount} plates · {loadout.dumbbellKg.length} dumbbells
            </p>
          </div>
          <ArrowRight size={16} className="text-[var(--muted)]" />
        </button>
      </Reveal>

      {/* Rank shortcut */}
      <Reveal delay={43}>
        <button
          className="card flex w-full items-center gap-3 p-4 text-left"
          onClick={() => router.push("/ranks")}
        >
          <div
            className="grid h-11 w-11 shrink-0 place-items-center rounded-xl"
            style={{ background: `${progression.rank.rank.color}1f`, color: progression.rank.rank.color }}
          >
            <Shield size={19} />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold">
              {progression.rank.rank.name}{" "}
              <span className="text-[11px] font-semibold text-[var(--muted)]">
                Tier {progression.rank.rank.tier}
              </span>
            </p>
            <p className="tabular text-[11px] text-[var(--muted)]">
              {progression.xp.total.toLocaleString()} XP · {progression.unlocked.length}/
              {progression.achievements.length} achievements
            </p>
          </div>
          <ArrowRight size={16} className="text-[var(--muted)]" />
        </button>
      </Reveal>

      {/* Personal records */}
      <Reveal delay={45}>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Personal records
            </p>
            <Medal size={14} className="text-[var(--volt)]" />
          </div>
          {records.length === 0 ? (
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">
              Log weighted sets during workouts and your best lifts will appear here — ranked by
              estimated 1-rep max.
            </p>
          ) : (
            <div className="flex flex-col divide-y divide-[var(--line)]">
              {records.map((r) => (
                <div key={r.exerciseId} className="flex items-center gap-3 py-2.5">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-[var(--surface-2)] text-[var(--volt)]">
                    <Medal size={14} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-bold">{r.name}</p>
                    <p className="tabular text-[11px] text-[var(--muted)]">
                      est. 1RM {wOut(r.est1rm, sys)} {wUnit(sys)}
                    </p>
                  </div>
                  <span className="tabular text-sm font-extrabold text-[var(--volt)]">
                    {r.added ? "+" : ""}
                    {wOut(r.kg, sys)} {wUnit(sys)} × {r.reps}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </Reveal>

      {/* Measurements */}
      <Reveal delay={52}>
        <ProGate feature="measurements" compact>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Body measurements
            </p>
            <button
              className="chip chip-on !px-3 !py-1.5 text-[11px] font-bold"
              onClick={() => setMeasureOpen(true)}
            >
              <Ruler size={12} /> Log
            </button>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {(
              [
                { key: "waist", label: "Waist" },
                { key: "chest", label: "Chest" },
                { key: "arm", label: "Arm" },
                { key: "thigh", label: "Thigh" },
              ] as const
            ).map((m) => {
              const { latest, delta } = measureField(m.key);
              return (
                <div key={m.key} className="card-2 p-3 text-center">
                  <p className="font-display tabular text-lg leading-tight">
                    {latest == null ? "—" : lOut(latest, sys)}
                    <span className="text-[10px] text-[var(--muted)]">{latest ? lUnit(sys) : ""}</span>
                  </p>
                  <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">{m.label}</p>
                  <p
                    className={`tabular mt-0.5 text-[9px] font-bold ${
                      delta === null ? "text-transparent" : delta <= 0 ? "text-[var(--volt)]" : "text-[var(--ember)]"
                    }`}
                  >
                    {delta === null ? "·" : `${delta > 0 ? "+" : ""}${lOut(delta, sys)}`}
                  </p>
                </div>
              );
            })}
          </div>
          {bodyFat !== null ? (
            <div className="mt-3 flex items-center justify-between border-t border-[var(--line)] pt-3">
              <span className="text-[11px] font-semibold text-[var(--muted)]">
                Est. body fat (US Navy method)
              </span>
              <span className="tabular flex items-center gap-2 text-sm font-extrabold">
                <span className="text-[var(--volt)]">{bodyFat}%</span>
                <span className="rounded-full bg-[rgba(205,248,63,0.12)] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[var(--volt)]">
                  {fatCategory(bodyFat, profile.sex)}
                </span>
              </span>
            </div>
          ) : (
            <p className="mt-3 border-t border-[var(--line)] pt-3 text-[11px] text-[var(--muted)]">
              Log waist + neck{profile.sex === "female" ? " + hip" : ""} to estimate body fat % (US Navy
              method).
            </p>
          )}
        </div>
        </ProGate>
      </Reveal>

      {/* Progress photos */}
      <Reveal delay={55}>
        <ProGate feature="photos" compact>
        <button className="card w-full p-4 text-left" onClick={() => setPhotosOpen(true)}>
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-[var(--volt)]">
              <Camera size={19} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">Progress photos</p>
              <p className="text-[11px] text-[var(--muted)]">
                {photos.length
                  ? `${photos.length} photo${photos.length > 1 ? "s" : ""} — tap to view & compare`
                  : "Monthly mirror check-ins, stored on-device only"}
              </p>
            </div>
            <Images size={16} className="text-[var(--muted)]" />
          </div>
          {photos.length > 0 && (
            <div className="mt-3 flex gap-2">
              {photos.slice(0, 4).map((p) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  key={p.id}
                  src={p.dataUrl}
                  alt=""
                  className="h-16 w-14 rounded-xl border border-[var(--line)] object-cover"
                />
              ))}
            </div>
          )}
        </button>
        </ProGate>
      </Reveal>

      {/* Reminders */}
      <Reveal delay={58}>
        <div className="card p-4">
          <div className="flex items-center gap-3">
            <div className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${reminder.enabled ? "bg-[var(--volt)] text-[#0b0c0e]" : "bg-[var(--surface-2)] text-[var(--muted)]"}`}>
              <BellRing size={19} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">Workout alarm</p>
              <p className="truncate text-[11px] text-[var(--muted)]">
                {notifDenied
                  ? "Notifications blocked — enable them in settings"
                  : reminder.enabled
                    ? `${reminder.time} · ${reminder.soundName ?? "Forge Bell"}${reminder.vibrate === false ? "" : " · vibrate"}`
                    : "Off — choose your sound and time"}
              </p>
            </div>
            <button
              className={`h-9 shrink-0 rounded-full px-4 text-[12px] font-extrabold ${reminder.enabled ? "bg-[var(--volt)] text-[#0b0c0e]" : "bg-[var(--surface-2)] text-[var(--muted)]"}`}
              onClick={() => void toggleReminder()}
            >
              {reminder.enabled ? "ON" : "OFF"}
            </button>
          </div>
          <button
            className="btn btn-ghost mt-3 h-10 w-full text-[12px]"
            onClick={() => setReminderOpen(true)}
          >
            <Music size={14} /> Configure sound, vibration & time
          </button>
        </div>
      </Reveal>

      {/* Plate calculator */}
      <Reveal delay={62}>
        <button className="card flex w-full items-center gap-3 p-4 text-left" onClick={() => setPlatesOpen(true)}>
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-[var(--volt)]">
            <Calculator size={19} />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold">Plate calculator</p>
            <p className="text-[11px] text-[var(--muted)]">Which plates to load per side of the bar</p>
          </div>
        </button>
      </Reveal>

      {/* Cloud sync */}
      <Reveal delay={66}>
        <div className="card p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
                Cloud backup
              </p>
              <p className="mt-1 text-[12px] text-[var(--muted)]">
                {syncStatus === "offline" ? (
                  "Offline — data stored safely on this phone."
                ) : lastSyncedAt ? (
                  <>
                    Last synced{" "}
                    <span className="font-semibold text-[var(--text)]">
                      {new Date(lastSyncedAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
                    </span>
                  </>
                ) : (
                  "Not synced yet."
                )}
              </p>
            </div>
            <button
              className="btn btn-ghost h-10 px-4 text-[12px]"
              onClick={() => void syncNow(true)}
            >
              {syncStatus === "syncing" ? (
                <RefreshCw size={14} className="animate-spin" />
              ) : syncStatus === "offline" ? (
                <CloudOff size={14} className="text-[var(--ember)]" />
              ) : (
                <CloudCheck size={14} className="text-[var(--volt)]" />
              )}
              Sync now
            </button>
          </div>
          <p className="mt-3 border-t border-[var(--line)] pt-3 text-[11px] leading-relaxed text-[var(--muted)]">
            Everything works fully offline. Whenever you are online, FORGE pushes an encrypted-transit
            snapshot to your cloud database so a reinstall never loses your streak.
          </p>
        </div>
      </Reveal>

      {/* Android install — web only, never shown inside the APK itself */}
      {!BUNDLED_MOBILE && (
        <Reveal delay={80}>
          <div className="card p-4">
            <div className="flex items-center gap-3">
              <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--volt)] text-[#0b0c0e]">
                <Smartphone size={20} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold">FORGE for Android</p>
                <p className="text-[11px] leading-relaxed text-[var(--muted)]">
                  Native offline APK · built for Android 6+
                </p>
              </div>
              <a
                href="/FORGE-fitness.apk"
                download
                className="btn btn-volt h-10 px-4 text-[12px]"
              >
                <Download size={14} /> APK
              </a>
            </div>
          </div>
        </Reveal>
      )}

      {/* Data */}
      <Reveal delay={100}>
        <div className="card flex flex-col gap-2 p-4">
          <button
            className="btn btn-ghost h-11 w-full text-sm"
            onClick={() => (access.isPro ? exportData() : setPayOpen(true))}
          >
            <Download size={15} /> Export data (JSON){!access.isPro && <ProBadge className="ml-1" />}
          </button>
          <input
            ref={importRef}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={(e) => void importData(e.target.files?.[0])}
          />
          <button
            className="btn btn-ghost h-11 w-full text-sm"
            onClick={() => importRef.current?.click()}
          >
            <Upload size={15} /> Import backup (JSON)
          </button>
          {importMsg && (
            <p
              className={`text-center text-[11px] font-bold ${
                importMsg.ok ? "text-[var(--volt)]" : "text-[var(--ember)]"
              }`}
            >
              {importMsg.text}
            </p>
          )}
          <button className="btn btn-danger h-11 w-full text-sm" onClick={() => setConfirmReset(true)}>
            <Trash2 size={15} /> Reset everything
          </button>
        </div>
      </Reveal>

      <p className="pb-2 text-center text-[10px] font-semibold uppercase tracking-[0.3em] text-[var(--muted)]">
        Forge · {logs.length} sessions logged
      </p>

      <Sheet open={confirmReset} onClose={() => setConfirmReset(false)} title="Reset everything?">
        <p className="text-sm leading-relaxed text-[var(--muted)]">
          This wipes your profile, routines, plans, meals and history from this device. Cloud backup
          will be overwritten on the next sync.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button className="btn btn-ghost h-12" onClick={() => setConfirmReset(false)}>
            Cancel
          </button>
          <button
            className="btn btn-danger h-12"
            onClick={() => {
              resetAll();
              setConfirmReset(false);
            }}
          >
            Wipe it
          </button>
        </div>
      </Sheet>

      <MeasureSheet open={measureOpen} onClose={() => setMeasureOpen(false)} />
      <PlateSheet open={platesOpen} onClose={() => setPlatesOpen(false)} />
      <ReminderSheet open={reminderOpen} onClose={() => setReminderOpen(false)} />
      <PhotoSheet
        open={photosOpen}
        onClose={() => setPhotosOpen(false)}
        photos={photos}
        onChanged={() => void refreshPhotos()}
      />
      <LoadoutSheet open={loadoutOpen} onClose={() => setLoadoutOpen(false)} />
      <PaywallSheet open={payOpen} onClose={() => setPayOpen(false)} />
      <AuthSheet open={authOpen} onClose={() => setAuthOpen(false)} />
    </div>
  );
}

/* ------------------------- Reminder ringtone -------------------------- */

function ReminderSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const reminder = useStore((s) => s.reminder);
  const setReminder = useStore((s) => s.setReminder);
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) {
      stopRingtone();
      setPlaying(false);
    }
    return () => stopRingtone();
  }, [open]);

  const chooseCustom = async () => {
    setError(null);
    if (isNativeAndroid()) {
      setBusy(true);
      try {
        const picked = await chooseNativeRingtone();
        setReminder({ soundId: "custom", soundName: picked.name });
      } catch {
        setError("No audio file was selected.");
      } finally {
        setBusy(false);
      }
      return;
    }
    fileRef.current?.click();
  };

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    setError(null);
    try {
      const saved = await saveCustomTone(file);
      setReminder({ soundId: "custom", soundName: saved.name });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't save that audio file.");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const preview = async () => {
    if (playing) {
      stopRingtone();
      setPlaying(false);
      return;
    }
    setError(null);
    try {
      await previewRingtone((reminder.soundId ?? "forge") as RingtoneId);
      setPlaying(true);
      setTimeout(() => setPlaying(false), 2500);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't play this sound.");
    }
  };

  return (
    <Sheet open={open} onClose={onClose} title="Workout alarm">
      <input
        ref={fileRef}
        type="file"
        accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg"
        className="hidden"
        onChange={(e) => void onFile(e.target.files?.[0])}
      />
      <div className="flex flex-col gap-5">
        <p className="text-[12px] leading-relaxed text-[var(--muted)]">
          Pick a sound that actually gets you moving. On Android, your selected ringtone works as a
          native alarm even when FORGE is closed. On Windows, keep FORGE open or minimized.
        </p>

        <div>
          <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Reminder time
          </label>
          <input
            type="time"
            className="field font-display !text-2xl tracking-wide"
            value={reminder.time || "07:00"}
            onChange={(e) => setReminder({ time: e.target.value })}
          />
        </div>

        <div>
          <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Ringtone
          </p>
          <div className="flex flex-col gap-2">
            {TONES.map((tone) => {
              const selected = (reminder.soundId ?? "forge") === tone.id;
              return (
                <button
                  key={tone.id}
                  className={`card-2 flex items-center gap-3 p-3.5 text-left transition-all ${
                    selected ? "border-[var(--volt)] bg-[rgba(205,248,63,0.05)]" : ""
                  }`}
                  onClick={() => {
                    if (tone.id === "custom") {
                      void chooseCustom();
                    } else {
                      setReminder({ soundId: tone.id, soundName: tone.label });
                    }
                  }}
                >
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[var(--surface-3)] text-lg">
                    {tone.icon}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[13px] font-bold">
                      {tone.id === "custom" && reminder.soundId === "custom"
                        ? reminder.soundName || tone.label
                        : tone.label}
                    </span>
                    <span className="block text-[10px] text-[var(--muted)]">
                      {tone.id === "custom" && isNativeAndroid()
                        ? "Pick from Music, Downloads or Files"
                        : tone.hint}
                    </span>
                  </span>
                  {selected && <Check size={16} className="text-[var(--volt)]" strokeWidth={3} />}
                </button>
              );
            })}
          </div>
        </div>

        <button className="btn btn-ghost h-11 w-full text-sm" onClick={() => void preview()} disabled={busy}>
          <Volume2 size={16} /> {busy ? "Loading…" : playing ? "Stop preview" : "Preview sound"}
        </button>

        <div className="card-2 flex items-center gap-3 p-3.5">
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[var(--surface-3)] text-[var(--aqua)]">
            <Vibrate size={16} />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-bold">Vibration</p>
            <p className="text-[10px] text-[var(--muted)]">Strong workout-alarm pattern</p>
          </div>
          <button
            className={`h-8 rounded-full px-3 text-[11px] font-extrabold ${
              reminder.vibrate === false
                ? "bg-[var(--surface-3)] text-[var(--muted)]"
                : "bg-[var(--volt)] text-[#0b0c0e]"
            }`}
            onClick={() => setReminder({ vibrate: reminder.vibrate === false })}
          >
            {reminder.vibrate === false ? "OFF" : "ON"}
          </button>
        </div>

        <div>
          <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Snooze length
          </p>
          <Segmented
            value={reminder.snoozeMinutes ?? 10}
            onChange={(v) => setReminder({ snoozeMinutes: v })}
            options={[
              { value: 5, label: "5 min" },
              { value: 10, label: "10 min" },
              { value: 15, label: "15 min" },
              { value: 30, label: "30 min" },
            ]}
          />
        </div>

        {error && (
          <p className="rounded-xl border border-[rgba(255,122,47,0.3)] bg-[rgba(255,122,47,0.07)] p-3 text-[11px] text-[var(--ember)]">
            {error}
          </p>
        )}

        {reminder.soundId === "custom" && !isNativeAndroid() && (
          <button
            className="text-center text-[10px] font-semibold text-[var(--muted)] underline"
            onClick={() => {
              void deleteCustomTone();
              setReminder({ soundId: "forge", soundName: "Forge Bell" });
            }}
          >
            Remove custom ringtone
          </button>
        )}

        <button
          className="btn btn-volt h-12 w-full"
          onClick={() => {
            setReminder({ enabled: true });
            onClose();
          }}
        >
          <BellRing size={16} /> Save & enable alarm
        </button>
      </div>
    </Sheet>
  );
}

/* --------------------------- Loadout editor --------------------------- */

function LoadoutSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const loadout = useStore((s) => s.loadout) ?? DEFAULT_LOADOUT;
  const setLoadout = useStore((s) => s.setLoadout);
  const [newDb, setNewDb] = useState("");
  const [newKb, setNewKb] = useState("");

  const setPlate = (size: number, n: number) =>
    setLoadout({ plates: { ...loadout.plates, [String(size)]: Math.max(0, n) } });

  const addWeight = (kind: "dumbbellKg" | "kettlebellKg", raw: string) => {
    const v = Number(raw);
    if (!v || v <= 0) return;
    const list = [...new Set([...(loadout[kind] ?? []), v])].sort((a, b) => a - b);
    setLoadout({ [kind]: list } as Partial<typeof loadout>);
  };

  const removeWeight = (kind: "dumbbellKg" | "kettlebellKg", v: number) =>
    setLoadout({ [kind]: (loadout[kind] ?? []).filter((x) => x !== v) } as Partial<typeof loadout>);

  const barTotal =
    loadout.barKg +
    PLATE_SIZES.reduce((s, p) => s + p * 2 * Math.floor((loadout.plates?.[String(p)] ?? 0) / 2), 0);

  return (
    <Sheet open={open} onClose={onClose} title="My weights & plates">
      <div className="flex flex-col gap-5">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
              Barbell (kg)
            </label>
            <input
              className="field text-center"
              type="number"
              inputMode="decimal"
              step="0.5"
              value={loadout.barKg}
              onChange={(e) => setLoadout({ barKg: Number(e.target.value) || 0 })}
            />
          </div>
          <div>
            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
              EZ bar (kg)
            </label>
            <input
              className="field text-center"
              type="number"
              inputMode="decimal"
              step="0.5"
              value={loadout.ezBarKg}
              onChange={(e) => setLoadout({ ezBarKg: Number(e.target.value) || 0 })}
            />
          </div>
        </div>

        <div>
          <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Plates owned (total pieces)
          </p>
          <div className="flex flex-col gap-2">
            {PLATE_SIZES.map((p) => {
              const n = loadout.plates?.[String(p)] ?? 0;
              return (
                <div key={p} className="card-2 flex items-center gap-3 p-2.5">
                  <span className="tabular w-14 text-sm font-extrabold">{p} kg</span>
                  <span className="flex-1 text-[11px] text-[var(--muted)]">
                    {n >= 2 ? `${Math.floor(n / 2)} pair${Math.floor(n / 2) > 1 ? "s" : ""}` : n === 1 ? "single" : "none"}
                  </span>
                  <Stepper value={n} min={0} max={20} onChange={(v) => setPlate(p, v)} />
                </div>
              );
            })}
          </div>
          <p className="tabular mt-2 text-[11px] text-[var(--muted)]">
            Max loadable barbell:{" "}
            <span className="font-bold text-[var(--volt)]">{barTotal} kg</span>
          </p>
        </div>

        {(["dumbbellKg", "kettlebellKg"] as const).map((kind) => (
          <div key={kind}>
            <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
              {kind === "dumbbellKg" ? "Dumbbells" : "Kettlebells"} (kg each)
            </p>
            <div className="mb-2 flex flex-wrap gap-1.5">
              {(loadout[kind] ?? []).map((w) => (
                <button
                  key={w}
                  className="chip chip-on !py-1.5 text-[11px] font-bold"
                  onClick={() => removeWeight(kind, w)}
                >
                  {w} kg <X size={11} strokeWidth={3} />
                </button>
              ))}
              {(loadout[kind] ?? []).length === 0 && (
                <span className="text-[11px] text-[var(--muted)]">None added yet</span>
              )}
            </div>
            <div className="flex gap-2">
              <input
                className="field flex-1 text-center"
                type="number"
                inputMode="decimal"
                step="0.5"
                placeholder="Add weight…"
                value={kind === "dumbbellKg" ? newDb : newKb}
                onChange={(e) => (kind === "dumbbellKg" ? setNewDb(e.target.value) : setNewKb(e.target.value))}
              />
              <button
                className="btn btn-ghost h-11 px-5 text-sm"
                onClick={() => {
                  addWeight(kind, kind === "dumbbellKg" ? newDb : newKb);
                  kind === "dumbbellKg" ? setNewDb("") : setNewKb("");
                }}
              >
                Add
              </button>
            </div>
          </div>
        ))}

        <p className="text-[11px] leading-relaxed text-[var(--muted)]">
          The plate calculator only suggests loads you can actually build, and the workout player
          uses these when recommending weights.
        </p>
        <button className="btn btn-volt h-12 w-full" onClick={onClose}>
          <Check size={16} strokeWidth={3} /> Done
        </button>
      </div>
    </Sheet>
  );
}

/* ------------------------- Measurement logger ------------------------- */

function MeasureSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const logMeasurement = useStore((s) => s.logMeasurement);
  const profile = useStore((s) => s.profile);
  const [vals, setVals] = useState({ waist: "", chest: "", arm: "", thigh: "", neck: "", hip: "" });

  const save = () => {
    const entry: {
      date: string;
      waist?: number;
      chest?: number;
      arm?: number;
      thigh?: number;
      neck?: number;
      hip?: number;
    } = { date: dateKey() };
    for (const k of ["waist", "chest", "arm", "thigh", "neck", "hip"] as const) {
      const v = lIn(Number(vals[k]), sys);
      if (Number(vals[k]) > 0) entry[k] = v;
    }
    if (Object.keys(entry).length > 1) logMeasurement(entry);
    setVals({ waist: "", chest: "", arm: "", thigh: "", neck: "", hip: "" });
    onClose();
  };

  return (
    <Sheet open={open} onClose={onClose} title="Log measurements">
      <p className="mb-4 text-[12px] leading-relaxed text-[var(--muted)]">
        Measure in {lUnit(sys)}, same time of day for honest trends. Neck (and hip) feed the US Navy
        body-fat estimate.
      </p>
      <div className="grid grid-cols-2 gap-3">
        {(
          [
            ["waist", "Waist"],
            ["chest", "Chest"],
            ["neck", "Neck"],
            ["hip", profile?.sex === "female" ? "Hip" : "Hip — optional"],
            ["arm", "Arm"],
            ["thigh", "Thigh"],
          ] as const
        ).map(([k, label]) => (
          <div key={k}>
            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
              {label} ({lUnit(sys)})
            </label>
            <input
              className="field text-center"
              type="number"
              inputMode="decimal"
              placeholder="—"
              value={vals[k]}
              onChange={(e) => setVals({ ...vals, [k]: e.target.value })}
            />
          </div>
        ))}
      </div>
      <button className="btn btn-volt mt-4 h-12 w-full" onClick={save}>
        <Check size={16} strokeWidth={3} /> Save measurements
      </button>
    </Sheet>
  );
}

/* ------------------------- Progress photos ---------------------------- */

function PhotoSheet({
  open,
  onClose,
  photos,
  onChanged,
}: {
  open: boolean;
  onClose: () => void;
  photos: ProgressPhoto[];
  onChanged: () => void;
}) {
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const fileRef = useRef<HTMLInputElement>(null);
  const weightNow = useStore((s) => s.weights[0]?.kg ?? s.profile?.weightKg ?? null);
  const [compare, setCompare] = useState(false);
  const [busy, setBusy] = useState(false);

  const pick = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    try {
      const dataUrl = await fileToDataUrl(file);
      await addPhoto({
        id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        date: dateKey(),
        dataUrl,
        weightKg: weightNow,
      });
      onChanged();
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const oldest = photos.length ? photos[photos.length - 1] : null;
  const newest = photos.length ? photos[0] : null;

  return (
    <Sheet open={open} onClose={onClose} title="Progress photos">
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        capture="user"
        className="hidden"
        onChange={(e) => void pick(e.target.files?.[0])}
      />

      {photos.length >= 2 && (
        <button className="chip !px-3 !py-1.5 mb-3 text-[11px] font-bold" onClick={() => setCompare((c) => !c)}>
          {compare ? "Show gallery" : "Compare first vs latest"}
        </button>
      )}

      {compare && oldest && newest ? (
        <div className="grid grid-cols-2 gap-2">
          {[
            { p: oldest, tag: "Before" },
            { p: newest, tag: "Now" },
          ].map(({ p, tag }) => (
            <div key={tag} className="card-2 overflow-hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={p.dataUrl} alt={tag} className="h-56 w-full object-cover" />
              <div className="p-2.5">
                <p className="text-[10px] font-extrabold uppercase tracking-widest text-[var(--volt)]">{tag}</p>
                <p className="tabular text-[11px] text-[var(--muted)]">
                  {new Date(p.date + "T00:00").toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}
                  {p.weightKg ? ` · ${wOut(p.weightKg, sys)} ${wUnit(sys)}` : ""}
                </p>
              </div>
            </div>
          ))}
        </div>
      ) : photos.length === 0 ? (
        <p className="py-4 text-center text-[12px] leading-relaxed text-[var(--muted)]">
          No photos yet. Take one on day 1, then one every few weeks — same light, same pose. Photos
          never leave this phone.
        </p>
      ) : (
        <div className="grid grid-cols-3 gap-2">
          {photos.map((p) => (
            <div key={p.id} className="card-2 group relative overflow-hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={p.dataUrl} alt="" className="h-28 w-full object-cover" />
              <button
                className="absolute right-1.5 top-1.5 grid h-6 w-6 place-items-center rounded-full bg-black/60 text-white"
                onClick={() => void deletePhoto(p.id).then(onChanged)}
                aria-label="Delete photo"
              >
                <X size={12} />
              </button>
              <p className="tabular px-2 py-1.5 text-[9px] font-bold text-[var(--muted)]">
                {new Date(p.date + "T00:00").toLocaleDateString(undefined, { day: "numeric", month: "short" })}
                {p.weightKg ? ` · ${wOut(p.weightKg, sys)} ${wUnit(sys)}` : ""}
              </p>
            </div>
          ))}
        </div>
      )}

      <button
        className={`btn mt-4 h-12 w-full ${busy ? "btn-ghost opacity-60" : "btn-volt"}`}
        onClick={() => fileRef.current?.click()}
        disabled={busy}
      >
        <Camera size={17} /> {busy ? "Saving…" : "Take / upload photo"}
      </button>
    </Sheet>
  );
}

/* -------------------------- Plate calculator -------------------------- */

function PlateSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const loadout = useStore((s) => s.loadout) ?? DEFAULT_LOADOUT;
  const [total, setTotal] = useState(60);
  const [bar, setBar] = useState(loadout.barKg || 20);
  const [useInventory, setUseInventory] = useState(true);
  const inventory = useInventory
    ? Object.fromEntries(
        Object.entries(loadout.plates ?? {}).map(([k, v]) => [Number(k), v])
      )
    : undefined;
  const { perSide, exact, loadedTotal } = platesFor(total, bar, inventory);
  const reachable = total >= bar;

  const colorOf = (w: number) =>
    w >= 25 ? "var(--ember)" : w >= 20 ? "var(--volt)" : w >= 10 ? "var(--aqua)" : "#e8e8e2";

  return (
    <Sheet open={open} onClose={onClose} title="Plate calculator">
      <div className="flex flex-col gap-4">
        <div>
          <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Total weight incl. bar (kg)
          </label>
          <input
            className="field font-display !text-2xl tracking-wide"
            type="number"
            inputMode="decimal"
            step="1.25"
            value={total}
            onChange={(e) => setTotal(Number(e.target.value))}
          />
        </div>
        <div>
          <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">Bar</p>
          <Segmented
            value={bar}
            onChange={setBar}
            options={[
              { value: 20, label: "20 kg" },
              { value: 15, label: "15 kg" },
              { value: 10, label: "10 kg" },
              { value: 7, label: "7 kg" },
            ]}
          />
        </div>

        <div className="card-2 p-4">
          {!reachable ? (
            <p className="text-center text-[12px] text-[var(--muted)]">
              Total is lighter than the bar — just lift the bar.
            </p>
          ) : (
            <>
              <p className="mb-3 text-center text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
                Per side
              </p>
              <div className="flex min-h-[72px] items-center justify-center gap-1.5">
                <div className="mr-1 h-2 w-6 rounded-sm bg-white/30" />
                {perSide.length === 0 && (
                  <span className="text-[12px] text-[var(--muted)]">bar only</span>
                )}
                {perSide.map((p, i) => (
                  <div
                    key={i}
                    className="tabular grid place-items-center rounded-[4px] text-[10px] font-extrabold text-[#0b0c0e]"
                    style={{
                      background: colorOf(p),
                      width: 18 + Math.min(30, p) * 0.9,
                      height: 18 + Math.sqrt(p) * 12,
                    }}
                  >
                    {p}
                  </div>
                ))}
              </div>
              <p className="tabular mt-3 text-center text-[12px] font-semibold">
                {perSide.join(" + ") || "—"} kg each side
              </p>
              {!exact && (
                <p className="mt-1 text-center text-[11px] text-[var(--ember)]">
                  {useInventory
                    ? `Can't hit that with your plates — closest is ${loadedTotal} kg.`
                    : `Not exact with standard plates — closest is ${loadedTotal} kg.`}
                </p>
              )}
            </>
          )}
        </div>
        <button
          className={`chip ${useInventory ? "chip-on" : ""} w-full justify-center !py-2 text-[11px] font-bold`}
          onClick={() => setUseInventory((v) => !v)}
        >
          {useInventory ? "Using only plates I own" : "Assuming unlimited plates"}
        </button>
        <p className="text-[11px] leading-relaxed text-[var(--muted)]">
          Loads from the inside out using 25 / 20 / 15 / 10 / 5 / 2.5 / 1.25 kg plates. Edit your
          inventory in “My weights & plates”.
        </p>
      </div>
    </Sheet>
  );
}
