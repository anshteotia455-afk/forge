"use client";

import {
  ArrowLeft,
  Check,
  CircleDot,
  Flag,
  Lock,
  Play,
  Plus,
  RefreshCw,
  Target,
  Trophy,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useT } from "@/lib/i18n";
import { useMemo, useState } from "react";
import { Reveal } from "@/components/ui";
import { EQUIPMENT } from "@/lib/data";
import { PlannedItem } from "@/lib/engine";
import { doableWith, planDrills, skillFit, SkillFit } from "@/lib/substitute";
import {
  currentStageIndex,
  resolveDrill,
  Skill,
  SKILLS,
  skillPercent,
} from "@/lib/skills";
import { useStore } from "@/lib/store";

const STATUS_RANK: Record<SkillFit["status"], number> = { full: 0, adapted: 1, partial: 2 };

function StatusBadge({ fit }: { fit: SkillFit }) {
  const labels = fit.missing.map((m) => EQUIPMENT.find((e) => e.id === m)?.label ?? m);
  if (fit.status === "full") {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-[rgba(205,248,63,0.14)] px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider text-[var(--volt)]">
        <Check size={9} strokeWidth={4} /> Fits your gear
      </span>
    );
  }
  if (fit.status === "adapted") {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-[rgba(255,199,64,0.15)] px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider text-[#ffc740]">
        <RefreshCw size={9} /> Adapts · {fit.adapted} swap{fit.adapted > 1 ? "s" : ""}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-[rgba(255,122,47,0.15)] px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider text-[var(--ember)]">
      <Lock size={9} /> Needs: {labels.slice(0, 2).join(", ")}
      {labels.length > 2 ? "…" : ""}
    </span>
  );
}

export default function SkillsPage() {
  const t = useT();
  const router = useRouter();
  const [openId, setOpenId] = useState<string | null>(null);
  const skillProgress = useStore((s) => s.skillProgress) ?? {};
  const equipment = useStore((s) => s.equipment);

  const available = useMemo(() => new Set(equipment), [equipment]);
  const open = SKILLS.find((s) => s.id === openId) ?? null;

  // Sort so fully-doable skills come first; adapted next; gear-blocked last.
  const ranked = useMemo(
    () =>
      SKILLS.map((s, i) => ({ s, i, fit: skillFit(s, available) })).sort(
        (a, b) => STATUS_RANK[a.fit.status] - STATUS_RANK[b.fit.status] || a.i - b.i
      ),
    [available]
  );
  const anyAdapted = ranked.some((r) => r.fit.status !== "full");

  if (open) {
    return (
      <SkillDetail skill={open} onBack={() => setOpenId(null)} onSelect={setOpenId} />
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <Reveal>
        <div className="flex items-center gap-3 pt-1">
          <button
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-2)]"
            onClick={() => router.push("/")}
            aria-label="Back"
          >
            <ArrowLeft size={16} />
          </button>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--volt)]">{t("pg.skillEyebrow")}
          </p>
            <h1 className="font-display text-[28px] uppercase leading-none tracking-wide">{t("pg.skillTitle")}
          </h1>
          </div>
        </div>
      </Reveal>

      <Reveal>
        <p className="text-[12px] leading-relaxed text-[var(--muted)]">
          Each skill is a staged roadmap with a clear standard to hit. Drills are matched to the
          equipment you own — missing gear gets an alternative, never an impossible session.
        </p>
      </Reveal>

      {anyAdapted && (
        <Reveal>
          <p className="text-[10px] font-semibold uppercase tracking-wider text-[var(--muted)]">
            Sorted so your doable skills come first
          </p>
        </Reveal>
      )}

      <div className="flex flex-col gap-3">
        {ranked.map(({ s, i, fit }, rank) => {
          const done = skillProgress[s.id] ?? [];
          const pct = skillPercent(s, done);
          const stageIdx = currentStageIndex(s, done);
          const complete = pct >= 1;
          return (
            <Reveal key={s.id} delay={rank * 35}>
              <button
                onClick={() => setOpenId(s.id)}
                className="card w-full overflow-hidden p-4 text-left transition-transform active:scale-[0.99]"
                style={complete ? { borderColor: `${s.color}66` } : undefined}
              >
                <div className="flex items-start gap-3">
                  <span
                    className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-2xl"
                    style={{ background: `${s.color}1a` }}
                  >
                    {s.icon}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p
                        className="font-display text-lg uppercase leading-none tracking-wide"
                        style={{ color: s.color }}
                      >
                        {s.name}
                      </p>
                      {complete && <Trophy size={14} className="text-[var(--volt)]" />}
                      <StatusBadge fit={fit} />
                    </div>
                    <p className="mt-1 text-[11px] leading-snug text-[var(--muted)]">{s.tagline}</p>
                    <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{ width: `${pct * 100}%`, background: s.color }}
                      />
                    </div>
                    <div className="mt-1.5 flex items-center justify-between">
                      <p className="tabular text-[10px] font-bold uppercase tracking-wider text-[var(--muted)]">
                        {complete
                          ? "Mastered"
                          : `Stage ${stageIdx + 1}/${s.stages.length} · ${s.stages[stageIdx].name}`}
                      </p>
                      <p className="text-[10px] font-semibold text-[var(--muted)]">{s.weeks}</p>
                    </div>
                  </div>
                </div>
              </button>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
}

/* ----------------------------- Detail view ----------------------------- */

function SkillDetail({
  skill,
  onBack,
  onSelect,
}: {
  skill: Skill;
  onBack: () => void;
  onSelect: (id: string) => void;
}) {
  const router = useRouter();
  const skillProgress = useStore((s) => s.skillProgress) ?? {};
  const toggleStage = useStore((s) => s.toggleStage);
  const startWorkout = useStore((s) => s.startWorkout);
  const equipment = useStore((s) => s.equipment);

  const available = useMemo(() => new Set(equipment), [equipment]);
  const fit = useMemo(() => skillFit(skill, available), [skill, available]);

  const done = skillProgress[skill.id] ?? [];
  const pct = skillPercent(skill, done);
  const activeIdx = currentStageIndex(skill, done);

  // Fully-doable alternatives when this skill needs gear you don't own.
  const alternatives = useMemo(
    () =>
      SKILLS.filter(
        (s) => s.id !== skill.id && skillFit(s, available).status === "full"
      ).slice(0, 4),
    [skill, available]
  );

  const missingLabels = fit.missing.map(
    (m) => EQUIPMENT.find((e) => e.id === m)?.label ?? m
  );

  const practise = (stageIdx: number) => {
    const stage = skill.stages[stageIdx];
    const items: PlannedItem[] = [];
    for (const plan of planDrills(stage.drills, available)) {
      if (plan.skipped || !plan.inLibrary) continue; // only doable library moves can drive the player
      const d = resolveDrill(plan.id);
      if (!d) continue;
      items.push({
        exerciseId: plan.id,
        sets: 3,
        reps: d.reps,
        sec: d.sec,
        rest: 45,
      });
    }
    if (!items.length) return;
    startWorkout(`${skill.name} · ${stage.name}`, items);
    router.push("/workout");
  };

  return (
    <div className="flex flex-col gap-4">
      <Reveal>
        <div className="flex items-center gap-3 pt-1">
          <button
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-2)]"
            onClick={onBack}
            aria-label="Back to skills"
          >
            <ArrowLeft size={16} />
          </button>
          <div className="flex min-w-0 items-center gap-2.5">
            <span
              className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-xl"
              style={{ background: `${skill.color}1a` }}
            >
              {skill.icon}
            </span>
            <div className="min-w-0">
              <h1
                className="font-display truncate text-[24px] uppercase leading-none tracking-wide"
                style={{ color: skill.color }}
              >
                {skill.name}
              </h1>
              <p className="text-[10px] font-semibold uppercase tracking-wider text-[var(--muted)]">
                {skill.weeks} · {done.length}/{skill.stages.length} stages
              </p>
            </div>
          </div>
        </div>
      </Reveal>

      <Reveal>
        <div className="card p-4">
          <p className="text-[12px] leading-relaxed text-[var(--muted)]">{skill.tagline}</p>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/[0.07]">
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{ width: `${pct * 100}%`, background: skill.color }}
            />
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {skill.equipment.map((e) => {
              const def = EQUIPMENT.find((x) => x.id === e);
              const have = equipment.includes(e);
              return (
                <span
                  key={e}
                  className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${
                    have
                      ? "bg-[rgba(205,248,63,0.14)] text-[var(--volt)]"
                      : "bg-white/[0.06] text-[var(--muted)]"
                  }`}
                >
                  {have ? "✓ " : ""}
                  {def?.label ?? e}
                </span>
              );
            })}
          </div>
        </div>
      </Reveal>

      {/* Equipment adaptation banner */}
      {fit.status === "full" && (
        <Reveal>
          <p className="flex items-center gap-1.5 text-[11px] font-semibold text-[var(--volt)]">
            <Check size={13} strokeWidth={3} /> All drills match the equipment you own
          </p>
        </Reveal>
      )}
      {fit.status !== "full" && (
        <Reveal>
          <div
            className="card p-4"
            style={{
              borderColor:
                fit.status === "adapted" ? "rgba(255,199,64,0.35)" : "rgba(255,122,47,0.35)",
              background:
                fit.status === "adapted" ? "rgba(255,199,64,0.05)" : "rgba(255,122,47,0.05)",
            }}
          >
            <p className="text-[12px] font-bold">
              {fit.status === "adapted" ? "Adapting to your gear" : "Some drills need gear you don't own"}
            </p>
            <p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">
              Missing: <b className="text-[var(--text)]">{missingLabels.join(", ")}</b>.{" "}
              {fit.adapted > 0 &&
                `${fit.adapted} drill${fit.adapted > 1 ? "s" : ""} swapped for alternatives below.`}
              {fit.skipped > 0 && ` ${fit.skipped} drill${fit.skipped > 1 ? "s" : ""} can't be done yet.`}
            </p>
            {fit.status === "partial" && alternatives.length > 0 && (
              <div className="mt-2.5">
                <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-[var(--muted)]">
                  Do this instead — needs no extra gear
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {alternatives.map((alt) => (
                    <button
                      key={alt.id}
                      className="chip !py-1.5 text-[11px] font-bold"
                      onClick={() => onSelect(alt.id)}
                    >
                      {alt.icon} {alt.name}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </Reveal>
      )}

      {/* Roadmap */}
      <div className="flex flex-col gap-2.5">
        {skill.stages.map((stage, i) => {
          const isDone = done.includes(stage.id);
          const isActive = i === activeIdx && !isDone;
          const locked = i > activeIdx && !isDone;
          const plans = planDrills(stage.drills, available);
          const usable = plans.filter((p) => !p.skipped && p.inLibrary).length;
          return (
            <Reveal key={stage.id} delay={i * 40}>
              <div
                className={`card relative overflow-hidden p-4 ${locked ? "opacity-60" : ""}`}
                style={isActive ? { borderColor: `${skill.color}66` } : undefined}
              >
                {/* Rail */}
                <div className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <span
                      className="grid h-7 w-7 shrink-0 place-items-center rounded-full text-[11px] font-extrabold"
                      style={{
                        background: isDone ? skill.color : isActive ? `${skill.color}26` : "rgba(255,255,255,0.06)",
                        color: isDone ? "#0b0c0e" : isActive ? skill.color : "var(--muted)",
                      }}
                    >
                      {isDone ? <Check size={13} strokeWidth={4} /> : locked ? <Lock size={11} /> : i + 1}
                    </span>
                    {i < skill.stages.length - 1 && (
                      <span
                        className="mt-1 w-px flex-1"
                        style={{ background: isDone ? `${skill.color}80` : "var(--line)" }}
                      />
                    )}
                  </div>

                  <div className="min-w-0 flex-1 pb-1">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-[14px] font-extrabold leading-tight">{stage.name}</p>
                      {isActive && (
                        <span
                          className="shrink-0 rounded-full px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider"
                          style={{ background: `${skill.color}26`, color: skill.color }}
                        >
                          Current
                        </span>
                      )}
                    </div>

                    <p className="mt-1.5 flex items-start gap-1.5 text-[12px] font-semibold leading-snug">
                      <Target size={13} className="mt-0.5 shrink-0" style={{ color: skill.color }} />
                      <span>{stage.goal}</span>
                    </p>
                    <p className="mt-1.5 text-[11px] leading-relaxed text-[var(--muted)]">
                      {stage.focus}
                    </p>
                    <p className="mt-1.5 text-[10px] font-bold uppercase tracking-wider text-[var(--muted)]">
                      {stage.frequency}
                    </p>

                    {/* Drills — adapted to the user's inventory */}
                    <div className="mt-2.5 flex flex-wrap gap-1.5">
                      {plans.map((plan) => {
                        const d = resolveDrill(plan.id);
                        const meta = d?.sec ? `${d.sec}s` : d?.reps ? `×${d.reps}` : "";
                        if (plan.skipped) {
                          return (
                            <span
                              key={plan.originalId}
                              className="rounded-full bg-white/[0.04] px-2.5 py-1 text-[10px] font-semibold text-[var(--muted)] line-through opacity-70"
                              title={`Needs gear you don't own: ${plan.originalName}`}
                            >
                              <Lock size={9} className="mr-1 inline" />
                              {plan.originalName}
                            </span>
                          );
                        }
                        if (plan.substituted) {
                          return (
                            <span
                              key={`${plan.originalId}-sub`}
                              className="rounded-full bg-[rgba(205,248,63,0.12)] px-2.5 py-1 text-[10px] font-semibold text-[var(--volt)]"
                              title={`Instead of ${plan.originalName}`}
                            >
                              <RefreshCw size={9} className="mr-1 inline" />
                              {plan.name} {meta}
                            </span>
                          );
                        }
                        return (
                          <span
                            key={plan.originalId}
                            className="rounded-full bg-white/[0.06] px-2.5 py-1 text-[10px] font-semibold text-[var(--muted)]"
                            title={d?.cue}
                          >
                            {plan.name} {meta}
                          </span>
                        );
                      })}
                    </div>

                    <div className="mt-3 flex gap-2">
                      <button
                        className={`btn h-9 flex-1 text-[12px] ${usable > 0 ? "btn-ghost" : "btn-ghost opacity-40"}`}
                        onClick={() => practise(i)}
                        disabled={usable === 0}
                      >
                        <Play size={13} /> {usable > 0 ? "Practise" : "No drills available"}
                      </button>
                      <button
                        className={`btn h-9 flex-1 text-[12px] ${isDone ? "btn-ghost" : "btn-volt"}`}
                        onClick={() => toggleStage(skill.id, stage.id)}
                      >
                        {isDone ? (
                          <>
                            <CircleDot size={13} /> Undo
                          </>
                        ) : (
                          <>
                            <Flag size={13} /> Mark done
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          );
        })}
      </div>

      {pct >= 1 && (
        <div className="anim-pop card flex flex-col items-center gap-2 p-6 text-center">
          <Trophy size={30} style={{ color: skill.color }} />
          <p className="font-display text-xl uppercase tracking-wide">Skill mastered</p>
          <p className="text-[12px] text-[var(--muted)]">
            You&apos;ve completed every stage of {skill.name}. Keep it sharp with weekly practice.
          </p>
        </div>
      )}

      {fit.missing.length > 0 && alternatives.length > 0 && (
        <div>
          <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[var(--muted)]">
            Other skills you can start right now
          </p>
          <div className="flex flex-wrap gap-1.5">
            {alternatives.map((alt) => (
              <button key={alt.id} className="chip !py-1.5 text-[11px] font-bold" onClick={() => onSelect(alt.id)}>
                {alt.icon} {alt.name}
              </button>
            ))}
          </div>
        </div>
      )}

      <button className="btn btn-ghost h-11 w-full text-sm" onClick={onBack}>
        <Plus size={15} /> Browse other skills
      </button>
    </div>
  );
}
