"use client";

import {
  Activity,
  ArrowRight,
  BellRing,
  Bolt,
  Check,
  CloudOff,
  Crown,
  Droplets,
  Flame,
  Minus,
  Play,
  Plus,
  Scale,
  Shield,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Trophy,
  UserRound,
  UtensilsCrossed,
  Zap,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useT } from "@/lib/i18n";
import { useEffect, useMemo, useState } from "react";
import { Ring, Reveal, Sheet } from "@/components/ui";
import { AuthSheet } from "@/components/auth-sheet";
import { PaywallSheet, useAccess } from "@/components/paywall";
import { BUNDLED_MOBILE, loadSession } from "@/lib/auth";
import { summarize } from "@/lib/achievements";
import { wDeltaOut, wIn, wOut, wUnit } from "@/lib/units";
import { addDays, calcTargets, dateKey, projectGoal, recoveryAdvice, streakOf, weekDates } from "@/lib/engine";
import { DEFAULT_HYDRATION, vesselsForGoal } from "@/lib/engine";
import { currentStageIndex, SKILLS, skillPercent } from "@/lib/skills";
import { readinessOf } from "@/lib/recovery";
import { strengthClass } from "@/lib/standards";
import { useStore, WorkoutLog } from "@/lib/store";

const HERO_IMG =
  "https://images.pexels.com/photos/4753885/pexels-photo-4753885.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200";

export default function Dashboard() {
  const t = useT();
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const router = useRouter();
  const profile = useStore((s) => s.profile);
  const meals = useStore((s) => s.meals);
  const logs = useStore((s) => s.logs);
  const schedule = useStore((s) => s.schedule);
  const routines = useStore((s) => s.routines);
  const water = useStore((s) => s.water);
  const setWater = useStore((s) => s.setWater);
  const startWorkout = useStore((s) => s.startWorkout);
  const weights = useStore((s) => s.weights);
  const logWeight = useStore((s) => s.logWeight);
  const setProfile = useStore((s) => s.setProfile);
  const reminder = useStore((s) => s.reminder);
  const checkins = useStore((s) => s.checkins);

  const [weightSheet, setWeightSheet] = useState(false);
  const [payOpen, setPayOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [signedIn, setSignedIn] = useState(true); // assume yes until checked, avoids flash
  const access = useAccess();

  useEffect(() => {
    setSignedIn(Boolean(loadSession()));
  }, [authOpen]);
  const [kgInput, setKgInput] = useState("");

  const today = dateKey();
  const targets = useMemo(
    () =>
      profile
        ? calcTargets(profile)
        : { calories: 2200, protein: 120, carbs: 240, fat: 61, bmr: 0, maintenance: 2200, delta: 0 },
    [profile]
  );

  const dayMeals = meals.filter((m) => m.date === today);
  const eaten = dayMeals.reduce((s, m) => s + m.cal * m.qty, 0);
  const p = dayMeals.reduce((s, m) => s + m.p * m.qty, 0);
  const c = dayMeals.reduce((s, m) => s + m.c * m.qty, 0);
  const f = dayMeals.reduce((s, m) => s + m.f * m.qty, 0);
  const kcalLeft = Math.max(0, targets.calories - eaten);
  const burnedToday = logs.filter((l) => l.date === today).reduce((s, l) => s + l.kcal, 0);

  const streak = streakOf(logs.map((l) => l.date));
  const week = weekDates(0);
  const logsByDay = new Set(logs.map((l) => l.date));

  const assigned = schedule[today];
  const routine = assigned && assigned !== "rest" ? routines.find((r) => r.id === assigned) : null;
  const isRest = assigned === "rest";
  const glasses = water[today] ?? 0;
  const hydration = useStore((st) => st.hydration) ?? DEFAULT_HYDRATION;
  const targetVessels = vesselsForGoal(hydration);
  const drunkMl = glasses * hydration.vesselMl;

  // Weekly calorie intake per day
  const weekCal = week.map((d) => ({
    ...d,
    eaten: meals.filter((m) => m.date === d.key).reduce((s, m) => s + m.cal * m.qty, 0),
  }));
  const calCeil = Math.max(targets.calories, ...weekCal.map((d) => d.eaten), 1);

  // Weight trend
  const latestWeight = weights[0];
  const prevWeight = weights[1];
  const weightDelta =
    latestWeight && prevWeight
      ? Math.round((latestWeight.kg - prevWeight.kg) * 10) / 10
      : null;
  const spark = weights
    .slice(0, 14)
    .map((w) => w.kg)
    .reverse();

  // Lifetime totals
  const totalSessions = logs.length;
  const totalBurned = logs.reduce((s, l) => s + l.kcal, 0);

  // Reminder due?
  const remindDue = (() => {
    if (!reminder?.enabled) return false;
    const [h, m] = (reminder.time || "07:00").split(":").map(Number);
    const at = new Date();
    at.setHours(h ?? 7, m ?? 0, 0, 0);
    return new Date() >= at && !logs.some((l) => l.date === today);
  })();

  // Last 7 days report
  const days7 = Array.from({ length: 7 }, (_, i) => dateKey(addDays(new Date(), -i)));
  const daySet7 = new Set(days7);
  const intake7 = days7
    .map((k) => meals.filter((m) => m.date === k).reduce((s, m) => s + m.cal * m.qty, 0))
    .filter((v) => v > 0);
  const avgIntake = intake7.length
    ? Math.round(intake7.reduce((a, b) => a + b, 0) / intake7.length)
    : 0;
  const sessions7 = logs.filter((l) => daySet7.has(l.date)).length;
  const burned7 = logs.filter((l) => daySet7.has(l.date)).reduce((s, l) => s + l.kcal, 0);
  const wIn7 = weights.filter((w) => daySet7.has(w.date));
  const weightDelta7 =
    wIn7.length >= 2 ? Math.round((wIn7[0].kg - wIn7[wIn7.length - 1].kg) * 10) / 10 : null;
  const recovery = recoveryAdvice(logs);
  const todayCheckin = checkins.find((x) => x.date === today);
  const readiness = readinessOf(todayCheckin);

  const measurements = useStore((s) => s.measurements);
  const skillProgress = useStore((s) => s.skillProgress);
  const progression = useMemo(
    () => summarize({ logs, meals, weights, measurements, water, skillProgress, hydration, checkins }),
    [logs, meals, weights, measurements, water, skillProgress, hydration, checkins]
  );

  const strength = useMemo(
    () =>
      strengthClass(logs, weights[0]?.kg ?? profile?.weightKg ?? 70, profile?.sex ?? "male"),
    [logs, weights, profile]
  );

  // Goal projection from weight trend + intake
  const goalProj = useMemo(
    () =>
      projectGoal({
        weights,
        goal: profile?.goal ?? "maintain",
        goalWeightKg: profile?.goalWeightKg,
        profile,
        avgIntake7: avgIntake,
      }),
    [weights, profile, avgIntake]
  );

  // Most-advanced in-progress skill for the dashboard card
  const activeSkill = useMemo(() => {
    const entries = Object.entries(skillProgress ?? {}).filter(([, v]) => v.length > 0);
    if (!entries.length) return null;
    const [id, doneStages] = entries.sort((a, b) => b[1].length - a[1].length)[0];
    const skill = SKILLS.find((s) => s.id === id);
    if (!skill) return null;
    return {
      skill,
      pct: skillPercent(skill, doneStages),
      stageIdx: currentStageIndex(skill, doneStages),
    };
  }, [skillProgress]);

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return t("greet.morning");
    if (h < 17) return t("greet.afternoon");
    return t("greet.evening");
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Greeting */}
      <Reveal>
        <div className="flex items-end justify-between pt-1">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--muted)]">
              {new Date().toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" })}
            </p>
            <h1 className="font-display mt-1 text-[32px] uppercase leading-none tracking-wide">
              {greeting()}
              {profile?.name ? `, ${profile.name.split(" ")[0]}` : ""}
            </h1>
          </div>
          <div className="card-2 flex items-center gap-1.5 rounded-full px-3 py-2">
            <Flame size={15} className={streak > 0 ? "text-[var(--ember)]" : "text-[var(--muted)]"} />
            <span className="tabular text-sm font-extrabold">{streak}</span>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-[var(--muted)]">day</span>
          </div>
        </div>
      </Reveal>

      {/* Back up your data */}
      {!BUNDLED_MOBILE && !signedIn && profile?.onboarded && (logs.length > 0 || meals.length > 0) && (
        <Reveal>
          <button
            onClick={() => setAuthOpen(true)}
            className="card flex w-full items-center gap-3 p-4 text-left"
          >
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-[var(--aqua)]">
              <CloudOff size={18} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[13px] font-bold">Your data isn&apos;t backed up</p>
              <p className="text-[11px] leading-snug text-[var(--muted)]">
                Create a free account to keep it if you change phones
              </p>
            </div>
            <span className="shrink-0 rounded-full border border-[var(--line)] bg-[var(--surface-2)] px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wider">
              Save
            </span>
          </button>
        </Reveal>
      )}

      {/* Trial / upgrade banner */}
      {(!access.isPro || (access.inTrial && (access.daysLeft ?? 9) <= 3)) && profile?.onboarded && (
        <Reveal>
          <button
            onClick={() => setPayOpen(true)}
            className="card flex w-full items-center gap-3 border-[rgba(205,248,63,0.3)] bg-[rgba(205,248,63,0.05)] p-4 text-left"
          >
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[var(--volt)] text-[#0b0c0e]">
              <Crown size={18} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[13px] font-bold">
                {access.inTrial ? access.label : "Unlock FORGE Pro"}
              </p>
              <p className="text-[11px] leading-snug text-[var(--muted)]">
                {access.inTrial
                  ? "Upgrade now to keep standards, skills and photos."
                  : "Skills, strength ranks, full food database & more."}
              </p>
            </div>
            <span className="shrink-0 rounded-full bg-[var(--volt)] px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wider text-[#0b0c0e]">
              {access.inTrial ? "Keep Pro" : "Upgrade"}
            </span>
          </button>
        </Reveal>
      )}

      {/* Reminder banner */}
      {remindDue && profile?.onboarded && (
        <Reveal>
          <div className="card flex items-center gap-3 border-[rgba(205,248,63,0.35)] bg-[rgba(205,248,63,0.05)] p-4">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[var(--volt)] text-[#0b0c0e]">
              <BellRing size={18} />
            </div>
            <p className="flex-1 text-[13px] font-semibold leading-snug">
              It&apos;s training time —{" "}
              {routine ? `${routine.name} is ready` : "forge today's session"}.
            </p>
            <button
              className="btn btn-volt h-9 px-4 text-[12px]"
              onClick={() => {
                if (routine) {
                  startWorkout(routine.name, routine.items);
                  router.push("/workout");
                } else {
                  router.push("/generator");
                }
              }}
            >
              <Play size={14} fill="currentColor" /> Go
            </button>
          </div>
        </Reveal>
      )}

      {/* Onboarding nudge */}
      {!profile?.onboarded && (
        <Reveal>
          <button
            onClick={() => router.push("/profile")}
            className="card flex w-full items-center gap-3 p-4 text-left"
          >
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--volt)] text-[#0b0c0e]">
              <UserRound size={20} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">Set up your athlete profile</p>
              <p className="text-xs text-[var(--muted)]">
                Unlock precise calorie targets & the workout generator
              </p>
            </div>
            <ArrowRight size={18} className="text-[var(--volt)]" />
          </button>
        </Reveal>
      )}

      {/* Daily readiness */}
      <Reveal>
        <button
          onClick={() => router.push("/recovery")}
          className="card flex w-full items-center gap-4 p-4 text-left"
        >
          <Ring size={74} stroke={7} value={todayCheckin ? readiness.score / 100 : 0} color={readiness.color}>
            <div className="text-center">
              {todayCheckin ? (
                <p className="font-display tabular text-xl leading-none">{readiness.score}</p>
              ) : (
                <Activity size={18} className="text-[var(--muted)]" />
              )}
            </div>
          </Ring>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--muted)]">
                {t("dash.readiness")}
              </p>
              {todayCheckin && (
                <span
                  className="rounded-full px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider"
                  style={{ color: readiness.color, background: `color-mix(in srgb, ${readiness.color} 14%, transparent)` }}
                >
                  {readiness.label}
                </span>
              )}
            </div>
            <p className="mt-1 text-sm font-extrabold">
              {todayCheckin ? readiness.headline : t("dash.howRecovered")}
            </p>
            <p className="mt-0.5 line-clamp-2 text-[11px] leading-snug text-[var(--muted)]">
              {todayCheckin
                ? readiness.guidance
                : t("dash.checkinCta")}
            </p>
          </div>
          <ArrowRight size={16} className="shrink-0 text-[var(--muted)]" />
        </button>
      </Reveal>

      {/* Today's training hero */}
      <Reveal>
        <div className="card relative overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={HERO_IMG}
            alt=""
            aria-hidden
            className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-[rgba(10,11,13,0.45)]" />
          <div className="relative p-5">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--volt)]">
              {t("dash.training")}
            </p>
            {routine ? (
              <>
                <h2 className="font-display mt-2 text-[34px] uppercase leading-[0.95] tracking-wide">
                  {routine.name}
                </h2>
                <p className="mt-1.5 text-[13px] font-medium text-white/70">
                  {routine.items.length} exercises ·{" "}
                  {routine.items.reduce((s, i) => s + i.sets, 0)} sets
                </p>
                <button
                  className="btn btn-volt mt-5 h-12 w-full text-[15px]"
                  onClick={() => {
                    startWorkout(routine.name, routine.items);
                    router.push("/workout");
                  }}
                >
                  <Play size={18} fill="currentColor" /> {t("dash.startWorkout")}
                </button>
              </>
            ) : isRest ? (
              <>
                <h2 className="font-display mt-2 text-[34px] uppercase leading-[0.95] tracking-wide">
                  {t("dash.restDay")}
                </h2>
                <p className="mt-1.5 text-[13px] font-medium text-white/70">
                  {t("dash.recoverHint")}
                </p>
                <button
                  className="btn btn-ghost mt-5 h-12 w-full text-[15px]"
                  onClick={() => router.push("/planner")}
                >
                  <CalendarIcon /> {t("dash.changePlan")}
                </button>
              </>
            ) : (
              <>
                <h2 className="font-display mt-2 text-[34px] uppercase leading-[0.95] tracking-wide">
                  {t("dash.nothingPlanned")}
                </h2>
                <p className="mt-1.5 text-[13px] font-medium text-white/70">
                  {t("dash.generateCta")}
                </p>
                <button
                  className="btn btn-volt mt-5 h-12 w-full text-[15px]"
                  onClick={() => router.push("/generator")}
                >
                  <Zap size={18} /> {t("dash.forgeWorkout")}
                </button>
              </>
            )}
          </div>
        </div>
      </Reveal>

      {/* Calories */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-4 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              {t("dash.fuel")}
            </p>
            <button
              onClick={() => router.push("/nutrition")}
              className="chip chip-on !px-3 !py-1.5 text-[11px] font-bold"
            >
              <Plus size={13} strokeWidth={3} /> {t("dash.logFood")}
            </button>
          </div>
          <div className="flex items-center gap-5">
            <Ring size={118} stroke={11} value={eaten / targets.calories} color="var(--volt)">
              <div className="text-center">
                <p className="font-display tabular text-[26px] leading-none">{Math.round(kcalLeft)}</p>
                <p className="mt-0.5 text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">
                  {t("dash.kcalLeft")}
                </p>
              </div>
            </Ring>
            <div className="min-w-0 flex-1">
              <div className="mb-3 flex items-baseline justify-between">
                <span className="text-[13px] text-[var(--muted)]">
                  {t("dash.eaten")} <span className="tabular font-bold text-[var(--text)]">{Math.round(eaten)}</span>
                  {burnedToday > 0 && (
                    <span className="text-[var(--ember)]"> · −{burnedToday} burned</span>
                  )}
                </span>
                <span className="tabular text-[13px] font-bold">{targets.calories} goal</span>
              </div>
              <div className="flex flex-col gap-2.5">
                <MacroLine label="Protein" v={p} max={targets.protein} color="var(--volt)" />
                <MacroLine label="Carbs" v={c} max={targets.carbs} color="var(--aqua)" />
                <MacroLine label="Fat" v={f} max={targets.fat} color="var(--ember)" />
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      {/* Quick stats row */}
      <Reveal>
        <div className="grid grid-cols-2 gap-3">
          <div className="card flex flex-col justify-between gap-3 p-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--muted)]">{t("dash.water")}</span>
              <Droplets size={15} className="text-[var(--aqua)]" />
            </div>
            <p className="tabular font-display text-2xl leading-none">
              {glasses}
              <span className="text-sm text-[var(--muted)]"> / {targetVessels}</span>
            </p>
            <p className="tabular -mt-1 text-[10px] text-[var(--muted)]">
              {drunkMl} / {hydration.goalMl} ml
            </p>
            <div className="flex gap-2">
              <button
                className="btn btn-ghost h-9 flex-1"
                onClick={() => setWater(today, glasses - 1)}
                aria-label="Remove glass"
              >
                <Minus size={15} />
              </button>
              <button
                className="btn h-9 flex-1 bg-[rgba(92,214,255,0.15)] text-[var(--aqua)]"
                onClick={() => setWater(today, glasses + 1)}
                aria-label="Add glass"
              >
                <Plus size={15} strokeWidth={3} />
              </button>
            </div>
          </div>

          <div className="card flex flex-col justify-between gap-1 p-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--muted)]">
                {t("dash.thisWeek")}
              </span>
              <Bolt size={15} className="text-[var(--volt)]" />
            </div>
            <p className="tabular font-display text-2xl leading-none">
              {week.filter((d) => logsByDay.has(d.key)).length}
              <span className="text-sm text-[var(--muted)]"> / 7 trained</span>
            </p>
            <div className="flex justify-between pt-1">
              {week.map((d) => (
                <div key={d.key} className="flex flex-col items-center gap-1">
                  <span
                    className={`grid h-6 w-6 place-items-center rounded-full text-[9px] font-bold ${
                      logsByDay.has(d.key)
                        ? "bg-[var(--volt)] text-[#0b0c0e]"
                        : d.isToday
                          ? "border border-[var(--volt)] text-[var(--volt)]"
                          : "bg-white/5 text-[var(--muted)]"
                    }`}
                  >
                    {logsByDay.has(d.key) ? <Check size={11} strokeWidth={4} /> : d.dow}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Reveal>

      {/* Weekly calories */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-4 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Calories this week
            </p>
            <span className="tabular text-[11px] font-bold text-[var(--muted)]">
              goal <span className="text-[var(--volt)]">{targets.calories}</span>
            </span>
          </div>
          <div className="relative">
            <div
              className="absolute inset-x-0 border-t border-dashed border-white/25"
              style={{ bottom: `${(targets.calories / calCeil) * 100}%` }}
            />
            <div className="flex h-24 items-end gap-2">
              {weekCal.map((d) => {
                const pct = Math.min(100, (d.eaten / calCeil) * 100);
                const over = d.eaten > targets.calories;
                return (
                  <div key={d.key} className="flex h-full flex-1 flex-col items-center justify-end gap-1.5">
                    <div className="flex w-full flex-1 flex-col justify-end">
                      <div
                        className={`w-full rounded-t-[6px] transition-all duration-700 ${
                          d.eaten === 0
                            ? "bg-white/[0.06]"
                            : over
                              ? "bg-[var(--ember)]"
                              : "bg-[var(--volt)]"
                        }`}
                        style={{ height: `${Math.max(pct, 3)}%`, opacity: d.isToday ? 1 : 0.75 }}
                      />
                    </div>
                    <span
                      className={`text-[9px] font-bold uppercase ${
                        d.isToday ? "text-[var(--volt)]" : "text-[var(--muted)]"
                      }`}
                    >
                      {d.dow}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </Reveal>

      {/* Weight + lifetime stats */}
      <Reveal>
        <div className="grid grid-cols-5 gap-3">
          <div className="card col-span-3 flex flex-col justify-between gap-3 p-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--muted)]">
                Body weight
              </span>
              {weightDelta !== null && (
                <span
                  className={`flex items-center gap-0.5 rounded-full px-2 py-0.5 text-[10px] font-bold ${
                    weightDelta <= 0
                      ? "bg-[rgba(205,248,63,0.12)] text-[var(--volt)]"
                      : "bg-[rgba(255,122,47,0.12)] text-[var(--ember)]"
                  }`}
                >
                  {weightDelta <= 0 ? <TrendingDown size={11} /> : <TrendingUp size={11} />}
                  {weightDelta > 0 ? "+" : ""}
                  {wDeltaOut(weightDelta, sys)} {wUnit(sys)}
                </span>
              )}
            </div>
            <div className="flex items-end justify-between gap-2">
              <div>
                <p className="font-display tabular text-3xl leading-none">
                  {latestWeight
                    ? wOut(latestWeight.kg, sys)
                    : profile?.weightKg
                      ? wOut(profile.weightKg, sys)
                      : "—"}
                  <span className="text-sm text-[var(--muted)]"> {wUnit(sys)}</span>
                </p>
                <p className="mt-1 text-[10px] text-[var(--muted)]">
                  {latestWeight
                    ? `Last: ${new Date(latestWeight.date + "T00:00").toLocaleDateString(undefined, { day: "numeric", month: "short" })}`
                    : "No entries yet"}
                </p>
              </div>
              {spark.length > 1 && <Sparkline points={spark} />}
            </div>
            <button
              className="btn btn-ghost h-9 w-full text-[12px]"
              onClick={() => {
                setKgInput(String(wOut(latestWeight?.kg ?? profile?.weightKg ?? 70, sys)));
                setWeightSheet(true);
              }}
            >
              <Scale size={14} /> Log weight
            </button>
          </div>

          <div className="card col-span-2 flex flex-col justify-between p-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--muted)]">
                All time
              </span>
              <Trophy size={14} className="text-[var(--volt)]" />
            </div>
            <div className="mt-2 flex flex-col gap-3">
              <div>
                <p className="tabular font-display text-2xl leading-none">{totalSessions}</p>
                <p className="mt-0.5 text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">
                  sessions
                </p>
              </div>
              <div>
                <p className="tabular font-display text-2xl leading-none">
                  {totalBurned >= 1000 ? `${(totalBurned / 1000).toFixed(1)}k` : totalBurned}
                </p>
                <p className="mt-0.5 text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">
                  kcal burned
                </p>
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      {/* Last 7 days + recovery coach */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Last 7 days
            </p>
            <Activity size={14} className="text-[var(--volt)]" />
          </div>
          <div className="grid grid-cols-4 gap-2">
            {[
              { v: String(sessions7), l: "sessions" },
              { v: avgIntake ? `${avgIntake}` : "—", l: "avg kcal" },
              { v: burned7 >= 1000 ? `${(burned7 / 1000).toFixed(1)}k` : String(burned7), l: "burned" },
              {
                v:
                  weightDelta7 === null
                    ? "—"
                    : `${weightDelta7 > 0 ? "+" : ""}${wDeltaOut(weightDelta7, sys)}`,
                l: `${wUnit(sys)} Δ`,
              },
            ].map((s) => (
              <div key={s.l} className="card-2 p-2.5 text-center">
                <p className="font-display tabular text-lg leading-tight">{s.v}</p>
                <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">{s.l}</p>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-start gap-2.5 border-t border-[var(--line)] pt-3.5">
            <span
              className={`mt-0.5 shrink-0 rounded-full px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider ${
                recovery.verdict === "deload"
                  ? "bg-[rgba(255,122,47,0.15)] text-[var(--ember)]"
                  : recovery.verdict === "push"
                    ? "bg-[rgba(205,248,63,0.15)] text-[var(--volt)]"
                    : "bg-white/[0.07] text-[var(--muted)]"
              }`}
            >
              Coach: {recovery.label}
            </span>
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">{recovery.hint}</p>
          </div>
        </div>
      </Reveal>

      {/* Skills */}
      <Reveal>
        <button
          onClick={() => router.push("/skills")}
          className="card flex w-full items-center gap-3 p-4 text-left"
        >
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-xl">
            {activeSkill ? activeSkill.skill.icon : "🥊"}
          </div>
          <div className="min-w-0 flex-1">
            {activeSkill ? (
              <>
                <p className="truncate text-sm font-bold">
                  {activeSkill.skill.name}
                  <span className="ml-1.5 text-[11px] font-semibold text-[var(--muted)]">
                    stage {activeSkill.stageIdx + 1}/{activeSkill.skill.stages.length}
                  </span>
                </p>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/[0.08]">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${activeSkill.pct * 100}%`, background: activeSkill.skill.color }}
                  />
                </div>
                <p className="mt-1 truncate text-[10px] text-[var(--muted)]">
                  Next: {activeSkill.skill.stages[activeSkill.stageIdx].name}
                </p>
              </>
            ) : (
              <>
                <p className="text-sm font-bold">Learn a skill</p>
                <p className="text-[11px] text-[var(--muted)]">
                  Boxing · Pull-ups · Handstand · Kettlebell · Mobility
                </p>
              </>
            )}
          </div>
          <ArrowRight size={16} className="shrink-0 text-[var(--muted)]" />
        </button>
      </Reveal>

      {/* Goal projection */}
      <Reveal>
        <div className="card p-4">
          <div className="flex items-center justify-between gap-3">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              {t("dash.goalProjection")}
            </p>
            {profile && profile.goal !== "maintain" ? (
              profile.goalWeightKg ? (
                <span className="tabular text-[12px] font-extrabold text-[var(--volt)]">
                  {wOut(profile.goalWeightKg, sys)} {wUnit(sys)}
                </span>
              ) : (
                <input
                  type="number"
                  inputMode="decimal"
                  className="field !w-28 !py-1.5 text-center text-[12px]"
                  placeholder={`goal ${wUnit(sys)}`}
                  onBlur={(e) => {
                    const v = wIn(Number(e.target.value), sys);
                    if (profile && v > 20) setProfile({ ...profile, goalWeightKg: v });
                  }}
                />
              )
            ) : null}
          </div>

          <div className="mt-3 flex items-end justify-between gap-3">
            <div className="min-w-0">
              <p className="font-display truncate text-2xl uppercase leading-none">
                {goalProj.eta ??
                  (goalProj.direction === "stable"
                    ? t("dash.holding")
                    : goalProj.direction === "away"
                      ? t("dash.offPace")
                      : t("dash.setAGoal"))}
              </p>
              {goalProj.direction === "toward" && goalProj.weeklyRate !== 0 && (
                <p className="tabular mt-1 text-[11px] text-[var(--muted)]">
                  {goalProj.weeklyRate > 0 ? "+" : ""}{goalProj.weeklyRate} kg/week · {" "}
                  {goalProj.basis === "trend" ? t("dash.fromWeighins") : t("dash.fromIntake")}
                </p>
              )}
            </div>
            {goalProj.eta && goalProj.daysLeft !== null && (
              <span className="shrink-0 rounded-full bg-[rgba(205,248,63,0.14)] px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-[var(--volt)]">
                {goalProj.daysLeft} {t("dash.days")}
              </span>
            )}
          </div>
          <p className="mt-2 border-t border-[var(--line)] pt-2.5 text-[11px] leading-relaxed text-[var(--muted)]">
            {goalProj.message}
          </p>
        </div>
      </Reveal>

      {/* Rank card */}
      <Reveal>
        <button
          onClick={() => router.push("/ranks")}
          className="card relative w-full overflow-hidden p-4 text-left"
          style={{ boxShadow: `0 18px 50px -34px ${progression.rank.rank.glow}` }}
        >
          <div
            className="pointer-events-none absolute -right-6 -top-10 h-32 w-32 rounded-full blur-3xl"
            style={{ background: progression.rank.rank.glow }}
          />
          <div className="relative flex items-center gap-3.5">
            <div
              className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl"
              style={{ background: `${progression.rank.rank.color}1f`, color: progression.rank.rank.color }}
            >
              <Shield size={22} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline gap-2">
                <p
                  className="font-display text-xl uppercase leading-none tracking-wide"
                  style={{ color: progression.rank.rank.color }}
                >
                  {progression.rank.rank.name}
                </p>
                <span className="text-[9px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
                  Tier {progression.rank.rank.tier}
                </span>
              </div>
              <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/[0.08]">
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{
                    width: `${progression.rank.progress * 100}%`,
                    background: progression.rank.rank.color,
                  }}
                />
              </div>
              <p className="tabular mt-1 text-[10px] font-semibold text-[var(--muted)]">
                {progression.xp.total.toLocaleString()} XP
                {progression.rank.next
                  ? ` · ${progression.rank.xpToNext.toLocaleString()} to ${progression.rank.next.name}`
                  : " · max rank"}
                {" · "}
                {progression.unlocked.length}/{progression.achievements.length} badges
              </p>
              <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wider">
                {strength.tested.length > 0 ? (
                  <>
                    <span style={{ color: strength.level.color }}>{strength.level.name}</span>
                    <span className="text-[var(--muted)]"> strength class</span>
                  </>
                ) : (
                  <span className="text-[var(--ember)]">Tap to log a lift & get rated</span>
                )}
              </p>
            </div>
            <ArrowRight size={16} className="shrink-0 text-[var(--muted)]" />
          </div>
        </button>
      </Reveal>

      {/* Consistency heatmap */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Consistency · last 24 weeks
            </p>
            <span className="text-[10px] font-semibold text-[var(--muted)]">less · more</span>
          </div>
          <ConsistencyMap logs={logs} />
        </div>
      </Reveal>

      {/* Recent activity */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              {t("dash.recent")}
            </p>
            <Sparkles size={14} className="text-[var(--volt)]" />
          </div>
          {logs.length === 0 ? (
            <p className="py-3 text-center text-[13px] text-[var(--muted)]">
              No sessions yet — your grind history will live here.
            </p>
          ) : (
            <div className="flex flex-col divide-y divide-[var(--line)]">
              {logs.slice(0, 4).map((l) => (
                <div key={l.id} className="flex items-center gap-3 py-3">
                  <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-[var(--volt)]">
                    <Zap size={17} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold">{l.name}</p>
                    <p className="text-xs text-[var(--muted)]">
                      {l.minutes} {t("dash.min")} · {l.setsDone}/{l.totalSets} {t("dash.sets")}
                      {l.rpe ? ` · RPE ${l.rpe}` : ""}
                    </p>
                  </div>
                  <span className="tabular text-sm font-bold text-[var(--ember)]">−{l.kcal}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </Reveal>

      {/* Quick meal */}
      <Reveal>
        <button
          onClick={() => router.push("/nutrition")}
          className="card flex w-full items-center gap-3 p-4 text-left"
        >
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-[var(--ember)]">
            <UtensilsCrossed size={19} />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold">Log a meal</p>
            <p className="text-xs text-[var(--muted)]">
              {dayMeals.length === 0 ? "Nothing logged yet today" : `${dayMeals.length} item${dayMeals.length > 1 ? "s" : ""} logged today`}
            </p>
          </div>
          <ArrowRight size={18} className="text-[var(--muted)]" />
        </button>
      </Reveal>

      <PaywallSheet open={payOpen} onClose={() => setPayOpen(false)} />
      <AuthSheet open={authOpen} onClose={() => setAuthOpen(false)} />

      {/* Log weight sheet */}
      <Sheet open={weightSheet} onClose={() => setWeightSheet(false)} title="Log weight">
        <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
          Today&apos;s weight ({wUnit(sys)})
        </label>
        <input
          className="field font-display !text-3xl tracking-wide"
          type="number"
          inputMode="decimal"
          step="0.1"
          value={kgInput}
          onChange={(e) => setKgInput(e.target.value)}
        />
        <p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">
          Weigh yourself in the morning, after the bathroom, before breakfast — that keeps the trend
          honest.
        </p>
        <button
          className="btn btn-volt mt-4 h-12 w-full"
          onClick={() => {
            const kg = Number(kgInput);
            if (kg > 0) logWeight(today, wIn(kg, sys));
            setWeightSheet(false);
          }}
        >
          <Check size={17} strokeWidth={3} /> Save entry
        </button>
      </Sheet>
    </div>
  );
}

function ConsistencyMap({ logs }: { logs: WorkoutLog[] }) {
  const counts = new Map<string, number>();
  for (const l of logs) counts.set(l.date, (counts.get(l.date) ?? 0) + 1);

  const today = new Date();
  const thisMonday = addDays(today, -((today.getDay() + 6) % 7));
  const cols: { key: string; n: number; future: boolean }[][] = [];
  for (let w = 23; w >= 0; w--) {
    const col: { key: string; n: number; future: boolean }[] = [];
    for (let d = 0; d < 7; d++) {
      const date = addDays(thisMonday, -w * 7 + d);
      col.push({ key: dateKey(date), n: counts.get(dateKey(date)) ?? 0, future: date > today });
    }
    cols.push(col);
  }

  return (
    <div className="grid grid-flow-col grid-rows-7 gap-[3px]">
      {cols.flatMap((col, ci) =>
        col.map((cell) => (
          <div
            key={`${ci}-${cell.key}`}
            title={cell.key}
            className="h-[11px] w-full rounded-[3px]"
            style={{
              background: cell.future
                ? "transparent"
                : cell.n === 0
                  ? "rgba(255,255,255,0.06)"
                  : cell.n === 1
                    ? "rgba(205,248,63,0.45)"
                    : "var(--volt)",
            }}
          />
        ))
      )}
    </div>
  );
}

function Sparkline({ points }: { points: number[] }) {
  const w = 84;
  const h = 34;
  const min = Math.min(...points);
  const max = Math.max(...points);
  const span = Math.max(0.1, max - min);
  const coords = points.map((p, i) => {
    const x = (i / (points.length - 1)) * (w - 4) + 2;
    const y = h - 4 - ((p - min) / span) * (h - 8);
    return [x, y] as const;
  });
  const path = coords.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const last = coords[coords.length - 1];
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="shrink-0">
      <path d={path} fill="none" stroke="var(--volt)" strokeWidth={2} strokeLinecap="round" />
      <circle cx={last[0]} cy={last[1]} r={3} fill="var(--volt)" />
    </svg>
  );
}

function MacroLine({ label, v, max, color }: { label: string; v: number; max: number; color: string }) {
  const pct = max > 0 ? Math.min(100, (v / max) * 100) : 0;
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between text-[10px] font-bold uppercase tracking-widest">
        <span className="text-[var(--muted)]">{label}</span>
        <span className="tabular">
          {Math.round(v)}<span className="text-[var(--muted)]">/{Math.round(max)}g</span>
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
        <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

function CalendarIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <path d="M16 2v4M8 2v4M3 10h18" />
    </svg>
  );
}
