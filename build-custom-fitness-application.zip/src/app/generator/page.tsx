"use client";

import {
  BookOpen,
  Bookmark,
  Check,
  ChevronDown,
  Clock3,
  Dices,
  Dumbbell,
  Flame,
  Info,
  Play,
  Wind,
  Zap,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useT } from "@/lib/i18n";
import { useMemo, useState } from "react";
import { EquipmentPicker, equipmentSummary } from "@/components/equipment-picker";
import { PaywallSheet, useAccess } from "@/components/paywall";
import { FREE_LIMITS } from "@/lib/billing";
import { Chip, Reveal, Segmented, Sheet } from "@/components/ui";
import { Exercise, MUSCLES, MUSCLE_LABEL, Muscle } from "@/lib/data";
import { ExerciseDetailSheet } from "@/components/exercise-detail";
import { readinessOf } from "@/lib/recovery";
import { bodyTypePlan, rampStateOf, trainingStatusOf } from "@/lib/readiness-profile";
import {
  dateKey,
  displayDate,
  exerciseHistory,
  GeneratedWorkout,
  generateFlow,
  generateWorkout,
  GenOptions,
  totalSets,
  uid,
  weekDates,
} from "@/lib/engine";
import { Routine, useStore } from "@/lib/store";

export default function GeneratorPage() {
  const t = useT();
  const router = useRouter();
  const equipment = useStore((s) => s.equipment);
  const toggleEquipment = useStore((s) => s.toggleEquipment);
  const upsertRoutine = useStore((s) => s.upsertRoutine);
  const assignDay = useStore((s) => s.assignDay);
  const startGenerated = useStore((s) => s.startGenerated);
  const startWorkout = useStore((s) => s.startWorkout);
  const profile = useStore((s) => s.profile);
  const customExercises = useStore((s) => s.customExercises);
  const logs = useStore((s) => s.logs);
  const checkins = useStore((s) => s.checkins);
  const todayCheckin = checkins.find((c) => c.date === dateKey());
  const readiness = readinessOf(todayCheckin);

  // Comeback ramp from their setup answers, blended with today's readiness.
  const trainingStatus = trainingStatusOf(profile?.lastWorkoutGap);
  const ramp = rampStateOf(trainingStatus, logs.length);
  const bodyPlan = bodyTypePlan(profile?.bodyType);
  // Never exceed what the rebuild allows, even on a great recovery day.
  const advisedLevel = Math.min(
    ramp.level,
    todayCheckin ? readiness.level : ramp.level
  ) as 1 | 2 | 3;
  const advisedVolume = Math.min(
    ramp.volumePct,
    todayCheckin ? readiness.volumePct : ramp.volumePct
  );

  const [muscles, setMuscles] = useState<Muscle[]>(["full"]);
  const [minutes, setMinutes] = useState<number>(30);
  const [level, setLevel] = useState<1 | 2 | 3>(2);
  const [seed, setSeed] = useState(() => Math.floor(Math.random() * 99999));
  const [workout, setWorkout] = useState<GeneratedWorkout | null>(null);
  const [openCue, setOpenCue] = useState<string | null>(null);
  const [guideEx, setGuideEx] = useState<Exercise | null>(null);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveName, setSaveName] = useState("");
  const [savedOk, setSavedOk] = useState(false);
  const [gearOpen, setGearOpen] = useState(false);
  const [payOpen, setPayOpen] = useState(false);
  const access = useAccess();
  const genUsage = useStore((st) => st.genUsage);
  const noteGeneration = useStore((st) => st.noteGeneration);
  const usedToday = genUsage?.[dateKey()] ?? 0;
  const genLeft = access.isPro ? Infinity : Math.max(0, FREE_LIMITS.generationsPerDay - usedToday);

  const opts: GenOptions = useMemo(
    () => ({ equipment, muscles, minutes, level, custom: customExercises }),
    [equipment, muscles, minutes, level, customExercises]
  );

  const pickMuscle = (m: Muscle) => {
    setMuscles((cur) => {
      if (m === "full") return ["full"];
      const without = cur.filter((x) => x !== "full");
      return without.includes(m)
        ? without.filter((x) => x !== m).length
          ? without.filter((x) => x !== m)
          : ["full"]
        : [...without, m];
    });
  };

  const forge = (newSeed?: number) => {
    if (genLeft <= 0) {
      setPayOpen(true);
      return;
    }
    if (!access.isPro) noteGeneration();
    const s = newSeed ?? Math.floor(Math.random() * 999999);
    setSeed(s);
    setWorkout(generateWorkout(opts, s, profile?.weightKg ?? 70));
    setSavedOk(false);
  };

  /** Standalone mobility flow, limited to the user's inventory. */
  const launchFlow = (kind: "warmup" | "cooldown") => {
    const targets: Muscle[] = muscles.length && muscles[0] !== "full" ? muscles : ["full"];
    const flow = generateFlow(kind, targets, new Set(equipment), Math.floor(Math.random() * 99999));
    startWorkout(flow.name, flow.items);
    router.push("/workout");
  };

  const doSave = (dayKey?: string) => {
    if (!workout) return;
    const routine: Routine = {
      id: uid(),
      name: saveName.trim() || workout.name,
      createdAt: new Date().toISOString(),
      items: workout.items.map((it) => ({
        exerciseId: it.ex.id,
        sets: it.sets,
        reps: it.reps,
        sec: it.sec,
        rest: it.rest,
      })),
    };
    upsertRoutine(routine);
    if (dayKey) assignDay(dayKey, routine.id);
    setSavedOk(true);
    setSaveOpen(false);
  };

  return (
    <div className="flex flex-col gap-5">
      <Reveal>
        <div className="pt-1">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--volt)]">{t("pg.genEyebrow")}
          </p>
          <h1 className="font-display mt-1 text-[32px] uppercase leading-none tracking-wide">{t("pg.genTitle")}
          </h1>
          <p className="mt-1.5 text-[13px] text-[var(--muted)]">
            Built only from the equipment you actually own.
          </p>
          <button
            className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--surface-2)] px-3.5 py-2 text-[12px] font-bold text-[var(--volt)]"
            onClick={() => router.push("/library")}
          >
            <BookOpen size={14} /> Exercise library · how-to & videos
          </button>
        </div>
      </Reveal>

      {/* Recovery-aware recommendation */}
      {todayCheckin ? (
        <Reveal>
          <div
            className="card flex items-center gap-3 p-4"
            style={{ borderColor: `color-mix(in srgb, ${readiness.color} 40%, transparent)` }}
          >
            <span
              className="font-display tabular grid h-11 w-11 shrink-0 place-items-center rounded-xl text-xl"
              style={{ color: readiness.color, background: `color-mix(in srgb, ${readiness.color} 12%, transparent)` }}
            >
              {readiness.score}
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[12px] font-extrabold">{readiness.headline}</p>
              <p className="mt-0.5 text-[10px] leading-snug text-[var(--muted)]">
                Recommended: {advisedLevel === 1 ? "Starter" : advisedLevel === 2 ? "Solid" : "Savage"}
                {advisedVolume > 0 ? ` · ${advisedVolume}% volume` : " · rest day"}
              </p>
            </div>
            <button
              className="rounded-full bg-[var(--surface-2)] px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wider text-[var(--volt)]"
              onClick={() => {
                setLevel(advisedLevel);
                if (advisedVolume <= 50) setMinutes(15);
                else if (advisedVolume <= 75) setMinutes(30);
              }}
            >
              Apply
            </button>
          </div>
        </Reveal>
      ) : (
        <button
          onClick={() => router.push("/recovery")}
          className="card flex items-center justify-between gap-3 p-3.5 text-left"
        >
          <span className="text-[11px] text-[var(--muted)]">
            Check in first for a recovery-based intensity recommendation.
          </span>
          <span className="shrink-0 text-[10px] font-extrabold uppercase tracking-wider text-[var(--aqua)]">
            Check in →
          </span>
        </button>
      )}

      {ramp.active && (
        <Reveal>
          <div className="card border-[rgba(205,248,63,0.3)] bg-[rgba(205,248,63,0.04)] p-4">
            <div className="flex items-center justify-between gap-3">
              <p className="text-[12px] font-extrabold">{trainingStatus.headline}</p>
              <span className="tabular shrink-0 text-[10px] font-bold text-[var(--muted)]">
                {ramp.message}
              </span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/[0.08]">
              <div
                className="h-full rounded-full bg-[var(--volt)] transition-all duration-700"
                style={{ width: `${Math.max(4, ramp.progress * 100)}%` }}
              />
            </div>
            {trainingStatus.caution && (
              <p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">
                {trainingStatus.caution}
              </p>
            )}
          </div>
        </Reveal>
      )}

      {/* Equipment */}
      <Reveal>
        <section>
          <div className="mb-2 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              My equipment
            </p>
            <button
              className="text-[11px] font-bold text-[var(--volt)]"
              onClick={() => setGearOpen((o) => !o)}
            >
              {gearOpen ? "Done" : `Edit (${equipment.length})`}
            </button>
          </div>
          {gearOpen ? (
            <div className="anim-fade-up card p-4">
              <EquipmentPicker compact />
            </div>
          ) : (
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">
              {equipmentSummary(equipment)}
            </p>
          )}
          <p className="mt-2 text-[11px] text-[var(--muted)]">
            Bodyweight moves are always included.
          </p>
        </section>
      </Reveal>

      {/* Muscles */}
      <Reveal delay={40}>
        <section>
          <Section label="Target muscles" />
          <div className="flex flex-wrap gap-2">
            {MUSCLES.map((m) => (
              <Chip key={m.id} active={muscles.includes(m.id)} onClick={() => pickMuscle(m.id)}>
                {m.label}
              </Chip>
            ))}
          </div>
        </section>
      </Reveal>

      {/* Time + level */}
      <Reveal delay={80}>
        <section className="flex flex-col gap-4">
          <div>
            <Section label="Session length" />
            <Segmented
              value={minutes}
              onChange={setMinutes}
              options={[
                { value: 15, label: "15 min" },
                { value: 30, label: "30 min" },
                { value: 45, label: "45 min" },
                { value: 60, label: "60 min" },
              ]}
            />
          </div>
          <div>
            <Section label="Intensity" />
            <p className="mb-2 -mt-1 text-[10px] text-[var(--muted)]">
              Your build suits {bodyPlan.repRange[0]}–{bodyPlan.repRange[1]} reps with ~
              {bodyPlan.restSec}s rest.
            </p>
            <Segmented
              value={level}
              onChange={(v) => setLevel(v)}
              options={[
                { value: 1 as const, label: "Starter" },
                { value: 2 as const, label: "Solid" },
                { value: 3 as const, label: "Savage" },
              ]}
            />
          </div>
        </section>
      </Reveal>

      <Reveal delay={110}>
        <div className="flex flex-col gap-2">
          <button className="btn btn-volt h-14 w-full text-base" onClick={() => forge()}>
            <Zap size={19} fill="currentColor" />
            {workout ? "Forge again" : "Forge my workout"}
          </button>
          {!access.isPro && (
            <p className="text-center text-[10px] font-semibold text-[var(--muted)]">
              {genLeft > 0
                ? `${genLeft} of ${FREE_LIMITS.generationsPerDay} free workouts left today`
                : "Daily free limit reached — go Pro for unlimited"}
            </p>
          )}
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button className="btn btn-ghost h-11 text-[12px]" onClick={() => launchFlow("warmup")}>
            <Flame size={14} /> Warm-up flow
          </button>
          <button className="btn btn-ghost h-11 text-[12px]" onClick={() => launchFlow("cooldown")}>
            <Wind size={14} /> Cooldown flow
          </button>
        </div>
      </Reveal>

      {/* Result */}
      {workout && (
        <div className="anim-fade-up flex flex-col gap-3">
          <div className="card p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--volt)]">
                  Session ready
                </p>
                <h2 className="font-display mt-1 text-3xl uppercase leading-[0.95] tracking-wide">
                  {workout.name}
                </h2>
              </div>
              <button
                className="btn btn-ghost h-9 w-9 !rounded-full"
                onClick={() => forge(seed + 1)}
                aria-label="Regenerate"
              >
                <Dices size={16} />
              </button>
            </div>
            <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-[12px] font-semibold text-[var(--muted)]">
              <span className="flex items-center gap-1.5">
                <Clock3 size={13} className="text-[var(--volt)]" /> ~{workout.minutes} min
              </span>
              <span className="flex items-center gap-1.5">
                <Flame size={13} className="text-[var(--ember)]" /> ~{workout.kcal} kcal
              </span>
              <span className="flex items-center gap-1.5">
                <Dumbbell size={13} className="text-[var(--aqua)]" /> {totalSets(workout.items)} sets
              </span>
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {workout.focus.map((m) => (
                <span
                  key={m}
                  className="rounded-full bg-white/[0.06] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[var(--muted)]"
                >
                  {MUSCLE_LABEL[m]}
                </span>
              ))}
            </div>
          </div>

          <div className="card divide-y divide-[var(--line)] overflow-hidden">
            {workout.items.map((it, i) => (
              <div key={`${it.ex.id}-${i}`} className="px-4">
                <button
                  className="flex w-full items-center gap-3 py-3.5 text-left"
                  onClick={() => setOpenCue(openCue === it.ex.id ? null : it.ex.id)}
                >
                  <span className="tabular grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-[var(--surface-2)] text-[12px] font-extrabold text-[var(--volt)]">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold">{it.ex.name}</p>
                    <p className="text-[11px] text-[var(--muted)]">
                      {it.ex.muscles.slice(0, 2).map((m) => MUSCLE_LABEL[m]).join(" · ")}
                      {it.ex.uni ? " · each side" : ""}
                    </p>
                  </div>
                  <span className="tabular shrink-0 text-sm font-extrabold">
                    {it.sets}×{it.sec !== null ? `${it.sec}s` : it.reps}
                  </span>
                  <ChevronDown
                    size={15}
                    className={`shrink-0 text-[var(--muted)] transition-transform ${openCue === it.ex.id ? "rotate-180" : ""}`}
                  />
                </button>
                {openCue === it.ex.id && (
                  <div className="anim-fade-up mb-3 flex flex-col gap-1.5 rounded-xl bg-[var(--surface-2)] p-3 text-[12px] leading-relaxed text-[var(--muted)]">
                    <span className="flex items-start gap-2">
                      <Info size={14} className="mt-0.5 shrink-0 text-[var(--volt)]" />
                      <span>
                        {it.ex.cue} Rest {it.rest}s between sets.
                      </span>
                    </span>
                    {(() => {
                      const hist = exerciseHistory(logs, it.ex.id);
                      if (!hist.length) return null;
                      const last = hist[hist.length - 1];
                      const best = Math.max(...hist.map((h) => h.est1rm));
                      return (
                        <span className="flex items-start gap-2 border-t border-[var(--line)] pt-1.5">
                          <Flame size={14} className="mt-0.5 shrink-0 text-[var(--ember)]" />
                          <span>
                            Done {hist.length}× before — last: {last.setsDone} sets ×{" "}
                            {last.bestKg ? `${last.bestRepsAtKg} reps @ ${last.bestKg}kg` : `${last.totalReps} reps`}
                            {best > 0 && (
                              <span className="text-[var(--volt)]"> · best est. 1RM {Math.round(best)} kg</span>
                            )}
                          </span>
                        </span>
                      );
                    })()}
                    <button
                      className="mt-1 flex items-center gap-2 rounded-lg bg-[var(--surface-3)] px-3 py-2 text-[12px] font-bold text-[var(--volt)]"
                      onClick={() => setGuideEx(it.ex)}
                    >
                      <BookOpen size={14} /> Full guide · how to & video
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>

          {savedOk && (
            <p className="anim-fade-up flex items-center justify-center gap-1.5 text-[12px] font-semibold text-[var(--volt)]">
              <Check size={14} strokeWidth={3} /> Saved to your routines
            </p>
          )}

          <div className="grid grid-cols-2 gap-3">
            <button className="btn btn-ghost h-12" onClick={() => { setSaveName(workout.name); setSaveOpen(true); }}>
              <Bookmark size={16} /> Save
            </button>
            <button
              className="btn btn-volt h-12"
              onClick={() => {
                startGenerated(workout.name, workout.items);
                router.push("/workout");
              }}
            >
              <Play size={16} fill="currentColor" /> Start
            </button>
          </div>
        </div>
      )}

      <PaywallSheet open={payOpen} onClose={() => setPayOpen(false)} feature="splits" />
      <ExerciseDetailSheet exercise={guideEx} onClose={() => setGuideEx(null)} />

      {/* Save sheet */}
      <Sheet open={saveOpen} onClose={() => setSaveOpen(false)} title="Save routine">
        <div className="flex flex-col gap-4">
          <div>
            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
              Routine name
            </label>
            <input
              className="field"
              value={saveName}
              onChange={(e) => setSaveName(e.target.value)}
              placeholder="e.g. Iron Circuit"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
              Also schedule on
            </label>
            <div className="grid grid-cols-2 gap-2">
              {weekDates(0).map((d) => (
                <button
                  key={d.key}
                  className="btn btn-ghost h-11 justify-start px-3 text-left text-[12px]"
                  onClick={() => doSave(d.key)}
                >
                  <span className="tabular w-7 font-display text-sm text-[var(--volt)]">{d.dow}</span>
                  {displayDate(d.key)}
                </button>
              ))}
            </div>
          </div>
          <button className="btn btn-ghost h-12 w-full" onClick={() => doSave()}>
            Just save it
          </button>
        </div>
      </Sheet>

      {/* Footer hint */}
      {!workout && (
        <p className="pb-2 text-center text-[11px] leading-relaxed text-[var(--muted)]">
          Sessions are balanced across muscle groups and scaled to
          <br />
          your equipment, time and intensity.
        </p>
      )}
    </div>
  );
}

function Section({ label }: { label: string }) {
  return (
    <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">{label}</p>
  );
}
