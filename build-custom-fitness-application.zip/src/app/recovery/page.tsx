"use client";

import {
  Activity,
  ArrowLeft,
  BedDouble,
  Check,
  Footprints,
  HeartPulse,
  Moon,
  Smile,
  Sparkles,
  Trash2,
  TrendingDown,
  TrendingUp,
  Zap,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useT } from "@/lib/i18n";
import { useMemo, useState } from "react";
import { Chip, Reveal, Ring } from "@/components/ui";
import { dateKey } from "@/lib/engine";
import {
  DailyCheckin,
  PAIN_AREAS,
  readinessOf,
  recoveryTrend,
} from "@/lib/recovery";
import { acwrOf } from "@/lib/training";
import { useStore } from "@/lib/store";

const DEFAULT: Omit<DailyCheckin, "id" | "date"> = {
  sleepHours: 7.5,
  sleepQuality: 3,
  energy: 3,
  soreness: 2,
  stress: 2,
  steps: 0,
  restingHr: null,
  painAreas: [],
  note: "",
};

export default function RecoveryPage() {
  const t = useT();
  const router = useRouter();
  const checkins = useStore((s) => s.checkins);
  const logs = useStore((s) => s.logs);
  const acwr = useMemo(() => acwrOf(logs), [logs]);
  const upsertCheckin = useStore((s) => s.upsertCheckin);
  const removeCheckin = useStore((s) => s.removeCheckin);
  const today = dateKey();
  const existing = checkins.find((c) => c.date === today);

  const [form, setForm] = useState<Omit<DailyCheckin, "id" | "date">>(
    existing
      ? {
          sleepHours: existing.sleepHours,
          sleepQuality: existing.sleepQuality,
          energy: existing.energy,
          soreness: existing.soreness,
          stress: existing.stress,
          steps: existing.steps,
          restingHr: existing.restingHr,
          painAreas: existing.painAreas,
          note: existing.note,
        }
      : DEFAULT
  );
  const [saved, setSaved] = useState(Boolean(existing));

  const preview: DailyCheckin = {
    ...form,
    id: existing?.id ?? "preview",
    date: today,
  };
  const ready = readinessOf(preview);
  const trend = useMemo(() => recoveryTrend(checkins), [checkins]);

  const save = () => {
    upsertCheckin({ ...form, date: today, id: existing?.id });
    setSaved(true);
  };

  return (
    <div className="flex flex-col gap-4">
      <Reveal>
        <div className="flex items-center gap-3 pt-1">
          <button
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-2)]"
            onClick={() => router.back()}
            aria-label="Back"
          >
            <ArrowLeft size={16} />
          </button>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--aqua)]">{t("pg.recEyebrow")}
          </p>
            <h1 className="font-display text-[28px] uppercase leading-none tracking-wide">{t("pg.recTitle")}
          </h1>
          </div>
        </div>
      </Reveal>

      {/* Readiness */}
      <Reveal>
        <div className="card flex items-center gap-5 p-5">
          <Ring size={118} stroke={10} value={ready.score / 100} color={ready.color}>
            <div className="text-center">
              <p className="font-display tabular text-[30px] leading-none">{ready.score}</p>
              <p className="mt-0.5 text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">
                readiness
              </p>
            </div>
          </Ring>
          <div className="min-w-0 flex-1">
            <span
              className="rounded-full px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider"
              style={{ color: ready.color, background: `color-mix(in srgb, ${ready.color} 14%, transparent)` }}
            >
              {ready.label}
            </span>
            <h2 className="font-display mt-2 text-2xl uppercase leading-none tracking-wide">
              {ready.headline}
            </h2>
            <p className="mt-1.5 text-[11px] leading-relaxed text-[var(--muted)]">
              {ready.guidance}
            </p>
          </div>
        </div>
      </Reveal>

      {/* Component scores */}
      <Reveal>
        <div className="grid grid-cols-3 gap-2">
          {[
            { l: "Sleep", v: ready.sleepScore, icon: Moon, color: "#b98cff" },
            { l: "Body", v: ready.bodyScore, icon: Activity, color: "var(--volt)" },
            { l: "Mind", v: ready.mindScore, icon: Smile, color: "var(--aqua)" },
          ].map((x) => (
            <div key={x.l} className="card p-3 text-center">
              <x.icon size={14} className="mx-auto mb-1.5" style={{ color: x.color }} />
              <p className="font-display tabular text-xl leading-none">{x.v}</p>
              <p className="mt-1 text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">
                {x.l}
              </p>
            </div>
          ))}
        </div>
      </Reveal>

      {/* Sleep */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-3 flex items-center gap-2">
            <BedDouble size={15} className="text-[#b98cff]" />
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Last night
            </p>
          </div>
          <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Sleep hours
          </label>
          <div className="flex items-center gap-3">
            <input
              type="range"
              min="3"
              max="12"
              step="0.25"
              value={form.sleepHours}
              onChange={(e) => {
                setForm({ ...form, sleepHours: Number(e.target.value) });
                setSaved(false);
              }}
              className="flex-1 accent-[var(--volt)]"
            />
            <span className="tabular font-display w-16 text-right text-2xl">
              {form.sleepHours}h
            </span>
          </div>
          <MetricPicker
            label="Sleep quality"
            value={form.sleepQuality}
            low="Poor"
            high="Great"
            onChange={(v) => {
              setForm({ ...form, sleepQuality: v });
              setSaved(false);
            }}
          />
        </div>
      </Reveal>

      {/* Subjective scores */}
      <Reveal>
        <div className="card flex flex-col gap-4 p-5">
          <MetricPicker
            label="Energy"
            value={form.energy}
            low="Flat"
            high="Flying"
            onChange={(v) => {
              setForm({ ...form, energy: v });
              setSaved(false);
            }}
          />
          <MetricPicker
            label="Muscle soreness"
            value={form.soreness}
            low="Fresh"
            high="Very sore"
            inverse
            onChange={(v) => {
              setForm({ ...form, soreness: v });
              setSaved(false);
            }}
          />
          <MetricPicker
            label="Stress"
            value={form.stress}
            low="Calm"
            high="Overloaded"
            inverse
            onChange={(v) => {
              setForm({ ...form, stress: v });
              setSaved(false);
            }}
          />
        </div>
      </Reveal>

      {/* Objective activity */}
      <Reveal>
        <div className="card p-5">
          <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
            Activity & heart
          </p>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[var(--muted)]">
                <Footprints size={12} /> Steps
              </label>
              <input
                className="field text-center"
                type="number"
                inputMode="numeric"
                placeholder="0"
                value={form.steps || ""}
                onChange={(e) => {
                  setForm({ ...form, steps: Math.max(0, Number(e.target.value)) });
                  setSaved(false);
                }}
              />
            </div>
            <div>
              <label className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[var(--muted)]">
                <HeartPulse size={12} /> Resting BPM
              </label>
              <input
                className="field text-center"
                type="number"
                inputMode="numeric"
                placeholder="Optional"
                value={form.restingHr ?? ""}
                onChange={(e) => {
                  const v = Number(e.target.value);
                  setForm({ ...form, restingHr: v > 0 ? v : null });
                  setSaved(false);
                }}
              />
            </div>
          </div>
        </div>
      </Reveal>

      {/* Pain flags */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-2 flex items-baseline justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Pain or irritation
            </p>
            <span className="text-[10px] text-[var(--muted)]">not normal soreness</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {PAIN_AREAS.map((a) => (
              <Chip
                key={a}
                active={form.painAreas.includes(a)}
                onClick={() => {
                  const has = form.painAreas.includes(a);
                  setForm({
                    ...form,
                    painAreas: has
                      ? form.painAreas.filter((x) => x !== a)
                      : [...form.painAreas, a],
                  });
                  setSaved(false);
                }}
              >
                {a}
              </Chip>
            ))}
          </div>
          {form.painAreas.length > 0 && (
            <p className="mt-3 text-[11px] leading-relaxed text-[var(--ember)]">
              FORGE will suggest a lower-intensity session. Persistent, sharp or worsening pain
              should be assessed by a qualified clinician.
            </p>
          )}
        </div>
      </Reveal>

      {/* Note */}
      <Reveal>
        <div>
          <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Note (optional)
          </label>
          <textarea
            className="field min-h-24 resize-none"
            placeholder="Late night, stressful day, knee felt odd…"
            value={form.note}
            onChange={(e) => {
              setForm({ ...form, note: e.target.value.slice(0, 300) });
              setSaved(false);
            }}
          />
        </div>
      </Reveal>

      <button className="btn btn-volt h-14 w-full text-base" onClick={save}>
        {saved ? <Check size={18} strokeWidth={3} /> : <Sparkles size={18} />}
        {saved ? "Today's check-in saved" : "Save today's check-in"}
      </button>

      {/* Training load ratio (ACWR) */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Training load · ACWR
            </p>
            <span
              className="rounded-full px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider"
              style={{
                color: acwr.color,
                background: `color-mix(in srgb, ${acwr.color} 14%, transparent)`,
              }}
            >
              {acwr.label}
            </span>
          </div>

          {acwr.ratio !== null ? (
            <>
              <div className="flex items-end gap-3">
                <p
                  className="font-display tabular text-4xl leading-none"
                  style={{ color: acwr.color }}
                >
                  {acwr.ratio.toFixed(2)}
                </p>
                <p className="pb-1 text-[11px] text-[var(--muted)]">acute ÷ chronic</p>
              </div>

              <div className="mt-3 flex gap-1">
                {["undertrained", "optimal", "caution", "high"].map((z, i) => (
                  <div
                    key={z}
                    className="h-2 rounded-full transition-all"
                    style={{
                      width: ["20%", "45%", "15%", "20%"][i],
                      background: ["var(--aqua)", "var(--volt)", "#ffc740", "var(--ember)"][i],
                      opacity: acwr.zone === z ? 1 : 0.22,
                    }}
                  />
                ))}
              </div>
              <div className="mt-1 flex justify-between text-[8px] font-bold uppercase tracking-wider text-[var(--muted)]">
                <span>Under</span>
                <span>Sweet spot</span>
                <span>Caution</span>
                <span>High</span>
              </div>

              <p className="tabular mt-3 text-[11px] text-[var(--muted)]">
                7d: {acwr.acute7.toLocaleString()} kg · 4-wk avg: {" "}
                {acwr.chronicWeek.toLocaleString()} kg/wk · {acwr.daysWithData} active days
              </p>
              <p className="mt-2 text-[12px] leading-relaxed text-[var(--muted)]">
                {acwr.advice}
              </p>
            </>
          ) : (
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">{acwr.advice}</p>
          )}
        </div>
      </Reveal>

      {/* Seven-day trend */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Recent trend
            </p>
            {trend.direction === "up" ? (
              <TrendingUp size={15} className="text-[var(--volt)]" />
            ) : trend.direction === "down" ? (
              <TrendingDown size={15} className="text-[var(--ember)]" />
            ) : (
              <Zap size={15} className="text-[var(--muted)]" />
            )}
          </div>
          {trend.checkins === 0 ? (
            <p className="py-3 text-center text-[12px] text-[var(--muted)]">
              Save a few check-ins to build your recovery trend.
            </p>
          ) : (
            <>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { l: "Readiness", v: `${trend.averageReadiness}` },
                  { l: "Avg sleep", v: `${trend.averageSleep}h` },
                  { l: "Avg steps", v: trend.averageSteps.toLocaleString() },
                ].map((x) => (
                  <div key={x.l} className="card-2 p-3 text-center">
                    <p className="font-display tabular text-xl leading-none">{x.v}</p>
                    <p className="mt-1 text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                      {x.l}
                    </p>
                  </div>
                ))}
              </div>
              {trend.sleepDebtHours > 0 && (
                <p className="mt-3 text-[11px] leading-relaxed text-[var(--muted)]">
                  Estimated sleep debt across these check-ins:{" "}
                  <span className="tabular font-bold text-[var(--text)]">
                    {trend.sleepDebtHours} hours
                  </span>
                  . Aim for consistent nights rather than trying to fix it all at once.
                </p>
              )}
            </>
          )}
        </div>
      </Reveal>

      {/* History */}
      {checkins.length > 0 && (
        <Reveal>
          <div className="card divide-y divide-[var(--line)] overflow-hidden">
            {checkins.slice(0, 10).map((c) => {
              const r = readinessOf(c);
              return (
                <div key={c.id} className="flex items-center gap-3 px-4 py-3">
                  <span
                    className="font-display tabular grid h-10 w-10 shrink-0 place-items-center rounded-xl text-lg"
                    style={{ color: r.color, background: `color-mix(in srgb, ${r.color} 12%, transparent)` }}
                  >
                    {r.score}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-bold">
                      {new Date(c.date + "T00:00").toLocaleDateString(undefined, {
                        weekday: "short",
                        day: "numeric",
                        month: "short",
                      })}
                    </p>
                    <p className="truncate text-[10px] text-[var(--muted)]">
                      {c.sleepHours}h sleep · energy {c.energy}/5 · soreness {c.soreness}/5
                      {c.painAreas.length ? ` · ${c.painAreas.join(", ")}` : ""}
                    </p>
                  </div>
                  <button
                    className="text-[var(--muted)] active:text-[var(--red)]"
                    onClick={() => removeCheckin(c.id)}
                    aria-label="Delete check-in"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              );
            })}
          </div>
        </Reveal>
      )}
    </div>
  );
}

function MetricPicker({
  label,
  value,
  low,
  high,
  inverse = false,
  onChange,
}: {
  label: string;
  value: 1 | 2 | 3 | 4 | 5;
  low: string;
  high: string;
  inverse?: boolean;
  onChange: (v: 1 | 2 | 3 | 4 | 5) => void;
}) {
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between">
        <p className="text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">{label}</p>
        <span className="tabular text-[11px] font-extrabold">{value}/5</span>
      </div>
      <div className="grid grid-cols-5 gap-1.5">
        {([1, 2, 3, 4, 5] as const).map((n) => {
          const good = inverse ? 6 - n : n;
          const color = good >= 4 ? "var(--volt)" : good >= 3 ? "#ffc740" : "var(--ember)";
          return (
            <button
              key={n}
              onClick={() => onChange(n)}
              className="h-9 rounded-xl border text-[12px] font-extrabold transition-all active:scale-95"
              style={{
                color: value === n ? "#0b0c0e" : "var(--muted)",
                background: value === n ? color : "var(--surface-2)",
                borderColor: value === n ? color : "var(--line)",
              }}
            >
              {n}
            </button>
          );
        })}
      </div>
      <div className="mt-1.5 flex justify-between text-[9px] font-semibold uppercase tracking-wider text-[var(--muted)]">
        <span>{low}</span>
        <span>{high}</span>
      </div>
    </div>
  );
}
