"use client";

import { BookOpen, Check, Dumbbell, History, Pause, Play, Plus, Scale, Share2, SkipForward, Target, Trophy, Wind, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { Ring, Sheet, Stepper } from "@/components/ui";
import { ExerciseDetailSheet } from "@/components/exercise-detail";
import { EXERCISE_BY_ID } from "@/lib/data";
import { generateFlow, lastPerformance, nextTarget, totalSets } from "@/lib/engine";
import { shareWorkoutCard } from "@/lib/share";
import { targetHeadline, targetLastLabel, targetNote, wIn, wOut, wUnit } from "@/lib/units";
import { useStore } from "@/lib/store";

export default function WorkoutPlayer() {
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const router = useRouter();
  const active = useStore((s) => s.activeWorkout);
  const setSetDone = useStore((s) => s.setSetDone);
  const setSetKg = useStore((s) => s.setSetKg);
  const finishWorkout = useStore((s) => s.finishWorkout);
  const cancelWorkout = useStore((s) => s.cancelWorkout);
  const profile = useStore((s) => s.profile);
  const logs = useStore((s) => s.logs);

  const [pos, setPos] = useState({ ex: 0, set: 0 });
  const [restUntil, setRestUntil] = useState<number | null>(null);
  const [restTotal, setRestTotal] = useState(0);
  const [restNow, setRestNow] = useState(0);
  const [timedSet, setTimedSet] = useState<number | null>(null); // seconds remaining for running timed set
  const [confirmQuit, setConfirmQuit] = useState(false);
  const [finished, setFinished] = useState(false);
  const [rpe, setRpe] = useState<number | null>(null);
  const [guideId, setGuideId] = useState<string | null>(null);
  const customExercises = useStore((s) => s.customExercises);
  const startWorkout = useStore((s) => s.startWorkout);
  const equipment = useStore((s) => s.equipment);
  const guideExercise = guideId
    ? EXERCISE_BY_ID.get(guideId) ?? customExercises.find((e) => e.id === guideId) ?? null
    : null;

  const total = useMemo(() => (active ? totalSets(active.items) : 0), [active]);
  const doneCount = useMemo(
    () => (active ? active.items.reduce((s, it) => s + it.done.filter(Boolean).length, 0) : 0),
    [active]
  );
  const item = active?.items[pos.ex];
  const curEx = item
    ? EXERCISE_BY_ID.get(item.exerciseId) ??
      customExercises.find((e) => e.id === item.exerciseId) ??
      null
    : null;
  const target = useMemo(() => (curEx ? nextTarget(logs, curEx) : null), [curEx, logs]);

  // advance position if current slot is already done (works after unpersist)
  useEffect(() => {
    if (!active) return;
    outer: for (let i = 0; i < active.items.length; i++) {
      for (let j = 0; j < active.items[i].done.length; j++) {
        if (!active.items[i].done[j]) {
          setPos({ ex: i, set: j });
          break outer;
        }
      }
    }
    if (active.items.every((it) => it.done.every(Boolean))) setFinished(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // rest countdown
  useEffect(() => {
    if (restUntil === null) return;
    const iv = setInterval(() => {
      const left = Math.max(0, Math.ceil((restUntil - Date.now()) / 1000));
      setRestNow(left);
      if (left <= 0) {
        setRestUntil(null);
        navigator.vibrate?.([60, 40, 60]);
      }
    }, 200);
    return () => clearInterval(iv);
  }, [restUntil]);

  // timed set countdown
  useEffect(() => {
    if (timedSet === null) return;
    const iv = setInterval(() => {
      setTimedSet((t) => {
        if (t === null) return null;
        if (t <= 1) {
          clearInterval(iv);
          completeSet();
          return null;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timedSet !== null]);

  if (!active || !item) {
    return (
      <div className="grid min-h-dvh place-items-center px-6">
        <div className="card flex w-full flex-col items-center gap-3 p-8 text-center">
          <Dumbbell size={26} className="text-[var(--volt)]" />
          <p className="font-display text-xl uppercase tracking-wide">No active session</p>
          <p className="text-[13px] text-[var(--muted)]">Start a workout from Home, Plan or Forge.</p>
          <button className="btn btn-volt mt-2 h-11 px-6" onClick={() => router.replace("/")}>
            Back home
          </button>
        </div>
      </div>
    );
  }

  const progress = total > 0 ? doneCount / total : 0;

  const volumeDone = active.items.reduce(
    (sum, it) => sum + it.done.reduce((ss, d, j) => ss + (d && it.loadable ? (it.kg[j] ?? 0) * (it.reps ?? 0) : 0), 0),
    0
  );

  const prev = item ? lastPerformance(logs, item.exerciseId) : null;
  const prevSets = prev ? prev.sets.filter((s) => s.done) : [];
  const prevKg = prevSets.find((s) => s.kg)?.kg;
  const prevReps = prevSets[0]?.reps ?? null;

  const shareNow = () => {
    const minutes = Math.max(1, Math.round((Date.now() - active.startedAt) / 60000));
    const avgMet = active.items.reduce((s, it) => s + it.met, 0) / Math.max(1, active.items.length);
    const kcal = Math.round(avgMet * (profile?.weightKg ?? 70) * (minutes / 60) * 0.9 * (doneCount / Math.max(1, total)));
    void shareWorkoutCard({
      name: active.name,
      minutes,
      kcal,
      sets: doneCount,
      volume: Math.round(wOut(volumeDone, sys)),
      volumeUnit: wUnit(sys),
    });
  };

  const completeSet = () => {
    setSetDone(pos.ex, pos.set, true);
    navigator.vibrate?.(30);

    // Local copy with this set marked done so scans see the true state.
    const items = active.items.map((it, i) =>
      i === pos.ex ? { ...it, done: it.done.map((d, j) => (j === pos.set ? true : d)) } : it
    );
    const cur = items[pos.ex];
    const groupId = cur.group;

    const atIndex = (i: number, j: number) =>
      j < items[i].sets && !items[i].done[j] ? { ex: i, set: j } : null;
    const scan = (from: number, to: number) => {
      for (let i = from; i <= to; i++) {
        for (let j = 0; j < items[i].sets; j++) {
          if (!items[i].done[j]) return { ex: i, set: j };
        }
      }
      return null;
    };

    let next: { ex: number; set: number } | null = null;
    let restSec = cur.rest;

    if (groupId != null) {
      // Maximal consecutive run sharing this group id.
      let start = pos.ex;
      while (start > 0 && items[start - 1].group === groupId) start--;
      let end = pos.ex;
      while (end + 1 < items.length && items[end + 1].group === groupId) end++;
      const j = pos.set;

      // Alternate: next member's set at the same index — no rest inside.
      for (let i = pos.ex + 1; i <= end && !next; i++) next = atIndex(i, j);
      for (let i = start; i < pos.ex && !next; i++) next = atIndex(i, j);
      // Index complete → next index within the group, then rest.
      for (let i = start; i <= end && !next; i++) {
        const hit = atIndex(i, j + 1);
        if (hit) {
          next = hit;
          restSec = cur.rest;
        }
      }
      // Group complete → first undone move after it (transition rest).
      if (!next) {
        next = scan(end + 1, items.length - 1);
        restSec = cur.rest + 15;
      }
    } else if (pos.set + 1 < cur.sets) {
      next = { ex: pos.ex, set: pos.set + 1 };
    } else {
      next = scan(pos.ex + 1, items.length - 1);
      restSec = cur.rest + 15;
    }

    if (!next) {
      setFinished(true);
      return;
    }
    setPos(next);
    if (restSec > 0) startRest(restSec);
  };

  const startRest = (secs: number) => {
    setRestTotal(secs);
    setRestNow(secs);
    setRestUntil(Date.now() + secs * 1000);
  };

  const chipDone = (i: number, j: number) => {
    if (active.items[i].done[j]) setSetDone(i, j, false);
    setPos({ ex: i, set: j });
  };

  if (finished) {
    const minutes = Math.max(1, Math.round((Date.now() - active.startedAt) / 60000));
    return (
      <div className="grid min-h-dvh place-items-center px-6">
        <div className="anim-pop flex w-full flex-col items-center gap-4 text-center">
          <div className="grid h-24 w-24 place-items-center rounded-full bg-[var(--volt)] text-[#0b0c0e] shadow-[0_0_80px_rgba(205,248,63,0.35)]">
            <Trophy size={42} />
          </div>
          <h1 className="font-display text-4xl uppercase tracking-wide">Session crushed</h1>
          <p className="text-[13px] text-[var(--muted)]">{active.name}</p>
          <div className="mt-2 grid w-full grid-cols-4 gap-2">
            {[
              { v: doneCount, l: "sets" },
              { v: minutes, l: "min" },
              { v: active.items.length, l: "moves" },
              {
                v:
                  sys === "metric" && volumeDone >= 1000
                    ? `${(volumeDone / 1000).toFixed(1)}t`
                    : `${Math.round(wOut(volumeDone, sys))} ${wUnit(sys)}`,
                l: "volume",
              },
            ].map((s) => (
              <div key={s.l} className="card p-3">
                <p className="font-display tabular text-xl">{s.v}</p>
                <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">{s.l}</p>
              </div>
            ))}
          </div>
          <div className="mt-1 w-full">
            <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.16em] text-[var(--muted)]">
              How hard was that? (RPE 1–10)
            </p>
            <div className="grid grid-cols-5 gap-1.5">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
                <button
                  key={n}
                  onClick={() => setRpe(n)}
                  className="h-9 rounded-xl border text-[12px] font-extrabold transition-all active:scale-95"
                  style={{
                    color: rpe === n ? "#0b0c0e" : n >= 8 ? "var(--ember)" : n >= 5 ? "#ffc740" : "var(--muted)",
                    background:
                      rpe === n
                        ? n >= 8
                          ? "var(--ember)"
                          : n >= 5
                            ? "#ffc740"
                            : "var(--volt)"
                        : "var(--surface-2)",
                    borderColor: rpe === n ? "transparent" : "var(--line)",
                  }}
                >
                  {n}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-3 grid w-full grid-cols-2 gap-3">
            <button className="btn btn-ghost h-12" onClick={shareNow}>
              <Share2 size={16} /> Share card
            </button>
            <button
              className="btn btn-volt h-12 text-base"
              onClick={() => {
                finishWorkout(profile?.weightKg ?? 70, rpe ?? undefined);
                router.replace("/");
              }}
            >
              <Check size={18} strokeWidth={3} /> Log & finish
            </button>
          </div>

          <button
            className="btn btn-ghost mt-3 h-12 w-full text-sm"
            onClick={() => {
              finishWorkout(profile?.weightKg ?? 70, rpe ?? undefined);
              const flow = generateFlow("cooldown", ["full"], new Set(equipment), 7);
              startWorkout(flow.name, flow.items);
              router.push("/workout");
            }}
          >
            <Wind size={15} /> Log & start cooldown flow
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-dvh flex-col">
      {/* Top bar */}
      <div className="pt-safe sticky top-0 z-30 bg-[var(--bg)]">
        <div className="flex h-14 items-center justify-between px-4">
          <button
            className="grid h-9 w-9 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-2)]"
            onClick={() => setConfirmQuit(true)}
            aria-label="Quit workout"
          >
            <X size={16} />
          </button>
          <div className="text-center">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--volt)]">
              {active.name}
            </p>
            <p className="tabular text-[11px] font-semibold text-[var(--muted)]">
              {doneCount} / {total} sets
            </p>
          </div>
          <span className="tabular w-9 text-right text-sm font-extrabold text-[var(--volt)]">
            {Math.round(progress * 100)}%
          </span>
        </div>
        <div className="h-1 bg-white/[0.06]">
          <div
            className="h-full bg-[var(--volt)] transition-all duration-500"
            style={{ width: `${progress * 100}%` }}
          />
        </div>
      </div>

      <div className="flex flex-1 flex-col px-4 pb-8 pt-5">
        {/* Exercise header */}
        <div key={pos.ex} className="anim-fade-up">
          <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
            Move {pos.ex + 1} of {active.items.length}
          </p>
          {(() => {
            const gid = item.group;
            if (gid == null) return null;
            let s0 = pos.ex;
            while (s0 > 0 && active.items[s0 - 1].group === gid) s0--;
            let e0 = pos.ex;
            while (e0 + 1 < active.items.length && active.items[e0 + 1].group === gid) e0++;
            const size = e0 - s0 + 1;
            const idx = pos.ex - s0 + 1;
            return (
              <span className="mt-1.5 inline-block rounded-full bg-[rgba(92,214,255,0.14)] px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider text-[var(--aqua)]">
                {size > 2 ? "Circuit" : "Superset"} · move {idx} of {size} · no rest between
              </span>
            );
          })()}
          <h1 className="font-display mt-1 text-[40px] uppercase leading-[0.95] tracking-wide">
            {item.name}
          </h1>
          <p className="mt-2 flex items-start gap-1.5 text-[13px] leading-relaxed text-[var(--muted)]">
            <span className="text-[var(--volt)]">›</span> {item.cue}
            {item.uni ? " Each side." : ""}
          </p>
          <button
            className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--surface-2)] px-3 py-1.5 text-[11px] font-bold text-[var(--volt)]"
            onClick={() => setGuideId(item.exerciseId)}
          >
            <BookOpen size={13} /> How to & video
          </button>
        </div>

        {/* Next-session progression target */}
        {target && (
          <div className="mt-4 flex items-center gap-3 rounded-2xl border border-[rgba(92,214,255,0.3)] bg-[rgba(92,214,255,0.06)] px-4 py-3">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[rgba(92,214,255,0.15)] text-[var(--aqua)]">
              <Target size={16} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[9px] font-bold uppercase tracking-[0.16em] text-[var(--muted)]">
                Next-session target
              </p>
              <p className="tabular text-[14px] font-extrabold text-[var(--aqua)]">
                {targetHeadline(target, sys)}
                {targetLastLabel(target, sys) && (
                  <span className="ml-2 text-[10px] font-semibold text-[var(--muted)]">
                    last: {targetLastLabel(target, sys)}
                  </span>
                )}
              </p>
              <p className="mt-0.5 text-[10px] leading-snug text-[var(--muted)]">
                {targetNote(target, sys)}
              </p>
            </div>
          </div>
        )}

        {/* Target */}
        <div className="card mt-6 flex items-center justify-center gap-8 p-6">
          <div className="text-center">
            <p className="font-display tabular text-5xl">{item.sets}</p>
            <p className="mt-1 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">sets</p>
          </div>
          <div className="h-10 w-px bg-[var(--line)]" />
          <div className="text-center">
            <p className="font-display tabular text-5xl text-[var(--volt)]">
              {item.sec !== null ? `${item.sec}s` : item.reps}
            </p>
            <p className="mt-1 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">
              {item.sec !== null ? "seconds" : "reps"} / set
            </p>
          </div>
        </div>

        {/* Set dots */}
        <div className="mt-5 flex flex-wrap gap-2">
          {item.done.map((d, j) => (
            <button
              key={j}
              onClick={() => chipDone(pos.ex, j)}
              className={`grid h-11 w-11 place-items-center rounded-full border text-[13px] font-extrabold transition-all ${
                d
                  ? "border-[var(--volt)] bg-[var(--volt)] text-[#0b0c0e]"
                  : j === pos.set
                    ? "border-[var(--volt)] text-[var(--volt)]"
                    : "border-[var(--line)] bg-[var(--surface-2)] text-[var(--muted)]"
              }`}
            >
              {d ? <Check size={16} strokeWidth={3.5} /> : j + 1}
            </button>
          ))}
        </div>

        {/* Load tracking */}
        {item.loadable && (
          <div className="card-2 mt-4 flex items-center gap-3 p-3.5">
            <Scale size={15} className="shrink-0 text-[var(--volt)]" />
            <span className="min-w-0 flex-1 text-[12px] font-semibold text-[var(--muted)]">
              {item.loadMode === "added" ? "Added weight" : "Load"} set {pos.set + 1}{" "}
              <span className="tabular text-[var(--text)]">
                · {item.loadMode === "added" ? "+" : ""}
                {wOut(item.kg[pos.set] ?? 0, sys)} {wUnit(sys)}
              </span>
              {item.loadMode === "added" && (item.kg[pos.set] ?? 0) === 0 && (
                <span className="text-[var(--muted)]"> (bodyweight)</span>
              )}
            </span>
            <Stepper
              value={wOut(item.kg[pos.set] ?? 0, sys)}
              min={0}
              max={wOut(300, sys)}
              step={sys === "metric" ? 2.5 : 5}
              onChange={(v) => setSetKg(pos.ex, pos.set, wIn(v, sys))}
            />
            <button
              className="rounded-lg bg-[var(--surface-3)] px-2.5 py-1.5 text-[10px] font-extrabold uppercase tracking-wider text-[var(--volt)]"
              onClick={() => item.kg.forEach((_, j) => setSetKg(pos.ex, j, item.kg[pos.set] ?? 0))}
            >
              All
            </button>
          </div>
        )}

        {/* Coach note: last performance */}
        {prev && prevSets.length > 0 && (
          <div className="mt-4 flex items-start gap-2.5 rounded-2xl border border-[rgba(205,248,63,0.25)] bg-[rgba(205,248,63,0.05)] p-3.5">
            <History size={14} className="mt-0.5 shrink-0 text-[var(--volt)]" />
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">
              <span className="font-bold text-[var(--text)]">Last time:</span> {prevSets.length}×
              {prevReps ?? "—"}
              {prevKg
                  ? item.loadMode === "added"
                    ? ` with +${wOut(prevKg, sys)} ${wUnit(sys)}`
                    : ` @ ${wOut(prevKg, sys)} ${wUnit(sys)}`
                  : ""}.
              <span className="text-[var(--volt)]">
                {" "}
                {item.loadable
                  ? item.loadMode === "added"
                    ? "Strong? Strap on 2.5 kg more."
                    : "Feeling strong? Add 2.5 kg."
                  : "Aim for +1–2 reps today."}
              </span>
            </p>
          </div>
        )}

        {/* Up next */}
        {pos.ex + 1 < active.items.length && (
          <div className="card-2 mt-5 flex items-center gap-3 p-3.5">
            <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">Up next</span>
            <span className="min-w-0 flex-1 truncate text-sm font-semibold">
              {active.items[pos.ex + 1].name}
            </span>
            <span className="tabular text-xs font-bold text-[var(--muted)]">
              {active.items[pos.ex + 1].sets}×
              {active.items[pos.ex + 1].sec !== null
                ? `${active.items[pos.ex + 1].sec}s`
                : active.items[pos.ex + 1].reps}
            </span>
          </div>
        )}

        <div className="flex-1" />

        {/* Main action */}
        {item.sec !== null ? (
          <button
            className={`btn mt-6 h-16 w-full text-lg ${timedSet !== null ? "btn-ghost" : "btn-volt"}`}
            onClick={() => (timedSet !== null ? setTimedSet(null) : setTimedSet(item.sec))}
          >
            {timedSet !== null ? (
              <>
                <Pause size={20} /> <span className="tabular font-display text-3xl">{timedSet}s</span>
              </>
            ) : (
              <>
                <Play size={20} fill="currentColor" /> Start {item.sec}s hold
              </>
            )}
          </button>
        ) : (
          <button className="btn btn-volt mt-6 h-16 w-full text-lg" onClick={completeSet}>
            <Check size={22} strokeWidth={3} /> Complete set {pos.set + 1}
          </button>
        )}
        {item.sec !== null && timedSet === null && (
          <button className="btn btn-ghost mt-3 h-11 w-full text-sm" onClick={completeSet}>
            Skip timer — mark done
          </button>
        )}
      </div>

      {/* Rest overlay */}
      {restUntil !== null && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-[rgba(10,11,13,0.94)] backdrop-blur-sm">
          <div className="flex flex-col items-center gap-6">
            <p className="text-[11px] font-bold uppercase tracking-[0.3em] text-[var(--volt)]">Recover</p>
            <Ring size={220} stroke={12} value={restTotal > 0 ? restNow / restTotal : 0} color="var(--volt)">
              <div className="text-center">
                <p className="font-display tabular text-7xl leading-none">{restNow}</p>
                <p className="mt-1 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">
                  seconds
                </p>
              </div>
            </Ring>
            <div className="flex gap-3">
              <button
                className="btn btn-ghost h-12 px-6"
                onClick={() => setRestUntil((u) => (u ? u + 15_000 : u))}
              >
                <Plus size={16} /> 15s
              </button>
              <button className="btn btn-volt h-12 px-8" onClick={() => setRestUntil(null)}>
                <SkipForward size={16} /> Skip
              </button>
            </div>
            <p className="text-[12px] text-[var(--muted)]">
              Next: {item.name} — set {pos.set + 1}
            </p>
          </div>
        </div>
      )}

      {/* Quit confirm */}
      <Sheet open={confirmQuit} onClose={() => setConfirmQuit(false)} title="End session?">
        <p className="text-sm leading-relaxed text-[var(--muted)]">
          You have {total - doneCount} sets left. Progress so far will be discarded unless you finish.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button className="btn btn-ghost h-12" onClick={() => setConfirmQuit(false)}>
            Keep going
          </button>
          <button
            className="btn btn-danger h-12"
            onClick={() => {
              cancelWorkout();
              router.replace("/");
            }}
          >
            Discard
          </button>
        </div>
      </Sheet>

      <ExerciseDetailSheet exercise={guideExercise} onClose={() => setGuideId(null)} />
    </div>
  );
}
