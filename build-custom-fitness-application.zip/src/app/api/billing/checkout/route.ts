import { PLANS, type PlanId } from "@/lib/billing";

export const dynamic = "force-dynamic";

/**
 * Creates a payment order. Provider-agnostic: plug in whichever processor
 * you sign up with by setting the matching env vars.
 *
 *   Razorpay  → RAZORPAY_KEY_ID + RAZORPAY_KEY_SECRET
 *   Stripe    → STRIPE_SECRET_KEY
 *
 * Until keys exist this returns 501 with a clear reason, and the UI falls
 * back to licence-code redemption so the paywall is still usable.
 */
export async function POST(req: Request) {
  let planId: PlanId | undefined;
  try {
    const body = (await req.json()) as { planId?: PlanId };
    planId = body.planId;
  } catch {
    return Response.json({ error: "invalid body" }, { status: 400 });
  }

  const plan = PLANS.find((p) => p.id === planId);
  if (!plan) return Response.json({ error: "unknown plan" }, { status: 400 });

  const razorpayId = process.env.RAZORPAY_KEY_ID;
  const razorpaySecret = process.env.RAZORPAY_KEY_SECRET;
  const stripeKey = process.env.STRIPE_SECRET_KEY;

  /* ------------------------------ Razorpay ----------------------------- */
  if (razorpayId && razorpaySecret) {
    try {
      const auth = Buffer.from(`${razorpayId}:${razorpaySecret}`).toString("base64");
      const res = await fetch("https://api.razorpay.com/v1/orders", {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: plan.amount,
          currency: plan.currency,
          notes: { plan: plan.id, app: "forge" },
        }),
      });
      if (!res.ok) throw new Error("razorpay order failed");
      const order = (await res.json()) as { id: string; amount: number; currency: string };
      return Response.json({
        provider: "razorpay",
        keyId: razorpayId,
        orderId: order.id,
        amount: order.amount,
        currency: order.currency,
        plan: plan.id,
      });
    } catch {
      return Response.json({ error: "Could not reach Razorpay." }, { status: 502 });
    }
  }

  /* ------------------------------- Stripe ------------------------------ */
  if (stripeKey) {
    try {
      const origin = new URL(req.url).origin;
      const form = new URLSearchParams({
        mode: plan.durationDays === null ? "payment" : "subscription",
        "line_items[0][price_data][currency]": plan.currency.toLowerCase(),
        "line_items[0][price_data][product_data][name]": `FORGE Pro — ${plan.name}`,
        "line_items[0][price_data][unit_amount]": String(plan.amount),
        "line_items[0][quantity]": "1",
        success_url: `${origin}/profile?upgraded=1`,
        cancel_url: `${origin}/profile`,
      });
      if (plan.durationDays !== null) {
        form.set(
          "line_items[0][price_data][recurring][interval]",
          plan.id === "annual" ? "year" : "month"
        );
      }
      const res = await fetch("https://api.stripe.com/v1/checkout/sessions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${stripeKey}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: form,
      });
      if (!res.ok) throw new Error("stripe session failed");
      const session = (await res.json()) as { id: string; url: string };
      return Response.json({
        provider: "stripe",
        checkoutUrl: session.url,
        sessionId: session.id,
        plan: plan.id,
      });
    } catch {
      return Response.json({ error: "Could not reach Stripe." }, { status: 502 });
    }
  }

  return Response.json(
    {
      error: "no_provider",
      message:
        "Card payments aren't switched on yet. Add RAZORPAY_KEY_ID + RAZORPAY_KEY_SECRET (or STRIPE_SECRET_KEY) to enable checkout. You can still unlock Pro with a licence code.",
    },
    { status: 501 }
  );
}
