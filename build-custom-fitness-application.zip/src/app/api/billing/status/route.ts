import { db } from "@/db";
import { entitlements } from "@/db/schema";
import { eq } from "drizzle-orm";
import { TRIAL_DAYS, type Entitlement } from "@/lib/billing";

export const dynamic = "force-dynamic";

function toEntitlement(row: typeof entitlements.$inferSelect): Entitlement {
  return {
    tier: (row.tier as Entitlement["tier"]) ?? "free",
    plan: (row.plan as Entitlement["plan"]) ?? null,
    expiresAt: row.expiresAt ? new Date(row.expiresAt).toISOString() : null,
    trialEndsAt: row.trialEndsAt ? new Date(row.trialEndsAt).toISOString() : null,
    verifiedAt: new Date().toISOString(),
    provider: row.provider,
  };
}

/** Fetch the server's view of this install's entitlement. */
export async function GET(req: Request) {
  const accountId = new URL(req.url).searchParams.get("accountId");
  if (!accountId) {
    return Response.json({ error: "accountId required" }, { status: 400 });
  }
  try {
    const rows = await db
      .select()
      .from(entitlements)
      .where(eq(entitlements.accountId, accountId))
      .limit(1);
    if (!rows[0]) return Response.json({ entitlement: null });
    return Response.json({ entitlement: toEntitlement(rows[0]) });
  } catch {
    return Response.json({ error: "unavailable" }, { status: 503 });
  }
}

/**
 * Starts the free trial. Server-side so clearing app data or reinstalling
 * cannot farm unlimited trials for the same account id.
 */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { accountId?: string };
    const accountId = body.accountId;
    if (!accountId) {
      return Response.json({ error: "accountId required" }, { status: 400 });
    }

    const rows = await db
      .select()
      .from(entitlements)
      .where(eq(entitlements.accountId, accountId))
      .limit(1);
    const existing = rows[0];

    // Never re-issue a trial, and never downgrade an active purchase.
    if (existing) {
      if (existing.tier === "pro" || existing.trialEndsAt) {
        return Response.json({
          entitlement: toEntitlement(existing),
          alreadyUsed: existing.tier !== "pro",
        });
      }
    }

    const trialEnds = new Date(Date.now() + TRIAL_DAYS * 86400000).toISOString();
    const values = {
      accountId,
      tier: "trial",
      status: "active",
      plan: "trial",
      expiresAt: null,
      trialEndsAt: trialEnds,
      updatedAt: new Date().toISOString(),
    };

    const saved = existing
      ? await db
          .update(entitlements)
          .set(values)
          .where(eq(entitlements.accountId, accountId))
          .returning()
      : await db.insert(entitlements).values(values).returning();

    return Response.json({ entitlement: toEntitlement(saved[0]) });
  } catch {
    return Response.json({ error: "unavailable" }, { status: 503 });
  }
}
