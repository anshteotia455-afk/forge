import { db } from "@/db";
import { entitlements, licenseCodes } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import { normaliseCode, type Entitlement } from "@/lib/billing";

export const dynamic = "force-dynamic";

/**
 * Redeems a licence code. Lets you sell or gift access without a payment
 * provider, and is the fallback if a store purchase fails to attach.
 */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { accountId?: string; code?: string };
    const accountId = body.accountId?.trim();
    const code = normaliseCode(body.code ?? "");

    if (!accountId || !code) {
      return Response.json({ error: "accountId and code required" }, { status: 400 });
    }

    const found = await db
      .select()
      .from(licenseCodes)
      .where(and(eq(licenseCodes.code, code), eq(licenseCodes.active, true)))
      .limit(1);
    const lic = found[0];

    if (!lic) {
      return Response.json({ error: "That code isn't valid." }, { status: 404 });
    }
    if (lic.redemptions >= lic.maxRedemptions) {
      return Response.json({ error: "That code has already been used." }, { status: 409 });
    }

    const expiresAt =
      lic.durationDays && lic.durationDays > 0
        ? new Date(Date.now() + lic.durationDays * 86400000).toISOString()
        : null;

    const values = {
      accountId,
      tier: "pro",
      status: "active",
      plan: "code",
      expiresAt,
      trialEndsAt: null,
      provider: "license",
      providerRef: code,
      updatedAt: new Date().toISOString(),
    };

    const existing = await db
      .select()
      .from(entitlements)
      .where(eq(entitlements.accountId, accountId))
      .limit(1);

    if (existing[0]) {
      await db.update(entitlements).set(values).where(eq(entitlements.accountId, accountId));
    } else {
      await db.insert(entitlements).values(values);
    }

    await db
      .update(licenseCodes)
      .set({ redemptions: sql`${licenseCodes.redemptions} + 1` })
      .where(eq(licenseCodes.code, code));

    const entitlement: Entitlement = {
      tier: "pro",
      plan: "code",
      expiresAt,
      trialEndsAt: null,
      verifiedAt: new Date().toISOString(),
      provider: "license",
    };

    return Response.json({ entitlement });
  } catch {
    return Response.json({ error: "unavailable" }, { status: 503 });
  }
}
