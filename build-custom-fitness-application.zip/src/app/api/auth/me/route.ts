import { destroySession, userFromRequest } from "@/lib/auth-server";

export const dynamic = "force-dynamic";

/** Validates the stored token on app start. */
export async function GET(req: Request) {
  try {
    const user = await userFromRequest(req);
    if (!user) return Response.json({ user: null }, { status: 401 });
    return Response.json({ user });
  } catch {
    return Response.json({ error: "unavailable" }, { status: 503 });
  }
}

/** Logout — revokes the token server-side. */
export async function DELETE(req: Request) {
  try {
    await destroySession(req);
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: true });
  }
}
