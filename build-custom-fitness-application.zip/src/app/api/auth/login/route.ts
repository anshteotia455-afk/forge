import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createSession, normaliseEmail, verifyPassword } from "@/lib/auth-server";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { email?: string; password?: string };
    const email = normaliseEmail(body.email ?? "");
    const password = body.password ?? "";

    if (!email || !password) {
      return Response.json({ error: "Email and password are required." }, { status: 400 });
    }

    const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
    const user = rows[0];

    // Same message either way so the endpoint can't be used to discover
    // which email addresses are registered.
    const fail = () =>
      Response.json({ error: "Incorrect email or password." }, { status: 401 });

    if (!user) return fail();
    if (!verifyPassword(password, user.passwordSalt, user.passwordHash)) return fail();

    await db
      .update(users)
      .set({ lastSeenAt: new Date().toISOString() })
      .where(eq(users.id, user.id));

    const { token, expiresAt } = await createSession(user.id);

    return Response.json({
      token,
      expiresAt,
      user: { id: user.id, email: user.email, displayName: user.displayName },
    });
  } catch {
    return Response.json({ error: "Could not log in right now." }, { status: 503 });
  }
}
