import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  createSession,
  hashPassword,
  newUserId,
  normaliseEmail,
  validateCredentials,
} from "@/lib/auth-server";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      email?: string;
      password?: string;
      displayName?: string;
    };
    const email = normaliseEmail(body.email ?? "");
    const password = body.password ?? "";

    const invalid = validateCredentials(email, password);
    if (invalid) return Response.json({ error: invalid }, { status: 400 });

    const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (existing[0]) {
      return Response.json(
        { error: "An account with that email already exists. Try logging in." },
        { status: 409 }
      );
    }

    const { hash, salt } = hashPassword(password);
    const id = newUserId();
    const displayName = (body.displayName ?? "").trim().slice(0, 60) || null;

    await db.insert(users).values({
      id,
      email,
      displayName,
      passwordHash: hash,
      passwordSalt: salt,
    });

    const { token, expiresAt } = await createSession(id);

    return Response.json({
      token,
      expiresAt,
      user: { id, email, displayName },
    });
  } catch {
    return Response.json({ error: "Could not create the account." }, { status: 503 });
  }
}
