import { db } from "@/db";
import { syncState } from "@/db/schema";
import { eq } from "drizzle-orm";
import { userFromRequest } from "@/lib/auth-server";

export const dynamic = "force-dynamic";

/** Signed-out installs still get a backup slot, keyed by device id. */
const GUEST_PREFIX = "guest:";

async function resolveKey(req: Request): Promise<string | null> {
  const user = await userFromRequest(req);
  if (user) return `user:${user.id}`;
  const deviceId = new URL(req.url).searchParams.get("deviceId");
  if (deviceId && /^[\w-]{6,64}$/.test(deviceId)) return `${GUEST_PREFIX}${deviceId}`;
  return null;
}

export async function GET(req: Request) {
  try {
    const key = await resolveKey(req);
    if (!key) return Response.json({ row: null });
    const rows = await db.select().from(syncState).where(eq(syncState.id, key)).limit(1);
    return Response.json({ row: rows[0] ?? null });
  } catch {
    return Response.json({ error: "database unavailable" }, { status: 500 });
  }
}

/**
 * Last-write-wins sync, scoped to the signed-in account (or the device when
 * signed out) so two users on one phone never overwrite each other.
 */
export async function POST(req: Request) {
  try {
    const key = await resolveKey(req);
    if (!key) return Response.json({ error: "no sync target" }, { status: 400 });

    const body = (await req.json()) as { state?: unknown; updatedAt?: unknown };
    if (!body || typeof body.state !== "object" || body.state === null) {
      return Response.json({ error: "invalid state payload" }, { status: 400 });
    }
    const incomingAt =
      typeof body.updatedAt === "string" ? body.updatedAt : new Date().toISOString();

    const rows = await db.select().from(syncState).where(eq(syncState.id, key)).limit(1);
    const existing = rows[0];

    let winner = existing;
    if (!existing) {
      const inserted = await db
        .insert(syncState)
        .values({ id: key, state: body.state, updatedAt: incomingAt })
        .returning();
      winner = inserted[0];
    } else if (Date.parse(incomingAt) > Date.parse(String(existing.updatedAt))) {
      const updated = await db
        .update(syncState)
        .set({ state: body.state, updatedAt: incomingAt })
        .where(eq(syncState.id, key))
        .returning();
      winner = updated[0];
    }

    return Response.json({ state: winner.state, updatedAt: winner.updatedAt });
  } catch {
    return Response.json({ error: "database unavailable" }, { status: 500 });
  }
}
