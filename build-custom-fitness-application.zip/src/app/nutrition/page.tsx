"use client";

import {
  ArrowLeft,
  ArrowRight,
  Bookmark,
  Check,
  Coffee,
  Copy,
  Droplets,
  Minus,
  Moon,
  Plus,
  Search,
  Settings2,
  Sun,
  Sunrise,
  Trash2,
  X,
} from "lucide-react";
import { useMemo, useState } from "react";
import { useT } from "@/lib/i18n";
import { PaywallSheet, ProBadge, useAccess } from "@/components/paywall";
import { MacroBar, Reveal, Ring, Sheet, Stepper } from "@/components/ui";
import { FREE_LIMITS } from "@/lib/billing";
import { Food, FOODS, MealType } from "@/lib/data";
import {
  addDays,
  calcTargets,
  dateKey,
  DEFAULT_HYDRATION,
  displayDate,
  mlToLitres,
  parseKey,
  recommendedWaterMl,
  vesselsForGoal,
  VESSEL_PRESETS,
} from "@/lib/engine";
import { MealTemplate, useStore } from "@/lib/store";

const MEAL_ICONS: Record<MealType, typeof Sun> = {
  breakfast: Sunrise,
  lunch: Sun,
  dinner: Moon,
  snacks: Coffee,
};

const MEAL_ORDER: { id: MealType; label: string }[] = [
  { id: "breakfast", label: "Breakfast" },
  { id: "lunch", label: "Lunch" },
  { id: "dinner", label: "Dinner" },
  { id: "snacks", label: "Snacks" },
];

export default function NutritionPage() {
  const t = useT();
  const profile = useStore((s) => s.profile);
  const meals = useStore((s) => s.meals);
  const customFoods = useStore((s) => s.customFoods);
  const addMeal = useStore((s) => s.addMeal);
  const removeMeal = useStore((s) => s.removeMeal);
  const templates = useStore((s) => s.templates);
  const saveTemplate = useStore((s) => s.saveTemplate);
  const deleteTemplate = useStore((s) => s.deleteTemplate);
  const addCustomFood = useStore((s) => s.addCustomFood);
  const water = useStore((s) => s.water);
  const setWater = useStore((s) => s.setWater);

  const [selKey, setSelKey] = useState(dateKey());
  const [sheetMeal, setSheetMeal] = useState<MealType | null>(null);
  const [tab, setTab] = useState<"search" | "custom" | "recipe">("search");
  const [query, setQuery] = useState("");
  const [catFilter, setCatFilter] = useState<string | null>(null);
  const [picked, setPicked] = useState<Food | null>(null);
  const [qty, setQty] = useState(1);
  const [cf, setCf] = useState({ name: "", serving: "", cal: "", p: "", c: "", f: "" });
  const [hydrationOpen, setHydrationOpen] = useState(false);
  const [tmplSave, setTmplSave] = useState<MealType | null>(null);
  const [tmplName, setTmplName] = useState("");
  const [tmplLog, setTmplLog] = useState<MealTemplate | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [recipe, setRecipe] = useState<
    { foodId: string; name: string; serving: string; mult: number; cal: number; p: number; c: number; f: number }[]
  >([]);
  const [recipeYield, setRecipeYield] = useState(1);
  const [recipeName, setRecipeName] = useState("");
  const [recipeQuery, setRecipeQuery] = useState("");

  const flashToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2600);
  };
  const [payOpen, setPayOpen] = useState(false);
  const access = useAccess();

  const today = dateKey();
  const isToday = selKey === today;
  const targets = useMemo(
    () =>
      profile
        ? calcTargets(profile)
        : { calories: 2200, protein: 120, carbs: 240, fat: 61, bmr: 0, maintenance: 2200, delta: 0 },
    [profile]
  );

  // Weekly report anchored on the selected day (7 days ending there).
  const weekKeys = Array.from({ length: 7 }, (_, i) => dateKey(addDays(parseKey(selKey), i - 6)));
  const weekSet = new Set(weekKeys);
  const byDay = new Map<string, { kcal: number; p: number; c: number; f: number }>();
  for (const k of weekKeys) byDay.set(k, { kcal: 0, p: 0, c: 0, f: 0 });
  for (const m of meals) {
    if (!weekSet.has(m.date)) continue;
    const d = byDay.get(m.date)!;
    d.kcal += m.cal * m.qty;
    d.p += m.p * m.qty;
    d.c += m.c * m.qty;
    d.f += m.f * m.qty;
  }
  const loggedDays = weekKeys.filter((k) => (byDay.get(k)?.kcal ?? 0) > 0);
  const avgOf = (sel: (d: { kcal: number; p: number; c: number; f: number }) => number) =>
    loggedDays.length
      ? Math.round(loggedDays.reduce((sum, k) => sum + sel(byDay.get(k)!), 0) / loggedDays.length)
      : 0;
  const avgKcal = avgOf((d) => d.kcal);
  const avgP = avgOf((d) => d.p);
  const avgC = avgOf((d) => d.c);
  const avgF = avgOf((d) => d.f);
  const proteinHits = loggedDays.filter((k) => byDay.get(k)!.p >= targets.protein * 0.9).length;
  const bestDay = loggedDays.length
    ? loggedDays.reduce((a, b) => (byDay.get(a)!.p >= byDay.get(b)!.p ? a : b))
    : null;
  const overDay = loggedDays
    .filter((k) => byDay.get(k)!.kcal > targets.calories)
    .reduce<string | null>(
      (a, b) => (!a || byDay.get(b)!.kcal > byDay.get(a)!.kcal ? b : a),
      null
    );
  const avgShort = Math.round(targets.protein - avgP);
  const avgOver = Math.round(avgKcal - targets.calories);
  const reportTip =
    loggedDays.length === 0
      ? "Log a few days this week to unlock your nutrition report."
      : avgShort > 10
        ? `You average ${avgShort}g short of protein — add curd, eggs, paneer or a whey shake.`
        : avgOver > 100
          ? `Averaging ${avgOver} kcal over target on logged days — trim the snacks.`
          : "Nutrition is on track — protein and calories are landing close to target.";

  const allFoods = useMemo(() => {
    const base = access.isPro ? FOODS : FOODS.slice(0, FREE_LIMITS.foodItems);
    return [...customFoods, ...base];
  }, [customFoods, access.isPro]);
  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = allFoods;
    if (catFilter) list = list.filter((f) => f.cat === catFilter);
    if (!q) return list;
    return list.filter(
      (f) => f.name.toLowerCase().includes(q) || f.cat.toLowerCase().includes(q)
    );
  }, [query, allFoods, catFilter]);

  const categories = useMemo(() => {
    const order: string[] = [];
    for (const f of allFoods) if (!order.includes(f.cat)) order.push(f.cat);
    return order;
  }, [allFoods]);

  // Most recently logged unique foods — one-tap re-logging
  const recentFoods = useMemo(() => {
    const seen = new Map<string, Food>();
    for (let i = meals.length - 1; i >= 0 && seen.size < 8; i--) {
      const f = allFoods.find((x) => x.id === meals[i].foodId);
      if (f && !seen.has(f.id)) seen.set(f.id, f);
    }
    return [...seen.values()];
  }, [meals, allFoods]);

  const dayMeals = meals.filter((m) => m.date === selKey);
  const eaten = dayMeals.reduce((s, m) => s + m.cal * m.qty, 0);
  const p = dayMeals.reduce((s, m) => s + m.p * m.qty, 0);
  const c = dayMeals.reduce((s, m) => s + m.c * m.qty, 0);
  const f = dayMeals.reduce((s, m) => s + m.f * m.qty, 0);
  const left = targets.calories - eaten;
  const glasses = water[selKey] ?? 0;
  const hydration = useStore((st) => st.hydration) ?? DEFAULT_HYDRATION;
  const targetVessels = vesselsForGoal(hydration);
  const drunkMl = glasses * hydration.vesselMl;
  const remainingMl = Math.max(0, hydration.goalMl - drunkMl);
  const hydrationPct = hydration.goalMl > 0 ? drunkMl / hydration.goalMl : 0;

  const shiftDay = (n: number) => setSelKey(dateKey(addDays(parseKey(selKey), n)));

  const prevDayKey = dateKey(addDays(parseKey(selKey), -1));
  const prevDayMeals = meals.filter((m) => m.date === prevDayKey);

  const repeatYesterday = () => {
    for (const m of prevDayMeals) {
      addMeal({
        date: selKey,
        meal: m.meal,
        foodId: m.foodId,
        name: m.name,
        serving: m.serving,
        qty: m.qty,
        cal: m.cal,
        p: m.p,
        c: m.c,
        f: m.f,
      });
    }
  };

  const openSheet = (m: MealType) => {
    setSheetMeal(m);
    setTab("search");
    setQuery("");
    setCatFilter(null);
    setPicked(null);
    setQty(1);
  };

  const logFood = () => {
    if (!picked || !sheetMeal) return;
    addMeal({
      date: selKey,
      meal: sheetMeal,
      foodId: picked.id,
      name: picked.name,
      serving: picked.serving,
      qty,
      cal: picked.cal,
      p: picked.p,
      c: picked.c,
      f: picked.f,
    });
    setPicked(null);
    setQty(1);
  };

  const saveCustom = () => {
    if (!cf.name.trim() || !sheetMeal) return;
    const food = addCustomFood({
      name: cf.name.trim(),
      serving: cf.serving.trim() || "1 serving",
      cal: Number(cf.cal) || 0,
      p: Number(cf.p) || 0,
      c: Number(cf.c) || 0,
      f: Number(cf.f) || 0,
      cat: "My foods",
    });
    addMeal({
      date: selKey,
      meal: sheetMeal,
      foodId: food.id,
      name: food.name,
      serving: food.serving,
      qty: 1,
      cal: food.cal,
      p: food.p,
      c: food.c,
      f: food.f,
    });
    setCf({ name: "", serving: "", cal: "", p: "", c: "", f: "" });
    setSheetMeal(null);
  };

  // ---- Recipe estimator ----
  const recipeTotals = recipe.reduce(
    (a, it) => ({
      cal: a.cal + it.cal * it.mult,
      p: a.p + it.p * it.mult,
      c: a.c + it.c * it.mult,
      f: a.f + it.f * it.mult,
    }),
    { cal: 0, p: 0, c: 0, f: 0 }
  );
  const yieldN = Math.max(1, recipeYield);
  const perServing = {
    cal: recipeTotals.cal / yieldN,
    p: recipeTotals.p / yieldN,
    c: recipeTotals.c / yieldN,
    f: recipeTotals.f / yieldN,
  };
  const recipeResults = FOODS.filter((f) =>
    f.name.toLowerCase().includes(recipeQuery.trim().toLowerCase())
  ).slice(0, 8);
  const recipeTitle = () => recipeName.trim() || "My recipe";
  const round1 = (n: number) => Math.round(n * 10) / 10;

  const logRecipeServing = () => {
    if (!sheetMeal || recipe.length === 0) return;
    addMeal({
      date: selKey,
      meal: sheetMeal,
      foodId: `recipe-${Date.now()}`,
      name: recipeTitle(),
      serving: `1 of ${yieldN} servings`,
      qty: 1,
      cal: Math.round(perServing.cal),
      p: round1(perServing.p),
      c: round1(perServing.c),
      f: round1(perServing.f),
    });
    setRecipe([]);
    setRecipeName("");
    setSheetMeal(null);
    flashToast(`Logged 1 serving of ${recipeTitle()}`);
  };

  const saveRecipeAsFood = () => {
    if (recipe.length === 0) return;
    addCustomFood({
      name: recipeTitle(),
      serving: `1 serving (makes ${yieldN})`,
      cal: Math.round(perServing.cal),
      p: round1(perServing.p),
      c: round1(perServing.c),
      f: round1(perServing.f),
      cat: "My recipes",
    });
    setRecipe([]);
    setRecipeName("");
    flashToast("Recipe saved to My foods");
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Header + day switcher */}
      <Reveal>
        <div className="flex items-end justify-between pt-1">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--ember)]">{t("pg.nutEyebrow")}
          </p>
            <h1 className="font-display mt-1 text-[32px] uppercase leading-none tracking-wide">{t("pg.nutTitle")}
          </h1>
          </div>
          <div className="flex items-center gap-1">
            <button
              className="grid h-9 w-9 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-2)]"
              onClick={() => shiftDay(-1)}
              aria-label="Previous day"
            >
              <ArrowLeft size={15} />
            </button>
            <button
              className={`grid h-9 w-9 place-items-center rounded-full border border-[var(--line)] ${
                isToday ? "opacity-30" : "bg-[var(--surface-2)]"
              }`}
              onClick={() => !isToday && shiftDay(1)}
              aria-label="Next day"
              disabled={isToday}
            >
              <ArrowRight size={15} />
            </button>
          </div>
        </div>
        <div className="mt-2 flex items-center justify-between gap-2">
          <button className="text-[12px] font-semibold text-[var(--volt)]" onClick={() => setSelKey(today)}>
            {isToday ? "Today" : `${displayDate(selKey)} — tap for today`}
          </button>
          {prevDayMeals.length > 0 && dayMeals.length === 0 && (
            <button
              className="chip !px-3 !py-1.5 text-[11px] font-bold"
              onClick={repeatYesterday}
            >
              <Copy size={12} /> Repeat {isToday ? "yesterday" : "prev day"} ({prevDayMeals.length})
            </button>
          )}
        </div>
      </Reveal>

      {/* Calorie summary */}
      <Reveal>
        <div className="card p-5">
          <div className="flex items-center gap-5">
            <Ring
              size={128}
              stroke={12}
              value={eaten / targets.calories}
              color={left >= 0 ? "var(--volt)" : "var(--ember)"}
            >
              <div className="text-center">
                <p className="font-display tabular text-[28px] leading-none">
                  {Math.abs(Math.round(left))}
                </p>
                <p className="mt-0.5 text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">
                  {left >= 0 ? "kcal left" : "kcal over"}
                </p>
              </div>
            </Ring>
            <div className="min-w-0 flex-1">
              <div className="mb-1 flex items-baseline justify-between">
                <span className="text-[12px] text-[var(--muted)]">Eaten</span>
                <span className="tabular text-[15px] font-extrabold">{Math.round(eaten)}</span>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-[12px] text-[var(--muted)]">Daily target</span>
                <span className="tabular text-[15px] font-extrabold text-[var(--volt)]">
                  {targets.calories}
                </span>
              </div>
              <div className="mt-3 flex flex-col gap-2.5">
                <MacroBar label="Protein" value={p} max={targets.protein} color="var(--volt)" />
                <MacroBar label="Carbs" value={c} max={targets.carbs} color="var(--aqua)" />
                <MacroBar label="Fat" value={f} max={targets.fat} color="var(--ember)" />
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      {/* Water */}
      <Reveal>
        <div className="card p-4">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[rgba(92,214,255,0.12)] text-[var(--aqua)]">
              <Droplets size={18} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">
                Water{" "}
                <span className="tabular text-[var(--muted)]">
                  · {drunkMl} / {hydration.goalMl} ml
                </span>
              </p>
              <p className="tabular text-[11px] text-[var(--muted)]">
                {glasses}/{targetVessels} × {hydration.vesselMl} ml {hydration.vesselLabel.toLowerCase()}
                {remainingMl > 0 ? ` · ${remainingMl} ml to go` : " · goal reached 🎉"}
              </p>
            </div>
            <button
              className="shrink-0 rounded-full border border-[var(--line)] bg-[var(--surface-2)] p-2 text-[var(--muted)]"
              onClick={() => setHydrationOpen(true)}
              aria-label="Water settings"
            >
              <Settings2 size={14} />
            </button>
          </div>

          <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/[0.07]">
            <div
              className="h-full rounded-full bg-[var(--aqua)] transition-all duration-500"
              style={{ width: `${Math.min(100, hydrationPct * 100)}%` }}
            />
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            {Array.from({ length: Math.min(targetVessels, 16) }, (_, i) => (
              <button
                key={i}
                onClick={() => setWater(selKey, i < glasses ? i : i + 1)}
                className={`h-6 w-5 rounded-[5px] transition-all active:scale-90 ${
                  i < glasses ? "bg-[var(--aqua)]" : "bg-white/[0.08]"
                }`}
                aria-label={`${hydration.vesselLabel} ${i + 1}`}
              />
            ))}
            {glasses > targetVessels && (
              <span className="tabular rounded-full bg-[rgba(92,214,255,0.15)] px-2 py-0.5 text-[10px] font-bold text-[var(--aqua)]">
                +{glasses - targetVessels} extra
              </span>
            )}
            <div className="ml-auto flex gap-1.5">
              <button
                className="grid h-8 w-8 place-items-center rounded-full bg-[var(--surface-2)] text-[var(--muted)]"
                onClick={() => setWater(selKey, glasses - 1)}
                aria-label="Remove one"
              >
                <Minus size={14} />
              </button>
              <button
                className="grid h-8 w-8 place-items-center rounded-full bg-[rgba(92,214,255,0.18)] text-[var(--aqua)]"
                onClick={() => setWater(selKey, glasses + 1)}
                aria-label="Add one"
              >
                <Plus size={15} strokeWidth={3} />
              </button>
            </div>
          </div>
        </div>
      </Reveal>

      <HydrationSheet open={hydrationOpen} onClose={() => setHydrationOpen(false)} />

      {/* Weekly nutrition report */}
      <Reveal>
        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Weekly report
            </p>
            <span className="text-[10px] font-semibold text-[var(--muted)]">
              {loggedDays.length}/7 days logged
            </span>
          </div>

          {loggedDays.length > 0 ? (
            <>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { v: avgKcal || "—", l: "avg kcal" },
                  { v: avgP, l: "prot g" },
                  { v: avgC, l: "carb g" },
                  { v: avgF, l: "fat g" },
                ].map((x) => (
                  <div key={x.l} className="card-2 p-2.5 text-center">
                    <p className="font-display tabular text-lg leading-none">{x.v}</p>
                    <p className="mt-0.5 text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                      {x.l}
                    </p>
                  </div>
                ))}
              </div>

              <div className="mt-3 flex items-center justify-between rounded-xl bg-[rgba(205,248,63,0.07)] px-3.5 py-2.5">
                <span className="text-[11px] font-semibold text-[var(--muted)]">Protein goal hit</span>
                <span className="tabular text-[13px] font-extrabold text-[var(--volt)]">
                  {proteinHits}/{loggedDays.length} days
                </span>
              </div>

              <div className="mt-2 grid grid-cols-2 gap-2">
                <div className="card-2 px-3 py-2.5">
                  <p className="text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                    Best protein day
                  </p>
                  <p className="mt-0.5 truncate text-[12px] font-bold">
                    {bestDay
                      ? `${new Date(bestDay + "T00:00").toLocaleDateString(undefined, { weekday: "short" })} · ${Math.round(byDay.get(bestDay)!.p)}g`
                      : "—"}
                  </p>
                </div>
                <div className="card-2 px-3 py-2.5">
                  <p className="text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                    Most over target
                  </p>
                  <p className="mt-0.5 truncate text-[12px] font-bold">
                    {overDay
                      ? `${new Date(overDay + "T00:00").toLocaleDateString(undefined, { weekday: "short" })} · +${Math.round(byDay.get(overDay)!.kcal - targets.calories)}`
                      : "None 🎯"}
                  </p>
                </div>
              </div>

              <p className="mt-3 border-t border-[var(--line)] pt-3 text-[11px] leading-relaxed text-[var(--muted)]">
                {reportTip}
              </p>
            </>
          ) : tab === "recipe" ? (
          <div className="flex flex-col gap-4">
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">
              Build a recipe from foods you know: add ingredients, set how many servings it makes,
              then log or save exact macros per serving.
            </p>

            <input
              className="field"
              placeholder="Recipe name"
              value={recipeName}
              onChange={(e) => setRecipeName(e.target.value)}
            />

            <div className="relative">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
              <input
                className="field !py-2.5 !pl-9 text-sm"
                placeholder="Add an ingredient…"
                value={recipeQuery}
                onChange={(e) => setRecipeQuery(e.target.value)}
              />
            </div>

            {recipeQuery.trim() && (
              <div className="card-2 max-h-40 divide-y divide-[var(--line)] overflow-y-auto no-scrollbar">
                {recipeResults.map((f) => (
                  <button
                    key={f.id}
                    className="flex w-full items-center gap-2 px-3.5 py-2.5 text-left"
                    onClick={() => {
                      setRecipe((r) => [
                        ...r,
                        { foodId: f.id, name: f.name, serving: f.serving, mult: 1, cal: f.cal, p: f.p, c: f.c, f: f.f },
                      ]);
                      setRecipeQuery("");
                    }}
                  >
                    <span className="min-w-0 flex-1 truncate text-[13px] font-semibold">{f.name}</span>
                    <span className="tabular text-[11px] text-[var(--muted)]">{f.serving}</span>
                    <Plus size={14} className="shrink-0 text-[var(--volt)]" />
                  </button>
                ))}
                {recipeResults.length === 0 && (
                  <p className="px-3.5 py-4 text-center text-[12px] text-[var(--muted)]">
                    No match — try the Custom tab to define it yourself.
                  </p>
                )}
              </div>
            )}

            {recipe.length > 0 && (
              <div className="card-2 divide-y divide-[var(--line)] overflow-hidden">
                {recipe.map((it, i) => (
                  <div key={`${it.foodId}-${i}`} className="flex items-center gap-2 px-3.5 py-2.5">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-semibold">{it.name}</p>
                      <p className="tabular text-[10px] text-[var(--muted)]">
                        {Math.round(it.cal * it.mult)} kcal · P{Math.round(it.p * it.mult)} ·{" "}
                        {it.serving} × {it.mult}
                      </p>
                    </div>
                    <Stepper
                      value={it.mult}
                      min={0.5}
                      max={20}
                      step={0.5}
                      onChange={(v) =>
                        setRecipe((r) => r.map((x, j) => (j === i ? { ...x, mult: v } : x)))
                      }
                    />
                    <button
                      className="text-[var(--muted)] active:text-[var(--red)]"
                      onClick={() => setRecipe((r) => r.filter((_, j) => j !== i))}
                      aria-label="Remove ingredient"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
                  Servings it makes
                </label>
                <input
                  className="field text-center"
                  type="number"
                  inputMode="numeric"
                  min={1}
                  value={recipeYield}
                  onChange={(e) => setRecipeYield(Math.max(1, Number(e.target.value) || 1))}
                />
              </div>
              <div className="card-2 flex flex-col justify-center p-3 text-center">
                <p className="tabular font-display text-xl leading-none text-[var(--volt)]">
                  {Math.round(perServing.cal)}
                </p>
                <p className="text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                  kcal / serving
                </p>
              </div>
            </div>

            {recipe.length > 0 && (
              <>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { l: "protein", v: Math.round(perServing.p) },
                    { l: "carbs", v: Math.round(perServing.c) },
                    { l: "fat", v: Math.round(perServing.f) },
                  ].map((m) => (
                    <div key={m.l} className="card-2 p-2.5 text-center">
                      <p className="tabular font-display text-lg leading-none">{m.v}g</p>
                      <p className="text-[9px] font-bold uppercase tracking-wider text-[var(--muted)]">
                        {m.l}
                      </p>
                    </div>
                  ))}
                </div>
                <p className="tabular text-center text-[11px] text-[var(--muted)]">
                  Whole recipe: {Math.round(recipeTotals.cal)} kcal over {yieldN} serving
                  {yieldN > 1 ? "s" : ""}
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button className="btn btn-volt h-11 text-sm" onClick={logRecipeServing}>
                    Log 1 serving
                  </button>
                  <button className="btn btn-ghost h-11 text-sm" onClick={saveRecipeAsFood}>
                    Save as food
                  </button>
                </div>
              </>
            )}
          </div>
        ) : (
            <p className="py-2 text-[12px] leading-relaxed text-[var(--muted)]">{reportTip}</p>
          )}
        </div>
      </Reveal>

      {/* Save current meal as template */}
      <Sheet
        open={tmplSave !== null}
        onClose={() => setTmplSave(null)}
        title="Save as template"
      >
        <div className="flex flex-col gap-4">
          <p className="text-[12px] leading-relaxed text-[var(--muted)]">
            Save everything currently logged under{" "}
            <b className="text-[var(--text)]">
              {MEAL_ORDER.find((m) => m.id === tmplSave)?.label}
            </b>{" "}
            so you can log it again with a single tap.
          </p>
          <input
            className="field"
            value={tmplName}
            onChange={(e) => setTmplName(e.target.value)}
            placeholder="Template name"
          />
          <button
            className="btn btn-volt h-12 w-full"
            onClick={() => {
              if (!tmplSave) return;
              const items = dayMeals
                .filter((m) => m.meal === tmplSave)
                .map((m) => ({
                  foodId: m.foodId,
                  name: m.name,
                  serving: m.serving,
                  qty: m.qty,
                  cal: m.cal,
                  p: m.p,
                  c: m.c,
                  f: m.f,
                }));
              if (!items.length) return;
              saveTemplate({
                name: tmplName.trim() || "Template",
                sourceMeal: tmplSave,
                items,
              });
              setTmplSave(null);
              flashToast("Template saved");
            }}
          >
            <Bookmark size={16} /> Save template
          </button>
        </div>
      </Sheet>

      {/* Log a template → choose meal */}
      <Sheet
        open={tmplLog !== null}
        onClose={() => setTmplLog(null)}
        title={tmplLog?.name ?? "Template"}
      >
        <div className="flex flex-col gap-3">
          <p className="text-[12px] text-[var(--muted)]">
            {tmplLog?.items.map((i) => i.name).join(" · ")}
          </p>
          <div className="flex flex-col gap-2">
            {MEAL_ORDER.map((m) => (
              <button
                key={m.id}
                className="btn btn-ghost h-11 justify-start px-4 text-sm"
                onClick={() => {
                  if (!tmplLog) return;
                  for (const it of tmplLog.items) {
                    addMeal({
                      date: selKey,
                      meal: m.id,
                      foodId: it.foodId,
                      name: it.name,
                      serving: it.serving,
                      qty: it.qty,
                      cal: it.cal,
                      p: it.p,
                      c: it.c,
                      f: it.f,
                    });
                  }
                  const n = tmplLog.items.length;
                  setTmplLog(null);
                  flashToast(`Logged ${n} item${n > 1 ? "s" : ""} to ${m.label}`);
                }}
              >
                {m.label}
              </button>
            ))}
          </div>
          <button
            className="btn btn-danger h-10 text-[12px]"
            onClick={() => {
              if (tmplLog) deleteTemplate(tmplLog.id);
              setTmplLog(null);
            }}
          >
            <Trash2 size={14} /> Delete template
          </button>
        </div>
      </Sheet>
      <PaywallSheet open={payOpen} onClose={() => setPayOpen(false)} feature="customFoods" />

      {/* Meals */}
      {/* One-tap meal templates */}
      <Reveal>
        <div className="card p-4">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
              Quick templates
            </p>
            <span className="text-[10px] text-[var(--muted)]">tap to log instantly</span>
          </div>
          {templates.length === 0 ? (
            <p className="text-[12px] leading-relaxed text-[var(--muted)]">
              Log a meal, then tap the bookmark <Bookmark size={11} className="inline -mt-0.5" /> on
              its header to save it as a one-tap template.
            </p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {templates.map((t) => (
                <span key={t.id} className="relative inline-flex">
                  <button className="chip !py-2" onClick={() => setTmplLog(t)}>
                    {t.name} · {t.items.length}
                  </button>
                  <button
                    className="absolute -right-1.5 -top-1.5 grid h-4 w-4 place-items-center rounded-full bg-[var(--surface-3)] text-[var(--muted)]"
                    onClick={() => deleteTemplate(t.id)}
                    aria-label={`Delete ${t.name}`}
                  >
                    <X size={9} />
                  </button>
                </span>
              ))}
            </div>
          )}
          {toast && (
            <p className="anim-fade-up mt-2.5 text-[11px] font-bold text-[var(--volt)]">{toast}</p>
          )}
        </div>
      </Reveal>

      {MEAL_ORDER.map((section, si) => {
        const Icon = MEAL_ICONS[section.id];
        const items = dayMeals.filter((m) => m.meal === section.id);
        const kcal = items.reduce((s, m) => s + m.cal * m.qty, 0);
        return (
          <Reveal key={section.id} delay={si * 40}>
            <div className="card overflow-hidden">
              <div className="flex items-center gap-3 border-b border-[var(--line)] px-4 py-3">
                <Icon size={16} className="text-[var(--volt)]" />
                <p className="flex-1 text-sm font-bold">{section.label}</p>
                <span className="tabular text-[12px] font-bold text-[var(--muted)]">
                  {Math.round(kcal)} kcal
                </span>
                {items.length > 0 && (
                  <button
                    className="grid h-8 w-8 place-items-center rounded-full bg-[var(--surface-2)] text-[var(--muted)]"
                    onClick={() => {
                      setTmplSave(section.id);
                      setTmplName(`${section.label} template`);
                    }}
                    aria-label={`Save ${section.label} as template`}
                  >
                    <Bookmark size={14} />
                  </button>
                )}
                <button
                  className="grid h-8 w-8 place-items-center rounded-full bg-[var(--volt)] text-[#0b0c0e]"
                  onClick={() => openSheet(section.id)}
                  aria-label={`Add to ${section.label}`}
                >
                  <Plus size={16} strokeWidth={3} />
                </button>
              </div>
              {items.length === 0 ? (
                <p className="px-4 py-3.5 text-[12px] text-[var(--muted)]">Nothing logged yet</p>
              ) : (
                <div className="divide-y divide-[var(--line)]">
                  {items.map((m) => (
                    <div key={m.id} className="flex items-center gap-3 px-4 py-3">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-semibold">
                          {m.name}
                          <span className="tabular text-[var(--muted)]">
                            {" "}
                            ×{m.qty}
                          </span>
                        </p>
                        <p className="text-[11px] text-[var(--muted)]">
                          {m.serving} · P{Math.round(m.p * m.qty)} C{Math.round(m.c * m.qty)} F
                          {Math.round(m.f * m.qty)}
                        </p>
                      </div>
                      <span className="tabular text-[13px] font-extrabold">
                        {Math.round(m.cal * m.qty)}
                      </span>
                      <button
                        className="text-[var(--muted)] transition-colors active:text-[var(--red)]"
                        onClick={() => removeMeal(m.id)}
                        aria-label="Remove"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Reveal>
        );
      })}

      {/* Add food sheet */}
      <Sheet
        open={sheetMeal !== null}
        onClose={() => setSheetMeal(null)}
        title={sheetMeal ? `Add to ${MEAL_ORDER.find((m) => m.id === sheetMeal)?.label}` : "Add food"}
      >
        <div className="mb-4 flex gap-1 rounded-xl border border-[var(--line)] bg-[var(--surface-2)] p-1">
          {(["search", "custom", "recipe"] as const).map((t) => (
            <button
              key={t}
              onClick={() => {
                if (t === "custom" && !access.isPro) {
                  setPayOpen(true);
                  return;
                }
                setTab(t);
              }}
              className={`flex-1 rounded-lg px-3 py-2 text-[13px] font-semibold capitalize transition-all ${
                tab === t ? "bg-[var(--volt)] text-[#0b0c0e]" : "text-[var(--muted)]"
              }`}
            >
              {t === "search"
                ? "Food database"
                : t === "custom"
                  ? <>Custom food {!access.isPro && <ProBadge className="ml-1" />}</>
                  : "Recipe"}
            </button>
          ))}
        </div>

        {tab === "search" ? (
          <div className="flex flex-col gap-3">
            <div>
              <div className="relative">
                <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
                <input
                  className="field !pl-10"
                  placeholder="Search aloo tamatar, dal, sabzi…"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
              </div>
              <div className="mt-1.5 flex items-start justify-between gap-3 text-[10px] leading-snug text-[var(--muted)]">
                <span className="tabular shrink-0 font-semibold text-[var(--text)]">
                  {results.length} match{results.length === 1 ? "" : "es"} · {allFoods.length} foods
                </span>
                <span className="text-right">
                  {access.isPro
                    ? "Home recipes assume moderate oil; adjust quantity or use Custom."
                    : `Free plan shows ${FREE_LIMITS.foodItems} foods — Pro unlocks all ${FOODS.length}.`}
                </span>
              </div>
            </div>
            {!query.trim() && (
              <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
                <button
                  className={`chip shrink-0 !py-1.5 text-[11px] font-bold ${catFilter === null ? "chip-on" : ""}`}
                  onClick={() => setCatFilter(null)}
                >
                  All
                </button>
                {categories.map((c) => (
                  <button
                    key={c}
                    className={`chip shrink-0 !py-1.5 text-[11px] font-semibold ${catFilter === c ? "chip-on" : ""}`}
                    onClick={() => setCatFilter(catFilter === c ? null : c)}
                  >
                    {c}
                  </button>
                ))}
              </div>
            )}
            {!query.trim() && recentFoods.length > 0 && (
              <div>
                <p className="mb-1.5 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">
                  Recent — tap to re-log
                </p>
                <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-2">
                  {recentFoods.map((f) => (
                    <button
                      key={f.id}
                      className="chip shrink-0 !py-1.5 text-[11px] font-semibold"
                      onClick={() => setPicked(f)}
                    >
                      {f.name}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <div className="card-2 max-h-[38dvh] divide-y divide-[var(--line)] overflow-y-auto no-scrollbar">
              {results.slice(0, 60).map((food) => (
                <button
                  key={food.id}
                  className={`flex w-full items-center gap-3 px-4 py-3 text-left transition-colors ${
                    picked?.id === food.id ? "bg-[rgba(205,248,63,0.08)]" : ""
                  }`}
                  onClick={() => setPicked(food)}
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-semibold">
                      {food.name}
                      {food.custom && (
                        <span className="ml-1.5 rounded bg-[rgba(205,248,63,0.15)] px-1.5 py-0.5 text-[9px] font-bold uppercase text-[var(--volt)]">
                          mine
                        </span>
                      )}
                    </p>
                    <p className="text-[11px] text-[var(--muted)]">
                      {food.serving} · P{food.p} C{food.c} F{food.f}
                    </p>
                  </div>
                  <span className="tabular text-[13px] font-bold">{food.cal} kcal</span>
                </button>
              ))}
              {results.length === 0 && (
                <p className="px-4 py-6 text-center text-[12px] text-[var(--muted)]">
                  No match — try the Custom tab.
                </p>
              )}
            </div>

            {picked && (
              <div className="anim-fade-up card-2 flex items-center gap-3 p-3.5">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold">{picked.name}</p>
                  <p className="tabular text-[11px] text-[var(--muted)]">
                    {Math.round(picked.cal * qty)} kcal · {qty} × {picked.serving}
                  </p>
                </div>
                <Stepper value={qty} onChange={setQty} min={0.5} max={10} step={0.5} />
                <button className="btn btn-volt h-10 px-5 text-sm" onClick={logFood}>
                  Log
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            <input
              className="field"
              placeholder="Food name"
              value={cf.name}
              onChange={(e) => setCf({ ...cf, name: e.target.value })}
            />
            <input
              className="field"
              placeholder="Serving (e.g. 1 bowl, 100 g)"
              value={cf.serving}
              onChange={(e) => setCf({ ...cf, serving: e.target.value })}
            />
            <div className="grid grid-cols-4 gap-2">
              {(["cal", "p", "c", "f"] as const).map((k) => (
                <div key={k}>
                  <label className="mb-1 block text-center text-[10px] font-bold uppercase tracking-wider text-[var(--muted)]">
                    {k === "cal" ? "kcal" : k === "p" ? "Prot" : k === "c" ? "Carb" : "Fat"}
                  </label>
                  <input
                    className="field !px-2 text-center"
                    type="number"
                    inputMode="decimal"
                    placeholder="0"
                    value={cf[k]}
                    onChange={(e) => setCf({ ...cf, [k]: e.target.value })}
                  />
                </div>
              ))}
            </div>
            <p className="text-[11px] text-[var(--muted)]">
              Saved to “My foods” — reusable any day.
            </p>
            <button className="btn btn-volt h-12 w-full" onClick={saveCustom}>
              <Plus size={16} strokeWidth={3} /> Save & log
            </button>
          </div>
        )}
      </Sheet>
    </div>
  );
}


/* ------------------------- Hydration settings -------------------------- */

function HydrationSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const hydration = useStore((s) => s.hydration) ?? DEFAULT_HYDRATION;
  const setHydration = useStore((s) => s.setHydration);
  const profile = useStore((s) => s.profile);
  const weights = useStore((s) => s.weights);

  const [customMl, setCustomMl] = useState(String(hydration.vesselMl));
  const [goalMl, setGoalMl] = useState(String(hydration.goalMl));

  const bodyweight = weights[0]?.kg ?? profile?.weightKg ?? 70;
  const suggested = recommendedWaterMl(bodyweight, profile?.activity ?? 1.375);

  const vesselMl = Math.max(50, Number(customMl) || 0);
  const goal = Math.max(500, Number(goalMl) || 0);
  const vessels = vesselsForGoal({ ...hydration, vesselMl, goalMl: goal });

  const save = () => {
    setHydration({ vesselMl, goalMl: goal });
    onClose();
  };

  return (
    <Sheet open={open} onClose={onClose} title="Water goal">
      <div className="flex flex-col gap-5">
        <p className="text-[12px] leading-relaxed text-[var(--muted)]">
          Set the size of the glass or bottle you actually drink from, and your daily target.
          FORGE works out how many refills that is.
        </p>

        {/* Vessel presets */}
        <div>
          <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            My vessel
          </p>
          <div className="flex flex-wrap gap-1.5">
            {VESSEL_PRESETS.map((v) => (
              <button
                key={v.label + v.ml}
                className={`chip !py-1.5 text-[11px] font-semibold ${
                  Number(customMl) === v.ml ? "chip-on" : ""
                }`}
                onClick={() => {
                  setCustomMl(String(v.ml));
                  setHydration({ vesselLabel: v.label });
                }}
              >
                {v.icon} {v.label} · {v.ml}ml
              </button>
            ))}
          </div>
          <label className="mb-1.5 mt-3 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Exact capacity (ml)
          </label>
          <input
            className="field font-display !text-2xl tracking-wide"
            type="number"
            inputMode="numeric"
            value={customMl}
            onChange={(e) => setCustomMl(e.target.value)}
          />
        </div>

        {/* Daily goal */}
        <div>
          <div className="mb-2 flex items-baseline justify-between">
            <p className="text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
              Daily goal (ml)
            </p>
            <button
              className="text-[11px] font-bold text-[var(--volt)]"
              onClick={() => setGoalMl(String(suggested))}
            >
              Use {mlToLitres(suggested)} for {bodyweight}kg
            </button>
          </div>
          <input
            className="field font-display !text-2xl tracking-wide"
            type="number"
            inputMode="numeric"
            step="50"
            value={goalMl}
            onChange={(e) => setGoalMl(e.target.value)}
          />
          <div className="mt-2 flex flex-wrap gap-1.5">
            {[1500, 2000, 2500, 3000, 3500, 4000].map((g) => (
              <button
                key={g}
                className={`chip !py-1.5 text-[11px] font-semibold ${
                  Number(goalMl) === g ? "chip-on" : ""
                }`}
                onClick={() => setGoalMl(String(g))}
              >
                {mlToLitres(g)}
              </button>
            ))}
          </div>
        </div>

        <div className="card-2 p-4 text-center">
          <p className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">
            That works out to
          </p>
          <p className="font-display tabular mt-1 text-3xl text-[var(--aqua)]">
            {vessels} × {vesselMl} ml
          </p>
          <p className="mt-1 text-[11px] text-[var(--muted)]">
            {mlToLitres(vessels * vesselMl)} per day
          </p>
        </div>

        <button className="btn btn-volt h-12 w-full" onClick={save}>
          <Check size={16} strokeWidth={3} /> Save water goal
        </button>
      </div>
    </Sheet>
  );
}
