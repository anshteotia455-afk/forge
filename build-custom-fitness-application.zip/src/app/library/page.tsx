"use client";

import { ArrowLeft, BookOpen, ChevronRight, Dumbbell, Search } from "lucide-react";
import { useRouter } from "next/navigation";
import { useT } from "@/lib/i18n";
import { useMemo, useState } from "react";
import { Chip, Reveal } from "@/components/ui";
import { ExerciseDetailSheet } from "@/components/exercise-detail";
import { Exercise, EXERCISES, MUSCLES, MUSCLE_LABEL, Muscle } from "@/lib/data";
import { useStore } from "@/lib/store";

export default function LibraryPage() {
  const t = useT();
  const router = useRouter();
  const customExercises = useStore((s) => s.customExercises);
  const [query, setQuery] = useState("");
  const [muscle, setMuscle] = useState<Muscle | "all">("all");
  const [guideEx, setGuideEx] = useState<Exercise | null>(null);

  const all = useMemo(() => [...customExercises, ...EXERCISES], [customExercises]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return all.filter((e) => {
      if (muscle !== "all" && !e.muscles.includes(muscle)) return false;
      if (!q) return true;
      return (
        e.name.toLowerCase().includes(q) ||
        e.muscles.some((m) => MUSCLE_LABEL[m].toLowerCase().includes(q))
      );
    });
  }, [all, query, muscle]);

  return (
    <div className="flex flex-col gap-4">
      <Reveal>
        <div className="flex items-center gap-3 pt-1">
          <button
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-2)]"
            onClick={() => router.back()}
            aria-label="Back"
          >
            <ArrowLeft size={16} />
          </button>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--volt)]">{t("pg.libEyebrow")}
          </p>
            <h1 className="font-display text-[28px] uppercase leading-none tracking-wide">{t("pg.libTitle")}
          </h1>
          </div>
        </div>
      </Reveal>

      <Reveal>
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
          <input
            className="field !pl-10"
            placeholder="Search 350+ exercises…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </Reveal>

      <Reveal>
        <div className="no-scrollbar -mx-4 flex gap-1.5 overflow-x-auto px-4">
          <Chip active={muscle === "all"} onClick={() => setMuscle("all")}>
            All
          </Chip>
          {MUSCLES.map((m) => (
            <Chip key={m.id} active={muscle === m.id} onClick={() => setMuscle(m.id)}>
              {m.label}
            </Chip>
          ))}
        </div>
      </Reveal>

      <p className="tabular text-[11px] font-semibold text-[var(--muted)]">
        {results.length} exercise{results.length === 1 ? "" : "s"}
      </p>

      <div className="card divide-y divide-[var(--line)] overflow-hidden">
        {results.slice(0, 200).map((e) => (
          <button
            key={e.id}
            className="flex w-full items-center gap-3 px-4 py-3 text-left"
            onClick={() => setGuideEx(e)}
          >
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[var(--surface-2)] text-[var(--volt)]">
              <Dumbbell size={16} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-bold">{e.name}</p>
              <p className="truncate text-[11px] text-[var(--muted)]">
                {e.muscles.slice(0, 3).map((m) => MUSCLE_LABEL[m]).join(" · ")}
                {" · "}
                {e.level === 1 ? "Beginner" : e.level === 2 ? "Intermediate" : "Advanced"}
              </p>
            </div>
            <ChevronRight size={16} className="shrink-0 text-[var(--muted)]" />
          </button>
        ))}
        {results.length === 0 && (
          <div className="flex flex-col items-center gap-2 px-6 py-10 text-center">
            <BookOpen size={22} className="text-[var(--muted)]" />
            <p className="text-[13px] font-bold">No exercises found</p>
            <p className="text-[11px] text-[var(--muted)]">Try a different search or muscle filter.</p>
          </div>
        )}
      </div>
      {results.length > 200 && (
        <p className="pb-2 text-center text-[11px] text-[var(--muted)]">
          Showing the first 200 — refine your search to see more.
        </p>
      )}

      <ExerciseDetailSheet exercise={guideEx} onClose={() => setGuideEx(null)} />
    </div>
  );
}
