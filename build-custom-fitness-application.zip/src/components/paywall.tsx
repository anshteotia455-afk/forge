"use client";

import { Check, Crown, Lock, Sparkles, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { ReactNode, useEffect, useMemo, useState } from "react";
import { Sheet } from "@/components/ui";
import {
  AccessState,
  FEATURE_COPY,
  PAYWALL_ENABLED,
  normaliseCode,
  PLANS,
  PRO_HIGHLIGHTS,
  PlanId,
  ProFeature,
  resolveAccess,
  TRIAL_DAYS,
} from "@/lib/billing";
import { loadSession } from "@/lib/auth";
import { useStore } from "@/lib/store";

/* ------------------------------ Access hook ---------------------------- */

/** Current entitlement, resolved offline from the cached record. */
export function useAccess(): AccessState {
  const entitlement = useStore((s) => s.entitlement);
  // recompute on mount so day rollovers are picked up
  const [, tick] = useState(0);
  useEffect(() => {
    const iv = setInterval(() => tick((n) => n + 1), 60_000);
    return () => clearInterval(iv);
  }, []);
  return useMemo(
    () =>
      PAYWALL_ENABLED
        ? resolveAccess(entitlement)
        : {
            isPro: true,
            tier: "pro" as const,
            inTrial: false,
            daysLeft: null,
            expired: false,
            inGrace: false,
            label: "All features unlocked",
          },
    [entitlement]
  );
}

/** Syncs the cached entitlement with the server whenever online. */
/** Signed-in users carry entitlement across devices; guests key to the install. */
export function entitlementKey(): string {
  const session = loadSession();
  if (session?.user?.id) return session.user.id;
  return useStore.getState().ensureAccountId();
}

export async function refreshEntitlement(): Promise<void> {
  const st = useStore.getState();
  const accountId = entitlementKey();
  try {
    const res = await fetch(`/api/billing/status?accountId=${encodeURIComponent(accountId)}`);
    if (!res.ok) return;
    const data = (await res.json()) as { entitlement: null | Parameters<typeof st.setEntitlement>[0] };
    if (data.entitlement) st.setEntitlement(data.entitlement);
  } catch {
    /* offline — keep using the cached entitlement */
  }
}

/* ----------------------------- Pro badge ------------------------------- */

export function ProBadge({ className = "" }: { className?: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full bg-[rgba(205,248,63,0.15)] px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider text-[var(--volt)] ${className}`}
    >
      <Crown size={9} /> Pro
    </span>
  );
}

/* --------------------------- Locked overlay ---------------------------- */

/**
 * Wraps premium UI. Free users see a blurred preview with an unlock prompt,
 * which converts far better than hiding the feature entirely.
 */
export function ProGate({
  feature,
  children,
  compact = false,
}: {
  feature: ProFeature;
  children: ReactNode;
  compact?: boolean;
}) {
  const access = useAccess();
  const [open, setOpen] = useState(false);
  const copy = FEATURE_COPY[feature];

  if (access.isPro) return <>{children}</>;

  return (
    <>
      <div className="relative overflow-hidden rounded-[20px]">
        <div
          aria-hidden
          className="pointer-events-none select-none blur-[6px] saturate-50"
          style={{ opacity: 0.45 }}
        >
          {children}
        </div>
        <button
          onClick={() => setOpen(true)}
          className="absolute inset-0 grid place-items-center bg-[rgba(10,11,13,0.55)] px-4 text-center"
        >
          <span className="flex flex-col items-center gap-2">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[var(--volt)] text-[#0b0c0e]">
              <Lock size={18} />
            </span>
            <span className="font-display text-base uppercase tracking-wide">{copy.title}</span>
            {!compact && (
              <span className="max-w-[30ch] text-[11px] leading-snug text-[var(--muted)]">
                {copy.blurb}
              </span>
            )}
            <span className="mt-1 rounded-full bg-[var(--volt)] px-4 py-1.5 text-[11px] font-extrabold uppercase tracking-wider text-[#0b0c0e]">
              Unlock Pro
            </span>
          </span>
        </button>
      </div>
      <PaywallSheet open={open} onClose={() => setOpen(false)} feature={feature} />
    </>
  );
}

/* ---------------------------- Inline prompt ---------------------------- */

export function ProPrompt({ feature, label }: { feature: ProFeature; label?: string }) {
  const access = useAccess();
  const [open, setOpen] = useState(false);
  if (access.isPro) return null;
  const copy = FEATURE_COPY[feature];
  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="card flex w-full items-center gap-3 border-[rgba(205,248,63,0.3)] bg-[rgba(205,248,63,0.05)] p-3.5 text-left"
      >
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[var(--volt)] text-[#0b0c0e]">
          <Lock size={16} />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block text-[13px] font-bold">{label ?? copy.title}</span>
          <span className="block text-[11px] leading-snug text-[var(--muted)]">{copy.blurb}</span>
        </span>
        <ProBadge />
      </button>
      <PaywallSheet open={open} onClose={() => setOpen(false)} feature={feature} />
    </>
  );
}

/* ---------------------------- Paywall sheet ---------------------------- */

export function PaywallSheet({
  open,
  onClose,
  feature,
}: {
  open: boolean;
  onClose: () => void;
  feature?: ProFeature;
}) {
  const router = useRouter();
  const access = useAccess();
  const entitlement = useStore((s) => s.entitlement);
  const setEntitlement = useStore((s) => s.setEntitlement);
  const ensureAccountId = useStore((s) => s.ensureAccountId);

  const [plan, setPlan] = useState<PlanId>("annual");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [codeOpen, setCodeOpen] = useState(false);
  const [code, setCode] = useState("");

  const trialUsed = Boolean(entitlement?.trialEndsAt);
  const headline = feature ? FEATURE_COPY[feature].title : "FORGE Pro";

  const startTrial = async () => {
    setBusy(true);
    setErr(null);
    try {
      const accountId = entitlementKey();
      const res = await fetch("/api/billing/status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ accountId }),
      });
      const data = (await res.json()) as {
        entitlement?: Parameters<typeof setEntitlement>[0];
        alreadyUsed?: boolean;
        error?: string;
      };
      if (data.entitlement) {
        setEntitlement(data.entitlement);
        setMsg(data.alreadyUsed ? "You've already used your free trial." : "Trial started — enjoy Pro!");
        if (!data.alreadyUsed) setTimeout(onClose, 1200);
      } else {
        setErr("Couldn't start the trial. Check your connection.");
      }
    } catch {
      setErr("You appear to be offline. Connect once to start your trial.");
    } finally {
      setBusy(false);
    }
  };

  const buy = async () => {
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planId: plan }),
      });
      const data = (await res.json()) as {
        provider?: string;
        checkoutUrl?: string;
        message?: string;
        error?: string;
      };
      if (res.ok && data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
        return;
      }
      if (res.ok && data.provider === "razorpay") {
        setErr("Razorpay order created. Add the Razorpay SDK to complete payment in-app.");
        return;
      }
      setErr(data.message ?? data.error ?? "Checkout isn't available right now.");
      setCodeOpen(true);
    } catch {
      setErr("Couldn't reach the payment server.");
      setCodeOpen(true);
    } finally {
      setBusy(false);
    }
  };

  const redeem = async () => {
    const clean = normaliseCode(code);
    if (clean.length < 4) {
      setErr("Enter the full code.");
      return;
    }
    setBusy(true);
    setErr(null);
    try {
      const accountId = entitlementKey();
      const res = await fetch("/api/billing/redeem", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ accountId, code: clean }),
      });
      const data = (await res.json()) as {
        entitlement?: Parameters<typeof setEntitlement>[0];
        error?: string;
      };
      if (res.ok && data.entitlement) {
        setEntitlement(data.entitlement);
        setMsg("Pro unlocked. Welcome in.");
        setTimeout(onClose, 1200);
      } else {
        setErr(data.error ?? "That code didn't work.");
      }
    } catch {
      setErr("Couldn't verify the code — you may be offline.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet open={open} onClose={onClose} title={access.isPro ? "Your plan" : "Go Pro"}>
      <div className="flex flex-col gap-4">
        {access.isPro ? (
          <div className="card-2 flex items-center gap-3 p-4">
            <Crown size={20} className="text-[var(--volt)]" />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">{access.label}</p>
              <p className="text-[11px] text-[var(--muted)]">
                {access.inTrial
                  ? "Upgrade any time to keep access after the trial."
                  : "Thanks for supporting FORGE."}
              </p>
            </div>
          </div>
        ) : (
          <>
            <div>
              <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-[var(--volt)]">
                {feature ? "Pro feature" : "Upgrade"}
              </p>
              <h3 className="font-display mt-1 text-[26px] uppercase leading-none tracking-wide">
                {headline}
              </h3>
              {feature && (
                <p className="mt-1.5 text-[12px] leading-relaxed text-[var(--muted)]">
                  {FEATURE_COPY[feature].blurb}
                </p>
              )}
            </div>

            <ul className="flex flex-col gap-1.5">
              {PRO_HIGHLIGHTS.map((h) => (
                <li key={h} className="flex items-start gap-2 text-[12px] leading-snug">
                  <Check size={14} className="mt-0.5 shrink-0 text-[var(--volt)]" strokeWidth={3} />
                  <span>{h}</span>
                </li>
              ))}
            </ul>

            {/* Plans */}
            <div className="flex flex-col gap-2">
              {PLANS.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setPlan(p.id)}
                  className={`card flex items-center gap-3 p-3.5 text-left transition-all ${
                    plan === p.id ? "border-[var(--volt)] bg-[rgba(205,248,63,0.06)]" : ""
                  }`}
                >
                  <span
                    className={`grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 ${
                      plan === p.id
                        ? "border-[var(--volt)] bg-[var(--volt)] text-[#0b0c0e]"
                        : "border-[var(--line-strong)]"
                    }`}
                  >
                    {plan === p.id && <Check size={11} strokeWidth={4} />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className="text-[13px] font-extrabold">{p.name}</span>
                      {p.badge && (
                        <span className="rounded-full bg-[var(--volt)] px-1.5 py-0.5 text-[8px] font-extrabold uppercase tracking-wider text-[#0b0c0e]">
                          {p.badge}
                        </span>
                      )}
                    </span>
                    {p.subLabel && (
                      <span className="block text-[10px] text-[var(--muted)]">{p.subLabel}</span>
                    )}
                  </span>
                  <span className="shrink-0 text-right">
                    <span className="font-display block text-lg leading-none">{p.priceLabel}</span>
                    <span className="block text-[9px] uppercase tracking-wider text-[var(--muted)]">
                      {p.periodLabel}
                    </span>
                  </span>
                </button>
              ))}
            </div>

            {err && (
              <p className="rounded-xl border border-[rgba(255,122,47,0.3)] bg-[rgba(255,122,47,0.07)] p-3 text-[11px] leading-relaxed text-[var(--ember)]">
                {err}
              </p>
            )}
            {msg && (
              <p className="flex items-center justify-center gap-1.5 text-[12px] font-bold text-[var(--volt)]">
                <Check size={14} strokeWidth={3} /> {msg}
              </p>
            )}

            <button
              className={`btn h-13 w-full py-3.5 text-base ${busy ? "btn-ghost opacity-60" : "btn-volt"}`}
              onClick={buy}
              disabled={busy}
            >
              <Sparkles size={17} /> {busy ? "Working…" : `Get ${PLANS.find((p) => p.id === plan)?.name}`}
            </button>

            {!trialUsed && (
              <button className="btn btn-ghost h-11 w-full text-sm" onClick={startTrial} disabled={busy}>
                Start {TRIAL_DAYS}-day free trial
              </button>
            )}

            {codeOpen ? (
              <div className="anim-fade-up flex flex-col gap-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
                  Licence code
                </label>
                <div className="flex gap-2">
                  <input
                    className="field flex-1 text-center font-bold tracking-[0.2em]"
                    placeholder="FORGE-XXXX"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    autoCapitalize="characters"
                  />
                  <button className="btn btn-volt h-11 px-5 text-sm" onClick={redeem} disabled={busy}>
                    Redeem
                  </button>
                </div>
              </div>
            ) : (
              <button
                className="text-center text-[11px] font-semibold text-[var(--muted)] underline"
                onClick={() => setCodeOpen(true)}
              >
                I have a licence code
              </button>
            )}

            <p className="text-center text-[10px] leading-relaxed text-[var(--muted)]">
              Payments are processed securely. Your training data always stays on your device.
            </p>
          </>
        )}

        <button
          className="btn btn-ghost h-11 w-full text-sm"
          onClick={() => {
            onClose();
            if (access.isPro) router.push("/profile");
          }}
        >
          <X size={15} /> Close
        </button>
      </div>
    </Sheet>
  );
}
