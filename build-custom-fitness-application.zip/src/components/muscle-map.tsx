"use client";

import { Muscle } from "@/lib/data";

/* A stylised front/back body diagram that highlights the worked muscles. */

const ON = "var(--volt)";
const OFF = "rgba(255,255,255,0.09)";
const LINE = "rgba(255,255,255,0.18)";

function has(muscles: Muscle[], m: Muscle): boolean {
  return muscles.includes(m) || muscles.includes("full") || muscles.includes("cardio");
}

export function MuscleMap({ muscles }: { muscles: Muscle[] }) {
  const c = (m: Muscle) => (has(muscles, m) ? ON : OFF);

  return (
    <div className="flex items-start justify-center gap-6">
      {/* FRONT */}
      <figure className="flex flex-col items-center gap-1">
        <svg width="96" height="190" viewBox="0 0 96 190" aria-label="Front muscles">
          {/* head */}
          <circle cx="48" cy="16" r="11" fill={OFF} stroke={LINE} />
          {/* neck */}
          <rect x="43" y="26" width="10" height="7" fill={OFF} />
          {/* shoulders */}
          <circle cx="28" cy="40" r="9" fill={c("shoulders")} stroke={LINE} />
          <circle cx="68" cy="40" r="9" fill={c("shoulders")} stroke={LINE} />
          {/* chest */}
          <path d="M33 37 H63 a5 5 0 0 1 5 5 V55 a20 20 0 0 1 -40 0 V42 a5 5 0 0 1 5 -5 Z" fill={c("chest")} stroke={LINE} />
          {/* arms (biceps) */}
          <rect x="18" y="46" width="9" height="34" rx="4.5" fill={c("arms")} stroke={LINE} />
          <rect x="69" y="46" width="9" height="34" rx="4.5" fill={c("arms")} stroke={LINE} />
          {/* core */}
          <rect x="35" y="58" width="26" height="34" rx="5" fill={c("core")} stroke={LINE} />
          {/* legs (quads) */}
          <path d="M34 94 H47 V140 a6 6 0 0 1 -12 0 Z" fill={c("legs")} stroke={LINE} />
          <path d="M49 94 H62 V140 a6 6 0 0 1 -12 0 Z" fill={c("legs")} stroke={LINE} />
          {/* calves */}
          <rect x="36" y="146" width="10" height="34" rx="4" fill={c("legs")} stroke={LINE} />
          <rect x="50" y="146" width="10" height="34" rx="4" fill={c("legs")} stroke={LINE} />
        </svg>
        <figcaption className="text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">
          Front
        </figcaption>
      </figure>

      {/* BACK */}
      <figure className="flex flex-col items-center gap-1">
        <svg width="96" height="190" viewBox="0 0 96 190" aria-label="Back muscles">
          <circle cx="48" cy="16" r="11" fill={OFF} stroke={LINE} />
          <rect x="43" y="26" width="10" height="7" fill={OFF} />
          <circle cx="28" cy="40" r="9" fill={c("shoulders")} stroke={LINE} />
          <circle cx="68" cy="40" r="9" fill={c("shoulders")} stroke={LINE} />
          {/* upper back / lats */}
          <path d="M33 37 H63 a5 5 0 0 1 5 5 V60 a20 22 0 0 1 -40 0 V42 a5 5 0 0 1 5 -5 Z" fill={c("back")} stroke={LINE} />
          {/* triceps */}
          <rect x="18" y="46" width="9" height="34" rx="4.5" fill={c("arms")} stroke={LINE} />
          <rect x="69" y="46" width="9" height="34" rx="4.5" fill={c("arms")} stroke={LINE} />
          {/* lower back */}
          <rect x="36" y="62" width="24" height="18" rx="4" fill={c("back")} stroke={LINE} />
          {/* glutes */}
          <path d="M34 82 h28 a6 6 0 0 1 6 6 v6 a10 10 0 0 1 -20 0 a10 10 0 0 1 -20 0 v-6 a6 6 0 0 1 6 -6 Z" fill={c("glutes")} stroke={LINE} />
          {/* hamstrings */}
          <rect x="35" y="104" width="11" height="38" rx="4.5" fill={c("legs")} stroke={LINE} />
          <rect x="50" y="104" width="11" height="38" rx="4.5" fill={c("legs")} stroke={LINE} />
          {/* calves */}
          <rect x="36" y="146" width="10" height="34" rx="4" fill={c("legs")} stroke={LINE} />
          <rect x="50" y="146" width="10" height="34" rx="4" fill={c("legs")} stroke={LINE} />
        </svg>
        <figcaption className="text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">
          Back
        </figcaption>
      </figure>
    </div>
  );
}
