"use client";

export interface ChartPoint {
  label: string;
  value: number;
}

/**
 * Dependency-free SVG line chart with area fill, min/max guides and
 * date labels — sized to the phone-first layout.
 */
export function LineChart({
  points,
  color = "var(--volt)",
  height = 132,
}: {
  points: ChartPoint[];
  color?: string;
  height?: number;
}) {
  if (points.length < 2) return null;

  const w = 320;
  const h = height;
  const padL = 44;
  const padR = 10;
  const padT = 14;
  const padB = 24;

  const values = points.map((p) => p.value);
  let min = Math.min(...values);
  let max = Math.max(...values);
  if (max === min) {
    max += 1;
    min = Math.max(0, min - 1);
  }
  const range = max - min;

  const x = (i: number) => padL + (i / (points.length - 1)) * (w - padL - padR);
  const y = (v: number) => padT + (1 - (v - min) / range) * (h - padT - padB);

  const line = points
    .map((p, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`)
    .join(" ");
  const area = `${line} L${x(points.length - 1).toFixed(1)},${h - padB} L${x(0).toFixed(1)},${h - padB} Z`;

  const fmt = (v: number) => (v >= 100 ? Math.round(v).toString() : (Math.round(v * 10) / 10).toString());

  return (
    <svg viewBox={`0 0 ${w} ${h}`} width="100%" height={h} role="img" aria-label="Trend chart">
      <line
        x1={padL}
        y1={y(max)}
        x2={w - padR}
        y2={y(max)}
        stroke="rgba(244,245,240,0.14)"
        strokeDasharray="3 4"
      />
      <line
        x1={padL}
        y1={y(min)}
        x2={w - padR}
        y2={y(min)}
        stroke="rgba(244,245,240,0.14)"
        strokeDasharray="3 4"
      />
      <text x={2} y={y(max) + 3.5} fontSize="9" fill="var(--muted)">
        {fmt(max)}
      </text>
      <text x={2} y={y(min) + 3.5} fontSize="9" fill="var(--muted)">
        {fmt(min)}
      </text>

      <path d={area} fill={color} opacity="0.12" />
      <path
        d={line}
        fill="none"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {points.map((p, i) => (
        <circle
          key={i}
          cx={x(i)}
          cy={y(p.value)}
          r={i === points.length - 1 ? 4.5 : 3}
          fill="var(--bg)"
          stroke={color}
          strokeWidth="2"
        />
      ))}

      <text x={padL} y={h - 6} fontSize="9" fill="var(--muted)">
        {points[0].label}
      </text>
      <text x={w - padR} y={h - 6} fontSize="9" fill="var(--muted)" textAnchor="end">
        {points[points.length - 1].label}
      </text>
    </svg>
  );
}
