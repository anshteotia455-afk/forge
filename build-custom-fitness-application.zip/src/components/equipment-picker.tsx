"use client";

import { Check } from "lucide-react";
import { EQUIP_GROUPS, EQUIPMENT, EquipmentId } from "@/lib/data";
import { useStore } from "@/lib/store";

/** Grouped, scannable equipment selector shared by the generator & profile. */
export function EquipmentPicker({ compact = false }: { compact?: boolean }) {
  const equipment = useStore((s) => s.equipment);
  const toggleEquipment = useStore((s) => s.toggleEquipment);

  return (
    <div className="flex flex-col gap-3.5">
      {EQUIP_GROUPS.map((g) => {
        const items = EQUIPMENT.filter((e) => e.group === g && e.id !== "bodyweight");
        if (!items.length) return null;
        const onCount = items.filter((e) => equipment.includes(e.id)).length;
        return (
          <div key={g}>
            <div className="mb-1.5 flex items-baseline justify-between">
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--muted)]">{g}</p>
              {onCount > 0 && (
                <span className="tabular text-[10px] font-bold text-[var(--volt)]">{onCount} selected</span>
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {items.map((e) => {
                const on = equipment.includes(e.id);
                return (
                  <button
                    key={e.id}
                    onClick={() => toggleEquipment(e.id)}
                    title={e.hint}
                    className={`chip ${on ? "chip-on" : ""} ${compact ? "!px-3 !py-1.5 text-[11px]" : ""}`}
                  >
                    {on && <Check size={12} strokeWidth={3.5} />}
                    {e.label}
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/** Short human summary of owned gear. */
export function equipmentSummary(ids: EquipmentId[]): string {
  const labels = EQUIPMENT.filter((e) => ids.includes(e.id)).map((e) => e.label);
  return labels.length ? labels.join(" · ") : "Bodyweight only";
}
