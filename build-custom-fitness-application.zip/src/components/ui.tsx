"use client";

import { X } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { ReactNode, useEffect, useRef, useState } from "react";

/* ------------------------------- Ring -------------------------------- */

export function Ring({
  size = 120,
  stroke = 10,
  value,
  color = "var(--volt)",
  track = "rgba(244,245,240,0.08)",
  children,
}: {
  size?: number;
  stroke?: number;
  value: number; // 0..1
  color?: string;
  track?: string;
  children?: ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(1, value));
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke={track} strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - clamped)}
          className="ring-prog"
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

/* ------------------------------- Sheet ------------------------------- */

export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <button
        aria-label="Close"
        className="sheet-backdrop absolute inset-0 bg-black/70"
        onClick={onClose}
      />
      <div className="sheet-panel relative w-full max-w-[480px] rounded-t-[24px] border border-b-0 border-[var(--line-strong)] bg-[var(--surface)] pb-safe max-h-[88dvh] flex flex-col sm:rounded-[24px] sm:border-b">
        <div className="mx-auto mt-2.5 h-1 w-10 rounded-full bg-white/15" />
        <div className="flex items-center justify-between px-5 pb-2 pt-3">
          <h3 className="font-display text-xl uppercase tracking-wide">{title}</h3>
          <button
            onClick={onClose}
            className="grid h-9 w-9 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface-2)] text-[var(--muted)]"
            aria-label="Close sheet"
          >
            <X size={16} />
          </button>
        </div>
        <div className="overflow-y-auto px-5 pb-6 no-scrollbar">{children}</div>
      </div>
    </div>
  );
}

/* -------------------------------- Chip ------------------------------- */

export function Chip({
  active,
  onClick,
  children,
  className = "",
}: {
  active?: boolean;
  onClick?: () => void;
  children: ReactNode;
  className?: string;
}) {
  return (
    <button onClick={onClick} className={`chip ${active ? "chip-on" : ""} ${className}`}>
      {children}
    </button>
  );
}

/* ----------------------------- Segmented ------------------------------ */

export function Segmented<T extends string | number>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex gap-1 rounded-2xl border border-[var(--line)] bg-[var(--surface-2)] p-1">
      {options.map((o) => (
        <button
          key={String(o.value)}
          onClick={() => onChange(o.value)}
          className={`flex-1 rounded-xl px-2 py-2.5 text-[13px] font-semibold transition-all ${
            o.value === value ? "bg-[var(--volt)] text-[#0b0c0e]" : "text-[var(--muted)]"
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

/* ------------------------------- Macro bar ---------------------------- */

export function MacroBar({
  label,
  value,
  max,
  color,
  unit = "g",
}: {
  label: string;
  value: number;
  max: number;
  color: string;
  unit?: string;
}) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between text-[11px] font-semibold uppercase tracking-widest">
        <span className="text-[var(--muted)]">{label}</span>
        <span className="tabular text-[var(--text)]">
          {Math.round(value)}
          <span className="text-[var(--muted)]"> / {Math.round(max)}{unit}</span>
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${pct}%`, background: color }}
        />
      </div>
    </div>
  );
}

/* ------------------------------ Stepper ------------------------------- */

export function Stepper({
  value,
  onChange,
  min = 0,
  max = 99,
  step = 1,
}: {
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  step?: number;
}) {
  return (
    <div className="inline-flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--surface-2)] p-0.5">
      <button
        className="grid h-7 w-7 place-items-center rounded-full text-[var(--muted)] transition-colors active:bg-white/10"
        onClick={() => onChange(Math.max(min, +(value - step).toFixed(2)))}
        aria-label="Decrease"
      >
        −
      </button>
      <span className="tabular min-w-8 text-center text-sm font-bold">{value}</span>
      <button
        className="grid h-7 w-7 place-items-center rounded-full text-[var(--volt)] transition-colors active:bg-white/10"
        onClick={() => onChange(Math.min(max, +(value + step).toFixed(2)))}
        aria-label="Increase"
      >
        +
      </button>
    </div>
  );
}

/* ------------------------------- Reveal ------------------------------- */

export function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            el.classList.add("rv-on");
            io.disconnect();
          }
        }
      },
      { threshold: 0.08 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={`rv ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

/* ------------------------------- Empty -------------------------------- */

export function Empty({
  icon: Icon,
  title,
  body,
  children,
}: {
  icon: LucideIcon;
  title: string;
  body: string;
  children?: ReactNode;
}) {
  return (
    <div className="card flex flex-col items-center gap-2.5 px-6 py-9 text-center">
      <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[var(--surface-2)] text-[var(--volt)]">
        <Icon size={22} />
      </div>
      <p className="font-display text-lg uppercase tracking-wide">{title}</p>
      <p className="max-w-[26ch] text-[13px] leading-relaxed text-[var(--muted)]">{body}</p>
      {children ? <div className="mt-2">{children}</div> : null}
    </div>
  );
}

/* --------------------------- useMounted hook --------------------------- */

export function useMounted(): boolean {
  const [m, setM] = useState(false);
  useEffect(() => setM(true), []);
  return m;
}
