"use client";

import { AlertTriangle, Check, Dumbbell, Lightbulb, PlayCircle, Target, Wind } from "lucide-react";
import { Sheet } from "@/components/ui";
import { MuscleMap } from "@/components/muscle-map";
import { Exercise, EQUIPMENT, MUSCLE_LABEL } from "@/lib/data";
import { buildGuide, videoSearchUrl } from "@/lib/exercise-guide";

export function ExerciseDetailSheet({
  exercise,
  onClose,
}: {
  exercise: Exercise | null;
  onClose: () => void;
}) {
  if (!exercise) return null;
  const guide = buildGuide(exercise);
  const gear = EQUIPMENT.filter((e) => exercise.equipment.includes(e.id)).map((e) => e.label);
  const levelLabel = exercise.level === 1 ? "Beginner" : exercise.level === 2 ? "Intermediate" : "Advanced";

  return (
    <Sheet open={Boolean(exercise)} onClose={onClose} title={exercise.name}>
      <div className="flex flex-col gap-5">
        {/* Target muscle map */}
        <div className="card-2 p-4">
          <p className="mb-3 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
            <Target size={12} className="text-[var(--volt)]" /> Muscles worked
          </p>
          <MuscleMap muscles={exercise.muscles} />
          <div className="mt-3 flex flex-wrap justify-center gap-1.5">
            {exercise.muscles.map((m) => (
              <span
                key={m}
                className="rounded-full bg-[rgba(205,248,63,0.14)] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[var(--volt)]"
              >
                {MUSCLE_LABEL[m]}
              </span>
            ))}
          </div>
        </div>

        {/* Meta row */}
        <div className="grid grid-cols-3 gap-2">
          <Meta label="Level" value={levelLabel} />
          <Meta label="Type" value={exercise.kind === "time" ? "Timed" : "Reps"} />
          <Meta
            label="Target"
            value={exercise.kind === "time" ? `${exercise.sec ?? 30}s` : `${exercise.reps ?? 10} reps`}
          />
        </div>

        {/* Equipment */}
        <div className="flex items-center gap-2 text-[12px] text-[var(--muted)]">
          <Dumbbell size={14} className="shrink-0 text-[var(--volt)]" />
          <span>{gear.length ? gear.join(" · ") : "Bodyweight"}</span>
          {exercise.uni && (
            <span className="rounded-full bg-[var(--surface-2)] px-2 py-0.5 text-[10px] font-bold uppercase text-[var(--muted)]">
              Each side
            </span>
          )}
        </div>

        {/* Setup */}
        <div>
          <p className="mb-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
            Setup
          </p>
          <p className="text-[13px] leading-relaxed">{guide.setup}</p>
        </div>

        {/* Steps */}
        <div>
          <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--muted)]">
            How to do it
          </p>
          <ol className="flex flex-col gap-2.5">
            {guide.steps.map((s, i) => (
              <li key={i} className="flex gap-3">
                <span className="tabular grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[var(--volt)] text-[11px] font-extrabold text-[#0b0c0e]">
                  {i + 1}
                </span>
                <span className="text-[13px] leading-snug">{s}</span>
              </li>
            ))}
          </ol>
        </div>

        {/* Breathing */}
        <div className="flex items-start gap-2.5 rounded-2xl bg-[var(--surface-2)] p-3.5">
          <Wind size={15} className="mt-0.5 shrink-0 text-[var(--aqua)]" />
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-[var(--muted)]">Breathing</p>
            <p className="mt-0.5 text-[12px] leading-snug">{guide.breathing}</p>
          </div>
        </div>

        {/* Tips */}
        <div>
          <p className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--volt)]">
            <Lightbulb size={12} /> Form tips
          </p>
          <ul className="flex flex-col gap-1.5">
            {guide.tips.map((t, i) => (
              <li key={i} className="flex items-start gap-2 text-[12px] leading-snug">
                <Check size={14} className="mt-0.5 shrink-0 text-[var(--volt)]" strokeWidth={3} />
                <span>{t}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Mistakes */}
        <div>
          <p className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--ember)]">
            <AlertTriangle size={12} /> Common mistakes
          </p>
          <ul className="flex flex-col gap-1.5">
            {guide.mistakes.map((t, i) => (
              <li key={i} className="flex items-start gap-2 text-[12px] leading-snug text-[var(--muted)]">
                <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--ember)]" />
                <span>{t}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Video demo */}
        <a
          href={videoSearchUrl(exercise.name)}
          target="_blank"
          rel="noopener noreferrer"
          className="btn btn-volt h-12 w-full"
        >
          <PlayCircle size={18} /> Watch video demonstration
        </a>
        <p className="-mt-2 text-center text-[10px] leading-relaxed text-[var(--muted)]">
          Opens curated form videos in your browser (needs internet).
        </p>
      </div>
    </Sheet>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="card-2 p-3 text-center">
      <p className="text-[13px] font-extrabold">{value}</p>
      <p className="mt-0.5 text-[9px] font-bold uppercase tracking-widest text-[var(--muted)]">{label}</p>
    </div>
  );
}
