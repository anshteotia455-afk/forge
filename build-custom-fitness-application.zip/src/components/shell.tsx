"use client";

import {
  CalendarDays,
  CloudCheck,
  CloudOff,
  Dumbbell,
  Home,
  Loader2,
  Shield,
  Trophy,
  User,
  UtensilsCrossed,
  Zap,
} from "lucide-react";
import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { ReactNode, useEffect, useMemo, useState } from "react";
import { RANKS, summarize } from "@/lib/achievements";
import { refreshEntitlement } from "@/components/paywall";
import { BUNDLED_MOBILE, clearSession, loadSession, verifySession } from "@/lib/auth";
import { calcTargets, dateKey } from "@/lib/engine";
import { readinessOf } from "@/lib/recovery";
import { pushWidget } from "@/lib/widget";
import { verifyPin } from "@/lib/lock";
import { useT } from "@/lib/i18n";
import { wOut, wUnit } from "@/lib/units";
import {
  isNativeAndroid,
  previewRingtone,
  scheduleNativeReminder,
} from "@/lib/ringtone";
import { syncNow, useStore } from "@/lib/store";

const TABS = [
  { href: "/", label: "nav.home", icon: Home },
  { href: "/planner", label: "nav.plan", icon: CalendarDays },
  { href: "/generator", label: "nav.forge", icon: Zap, center: true },
  { href: "/nutrition", label: "nav.food", icon: UtensilsCrossed },
  { href: "/profile", label: "nav.you", icon: User },
] as const;

function Splash() {
  return (
    <div className="fixed inset-0 z-[100] grid place-items-center bg-[var(--bg)]">
      <div className="flex flex-col items-center gap-5" style={{ animation: "splash-pulse 1.6s ease-in-out infinite" }}>
        <div className="grid h-16 w-16 place-items-center rounded-[20px] bg-[var(--volt)] text-[#0b0c0e] shadow-[0_0_60px_rgba(205,248,63,0.25)]">
          <Dumbbell size={30} strokeWidth={2.4} />
        </div>
        <p className="font-display text-3xl uppercase tracking-[0.12em]">Forge</p>
        <div className="h-[3px] w-24 overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full bg-[var(--volt)]" style={{ animation: "bar-load 1.2s ease forwards" }} />
        </div>
      </div>
    </div>
  );
}

function SyncBadge() {
  const tr = useT();
  const status = useStore((s) => s.syncStatus);
  const [online, setOnline] = useState(true);

  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    update();
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => {
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
    };
  }, []);

  const st = !online ? "offline" : status;
  return (
    <button
      onClick={() => void syncNow(true)}
      className="flex items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--surface-2)] px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-[var(--muted)]"
      aria-label="Sync status"
    >
      {st === "syncing" && <Loader2 size={13} className="animate-spin text-[var(--volt)]" />}
      {st === "synced" && <CloudCheck size={13} className="text-[var(--volt)]" />}
      {st === "offline" && <CloudOff size={13} className="text-[var(--ember)]" />}
      {(st === "idle" || st === "error") && <CloudCheck size={13} className="text-[var(--muted)]" />}
      <span>
        {st === "syncing"
          ? tr("sync.syncing")
          : st === "offline"
            ? tr("sync.offline")
            : st === "synced"
              ? tr("sync.synced")
              : tr("sync.cloud")}
      </span>
    </button>
  );
}

/** Confetti bits — deterministic so SSR/client markup always match. */
const CONFETTI = Array.from({ length: 28 }, (_, i) => ({
  left: (i * 37 + 11) % 100,
  delay: (i % 7) * 0.13,
  duration: 1.7 + (i % 5) * 0.3,
  hue: [52, 45, 180, 330, 265, 15][i % 6],
  rotate: (i * 47) % 360,
}));

/** Full-screen celebration shown the moment a record falls. */
function PRCelebration() {
  const prs = useStore((s) => s.pendingPRs);
  const clear = useStore((s) => s.clearPendingPRs);
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const router = useRouter();

  useEffect(() => {
    if (prs.length) navigator.vibrate?.([120, 90, 120, 90, 220]);
  }, [prs.length]);

  if (!prs.length) return null;

  return (
    <div className="sheet-backdrop fixed inset-0 z-[95] grid place-items-center bg-black/85 px-6">
      <div className="confetti-layer" aria-hidden>
        {CONFETTI.map((c) => (
          <span
            key={c.left}
            className="confetti-bit"
            style={{
              left: `${c.left}%`,
              background: `hsl(${c.hue} 92% 62%)`,
              animationDelay: `${c.delay}s`,
              animationDuration: `${c.duration}s`,
              transform: `rotate(${c.rotate}deg)`,
            }}
          />
        ))}
      </div>
      <div className="anim-pop card relative w-full max-w-[360px] overflow-hidden p-6 text-center">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[var(--volt)] text-[#0b0c0e] shadow-[0_0_60px_rgba(205,248,63,0.45)]">
          <Trophy size={30} />
        </div>
        <p className="font-display mt-3 text-3xl uppercase tracking-wide">
          New record{prs.length > 1 ? "s" : ""}!
        </p>
        <div className="mt-4 flex flex-col gap-2">
          {prs.map((pr) => (
            <div key={pr.exerciseId} className="card-2 px-3 py-2.5">
              <p className="text-[13px] font-bold">{pr.name}</p>
              <p className="tabular text-[12px] text-[var(--volt)]">
                {pr.added ? "+" : ""}
                {wOut(pr.kg, sys)} {wUnit(sys)} × {pr.reps}
                <span className="text-[var(--muted)]">
                  {" "}
                  · est 1RM {wOut(pr.est1rm, sys)} {wUnit(sys)}
                </span>
              </p>
            </div>
          ))}
        </div>
        <button className="btn btn-volt mt-4 h-12 w-full" onClick={clear}>
          Nice!
        </button>
        <button
          className="btn btn-ghost mt-2 h-11 w-full text-sm"
          onClick={() => {
            clear();
            router.push("/ranks");
          }}
        >
          See your standards
        </button>
      </div>
    </div>
  );
}

/** Watches XP and fires a celebration when the ladder is climbed. */
function RankUpWatcher() {
  const logs = useStore((s) => s.logs);
  const meals = useStore((s) => s.meals);
  const weights = useStore((s) => s.weights);
  const measurements = useStore((s) => s.measurements);
  const water = useStore((s) => s.water);
  const skillProgress = useStore((s) => s.skillProgress);
  const hydration = useStore((s) => s.hydration);
  const checkins = useStore((s) => s.checkins);
  const lastRankId = useStore((s) => s.lastRankId);
  const setLastRankId = useStore((s) => s.setLastRankId);
  const setPendingRankUp = useStore((s) => s.setPendingRankUp);

  const rank = useMemo(
    () =>
      summarize({
        logs,
        meals,
        weights,
        measurements,
        water,
        skillProgress,
        hydration,
        checkins,
      }).rank,
    [logs, meals, weights, measurements, water, skillProgress, hydration, checkins]
  );

  useEffect(() => {
    if (!useStore.persist.hasHydrated()) return;
    if (lastRankId === null) {
      setLastRankId(rank.rank.id); // first run: record, never celebrate
      return;
    }
    if (rank.rank.id === lastRankId) return;
    const oldIdx = RANKS.findIndex((r) => r.id === lastRankId);
    const newIdx = RANKS.findIndex((r) => r.id === rank.rank.id);
    setLastRankId(rank.rank.id);
    if (newIdx > oldIdx) {
      setPendingRankUp({
        name: rank.rank.name,
        tier: rank.rank.tier,
        color: rank.rank.color,
        xp: rank.xp,
      });
    }
  }, [rank, lastRankId, setLastRankId, setPendingRankUp]);

  return null;
}

/** Full-screen promotion celebration. */
function RankUpCelebration() {
  const up = useStore((s) => s.pendingRankUp);
  const clear = useStore((s) => s.setPendingRankUp);
  const sys = useStore((s) => s.unitSystem) ?? "metric";
  const router = useRouter();

  useEffect(() => {
    if (up) navigator.vibrate?.([150, 100, 150, 100, 300]);
  }, [up]);

  if (!up) return null;

  return (
    <div className="sheet-backdrop fixed inset-0 z-[95] grid place-items-center bg-black/85 px-6">
      <div className="confetti-layer" aria-hidden>
        {CONFETTI.map((c) => (
          <span
            key={c.left}
            className="confetti-bit"
            style={{
              left: `${c.left}%`,
              background: `hsl(${c.hue} 92% 62%)`,
              animationDelay: `${c.delay}s`,
              animationDuration: `${c.duration}s`,
              transform: `rotate(${c.rotate}deg)`,
            }}
          />
        ))}
      </div>
      <div className="anim-pop card relative w-full max-w-[360px] overflow-hidden p-6 text-center">
        <div
          className="mx-auto grid h-16 w-16 place-items-center rounded-2xl shadow-[0_0_60px_rgba(255,255,255,0.15)]"
          style={{ background: `${up.color}22`, color: up.color }}
        >
          <Shield size={34} />
        </div>
        <p className="mt-3 text-[11px] font-bold uppercase tracking-[0.3em] text-[var(--muted)]">
          Rank up
        </p>
        <p
          className="font-display mt-1 text-4xl uppercase leading-none tracking-wide"
          style={{ color: up.color }}
        >
          {up.name}
        </p>
        <p className="mt-1.5 text-[13px] font-bold text-[var(--muted)]">Tier {up.tier}</p>
        <p className="tabular mt-2 text-[13px] font-extrabold text-[var(--volt)]">
          {up.xp.toLocaleString()} XP earned
        </p>
        <button className="btn btn-volt mt-5 h-12 w-full" onClick={() => clear(null)}>
          Awesome!
        </button>
        <button
          className="btn btn-ghost mt-2 h-11 w-full text-sm"
          onClick={() => {
            clear(null);
            router.push("/ranks");
          }}
        >
          See the ladder
        </button>
      </div>
    </div>
  );
}

/** Opaque PIN screen shown at launch whenever app lock is enabled. */
function LockGate() {
  const enabled = useStore((s) => s.appLock?.enabled);
  const unlocked = useStore((s) => s.appUnlocked);
  const setAppUnlocked = useStore((s) => s.setAppUnlocked);
  const [pin, setPin] = useState("");
  const [err, setErr] = useState(false);

  if (!enabled || unlocked) return null;

  const submit = async () => {
    const stored = useStore.getState().appLock?.pinHash ?? "";
    if (await verifyPin(pin, stored)) {
      setAppUnlocked(true);
      setPin("");
      navigator.vibrate?.(40);
    } else {
      setErr(true);
      setPin("");
      navigator.vibrate?.([80, 60, 80]);
      setTimeout(() => setErr(false), 400);
    }
  };

  return (
    <div
      className={`fixed inset-0 z-[98] grid place-items-center bg-[var(--bg)] px-8 ${
        err ? "shake" : ""
      }`}
    >
      <div className="flex w-full max-w-[320px] flex-col items-center gap-4">
        <div className="grid h-16 w-16 place-items-center rounded-2xl bg-[var(--volt)] text-[#0b0c0e]">
          <Shield size={30} />
        </div>
        <p className="font-display text-2xl uppercase tracking-wide">FORGE locked</p>
        <input
          autoFocus
          type="password"
          inputMode="numeric"
          maxLength={6}
          value={pin}
          onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
          onKeyDown={(e) => {
            if (e.key === "Enter" && pin.length >= 4) void submit();
          }}
          className="field text-center font-display !text-3xl tracking-[0.5em]"
          placeholder="••••"
          aria-label="Enter PIN"
        />
        <button
          className={`btn h-12 w-full ${pin.length >= 4 ? "btn-volt" : "btn-ghost opacity-50"}`}
          disabled={pin.length < 4}
          onClick={() => void submit()}
        >
          Unlock
        </button>
        {err && <p className="text-[12px] font-bold text-[var(--red)]">Incorrect PIN — try again</p>}
        <p className="text-center text-[10px] leading-relaxed text-[var(--muted)]">
          App lock keeps your logs, photos and notes private on a shared phone.
        </p>
      </div>
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const tr = useT();
  const pathname = usePathname();
  const reminder = useStore((s) => s.reminder);
  const schedule = useStore((s) => s.schedule);
  const routines = useStore((s) => s.routines);
  const meals = useStore((s) => s.meals);
  const checkins = useStore((s) => s.checkins);
  const profile = useStore((s) => s.profile);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    if (useStore.persist.hasHydrated()) {
      setHydrated(true);
      return;
    }
    const unsub = useStore.persist.onFinishHydration(() => setHydrated(true));
    return unsub;
  }, []);

  // Capacitor already serves every page offline. A service worker inside the
  // APK can cache the root HTML under named routes and bounce navigation home,
  // so native builds actively remove workers/caches left by older versions.
  useEffect(() => {
    if (!("serviceWorker" in navigator)) return;

    if (BUNDLED_MOBILE) {
      void (async () => {
        const registrations = await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map((r) => r.unregister()));
        if ("caches" in window) {
          const keys = await caches.keys();
          await Promise.all(keys.filter((k) => k.startsWith("pages-forge") || k.startsWith("assets-forge")).map((k) => caches.delete(k)));
        }
        // The current document can remain controlled until reload. Do one clean
        // reload, once, after removing the stale worker.
        if (navigator.serviceWorker.controller && !sessionStorage.getItem("forge-native-sw-cleared")) {
          sessionStorage.setItem("forge-native-sw-cleared", "1");
          window.location.reload();
        }
      })();
      return;
    }

    const register = () => {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    };
    if (document.readyState === "complete") register();
    else window.addEventListener("load", register, { once: true });
  }, []);

  // Validate the stored login. Offline keeps trusting the local session.
  useEffect(() => {
    if (!hydrated) return;
    if (!loadSession()) return;
    void verifySession().then((r) => {
      if (r === "invalid") {
        clearSession();
        window.location.reload();
      }
    });
  }, [hydrated]);

  // Verify subscription with the server whenever we're online
  useEffect(() => {
    if (!hydrated) return;
    void refreshEntitlement();
    const onOnline = () => void refreshEntitlement();
    window.addEventListener("online", onOnline);
    const iv = setInterval(() => void refreshEntitlement(), 6 * 60 * 60 * 1000);
    return () => {
      window.removeEventListener("online", onOnline);
      clearInterval(iv);
    };
  }, [hydrated]);

  // Cloud sync engine: on load, when coming back online, periodically
  useEffect(() => {
    if (!hydrated) return;
    void syncNow();
    const onOnline = () => void syncNow();
    const onVisible = () => {
      if (document.visibilityState === "visible") void syncNow();
    };
    window.addEventListener("online", onOnline);
    document.addEventListener("visibilitychange", onVisible);
    const iv = setInterval(() => void syncNow(), 45_000);
    return () => {
      window.removeEventListener("online", onOnline);
      document.removeEventListener("visibilitychange", onVisible);
      clearInterval(iv);
    };
  }, [hydrated]);

  // Home-screen widget: push today's summary whenever it changes.
  useEffect(() => {
    if (!hydrated || !isNativeAndroid()) return;
    const today = dateKey();
    const assigned = schedule[today];
    const routine =
      assigned && assigned !== "rest" ? routines.find((r) => r.id === assigned) : null;
    const line1 = routine ? routine.name : assigned === "rest" ? "Rest day" : "Plan a workout";

    const checkin = checkins.find((c) => c.date === today);
    const ready = readinessOf(checkin);
    const eaten = meals
      .filter((m) => m.date === today)
      .reduce((a, m) => a + m.cal * m.qty, 0);
    const calories = profile ? calcTargets(profile).calories : 2200;
    const left = Math.max(0, Math.round(calories - eaten));
    const line2 = checkin
      ? `Readiness ${ready.score} · ${left.toLocaleString()} kcal left`
      : `${left.toLocaleString()} kcal left today`;
    pushWidget(line1, line2);
  }, [hydrated, schedule, routines, meals, checkins, profile]);

  // Android schedules a true OS alarm that can wake the closed app.
  useEffect(() => {
    if (!hydrated || !isNativeAndroid()) return;
    void scheduleNativeReminder({
      time: reminder.time || "07:00",
      enabled: reminder.enabled,
      vibrate: reminder.vibrate !== false,
      snoozeMinutes: reminder.snoozeMinutes ?? 10,
      soundId: reminder.soundId ?? "forge",
    });
  }, [hydrated, reminder]);

  // Web/Windows reminder: fires while the app process is open or minimized.
  useEffect(() => {
    if (!hydrated || isNativeAndroid()) return;
    const tick = () => {
      const s = useStore.getState();
      const r = s.reminder;
      if (!r?.enabled) return;
      const [h, m] = (r.time || "07:00").split(":").map(Number);
      const at = new Date();
      at.setHours(h ?? 7, m ?? 0, 0, 0);
      if (new Date() < at) return;
      const today = dateKey();
      if (s.logs.some((l) => l.date === today)) return;
      const flag = `forge-reminded-${today}`;
      if (localStorage.getItem(flag)) return;
      localStorage.setItem(flag, "1");
      void previewRingtone(r.soundId ?? "forge").catch(() => undefined);
      if (r.vibrate !== false) navigator.vibrate?.([250, 120, 250, 120, 400]);
      if (typeof Notification !== "undefined" && Notification.permission === "granted") {
        const title = "Time to forge";
        const options = {
          body: "Today's session is waiting — keep the streak alive.",
          icon: "/icons/icon-192.png",
        };
        if ("serviceWorker" in navigator) {
          navigator.serviceWorker.ready
            .then((reg) => reg.showNotification(title, options))
            .catch(() => new Notification(title, options));
        } else {
          new Notification(title, options);
        }
      }
    };
    tick();
    const iv = setInterval(tick, 60_000);
    return () => clearInterval(iv);
  }, [hydrated]);

  const immersive = pathname.startsWith("/workout");

  return (
    <div className="mx-auto min-h-dvh w-full max-w-[480px]">
      {!hydrated && <Splash />}

      {!immersive && (
        <header className="pt-safe sticky top-0 z-40 border-b border-[var(--line)] bg-[rgba(10,11,13,0.86)] backdrop-blur-md">
          <div className="flex h-14 items-center justify-between px-4">
            <Link href="/" className="flex items-center gap-2">
              <span className="grid h-7 w-7 place-items-center rounded-lg bg-[var(--volt)] text-[#0b0c0e]">
                <Dumbbell size={15} strokeWidth={2.6} />
              </span>
              <span className="font-display text-lg uppercase tracking-[0.14em]">Forge</span>
            </Link>
            <SyncBadge />
          </div>
        </header>
      )}

      <main className={immersive ? "" : "px-4 pb-32 pt-4"}>{hydrated ? children : null}</main>

      <LockGate />
      <PRCelebration />
      <RankUpCelebration />
      <RankUpWatcher />

      {!immersive && (
        <nav className="fixed inset-x-0 bottom-0 z-40">
          <div className="mx-auto w-full max-w-[480px]">
            <div className="pb-safe border-t border-[var(--line)] bg-[rgba(13,14,17,0.92)] backdrop-blur-lg">
              <div className="grid grid-cols-5 px-2 pt-1.5">
                {TABS.map((t) => {
                  const Icon = t.icon;
                  const active = pathname === t.href;
                  if ("center" in t && t.center) {
                    return (
                      <div key={t.href} className="relative flex justify-center">
                        <Link
                          href={t.href}
                          aria-label="Forge a workout"
                          className={`absolute -top-8 grid h-16 w-16 place-items-center rounded-full border-4 border-[var(--bg)] transition-transform active:scale-90 ${
                            active
                              ? "bg-[var(--volt)] text-[#0b0c0e]"
                              : "bg-[var(--volt)] text-[#0b0c0e] shadow-[0_8px_30px_rgba(205,248,63,0.35)]"
                          }`}
                        >
                          <Icon size={26} strokeWidth={2.4} />
                        </Link>
                        <span
                          className={`mt-10 pb-1 text-[10px] font-bold uppercase tracking-wider ${
                            active ? "text-[var(--volt)]" : "text-[var(--muted)]"
                          }`}
                        >
                          {tr(t.label)}
                        </span>
                      </div>
                    );
                  }
                  return (
                    <Link
                      key={t.href}
                      href={t.href}
                      className="flex flex-col items-center gap-1 py-2"
                    >
                      <Icon
                        size={21}
                        strokeWidth={active ? 2.5 : 2}
                        className={active ? "text-[var(--volt)]" : "text-[var(--muted)]"}
                      />
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider ${
                          active ? "text-[var(--volt)]" : "text-[var(--muted)]"
                        }`}
                      >
                        {tr(t.label)}
                      </span>
                    </Link>
                  );
                })}
              </div>
            </div>
          </div>
        </nav>
      )}
    </div>
  );
}
