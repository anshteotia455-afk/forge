"use client";

import { Check, Cloud, Eye, EyeOff, Loader2, LogIn, ShieldCheck, UserPlus } from "lucide-react";
import { useState } from "react";
import { Sheet } from "@/components/ui";
import {
  archiveCurrentInto,
  AuthSession,
  login as doLogin,
  hasLocalDataFor,
  loadSession,
  saveSession,
  signup as doSignup,
  switchAccount,
} from "@/lib/auth";
import { useStore } from "@/lib/store";

type Mode = "login" | "signup";

export function AuthSheet({
  open,
  onClose,
  initialMode = "signup",
}: {
  open: boolean;
  onClose: () => void;
  initialMode?: Mode;
}) {
  const [mode, setMode] = useState<Mode>(initialMode);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const profileName = useStore((s) => s.profile?.name);

  const finish = (session: AuthSession) => {
    const prev = loadSession();
    const prevUserId = prev?.user?.id ?? null;
    const nextUserId = session.user.id;

    // Same account signing back in — just keep what's on screen.
    if (prevUserId === nextUserId) {
      saveSession(session);
      onClose();
      return;
    }

    const hadData = hasLocalDataFor(nextUserId);

    if (mode === "signup" && !hadData) {
      // A brand-new account adopts everything the guest already entered.
      archiveCurrentInto(prevUserId);
      archiveCurrentInto(nextUserId);
    } else {
      // Returning account: park the current dataset and restore its own slot.
      switchAccount(prevUserId, nextUserId);
    }
    saveSession(session);

    setNotice(
      hadData
        ? "Welcome back — restoring your saved data…"
        : "Account ready — keeping your current data and syncing…"
    );
    // Reload so the store rehydrates from the correct local slot.
    setTimeout(() => window.location.reload(), 700);
  };

  const submit = async () => {
    setBusy(true);
    setErr(null);
    const res =
      mode === "signup"
        ? await doSignup(email, password, name || profileName)
        : await doLogin(email, password);
    setBusy(false);

    if (!res.ok || !res.session) {
      setErr(res.error ?? "Something went wrong.");
      return;
    }
    finish(res.session);
  };

  const canSubmit = email.includes("@") && password.length >= 8 && !busy;

  return (
    <Sheet open={open} onClose={onClose} title={mode === "signup" ? "Create account" : "Log in"}>
      <div className="flex flex-col gap-4">
        <div className="card-2 flex items-start gap-3 p-3.5">
          <ShieldCheck size={18} className="mt-0.5 shrink-0 text-[var(--volt)]" />
          <p className="text-[11px] leading-relaxed text-[var(--muted)]">
            Your workouts and meals stay saved <b className="text-[var(--text)]">on this device</b> and
            keep working offline. An account simply lets you restore everything if you lose or
            change your phone.
          </p>
        </div>

        {/* Mode switch */}
        <div className="flex gap-1 rounded-2xl border border-[var(--line)] bg-[var(--surface-2)] p-1">
          {(["signup", "login"] as const).map((m) => (
            <button
              key={m}
              onClick={() => {
                setMode(m);
                setErr(null);
              }}
              className={`flex-1 rounded-xl px-2 py-2.5 text-[12px] font-bold transition-all ${
                mode === m ? "bg-[var(--volt)] text-[#0b0c0e]" : "text-[var(--muted)]"
              }`}
            >
              {m === "signup" ? "Sign up" : "Log in"}
            </button>
          ))}
        </div>

        {mode === "signup" && (
          <div>
            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
              Name (optional)
            </label>
            <input
              className="field"
              placeholder={profileName || "Your name"}
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
            />
          </div>
        )}

        <div>
          <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Email
          </label>
          <input
            className="field"
            type="email"
            inputMode="email"
            autoCapitalize="none"
            autoCorrect="off"
            autoComplete="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div>
          <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-[var(--muted)]">
            Password
          </label>
          <div className="relative">
            <input
              className="field !pr-11"
              type={showPw ? "text" : "password"}
              autoComplete={mode === "signup" ? "new-password" : "current-password"}
              placeholder="At least 8 characters"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && canSubmit) void submit();
              }}
            />
            <button
              type="button"
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--muted)]"
              onClick={() => setShowPw((v) => !v)}
              aria-label={showPw ? "Hide password" : "Show password"}
            >
              {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {mode === "signup" && (
            <p className="mt-1.5 text-[10px] leading-relaxed text-[var(--muted)]">
              Passwords are hashed before storage — nobody, including us, can read yours.
              There is no password reset yet, so keep it somewhere safe.
            </p>
          )}
        </div>

        {err && (
          <p className="rounded-xl border border-[rgba(255,122,47,0.3)] bg-[rgba(255,122,47,0.07)] p-3 text-[11px] leading-relaxed text-[var(--ember)]">
            {err}
          </p>
        )}
        {notice && (
          <p className="flex items-center justify-center gap-1.5 text-[12px] font-bold text-[var(--volt)]">
            <Check size={14} strokeWidth={3} /> {notice}
          </p>
        )}

        <button
          className={`btn h-13 w-full py-3.5 text-base ${canSubmit ? "btn-volt" : "btn-ghost opacity-55"}`}
          onClick={() => canSubmit && void submit()}
          disabled={!canSubmit}
        >
          {busy ? (
            <Loader2 size={17} className="animate-spin" />
          ) : mode === "signup" ? (
            <UserPlus size={17} />
          ) : (
            <LogIn size={17} />
          )}
          {busy ? "Please wait…" : mode === "signup" ? "Create account" : "Log in"}
        </button>

        <button className="btn btn-ghost h-11 w-full text-sm" onClick={onClose}>
          Continue without an account
        </button>

        <p className="flex items-start gap-1.5 text-center text-[10px] leading-relaxed text-[var(--muted)]">
          <Cloud size={12} className="mt-0.5 shrink-0" />
          <span>
            Signing in on a second phone pulls your backup down. Each account keeps its own
            separate data on a shared device.
          </span>
        </p>
      </div>
    </Sheet>
  );
}
