import { Muscle } from "./data";

/* ------------------------- Weekly split templates ---------------------- */

export interface SplitDay {
  /** Routine name for this day */
  label: string;
  muscles: Muscle[];
}

export interface SplitTemplate {
  id: string;
  name: string;
  blurb: string;
  /** default session length in minutes */
  minutes: number;
  /** Monday … Sunday. null = rest */
  days: (SplitDay | null)[];
  /** gear this split fundamentally needs — it is only recommended when owned */
  requires?: import("./data").EquipmentId[];
}

const REST = null;

const DAY = {
  push: { label: "Push Day", muscles: ["chest", "shoulders", "arms"] as Muscle[] },
  pull: { label: "Pull Day", muscles: ["back", "arms"] as Muscle[] },
  legs: { label: "Legs Day", muscles: ["legs", "glutes"] as Muscle[] },
  upper: { label: "Upper Body", muscles: ["chest", "back", "shoulders", "arms"] as Muscle[] },
  lower: { label: "Lower Body", muscles: ["legs", "glutes"] as Muscle[] },
  full: { label: "Full Body", muscles: ["full"] as Muscle[] },
  chest: { label: "Chest Day", muscles: ["chest"] as Muscle[] },
  back: { label: "Back Day", muscles: ["back"] as Muscle[] },
  shoulders: { label: "Shoulder Day", muscles: ["shoulders", "arms"] as Muscle[] },
  arms: { label: "Arm Day", muscles: ["arms"] as Muscle[] },
  cardio: { label: "Cardio", muscles: ["cardio"] as Muscle[] },
  core: { label: "Core & Abs", muscles: ["core"] as Muscle[] },
  box: { label: "Boxing & Conditioning", muscles: ["cardio", "full"] as Muscle[] },
} satisfies Record<string, SplitDay>;

export const SPLITS: SplitTemplate[] = [
  {
    id: "full3",
    name: "Full Body ×3",
    blurb: "Simple, effective — Mon/Wed/Fri",
    minutes: 30,
    days: [DAY.full, REST, DAY.full, REST, DAY.full, REST, REST],
  },
  {
    id: "ul4",
    name: "Upper / Lower ×4",
    blurb: "Balanced four-day build",
    minutes: 45,
    days: [DAY.upper, DAY.lower, REST, DAY.upper, DAY.lower, REST, REST],
  },
  {
    id: "ppl3",
    name: "Push · Pull · Legs",
    blurb: "One group per day, Mon/Wed/Fri",
    minutes: 45,
    days: [DAY.push, REST, DAY.pull, REST, DAY.legs, REST, REST],
  },
  {
    id: "ppl6",
    name: "PPL ×6",
    blurb: "Double push/pull/legs, six days",
    minutes: 40,
    days: [DAY.push, DAY.pull, DAY.legs, DAY.push, DAY.pull, DAY.legs, REST],
  },
  {
    id: "bro5",
    name: "Classic Bro Split",
    blurb: "Chest, back, shoulders, arms, legs",
    minutes: 45,
    days: [DAY.chest, DAY.back, DAY.shoulders, DAY.arms, DAY.legs, REST, REST],
  },
  {
    id: "cardio-core",
    name: "Cardio & Core",
    blurb: "Engine work, five short days",
    minutes: 30,
    days: [DAY.cardio, DAY.core, DAY.cardio, REST, DAY.cardio, DAY.core, REST],
  },
  {
    id: "boxing",
    name: "Boxing Focus",
    blurb: "Bag rounds + full-body strength",
    minutes: 30,
    requires: ["boxingbag"],
    days: [DAY.box, DAY.full, REST, DAY.box, DAY.full, REST, REST],
  },
  {
    id: "full2",
    name: "Full Body ×2",
    blurb: "Minimum effective dose — two days",
    minutes: 40,
    days: [DAY.full, REST, REST, DAY.full, REST, REST, REST],
  },
  {
    id: "ppl-arnold",
    name: "Arnold Split",
    blurb: "Chest+back, shoulders+arms, legs ×2",
    minutes: 50,
    days: [
      { label: "Chest & Back", muscles: ["chest", "back"] },
      { label: "Shoulders & Arms", muscles: ["shoulders", "arms"] },
      DAY.legs,
      { label: "Chest & Back", muscles: ["chest", "back"] },
      { label: "Shoulders & Arms", muscles: ["shoulders", "arms"] },
      DAY.legs,
      REST,
    ],
  },
  {
    id: "ul-full5",
    name: "Upper / Lower / Full",
    blurb: "Five days, high frequency",
    minutes: 45,
    days: [DAY.upper, DAY.lower, REST, DAY.upper, DAY.lower, DAY.full, REST],
  },
  {
    id: "glute-focus",
    name: "Glute & Leg Focus",
    blurb: "Lower-body priority with upper maintenance",
    minutes: 40,
    days: [
      { label: "Glute Day", muscles: ["glutes"] },
      DAY.upper,
      REST,
      DAY.legs,
      { label: "Glute Day", muscles: ["glutes"] },
      REST,
      REST,
    ],
  },
  {
    id: "core-shred",
    name: "Core & Conditioning",
    blurb: "Abs plus engine work, four days",
    minutes: 30,
    days: [DAY.core, DAY.cardio, REST, DAY.core, DAY.cardio, REST, REST],
  },
  {
    id: "home-minimal",
    name: "Bodyweight Only",
    blurb: "No equipment needed, four days",
    minutes: 25,
    days: [DAY.upper, DAY.lower, REST, DAY.full, DAY.core, REST, REST],
  },
  {
    id: "athlete7",
    name: "Athlete Week",
    blurb: "Six training days with active recovery",
    minutes: 50,
    days: [DAY.push, DAY.legs, DAY.pull, DAY.cardio, DAY.upper, DAY.full, REST],
  },
];

export const WEEKDAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
