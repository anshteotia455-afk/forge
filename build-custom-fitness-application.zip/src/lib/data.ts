/* ------------------------------------------------------------------ */
/* FORGE static data: equipment, muscles, exercise library, food DB    */
/* Bundled with the app so everything works fully offline.             */
/* ------------------------------------------------------------------ */

export type EquipmentId =
  | "bodyweight"
  | "dumbbells"
  | "barbell"
  | "plates"
  | "ezbar"
  | "kettlebell"
  | "squatrack"
  | "bands"
  | "pullupbar"
  | "bench"
  | "dipbars"
  | "rings"
  | "suspension"
  | "jumprope"
  | "mat"
  | "boxingbag"
  | "abwheel"
  | "medicineball"
  | "sandbag"
  | "battlerope"
  | "stabilityball"
  | "weightvest"
  | "ankleweights"
  | "foamroller"
  | "plyobox"
  | "cable"
  | "treadmill"
  | "bike"
  | "rower"
  | "trapbar"
  | "macebell"
  | "clubbell"
  | "powerbag"
  | "slamball"
  | "wristroller"
  | "grippers"
  | "indianclub"
  | "inclinebench"
  | "preachercurl"
  | "legpress"
  | "smithmachine"
  | "latpulldown"
  | "legextension"
  | "pecdeck"
  | "hyperextension"
  | "gluteham"
  | "elliptical"
  | "stairclimber"
  | "airbike"
  | "skierg"
  | "sled"
  | "agilityladder"
  | "cones"
  | "balanceboard"
  | "bosu"
  | "sliders"
  | "massagegun"
  | "lacrosseball"
  | "stretchstrap"
  | "yogablock"
  | "pushupbars"
  | "neckharness"
  | "speedbag"
  | "dipbelt";

export type EquipGroup = "Free weights" | "Rigs & bars" | "Bands & straps" | "Conditioning" | "Core & recovery" | "Machines";

export interface EquipmentDef {
  id: EquipmentId;
  label: string;
  hint: string;
  group: EquipGroup;
}

export const EQUIPMENT: EquipmentDef[] = [
  { id: "bodyweight", label: "Bodyweight", hint: "Always available — floor & gravity", group: "Free weights" },
  { id: "dumbbells", label: "Dumbbells", hint: "Pair or single adjustable", group: "Free weights" },
  { id: "barbell", label: "Barbell", hint: "Olympic or standard bar", group: "Free weights" },
  { id: "plates", label: "Weight plates", hint: "Loadable plates for the bar", group: "Free weights" },
  { id: "ezbar", label: "EZ curl bar", hint: "Short angled bar for arms", group: "Free weights" },
  { id: "kettlebell", label: "Kettlebell", hint: "One or two bells", group: "Free weights" },
  { id: "sandbag", label: "Sandbag", hint: "Shifting-load strongman work", group: "Free weights" },
  { id: "weightvest", label: "Weighted vest", hint: "Adds load to bodyweight moves", group: "Free weights" },
  { id: "ankleweights", label: "Ankle weights", hint: "Glute & core isolation", group: "Free weights" },
  { id: "medicineball", label: "Medicine / slam ball", hint: "Explosive throws & twists", group: "Free weights" },

  { id: "squatrack", label: "Squat rack", hint: "Rack, stands or power cage", group: "Rigs & bars" },
  { id: "pullupbar", label: "Pull-up bar", hint: "Doorway or wall-mounted", group: "Rigs & bars" },
  { id: "dipbars", label: "Dip bars / parallettes", hint: "Dip station or push-up bars", group: "Rigs & bars" },
  { id: "rings", label: "Gymnastic rings", hint: "Unstable pulling & pressing", group: "Rigs & bars" },
  { id: "bench", label: "Bench / chair", hint: "Flat bench or sturdy chair", group: "Rigs & bars" },
  { id: "plyobox", label: "Plyo box / step", hint: "Jumps, step-ups, elevations", group: "Rigs & bars" },

  { id: "bands", label: "Resistance bands", hint: "Loop or tube bands", group: "Bands & straps" },
  { id: "suspension", label: "Suspension straps", hint: "TRX-style strap trainer", group: "Bands & straps" },

  { id: "boxingbag", label: "Boxing bag", hint: "Heavy bag, gloves on", group: "Conditioning" },
  { id: "battlerope", label: "Battle rope", hint: "Waves, slams, power endurance", group: "Conditioning" },
  { id: "jumprope", label: "Jump rope", hint: "Speed or beaded rope", group: "Conditioning" },

  { id: "abwheel", label: "Ab wheel", hint: "Brutal anti-extension core", group: "Core & recovery" },
  { id: "stabilityball", label: "Stability ball", hint: "Swiss ball for core & legs", group: "Core & recovery" },
  { id: "mat", label: "Exercise mat", hint: "Floor work & mobility", group: "Core & recovery" },
  { id: "foamroller", label: "Foam roller", hint: "Recovery & tissue work", group: "Core & recovery" },

  { id: "cable", label: "Cable / pulley", hint: "Home gym cable stack", group: "Machines" },
  { id: "treadmill", label: "Treadmill", hint: "Walk, run, incline work", group: "Machines" },
  { id: "bike", label: "Exercise bike", hint: "Spin or upright bike", group: "Machines" },
  { id: "rower", label: "Rowing machine", hint: "Full-body cardio erg", group: "Machines" },

  /* --- Free weights wave 2 --- */
  { id: "trapbar", label: "Trap / hex bar", hint: "Safer deadlifts and carries", group: "Free weights" },
  { id: "macebell", label: "Steel mace", hint: "Offset-load swings and 360s", group: "Free weights" },
  { id: "clubbell", label: "Clubbell", hint: "Heavy club swings", group: "Free weights" },
  { id: "indianclub", label: "Indian clubs", hint: "Light shoulder mobility clubs", group: "Free weights" },
  { id: "powerbag", label: "Power bag", hint: "Gripped weighted bag", group: "Free weights" },
  { id: "slamball", label: "Slam ball", hint: "Non-bouncing ball for slams", group: "Free weights" },

  /* --- Rigs & bars wave 2 --- */
  { id: "inclinebench", label: "Adjustable / incline bench", hint: "Incline and decline angles", group: "Rigs & bars" },
  { id: "preachercurl", label: "Preacher curl bench", hint: "Strict arm isolation", group: "Rigs & bars" },
  { id: "pushupbars", label: "Push-up bars", hint: "Deeper push-up range", group: "Rigs & bars" },
  { id: "hyperextension", label: "Hyperextension bench", hint: "Back and hamstring extensions", group: "Rigs & bars" },
  { id: "gluteham", label: "Glute-ham developer", hint: "GHD raises and sit-ups", group: "Rigs & bars" },

  /* --- Machines wave 2 --- */
  { id: "smithmachine", label: "Smith machine", hint: "Guided barbell track", group: "Machines" },
  { id: "legpress", label: "Leg press", hint: "Heavy loaded leg pressing", group: "Machines" },
  { id: "latpulldown", label: "Lat pulldown", hint: "Seated vertical pulling", group: "Machines" },
  { id: "legextension", label: "Leg extension / curl", hint: "Quad and hamstring machine", group: "Machines" },
  { id: "pecdeck", label: "Pec deck / fly machine", hint: "Chest isolation machine", group: "Machines" },
  { id: "elliptical", label: "Elliptical", hint: "Low-impact cardio", group: "Machines" },
  { id: "stairclimber", label: "Stair climber", hint: "Step mill conditioning", group: "Machines" },
  { id: "airbike", label: "Air bike", hint: "Fan bike, brutal intervals", group: "Machines" },
  { id: "skierg", label: "Ski erg", hint: "Vertical pulling cardio", group: "Machines" },
  { id: "sled", label: "Prowler sled", hint: "Push and drag conditioning", group: "Conditioning" },

  /* --- Conditioning wave 2 --- */
  { id: "speedbag", label: "Speed bag", hint: "Hand speed and timing", group: "Conditioning" },
  { id: "agilityladder", label: "Agility ladder", hint: "Footwork and coordination", group: "Conditioning" },
  { id: "cones", label: "Agility cones", hint: "Shuttle runs and cuts", group: "Conditioning" },

  /* --- Core & recovery wave 2 --- */
  { id: "sliders", label: "Sliders / gliding discs", hint: "Core and hamstring slides", group: "Core & recovery" },
  { id: "balanceboard", label: "Balance board", hint: "Ankle stability training", group: "Core & recovery" },
  { id: "bosu", label: "Bosu ball", hint: "Unstable surface training", group: "Core & recovery" },
  { id: "massagegun", label: "Massage gun", hint: "Percussive recovery", group: "Core & recovery" },
  { id: "lacrosseball", label: "Lacrosse ball", hint: "Trigger-point release", group: "Core & recovery" },
  { id: "stretchstrap", label: "Stretch strap", hint: "Assisted deep stretching", group: "Core & recovery" },
  { id: "yogablock", label: "Yoga block", hint: "Support for mobility work", group: "Core & recovery" },

  /* --- Grip --- */
  { id: "wristroller", label: "Wrist roller", hint: "Forearm and grip burner", group: "Free weights" },
  { id: "grippers", label: "Hand grippers", hint: "Crushing grip strength", group: "Free weights" },
  { id: "neckharness", label: "Neck harness", hint: "Direct neck training", group: "Free weights" },
  { id: "dipbelt", label: "Dip belt", hint: "Hang plates for weighted pull-ups & dips", group: "Free weights" },
];

export const EQUIP_GROUPS: EquipGroup[] = [
  "Free weights",
  "Rigs & bars",
  "Bands & straps",
  "Conditioning",
  "Core & recovery",
  "Machines",
];

export type Muscle =
  | "full"
  | "chest"
  | "back"
  | "shoulders"
  | "arms"
  | "legs"
  | "glutes"
  | "core"
  | "cardio";

export const MUSCLES: { id: Muscle; label: string }[] = [
  { id: "full", label: "Full body" },
  { id: "chest", label: "Chest" },
  { id: "back", label: "Back" },
  { id: "shoulders", label: "Shoulders" },
  { id: "arms", label: "Arms" },
  { id: "legs", label: "Legs" },
  { id: "glutes", label: "Glutes" },
  { id: "core", label: "Core" },
  { id: "cardio", label: "Cardio" },
];

export const MUSCLE_LABEL: Record<Muscle, string> = Object.fromEntries(
  MUSCLES.map((m) => [m.id, m.label])
) as Record<Muscle, string>;

export interface Exercise {
  id: string;
  name: string;
  equipment: EquipmentId[];
  muscles: Muscle[];
  level: 1 | 2 | 3;
  kind: "reps" | "time";
  /** base reps (reps kind) or seconds (time kind) at intermediate level */
  reps?: number;
  sec?: number;
  /** metabolic equivalent — used for calorie burn estimation */
  met: number;
  /** performed one side at a time */
  uni?: boolean;
  cue: string;
  /** user-created exercise */
  custom?: boolean;
  /**
   * How load is recorded:
   *  - "external": the weight IS the load (barbell, dumbbells, kettlebell)
   *  - "added":    bodyweight move you can load with a vest / dip belt / backpack
   */
  load?: "external" | "added";
  /** fraction of bodyweight actually moved — used for weighted-calisthenics 1RM */
  bwFactor?: number;
}

/** Gear that lets you add weight to a bodyweight movement. */
export const LOADING_GEAR: EquipmentId[] = ["weightvest", "dipbelt", "plates", "dumbbells", "ankleweights"];

export const EXERCISES: Exercise[] = [
  /* ----------------------------- Bodyweight ----------------------------- */
  { id: "push-up", name: "Push-Up", equipment: ["bodyweight"], muscles: ["chest", "arms"], level: 1, kind: "reps", reps: 12, met: 6, cue: "Body in one line, chest kisses the floor.", load: "added", bwFactor: 0.64 },
  { id: "pike-push-up", name: "Pike Push-Up", equipment: ["bodyweight"], muscles: ["shoulders", "arms"], level: 2, kind: "reps", reps: 10, met: 5.5, cue: "Hips high, head between your arms.", load: "added", bwFactor: 0.7 },
  { id: "squat", name: "Bodyweight Squat", equipment: ["bodyweight"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 15, met: 5.3, cue: "Knees track over toes, chest proud.", load: "added", bwFactor: 0.85 },
  { id: "reverse-lunge", name: "Reverse Lunge", equipment: ["bodyweight"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 12, met: 5.8, uni: true, cue: "Step back softly, drive through the front heel.", load: "added", bwFactor: 0.85 },
  { id: "jump-squat", name: "Jump Squat", equipment: ["bodyweight"], muscles: ["legs", "cardio"], level: 2, kind: "reps", reps: 12, met: 9, cue: "Land soft, explode tall.", load: "added", bwFactor: 0.85 },
  { id: "glute-bridge", name: "Glute Bridge", equipment: ["bodyweight"], muscles: ["glutes", "core"], level: 1, kind: "reps", reps: 15, met: 5, cue: "Squeeze your glutes hard at the top.", load: "added", bwFactor: 0.5 },
  { id: "plank", name: "Plank", equipment: ["bodyweight"], muscles: ["core"], level: 1, kind: "time", sec: 40, met: 4, cue: "Ribs down, glutes tight, breathe.", load: "added", bwFactor: 0.6 },
  { id: "side-plank", name: "Side Plank", equipment: ["bodyweight"], muscles: ["core"], level: 2, kind: "time", sec: 30, met: 4, uni: true, cue: "Stack hips, reach long through the top arm.", load: "added", bwFactor: 0.5 },
  { id: "mountain-climbers", name: "Mountain Climbers", equipment: ["bodyweight"], muscles: ["cardio", "core"], level: 1, kind: "time", sec: 30, met: 8, cue: "Hips level, sprint your knees in." },
  { id: "burpees", name: "Burpees", equipment: ["bodyweight"], muscles: ["full", "cardio"], level: 2, kind: "reps", reps: 10, met: 9, cue: "Chest to floor, snap up, jump." },
  { id: "wall-sit", name: "Wall Sit", equipment: ["bodyweight"], muscles: ["legs"], level: 1, kind: "time", sec: 40, met: 4, cue: "Thighs parallel to the floor, back flat on the wall.", load: "added", bwFactor: 0.85 },
  { id: "calf-raise", name: "Calf Raise", equipment: ["bodyweight"], muscles: ["legs"], level: 1, kind: "reps", reps: 18, met: 3.5, cue: "Pause at the very top of each rep.", load: "added", bwFactor: 0.85 },
  { id: "superman", name: "Superman Hold", equipment: ["bodyweight"], muscles: ["back"], level: 1, kind: "time", sec: 30, met: 3.5, cue: "Lift chest and thighs, neck neutral.", load: "added", bwFactor: 0.4 },
  { id: "leg-raise", name: "Lying Leg Raise", equipment: ["bodyweight"], muscles: ["core"], level: 2, kind: "reps", reps: 12, met: 4, cue: "Low back pressed into the floor.", load: "added", bwFactor: 0.5 },
  { id: "bicycle-crunch", name: "Bicycle Crunch", equipment: ["bodyweight"], muscles: ["core"], level: 1, kind: "reps", reps: 20, met: 5, cue: "Rotate to the knee, slow and controlled." },
  { id: "high-knees", name: "High Knees", equipment: ["bodyweight"], muscles: ["cardio"], level: 1, kind: "time", sec: 30, met: 9, cue: "Knees to hip height, pump your arms." },
  { id: "bear-crawl", name: "Bear Crawl", equipment: ["bodyweight"], muscles: ["full", "core"], level: 2, kind: "time", sec: 30, met: 8, cue: "Knees hover an inch off the floor.", load: "added", bwFactor: 0.6 },
  { id: "inchworm", name: "Inchworm", equipment: ["bodyweight"], muscles: ["full", "core"], level: 1, kind: "reps", reps: 8, met: 6, cue: "Walk out long, walk back tall.", load: "added", bwFactor: 0.6 },
  { id: "donkey-kick", name: "Donkey Kick", equipment: ["bodyweight"], muscles: ["glutes"], level: 1, kind: "reps", reps: 14, met: 4, uni: true, cue: "Kick the ceiling, don't arch the back.", load: "added", bwFactor: 0.3 },
  { id: "jumping-jacks", name: "Jumping Jacks", equipment: ["bodyweight"], muscles: ["cardio", "full"], level: 1, kind: "time", sec: 40, met: 8, cue: "Light feet, full arm swing." },

  /* ----------------------------- Dumbbells ------------------------------ */
  { id: "db-goblet-squat", name: "Goblet Squat", equipment: ["dumbbells"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 12, met: 6, cue: "Elbows inside knees at the bottom." },
  { id: "db-floor-press", name: "Dumbbell Floor Press", equipment: ["dumbbells"], muscles: ["chest", "arms"], level: 1, kind: "reps", reps: 12, met: 6, cue: "Triceps tap the floor, then punch up." },
  { id: "db-bench-press", name: "Dumbbell Bench Press", equipment: ["dumbbells", "bench"], muscles: ["chest", "arms"], level: 2, kind: "reps", reps: 12, met: 6, cue: "Lower slow, press the dumbbells together." },
  { id: "db-row", name: "One-Arm Dumbbell Row", equipment: ["dumbbells"], muscles: ["back", "arms"], level: 1, kind: "reps", reps: 12, met: 6, uni: true, cue: "Pull to your hip, squeeze the shoulder blade." },
  { id: "db-shoulder-press", name: "Dumbbell Shoulder Press", equipment: ["dumbbells"], muscles: ["shoulders", "arms"], level: 1, kind: "reps", reps: 10, met: 6, cue: "Stack over ears, ribs down." },
  { id: "db-curl", name: "Dumbbell Bicep Curl", equipment: ["dumbbells"], muscles: ["arms"], level: 1, kind: "reps", reps: 12, met: 4, cue: "Elbows pinned, no swinging." },
  { id: "db-hammer-curl", name: "Hammer Curl", equipment: ["dumbbells"], muscles: ["arms"], level: 1, kind: "reps", reps: 12, met: 4, cue: "Palms face each other the whole way." },
  { id: "db-triceps-ext", name: "Overhead Triceps Extension", equipment: ["dumbbells"], muscles: ["arms"], level: 1, kind: "reps", reps: 12, met: 4.5, cue: "Elbows pointing at the ceiling." },
  { id: "db-lateral-raise", name: "Lateral Raise", equipment: ["dumbbells"], muscles: ["shoulders"], level: 1, kind: "reps", reps: 14, met: 4.5, cue: "Lead with elbows, stop at shoulder height." },
  { id: "db-rdl", name: "Dumbbell Romanian Deadlift", equipment: ["dumbbells"], muscles: ["back", "glutes", "legs"], level: 2, kind: "reps", reps: 12, met: 6.5, cue: "Hips hinge back, weights slide down thighs." },
  { id: "db-fly", name: "Dumbbell Floor Fly", equipment: ["dumbbells"], muscles: ["chest"], level: 2, kind: "reps", reps: 12, met: 5, cue: "Soft elbows, big stretch, hug a barrel." },
  { id: "db-thruster", name: "Dumbbell Thruster", equipment: ["dumbbells"], muscles: ["full", "cardio", "shoulders"], level: 2, kind: "reps", reps: 10, met: 9, cue: "Squat deep, drive straight overhead." },
  { id: "db-farmers", name: "Farmer's Carry", equipment: ["dumbbells"], muscles: ["full", "core"], level: 1, kind: "time", sec: 40, met: 7, cue: "Walk tall, shoulders crushed down." },
  { id: "db-renegade-row", name: "Renegade Row", equipment: ["dumbbells"], muscles: ["back", "core"], level: 3, kind: "reps", reps: 8, met: 8, uni: true, cue: "Hips dead level as you row." },
  { id: "db-lunge", name: "Dumbbell Lunge", equipment: ["dumbbells"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 10, met: 6.5, uni: true, cue: "Torso tall, knee hovers off the floor." },

  /* ------------------------------ Barbell ------------------------------- */
  { id: "bb-squat", name: "Barbell Back Squat", equipment: ["barbell"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 10, met: 7, cue: "Brace hard, sit between your heels." },
  { id: "bb-deadlift", name: "Deadlift", equipment: ["barbell"], muscles: ["back", "glutes", "legs"], level: 2, kind: "reps", reps: 8, met: 8, cue: "Push the floor away, bar hugs your legs." },
  { id: "bb-bench", name: "Barbell Bench Press", equipment: ["barbell", "bench"], muscles: ["chest", "arms"], level: 2, kind: "reps", reps: 10, met: 6.5, cue: "Shoulder blades locked, touch mid-chest." },
  { id: "bb-ohp", name: "Barbell Overhead Press", equipment: ["barbell"], muscles: ["shoulders", "arms"], level: 2, kind: "reps", reps: 8, met: 6.5, cue: "Glutes tight, head through at the top." },
  { id: "bb-row", name: "Barbell Bent-Over Row", equipment: ["barbell"], muscles: ["back", "arms"], level: 2, kind: "reps", reps: 10, met: 7, cue: "Hinge 45°, pull to the belly button." },
  { id: "bb-hip-thrust", name: "Barbell Hip Thrust", equipment: ["barbell", "bench"], muscles: ["glutes"], level: 2, kind: "reps", reps: 12, met: 6.5, cue: "Chin tucked, full lockout squeeze." },
  { id: "bb-curl", name: "Barbell Curl", equipment: ["barbell"], muscles: ["arms"], level: 1, kind: "reps", reps: 10, met: 4.5, cue: "Two seconds up, three seconds down." },

  /* ---------------------------- Kettlebell ------------------------------ */
  { id: "kb-swing", name: "Kettlebell Swing", equipment: ["kettlebell"], muscles: ["glutes", "back", "cardio"], level: 2, kind: "reps", reps: 15, met: 9, cue: "Snap the hips, arms are just ropes." },
  { id: "kb-goblet", name: "Kettlebell Goblet Squat", equipment: ["kettlebell"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 12, met: 6, cue: "Bell at the chest, sink deep." },
  { id: "kb-clean-press", name: "Kettlebell Clean & Press", equipment: ["kettlebell"], muscles: ["full", "shoulders"], level: 3, kind: "reps", reps: 8, met: 9, uni: true, cue: "Zip the elbow, punch to the ceiling." },
  { id: "kb-halo", name: "Kettlebell Halo", equipment: ["kettlebell"], muscles: ["shoulders", "core"], level: 1, kind: "reps", reps: 10, met: 4, cue: "Draw a tight circle around your head." },
  { id: "kb-windmill", name: "Kettlebell Windmill", equipment: ["kettlebell"], muscles: ["core", "shoulders"], level: 3, kind: "reps", reps: 8, met: 5, uni: true, cue: "Eyes on the bell, hips push sideways." },

  /* ---------------------------- Bands ----------------------------------- */
  { id: "band-pull-apart", name: "Band Pull-Apart", equipment: ["bands"], muscles: ["back", "shoulders"], level: 1, kind: "reps", reps: 15, met: 3.5, cue: "Pinch the shoulder blades as you pull." },
  { id: "band-squat", name: "Banded Squat", equipment: ["bands"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 15, met: 5, cue: "Stand on the band, press knees out." },
  { id: "band-row", name: "Banded Row", equipment: ["bands"], muscles: ["back", "arms"], level: 1, kind: "reps", reps: 14, met: 5, cue: "Anchor low, row to your ribs." },
  { id: "band-press", name: "Banded Chest Press", equipment: ["bands"], muscles: ["chest", "arms"], level: 1, kind: "reps", reps: 14, met: 5, cue: "Band across your back, punch forward." },
  { id: "band-face-pull", name: "Band Face Pull", equipment: ["bands"], muscles: ["back", "shoulders"], level: 1, kind: "reps", reps: 15, met: 3.5, cue: "Pull to eyebrows, elbows high." },
  { id: "band-curl", name: "Band Bicep Curl", equipment: ["bands"], muscles: ["arms"], level: 1, kind: "reps", reps: 15, met: 3.5, cue: "Constant tension, slow negative." },
  { id: "band-pushdown", name: "Band Triceps Pushdown", equipment: ["bands"], muscles: ["arms"], level: 1, kind: "reps", reps: 15, met: 3.5, cue: "Lock elbows to your ribs, press down." },
  { id: "pallof-press", name: "Pallof Press", equipment: ["bands"], muscles: ["core"], level: 2, kind: "reps", reps: 12, met: 4, uni: true, cue: "Resist the rotation, arms straight." },
  { id: "band-rdl", name: "Banded Romanian Deadlift", equipment: ["bands"], muscles: ["glutes", "back"], level: 1, kind: "reps", reps: 15, met: 5, cue: "Stand on the band, hinge from the hips." },

  /* ---------------------------- Pull-up bar ----------------------------- */
  { id: "pull-up", name: "Pull-Up", equipment: ["pullupbar"], muscles: ["back", "arms"], level: 3, kind: "reps", reps: 6, met: 8, cue: "Chest to the bar, dead-hang start.", load: "added", bwFactor: 1 },
  { id: "chin-up", name: "Chin-Up", equipment: ["pullupbar"], muscles: ["back", "arms"], level: 2, kind: "reps", reps: 6, met: 8, cue: "Palms facing you, squeeze at the top.", load: "added", bwFactor: 1 },
  { id: "dead-hang", name: "Dead Hang", equipment: ["pullupbar"], muscles: ["back"], level: 1, kind: "time", sec: 30, met: 3, cue: "Grip hard, shoulders away from ears.", load: "added", bwFactor: 1 },
  { id: "hanging-leg-raise", name: "Hanging Leg Raise", equipment: ["pullupbar"], muscles: ["core"], level: 2, kind: "reps", reps: 10, met: 6, cue: "No swinging — curl the pelvis up.", load: "added", bwFactor: 0.5 },
  { id: "scap-pull", name: "Scapular Pull-Up", equipment: ["pullupbar"], muscles: ["back"], level: 2, kind: "reps", reps: 10, met: 4, cue: "Arms straight, pull only with shoulders.", load: "added", bwFactor: 1 },

  /* ------------------------- Bench / step / rope ------------------------ */
  { id: "incline-push-up", name: "Incline Push-Up", equipment: ["bench"], muscles: ["chest", "arms"], level: 1, kind: "reps", reps: 14, met: 4, cue: "Hands on the bench, body rigid.", load: "added", bwFactor: 0.5 },
  { id: "chair-dip", name: "Chair Dip", equipment: ["bench"], muscles: ["arms", "chest"], level: 2, kind: "reps", reps: 10, met: 6, cue: "Shoulders down, elbows track back.", load: "added", bwFactor: 0.65 },
  { id: "step-up", name: "Step-Up", equipment: ["bench"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 12, met: 7, uni: true, cue: "Whole foot on, drive through the heel.", load: "added", bwFactor: 0.85 },
  { id: "bulgarian-split-squat", name: "Bulgarian Split Squat", equipment: ["bench"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 10, met: 6.5, uni: true, cue: "Rear foot up, drop straight down.", load: "added", bwFactor: 0.85 },
  { id: "bw-hip-thrust", name: "Hip Thrust", equipment: ["bench"], muscles: ["glutes"], level: 1, kind: "reps", reps: 14, met: 5, cue: "Shoulders on the bench, drive hips high.", load: "added", bwFactor: 0.5 },
  { id: "jump-rope", name: "Jump Rope", equipment: ["jumprope"], muscles: ["cardio", "legs"], level: 1, kind: "time", sec: 60, met: 10, cue: "Wrists turn, bounce on the balls of your feet." },
  { id: "rope-intervals", name: "Rope Intervals", equipment: ["jumprope"], muscles: ["cardio"], level: 2, kind: "time", sec: 40, met: 11, cue: "20 seconds fast, 20 seconds cruising." },

  /* -------------------------------- Mat --------------------------------- */
  { id: "cat-cow", name: "Cat-Cow Flow", equipment: ["mat"], muscles: ["core", "back"], level: 1, kind: "time", sec: 40, met: 2.5, cue: "Move one vertebra at a time." },
  { id: "world-stretch", name: "World's Greatest Stretch", equipment: ["mat"], muscles: ["full"], level: 1, kind: "time", sec: 40, met: 3, cue: "Lunge deep, rotate open, breathe slow." },

  /* ----------------------------- Boxing bag ----------------------------- */
  { id: "bag-jab-cross", name: "Bag Jab-Cross", equipment: ["boxingbag"], muscles: ["cardio", "shoulders", "arms"], level: 1, kind: "time", sec: 60, met: 8, cue: "Hands up, rotate the back foot on every cross." },
  { id: "bag-combos", name: "Bag 4-Punch Combos", equipment: ["boxingbag"], muscles: ["cardio", "full"], level: 2, kind: "time", sec: 45, met: 9.5, cue: "Jab-cross-hook-cross. Breathe out on each punch." },
  { id: "bag-hooks", name: "Bag Hooks & Uppercuts", equipment: ["boxingbag"], muscles: ["arms", "shoulders", "core"], level: 2, kind: "time", sec: 40, met: 8.5, cue: "Turn from the hips — the arm is just the delivery." },
  { id: "bag-knees", name: "Bag Knee Strikes", equipment: ["boxingbag"], muscles: ["core", "legs", "cardio"], level: 2, kind: "time", sec: 30, met: 9, cue: "Clinch high, drive the hip through each knee." },
  { id: "bag-speed-burst", name: "Bag Speed Burst", equipment: ["boxingbag"], muscles: ["cardio"], level: 3, kind: "time", sec: 20, met: 11, cue: "Fastest hands you have — all-out for the buzzer." },
  { id: "bag-footwork", name: "Bag Footwork Circles", equipment: ["boxingbag"], muscles: ["cardio", "legs"], level: 1, kind: "time", sec: 45, met: 7.5, cue: "Circle the bag light on your toes, never cross your feet." },

  /* -------------------------- Suspension straps -------------------------- */
  { id: "trx-row", name: "Strap Row", equipment: ["suspension"], muscles: ["back", "arms"], level: 1, kind: "reps", reps: 12, met: 5.5, cue: "Walk feet forward to make it harder. Squeeze the blades." },
  { id: "trx-press", name: "Strap Chest Press", equipment: ["suspension"], muscles: ["chest", "arms"], level: 2, kind: "reps", reps: 12, met: 5.5, cue: "Body rigid like a plank — press, don't sag." },
  { id: "trx-fallout", name: "Strap Fallout", equipment: ["suspension"], muscles: ["core", "shoulders"], level: 3, kind: "reps", reps: 10, met: 6, cue: "Arms overhead, ribs down. Only go as far as you control." },
  { id: "trx-ham-curl", name: "Strap Hamstring Curl", equipment: ["suspension"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 12, met: 6, cue: "Hips high throughout, heels drag to your butt." },
  { id: "trx-y-fly", name: "Strap Y-Fly", equipment: ["suspension"], muscles: ["shoulders", "back"], level: 2, kind: "reps", reps: 12, met: 5, cue: "Make a Y overhead, thumbs back." },
  { id: "trx-split-squat", name: "Strap Split Squat", equipment: ["suspension"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 10, met: 6, uni: true, cue: "Rear foot in the cradle, drop straight down.", load: "added", bwFactor: 0.85 },
  { id: "trx-pistol", name: "Strap Assisted Pistol", equipment: ["suspension"], muscles: ["legs"], level: 3, kind: "reps", reps: 8, met: 6.5, uni: true, cue: "Use the straps only as much as you need.", load: "added", bwFactor: 0.85 },

  /* ----------------------------- Rings ----------------------------------- */
  { id: "ring-row", name: "Ring Row", equipment: ["rings"], muscles: ["back", "arms"], level: 2, kind: "reps", reps: 10, met: 6, cue: "Rings turn out at the top — chest to the rings.", load: "added", bwFactor: 0.6 },
  { id: "ring-dip", name: "Ring Dip", equipment: ["rings"], muscles: ["chest", "arms"], level: 3, kind: "reps", reps: 6, met: 7, cue: "Lock the rings to your ribs, no swinging.", load: "added", bwFactor: 1 },
  { id: "ring-support", name: "Ring Support Hold", equipment: ["rings"], muscles: ["shoulders", "core"], level: 3, kind: "time", sec: 20, met: 5, cue: "Arms locked, rings turned out, shoulders down." },
  { id: "ring-pushup", name: "Ring Push-Up", equipment: ["rings"], muscles: ["chest", "core"], level: 3, kind: "reps", reps: 10, met: 6.5, cue: "Fight the wobble — slow and honest.", load: "added", bwFactor: 0.64 },

  /* -------------------------- Dip bars / parallettes --------------------- */
  { id: "parallel-dip", name: "Parallel Bar Dip", equipment: ["dipbars"], muscles: ["chest", "arms"], level: 2, kind: "reps", reps: 8, met: 7, cue: "Slight forward lean for chest, upright for triceps.", load: "added", bwFactor: 1 },
  { id: "captains-raise", name: "Hanging Knee Raise (bars)", equipment: ["dipbars"], muscles: ["core"], level: 2, kind: "reps", reps: 12, met: 5.5, cue: "Curl the pelvis, don't just swing the legs." },
  { id: "l-sit", name: "L-Sit Hold", equipment: ["dipbars"], muscles: ["core", "arms"], level: 3, kind: "time", sec: 20, met: 6, cue: "Push the bars down hard, legs locked straight.", load: "added", bwFactor: 0.9 },
  { id: "parallette-pushup", name: "Parallette Push-Up", equipment: ["dipbars"], muscles: ["chest", "arms"], level: 2, kind: "reps", reps: 12, met: 6, cue: "Deeper range than the floor — control the stretch.", load: "added", bwFactor: 0.64 },
  { id: "tuck-hold", name: "Tuck Support Hold", equipment: ["dipbars"], muscles: ["core", "shoulders"], level: 2, kind: "time", sec: 25, met: 5, cue: "Knees to chest, arms locked, breathe.", load: "added", bwFactor: 0.9 },

  /* ------------------------------ Ab wheel -------------------------------- */
  { id: "ab-rollout-knee", name: "Kneeling Ab Rollout", equipment: ["abwheel"], muscles: ["core"], level: 2, kind: "reps", reps: 8, met: 5.5, cue: "Tuck the pelvis — never let the low back arch.", load: "added", bwFactor: 0.5 },
  { id: "ab-rollout-stand", name: "Standing Ab Rollout", equipment: ["abwheel"], muscles: ["core", "shoulders"], level: 3, kind: "reps", reps: 5, met: 7, cue: "Elite move. Only if the knee version is easy.", load: "added", bwFactor: 0.7 },
  { id: "ab-wheel-oblique", name: "Ab Wheel Angled Rollout", equipment: ["abwheel"], muscles: ["core"], level: 3, kind: "reps", reps: 6, met: 6, uni: true, cue: "Roll out at 45° to hammer the obliques." },

  /* --------------------------- Medicine ball ------------------------------ */
  { id: "mb-slam", name: "Medicine Ball Slam", equipment: ["medicineball"], muscles: ["full", "cardio", "core"], level: 2, kind: "reps", reps: 12, met: 9.5, cue: "Reach tall, slam like you mean it, catch the bounce." },
  { id: "mb-russian-twist", name: "Med Ball Russian Twist", equipment: ["medicineball"], muscles: ["core"], level: 2, kind: "reps", reps: 20, met: 5, cue: "Chest tall, rotate from the ribs not the arms." },
  { id: "mb-wall-ball", name: "Wall Ball", equipment: ["medicineball"], muscles: ["legs", "shoulders", "cardio"], level: 2, kind: "reps", reps: 15, met: 9, cue: "Squat deep, drive up and throw in one motion." },
  { id: "mb-chest-pass", name: "Explosive Chest Pass", equipment: ["medicineball"], muscles: ["chest", "arms"], level: 2, kind: "reps", reps: 12, met: 7, cue: "Push hard and fast off the wall." },
  { id: "mb-vsit-pass", name: "Med Ball V-Sit Hold", equipment: ["medicineball"], muscles: ["core"], level: 2, kind: "time", sec: 30, met: 5, cue: "Balance on your sit bones, ball overhead." },

  /* ------------------------------ Sandbag --------------------------------- */
  { id: "sandbag-clean", name: "Sandbag Clean", equipment: ["sandbag"], muscles: ["full", "back", "legs"], level: 3, kind: "reps", reps: 8, met: 9, cue: "Hinge, rip it to the chest, stand tall." },
  { id: "sandbag-squat", name: "Sandbag Bear-Hug Squat", equipment: ["sandbag"], muscles: ["legs", "glutes", "core"], level: 2, kind: "reps", reps: 12, met: 7, cue: "Hug it tight to the chest, elbows up." },
  { id: "sandbag-carry", name: "Sandbag Carry", equipment: ["sandbag"], muscles: ["full", "core"], level: 2, kind: "time", sec: 40, met: 8, cue: "Walk tall, brace every step." },
  { id: "sandbag-shoulder", name: "Sandbag Shoulder-to-Shoulder", equipment: ["sandbag"], muscles: ["shoulders", "core"], level: 3, kind: "reps", reps: 8, met: 8.5, uni: true, cue: "Clean to one shoulder, then the other." },
  { id: "sandbag-rdl", name: "Sandbag Romanian Deadlift", equipment: ["sandbag"], muscles: ["glutes", "back"], level: 2, kind: "reps", reps: 12, met: 6.5, cue: "Hips back, bag slides down the thighs." },

  /* ----------------------------- Battle rope ------------------------------ */
  { id: "rope-alt-waves", name: "Alternating Rope Waves", equipment: ["battlerope"], muscles: ["cardio", "arms", "shoulders"], level: 2, kind: "time", sec: 30, met: 10, cue: "Quarter squat, pump fast from the shoulders." },
  { id: "rope-double-slam", name: "Double Rope Slam", equipment: ["battlerope"], muscles: ["full", "cardio"], level: 2, kind: "time", sec: 25, met: 10.5, cue: "Both arms overhead, slam the ropes down together." },
  { id: "rope-circles", name: "Rope Circles", equipment: ["battlerope"], muscles: ["shoulders", "cardio"], level: 2, kind: "time", sec: 25, met: 9.5, cue: "Draw outward circles — brutal on the delts." },
  { id: "rope-jump-slam", name: "Jumping Rope Slam", equipment: ["battlerope"], muscles: ["full", "cardio"], level: 3, kind: "time", sec: 20, met: 11.5, cue: "Jump as you slam. Full-body finisher." },

  /* ---------------------------- Stability ball ---------------------------- */
  { id: "ball-crunch", name: "Stability Ball Crunch", equipment: ["stabilityball"], muscles: ["core"], level: 1, kind: "reps", reps: 15, met: 4, cue: "Let the low back drape over the ball for full range." },
  { id: "ball-ham-curl", name: "Ball Hamstring Curl", equipment: ["stabilityball"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 12, met: 5.5, cue: "Hips lifted, heels pull the ball in." },
  { id: "ball-pike", name: "Ball Pike", equipment: ["stabilityball"], muscles: ["core", "shoulders"], level: 3, kind: "reps", reps: 10, met: 6.5, cue: "Hips to the ceiling, legs locked." },
  { id: "ball-plank", name: "Ball Forearm Plank", equipment: ["stabilityball"], muscles: ["core"], level: 2, kind: "time", sec: 30, met: 4.5, cue: "Elbows on the ball — fight every wobble." },
  { id: "ball-wall-squat", name: "Ball Wall Squat", equipment: ["stabilityball"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 15, met: 5, cue: "Ball between your back and the wall, roll down slow." },

  /* ---------------------------- Weighted vest ----------------------------- */
  { id: "vest-pushup", name: "Weighted Vest Push-Up", equipment: ["weightvest"], muscles: ["chest", "arms"], level: 2, kind: "reps", reps: 12, met: 7, cue: "Same strict form — the vest does the talking." },
  { id: "vest-squat", name: "Weighted Vest Squat", equipment: ["weightvest"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 15, met: 6.5, cue: "Sit back and down, chest proud." },
  { id: "vest-walk", name: "Weighted Vest Ruck Walk", equipment: ["weightvest"], muscles: ["legs", "cardio"], level: 1, kind: "time", sec: 60, met: 7, cue: "Brisk pace, tall posture, steady breathing." },
  { id: "vest-plank", name: "Weighted Vest Plank", equipment: ["weightvest"], muscles: ["core"], level: 2, kind: "time", sec: 40, met: 5, cue: "Glutes locked, no sagging under the load." },

  /* ----------------------------- Ankle weights ---------------------------- */
  { id: "ankle-leg-raise", name: "Weighted Lying Leg Raise", equipment: ["ankleweights"], muscles: ["core"], level: 2, kind: "reps", reps: 12, met: 4.5, cue: "Low back glued to the floor." },
  { id: "ankle-kickback", name: "Weighted Glute Kickback", equipment: ["ankleweights"], muscles: ["glutes"], level: 1, kind: "reps", reps: 15, met: 4.5, uni: true, cue: "Squeeze at the top, no arching." },
  { id: "ankle-fire-hydrant", name: "Weighted Fire Hydrant", equipment: ["ankleweights"], muscles: ["glutes"], level: 1, kind: "reps", reps: 15, met: 4.5, uni: true, cue: "Knee opens to the side, hips square." },
  { id: "ankle-flutter", name: "Weighted Flutter Kicks", equipment: ["ankleweights"], muscles: ["core"], level: 2, kind: "time", sec: 30, met: 5, cue: "Small fast scissors, heels never touch down." },

  /* ------------------------------ Plyo box -------------------------------- */
  { id: "box-jump", name: "Box Jump", equipment: ["plyobox"], muscles: ["legs", "cardio"], level: 2, kind: "reps", reps: 10, met: 9, cue: "Land soft in a quarter squat, step down." },
  { id: "box-stepover", name: "Lateral Box Step-Over", equipment: ["plyobox"], muscles: ["legs", "cardio"], level: 1, kind: "time", sec: 40, met: 8, cue: "Quick feet over the box, stay light.", load: "added", bwFactor: 0.85 },
  { id: "decline-pushup", name: "Decline Push-Up", equipment: ["plyobox"], muscles: ["chest", "shoulders"], level: 2, kind: "reps", reps: 12, met: 6, cue: "Feet elevated — hits the upper chest.", load: "added", bwFactor: 0.7 },
  { id: "box-shoulder-tap", name: "Elevated Shoulder Tap", equipment: ["plyobox"], muscles: ["core", "shoulders"], level: 2, kind: "reps", reps: 16, met: 5.5, cue: "Hips dead still as each hand taps." },

  /* ------------------------------ Foam roller ----------------------------- */
  { id: "foam-quads", name: "Foam Roll Quads", equipment: ["foamroller"], muscles: ["legs"], level: 1, kind: "time", sec: 45, met: 2.5, uni: true, cue: "Slow passes, pause on the tender spots." },
  { id: "foam-back", name: "Foam Roll Upper Back", equipment: ["foamroller"], muscles: ["back"], level: 1, kind: "time", sec: 45, met: 2.5, cue: "Support your head, roll the mid-back only." },
  { id: "foam-glutes", name: "Foam Roll Glutes", equipment: ["foamroller"], muscles: ["glutes"], level: 1, kind: "time", sec: 40, met: 2.5, uni: true, cue: "Ankle over knee, lean into the glute." },
  { id: "foam-chest-open", name: "Roller Chest Opener", equipment: ["foamroller"], muscles: ["chest", "back"], level: 1, kind: "time", sec: 60, met: 2.3, cue: "Lie lengthwise on the roller, arms wide, breathe." },

  /* -------------------------------- Plates -------------------------------- */
  { id: "plate-front-raise", name: "Plate Front Raise", equipment: ["plates"], muscles: ["shoulders"], level: 1, kind: "reps", reps: 12, met: 4.5, cue: "Hold at 3 and 9 o'clock, raise to eye level." },
  { id: "plate-halo", name: "Plate Halo", equipment: ["plates"], muscles: ["shoulders", "core"], level: 1, kind: "reps", reps: 10, met: 4, cue: "Tight circle around the head, ribs down." },
  { id: "plate-g2oh", name: "Plate Ground-to-Overhead", equipment: ["plates"], muscles: ["full", "cardio"], level: 2, kind: "reps", reps: 12, met: 8.5, cue: "Hinge down, stand and press in one chain." },
  { id: "plate-twist", name: "Plate Russian Twist", equipment: ["plates"], muscles: ["core"], level: 2, kind: "reps", reps: 20, met: 5, cue: "Heels up, rotate the plate hip to hip." },
  { id: "plate-squat", name: "Plate Goblet Squat", equipment: ["plates"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 15, met: 6, cue: "Hug the plate at your chest, sink deep." },
  { id: "plate-pinch-carry", name: "Plate Pinch Carry", equipment: ["plates"], muscles: ["arms", "core"], level: 2, kind: "time", sec: 30, met: 6, cue: "Pinch the smooth side — grip killer." },

  /* -------------------------------- EZ bar -------------------------------- */
  { id: "ez-curl", name: "EZ Bar Curl", equipment: ["ezbar"], muscles: ["arms"], level: 1, kind: "reps", reps: 12, met: 4.5, cue: "Elbows pinned to your ribs, no swinging." },
  { id: "ez-skullcrusher", name: "EZ Bar Skullcrusher", equipment: ["ezbar", "bench"], muscles: ["arms"], level: 2, kind: "reps", reps: 10, met: 5, cue: "Only the forearms move — lower to the forehead." },
  { id: "ez-upright-row", name: "EZ Bar Upright Row", equipment: ["ezbar"], muscles: ["shoulders", "back"], level: 2, kind: "reps", reps: 12, met: 5, cue: "Lead with the elbows, stop at chest height." },
  { id: "ez-preacher", name: "EZ Bar Drag Curl", equipment: ["ezbar"], muscles: ["arms"], level: 2, kind: "reps", reps: 10, met: 4.5, cue: "Drag the bar up your torso, elbows travel back." },

  /* ------------------------------ Squat rack ------------------------------ */
  { id: "rack-pull", name: "Rack Pull", equipment: ["barbell", "squatrack"], muscles: ["back", "glutes"], level: 2, kind: "reps", reps: 8, met: 7.5, cue: "Bar at knee height — drive hips through at lockout." },
  { id: "rack-front-squat", name: "Front Squat", equipment: ["barbell", "squatrack"], muscles: ["legs", "core"], level: 3, kind: "reps", reps: 8, met: 7.5, cue: "Elbows high, bar rests on the shelf of your delts." },
  { id: "rack-pin-press", name: "Pin Press", equipment: ["barbell", "squatrack"], muscles: ["shoulders", "chest"], level: 2, kind: "reps", reps: 8, met: 6.5, cue: "Dead-stop every rep from the pins." },

  /* -------------------------------- Cable --------------------------------- */
  { id: "cable-row", name: "Seated Cable Row", equipment: ["cable"], muscles: ["back", "arms"], level: 1, kind: "reps", reps: 12, met: 5.5, cue: "Chest tall, pull to the navel, squeeze." },
  { id: "cable-pulldown", name: "Lat Pulldown", equipment: ["cable"], muscles: ["back", "arms"], level: 1, kind: "reps", reps: 12, met: 5.5, cue: "Lead with the elbows, bar to the collarbone." },
  { id: "cable-pushdown", name: "Cable Triceps Pushdown", equipment: ["cable"], muscles: ["arms"], level: 1, kind: "reps", reps: 14, met: 4.5, cue: "Elbows locked at your sides, full lockout." },
  { id: "cable-curl", name: "Cable Bicep Curl", equipment: ["cable"], muscles: ["arms"], level: 1, kind: "reps", reps: 12, met: 4.5, cue: "Constant tension — no rest at the bottom." },
  { id: "cable-fly", name: "Cable Chest Fly", equipment: ["cable"], muscles: ["chest"], level: 2, kind: "reps", reps: 12, met: 5, cue: "Soft elbows, meet the handles in front of your chest." },
  { id: "cable-woodchop", name: "Cable Woodchop", equipment: ["cable"], muscles: ["core"], level: 2, kind: "reps", reps: 12, met: 5.5, uni: true, cue: "Rotate from the trunk, arms stay long." },
  { id: "cable-face-pull", name: "Cable Face Pull", equipment: ["cable"], muscles: ["shoulders", "back"], level: 1, kind: "reps", reps: 15, met: 4.5, cue: "Pull to the eyebrows, elbows high and wide." },

  /* ------------------------------- Treadmill ------------------------------ */
  { id: "tread-intervals", name: "Treadmill Intervals", equipment: ["treadmill"], muscles: ["cardio", "legs"], level: 2, kind: "time", sec: 60, met: 11, cue: "30s hard, 30s easy. Repeat till the clock dies." },
  { id: "tread-incline-walk", name: "Incline Walk", equipment: ["treadmill"], muscles: ["cardio", "legs", "glutes"], level: 1, kind: "time", sec: 90, met: 6.5, cue: "10–12% incline, no holding the rails." },
  { id: "tread-steady-run", name: "Steady Run", equipment: ["treadmill"], muscles: ["cardio"], level: 2, kind: "time", sec: 120, met: 9.8, cue: "Conversational pace — nose breathing if you can." },

  /* --------------------------------- Bike --------------------------------- */
  { id: "bike-sprints", name: "Bike Sprints", equipment: ["bike"], muscles: ["cardio", "legs"], level: 3, kind: "time", sec: 30, met: 12, cue: "20s all-out, 40s spin. Legs will scream." },
  { id: "bike-steady", name: "Steady Spin", equipment: ["bike"], muscles: ["cardio", "legs"], level: 1, kind: "time", sec: 120, met: 7, cue: "Moderate resistance, smooth 80–90 rpm." },
  { id: "bike-hill", name: "Bike Hill Climb", equipment: ["bike"], muscles: ["legs", "cardio"], level: 2, kind: "time", sec: 60, met: 9, cue: "Heavy resistance, slow grinding cadence." },

  /* -------------------------------- Rower --------------------------------- */
  { id: "row-intervals", name: "Rower Intervals", equipment: ["rower"], muscles: ["cardio", "back", "legs"], level: 2, kind: "time", sec: 60, met: 10.5, cue: "Legs, back, arms out — arms, back, legs in." },
  { id: "row-steady", name: "Steady Row", equipment: ["rower"], muscles: ["cardio", "back", "full"], level: 1, kind: "time", sec: 120, met: 7.5, cue: "Long powerful strokes, 22–24 strokes/min." },
  { id: "row-sprint", name: "250m Row Sprint", equipment: ["rower"], muscles: ["cardio", "full"], level: 3, kind: "time", sec: 50, met: 12, cue: "Rip it. Full send, then collapse (gracefully)." },

  /* ------------------------- Trap bar & specialty ------------------------ */
  { id: "trap-deadlift", name: "Trap Bar Deadlift", equipment: ["trapbar"], muscles: ["legs", "back", "glutes"], level: 2, kind: "reps", reps: 8, met: 7.5, cue: "Stand in the centre, push the floor away, chest tall." },
  { id: "trap-shrug", name: "Trap Bar Shrug", equipment: ["trapbar"], muscles: ["back", "shoulders"], level: 1, kind: "reps", reps: 15, met: 5, cue: "Shrug straight up, pause at the top." },
  { id: "trap-carry", name: "Trap Bar Farmer Carry", equipment: ["trapbar"], muscles: ["full", "core"], level: 2, kind: "time", sec: 40, met: 8, cue: "Walk tall, brace hard, small quick steps." },
  { id: "trap-jump", name: "Trap Bar Jump", equipment: ["trapbar"], muscles: ["legs", "cardio"], level: 3, kind: "reps", reps: 6, met: 9, cue: "Light load only — explode up, land soft." },

  /* ---------------------------- Mace & clubs ----------------------------- */
  { id: "mace-360", name: "Steel Mace 360", equipment: ["macebell"], muscles: ["shoulders", "core"], level: 3, kind: "reps", reps: 8, met: 7, uni: true, cue: "Let it swing behind the head, control the catch." },
  { id: "mace-1020", name: "Mace 10-to-2", equipment: ["macebell"], muscles: ["shoulders", "core"], level: 2, kind: "reps", reps: 10, met: 6.5, cue: "Small pendulum swings, ribs locked down." },
  { id: "mace-swing", name: "Mace Front Swing", equipment: ["macebell"], muscles: ["full", "core"], level: 2, kind: "reps", reps: 12, met: 7.5, cue: "Hinge and swing, grip relaxed but secure." },
  { id: "club-swing", name: "Clubbell Swing", equipment: ["clubbell"], muscles: ["shoulders", "arms"], level: 2, kind: "reps", reps: 12, met: 6.5, cue: "Lead with the hips, let the club arc." },
  { id: "club-mill", name: "Clubbell Mill", equipment: ["clubbell"], muscles: ["shoulders", "core"], level: 3, kind: "reps", reps: 8, met: 6.5, uni: true, cue: "Slow circles around the body, stay tall." },
  { id: "indian-club-circles", name: "Indian Club Circles", equipment: ["indianclub"], muscles: ["shoulders"], level: 1, kind: "time", sec: 45, met: 3.5, cue: "Light clubs, smooth loops — pure shoulder health." },

  /* ----------------------------- Power bag ------------------------------- */
  { id: "powerbag-clean", name: "Power Bag Clean", equipment: ["powerbag"], muscles: ["full", "legs"], level: 2, kind: "reps", reps: 10, met: 8.5, cue: "Hinge, pull hard, catch it on the chest." },
  { id: "powerbag-lunge", name: "Power Bag Lunge", equipment: ["powerbag"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 10, met: 7, uni: true, cue: "Bag on the shoulders, torso upright." },
  { id: "powerbag-thruster", name: "Power Bag Thruster", equipment: ["powerbag"], muscles: ["full", "shoulders", "cardio"], level: 3, kind: "reps", reps: 10, met: 9.5, cue: "Squat deep, drive the bag overhead in one move." },
  { id: "slam-ball-slam", name: "Slam Ball Slam", equipment: ["slamball"], muscles: ["full", "cardio", "core"], level: 2, kind: "reps", reps: 15, met: 9.5, cue: "Overhead, then smash it down with everything." },
  { id: "slam-ball-twist", name: "Slam Ball Rotational Throw", equipment: ["slamball"], muscles: ["core"], level: 2, kind: "reps", reps: 12, met: 7.5, uni: true, cue: "Pivot the back foot, throw from the hips." },

  /* --------------------------- Incline bench ----------------------------- */
  { id: "incline-db-press", name: "Incline Dumbbell Press", equipment: ["dumbbells", "inclinebench"], muscles: ["chest", "shoulders"], level: 2, kind: "reps", reps: 10, met: 6, cue: "30–45° bench, press up and slightly together." },
  { id: "incline-bb-press", name: "Incline Barbell Press", equipment: ["barbell", "inclinebench"], muscles: ["chest", "shoulders"], level: 2, kind: "reps", reps: 8, met: 6.5, cue: "Touch the upper chest, drive through the heels." },
  { id: "incline-db-fly", name: "Incline Dumbbell Fly", equipment: ["dumbbells", "inclinebench"], muscles: ["chest"], level: 2, kind: "reps", reps: 12, met: 5, cue: "Soft elbows, big stretch at the bottom." },
  { id: "decline-db-press", name: "Decline Dumbbell Press", equipment: ["dumbbells", "inclinebench"], muscles: ["chest"], level: 2, kind: "reps", reps: 10, met: 6, cue: "Hits the lower chest — control the descent." },
  { id: "incline-row", name: "Chest-Supported Incline Row", equipment: ["dumbbells", "inclinebench"], muscles: ["back", "arms"], level: 1, kind: "reps", reps: 12, met: 5.5, cue: "Chest on the bench, row to the hips, no swinging." },
  { id: "preacher-curl", name: "Preacher Curl", equipment: ["preachercurl"], muscles: ["arms"], level: 1, kind: "reps", reps: 12, met: 4.5, cue: "Armpits on the pad, full stretch at the bottom." },

  /* ------------------------------ Machines ------------------------------- */
  { id: "smith-squat", name: "Smith Machine Squat", equipment: ["smithmachine"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 12, met: 6.5, cue: "Feet slightly forward, control the fixed path." },
  { id: "smith-press", name: "Smith Machine Press", equipment: ["smithmachine"], muscles: ["chest", "shoulders"], level: 1, kind: "reps", reps: 10, met: 6, cue: "Great for pushing close to failure safely." },
  { id: "smith-row", name: "Smith Machine Row", equipment: ["smithmachine"], muscles: ["back"], level: 1, kind: "reps", reps: 12, met: 6, cue: "Hinge 45°, pull the bar to your waist." },
  { id: "leg-press", name: "Leg Press", equipment: ["legpress"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 12, met: 6.5, cue: "Feet mid-platform, never lock the knees hard." },
  { id: "leg-press-calf", name: "Leg Press Calf Raise", equipment: ["legpress"], muscles: ["legs"], level: 1, kind: "reps", reps: 18, met: 4.5, cue: "Toes on the edge, full stretch then full squeeze." },
  { id: "lat-pulldown-machine", name: "Lat Pulldown (machine)", equipment: ["latpulldown"], muscles: ["back", "arms"], level: 1, kind: "reps", reps: 12, met: 5.5, cue: "Chest up, drive the elbows down to your ribs." },
  { id: "leg-extension", name: "Leg Extension", equipment: ["legextension"], muscles: ["legs"], level: 1, kind: "reps", reps: 15, met: 4.5, cue: "Pause and squeeze at full extension." },
  { id: "leg-curl", name: "Lying Leg Curl", equipment: ["legextension"], muscles: ["legs"], level: 1, kind: "reps", reps: 12, met: 4.5, cue: "Hips pressed down, curl heels to glutes." },
  { id: "pec-deck", name: "Pec Deck Fly", equipment: ["pecdeck"], muscles: ["chest"], level: 1, kind: "reps", reps: 14, met: 4.5, cue: "Squeeze for a second where the handles meet." },
  { id: "back-extension", name: "Back Extension", equipment: ["hyperextension"], muscles: ["back", "glutes"], level: 1, kind: "reps", reps: 15, met: 4.5, cue: "Rise to a straight line — don't hyperextend.", load: "added", bwFactor: 0.6 },
  { id: "ghd-raise", name: "Glute-Ham Raise", equipment: ["gluteham"], muscles: ["legs", "glutes"], level: 3, kind: "reps", reps: 8, met: 6.5, cue: "Lower slow, pull yourself back with hamstrings.", load: "added", bwFactor: 0.7 },
  { id: "ghd-situp", name: "GHD Sit-Up", equipment: ["gluteham"], muscles: ["core"], level: 3, kind: "reps", reps: 12, met: 6, cue: "Controlled range only — this one humbles people.", load: "added", bwFactor: 0.5 },

  /* ---------------------------- Cardio machines -------------------------- */
  { id: "elliptical-steady", name: "Elliptical Steady", equipment: ["elliptical"], muscles: ["cardio"], level: 1, kind: "time", sec: 120, met: 6.5, cue: "Low impact — push and pull the handles too." },
  { id: "elliptical-intervals", name: "Elliptical Intervals", equipment: ["elliptical"], muscles: ["cardio"], level: 2, kind: "time", sec: 60, met: 9, cue: "Crank resistance for 30s, recover 30s." },
  { id: "stair-climb", name: "Stair Climber", equipment: ["stairclimber"], muscles: ["legs", "glutes", "cardio"], level: 2, kind: "time", sec: 120, met: 9, cue: "Stand tall, don't lean on the rails." },
  { id: "airbike-sprint", name: "Air Bike Sprint", equipment: ["airbike"], muscles: ["cardio", "full"], level: 3, kind: "time", sec: 20, met: 13, cue: "10–20s all out. The fan does not forgive." },
  { id: "airbike-steady", name: "Air Bike Steady", equipment: ["airbike"], muscles: ["cardio", "full"], level: 1, kind: "time", sec: 120, met: 7.5, cue: "Smooth arms and legs, steady breathing." },
  { id: "skierg-intervals", name: "Ski Erg Intervals", equipment: ["skierg"], muscles: ["back", "core", "cardio"], level: 2, kind: "time", sec: 45, met: 10, cue: "Hinge and drive down through the core." },
  { id: "sled-push", name: "Sled Push", equipment: ["sled"], muscles: ["legs", "full", "cardio"], level: 2, kind: "time", sec: 30, met: 10.5, cue: "Low body angle, relentless short steps." },
  { id: "sled-drag", name: "Sled Backward Drag", equipment: ["sled"], muscles: ["legs", "cardio"], level: 2, kind: "time", sec: 30, met: 9.5, cue: "Lean back, stay low — brilliant for knees." },

  /* ----------------------- Agility, speed & boxing ----------------------- */
  { id: "ladder-drills", name: "Agility Ladder Drills", equipment: ["agilityladder"], muscles: ["cardio", "legs"], level: 1, kind: "time", sec: 40, met: 8, cue: "Quick feet, eyes up, light on the toes." },
  { id: "ladder-lateral", name: "Ladder Lateral Shuffle", equipment: ["agilityladder"], muscles: ["legs", "cardio"], level: 2, kind: "time", sec: 30, met: 8.5, cue: "Hips low, never cross the feet." },
  { id: "cone-shuttle", name: "Cone Shuttle Run", equipment: ["cones"], muscles: ["cardio", "legs"], level: 2, kind: "time", sec: 30, met: 9.5, cue: "Plant hard, turn fast, accelerate out." },
  { id: "cone-tdrill", name: "T-Drill", equipment: ["cones"], muscles: ["cardio", "legs"], level: 2, kind: "time", sec: 30, met: 9.5, cue: "Sprint, shuffle, backpedal — stay square." },
  { id: "speedbag-rhythm", name: "Speed Bag Rhythm", equipment: ["speedbag"], muscles: ["shoulders", "arms", "cardio"], level: 2, kind: "time", sec: 60, met: 6.5, cue: "Elbows high, small circles, find the rhythm." },

  /* --------------------------- Sliders & balance ------------------------- */
  { id: "slider-mountain", name: "Slider Mountain Climbers", equipment: ["sliders"], muscles: ["core", "cardio"], level: 2, kind: "time", sec: 30, met: 8, cue: "Smooth glides, hips dead level." },
  { id: "slider-pike", name: "Slider Pike", equipment: ["sliders"], muscles: ["core", "shoulders"], level: 3, kind: "reps", reps: 10, met: 6.5, cue: "Hips to the ceiling, legs straight." },
  { id: "slider-ham-curl", name: "Slider Hamstring Curl", equipment: ["sliders"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 12, met: 5.5, cue: "Bridge up, slide heels out and back in." },
  { id: "slider-lunge", name: "Slider Reverse Lunge", equipment: ["sliders"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 12, met: 6, uni: true, cue: "Slide back under control, drive through the front heel.", load: "added", bwFactor: 0.85 },
  { id: "balance-board-hold", name: "Balance Board Hold", equipment: ["balanceboard"], muscles: ["legs", "core"], level: 1, kind: "time", sec: 45, met: 3.5, cue: "Soft knees, quiet feet, eyes forward." },
  { id: "bosu-squat", name: "Bosu Squat", equipment: ["bosu"], muscles: ["legs", "core"], level: 2, kind: "reps", reps: 12, met: 5.5, cue: "Control the wobble — slow is the point." },
  { id: "bosu-plank", name: "Bosu Plank", equipment: ["bosu"], muscles: ["core"], level: 2, kind: "time", sec: 40, met: 4.5, cue: "Elbows on the dome, brace everything." },

  /* -------------------------- Grip, neck & forearms ---------------------- */
  { id: "wrist-roller", name: "Wrist Roller", equipment: ["wristroller"], muscles: ["arms"], level: 2, kind: "reps", reps: 3, met: 4.5, cue: "Roll all the way up and slowly back down. Forearms on fire." },
  { id: "gripper-squeeze", name: "Hand Gripper Squeeze", equipment: ["grippers"], muscles: ["arms"], level: 1, kind: "reps", reps: 12, met: 3, uni: true, cue: "Full close, full open, no half reps." },
  { id: "neck-harness-ext", name: "Neck Harness Extension", equipment: ["neckharness"], muscles: ["full"], level: 2, kind: "reps", reps: 15, met: 4, cue: "Very light load, slow controlled range only." },
  { id: "pushup-bar-deep", name: "Deep Push-Up (bars)", equipment: ["pushupbars"], muscles: ["chest", "arms"], level: 2, kind: "reps", reps: 12, met: 6.5, cue: "Drop below the hands for the extra stretch.", load: "added", bwFactor: 0.64 },

  /* ------------------------ Recovery & mobility tools -------------------- */
  { id: "massage-gun-session", name: "Massage Gun Flush", equipment: ["massagegun"], muscles: ["full"], level: 1, kind: "time", sec: 90, met: 2, cue: "60–90s per sore muscle, never on bone or joints." },
  { id: "lacrosse-release", name: "Lacrosse Ball Release", equipment: ["lacrosseball"], muscles: ["back", "glutes"], level: 1, kind: "time", sec: 60, met: 2.2, uni: true, cue: "Find the knot, breathe, let it melt." },
  { id: "strap-hamstring", name: "Strap Hamstring Stretch", equipment: ["stretchstrap"], muscles: ["legs"], level: 1, kind: "time", sec: 45, met: 2.3, uni: true, cue: "Leg straight, pull gently, relax the jaw." },
  { id: "strap-shoulder", name: "Strap Shoulder Opener", equipment: ["stretchstrap"], muscles: ["shoulders", "chest"], level: 1, kind: "time", sec: 45, met: 2.3, cue: "Wide grip, sweep overhead and back slowly." },
  { id: "block-pigeon", name: "Supported Pigeon Pose", equipment: ["yogablock"], muscles: ["glutes", "legs"], level: 1, kind: "time", sec: 60, met: 2.5, uni: true, cue: "Block under the hip, sink and breathe." },
  { id: "block-bridge", name: "Supported Bridge", equipment: ["yogablock"], muscles: ["back", "glutes"], level: 1, kind: "time", sec: 60, met: 2.5, cue: "Block under the sacrum, fully let go." },

  /* ------------------------ Bodyweight · wave 2 ------------------------- */
  { id: "diamond-pushup", name: "Diamond Push-Up", equipment: ["bodyweight"], muscles: ["arms", "chest"], level: 2, kind: "reps", reps: 10, met: 6, cue: "Hands form a triangle — all triceps.", load: "added", bwFactor: 0.64 },
  { id: "wide-pushup", name: "Wide Push-Up", equipment: ["bodyweight"], muscles: ["chest"], level: 1, kind: "reps", reps: 12, met: 6, cue: "Hands wider than shoulders, chest leads.", load: "added", bwFactor: 0.64 },
  { id: "archer-pushup", name: "Archer Push-Up", equipment: ["bodyweight"], muscles: ["chest", "arms"], level: 3, kind: "reps", reps: 6, met: 7, uni: true, cue: "Shift to one arm, the other stays straight.", load: "added", bwFactor: 0.75 },
  { id: "hindu-pushup", name: "Hindu Push-Up", equipment: ["bodyweight"], muscles: ["chest", "shoulders"], level: 2, kind: "reps", reps: 10, met: 6.5, cue: "Dive forward and sweep up — one flowing arc." },
  { id: "spiderman-pushup", name: "Spiderman Push-Up", equipment: ["bodyweight"], muscles: ["chest", "core"], level: 3, kind: "reps", reps: 8, met: 7, uni: true, cue: "Knee to elbow as you lower." },
  { id: "staggered-pushup", name: "Staggered Push-Up", equipment: ["bodyweight"], muscles: ["chest", "arms"], level: 2, kind: "reps", reps: 10, met: 6, uni: true, cue: "One hand forward, one back — uneven load." },
  { id: "cossack-squat", name: "Cossack Squat", equipment: ["bodyweight"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 8, met: 6, uni: true, cue: "Sink to one side, other leg straight, heel down." },
  { id: "shrimp-squat", name: "Shrimp Squat", equipment: ["bodyweight"], muscles: ["legs"], level: 3, kind: "reps", reps: 5, met: 7, uni: true, cue: "Hold the rear ankle, knee taps the floor." },
  { id: "sissy-squat", name: "Sissy Squat", equipment: ["bodyweight"], muscles: ["legs"], level: 3, kind: "reps", reps: 10, met: 5.5, cue: "Knees travel forward, hips stay extended." },
  { id: "nordic-curl", name: "Nordic Hamstring Curl", equipment: ["bodyweight"], muscles: ["legs"], level: 3, kind: "reps", reps: 5, met: 6.5, cue: "Anchor the feet, lower as slowly as you can." },
  { id: "single-leg-rdl", name: "Single-Leg RDL (bodyweight)", equipment: ["bodyweight"], muscles: ["glutes", "legs"], level: 2, kind: "reps", reps: 10, met: 5, uni: true, cue: "Hips square, reach the free leg straight back." },
  { id: "single-leg-bridge", name: "Single-Leg Glute Bridge", equipment: ["bodyweight"], muscles: ["glutes"], level: 2, kind: "reps", reps: 12, met: 5, uni: true, cue: "One foot planted, drive the hip to the ceiling.", load: "added", bwFactor: 0.4 },
  { id: "frog-pump", name: "Frog Pump", equipment: ["bodyweight"], muscles: ["glutes"], level: 1, kind: "reps", reps: 20, met: 4.5, cue: "Soles together, knees wide, pulse the hips up." },
  { id: "wall-walk", name: "Wall Walk", equipment: ["bodyweight"], muscles: ["shoulders", "core"], level: 3, kind: "reps", reps: 4, met: 8, cue: "Walk the feet up the wall toward a handstand." },
  { id: "crab-walk", name: "Crab Walk", equipment: ["bodyweight"], muscles: ["arms", "core"], level: 1, kind: "time", sec: 30, met: 6, cue: "Hips high, move hand and opposite foot." },
  { id: "duck-walk", name: "Duck Walk", equipment: ["bodyweight"], muscles: ["legs"], level: 2, kind: "time", sec: 30, met: 7, cue: "Stay in a deep squat and walk forward." },
  { id: "broad-jump", name: "Broad Jump", equipment: ["bodyweight"], muscles: ["legs", "cardio"], level: 2, kind: "reps", reps: 8, met: 8.5, cue: "Swing the arms, jump far, land soft." },
  { id: "tuck-jump", name: "Tuck Jump", equipment: ["bodyweight"], muscles: ["legs", "cardio"], level: 3, kind: "reps", reps: 10, met: 9.5, cue: "Knees to chest at the top of every jump." },
  { id: "skater-jump", name: "Skater Jump", equipment: ["bodyweight"], muscles: ["legs", "cardio"], level: 2, kind: "time", sec: 30, met: 8.5, cue: "Bound side to side, land on one leg." },
  { id: "star-jump", name: "Star Jump", equipment: ["bodyweight"], muscles: ["cardio", "full"], level: 1, kind: "time", sec: 30, met: 8, cue: "Explode out into a star shape." },
  { id: "squat-thrust", name: "Squat Thrust", equipment: ["bodyweight"], muscles: ["cardio", "full"], level: 2, kind: "time", sec: 30, met: 8.5, cue: "Burpee without the push-up — keep it fast." },
  { id: "dead-bug", name: "Dead Bug", equipment: ["bodyweight"], muscles: ["core"], level: 1, kind: "reps", reps: 12, met: 4, uni: true, cue: "Opposite arm and leg, low back glued down." },
  { id: "bird-dog", name: "Bird Dog", equipment: ["bodyweight"], muscles: ["core", "back"], level: 1, kind: "reps", reps: 12, met: 3.5, uni: true, cue: "Reach long, no wobble through the hips." },
  { id: "hollow-rock", name: "Hollow Rock", equipment: ["bodyweight"], muscles: ["core"], level: 2, kind: "time", sec: 30, met: 5, cue: "Hold the hollow shape and rock from it." },
  { id: "v-up", name: "V-Up", equipment: ["bodyweight"], muscles: ["core"], level: 2, kind: "reps", reps: 12, met: 5.5, cue: "Hands and feet meet above the hips." },
  { id: "russian-twist-bw", name: "Russian Twist", equipment: ["bodyweight"], muscles: ["core"], level: 1, kind: "reps", reps: 20, met: 4.5, cue: "Heels up, rotate from the ribs." },
  { id: "toe-touch-crunch", name: "Toe Touch Crunch", equipment: ["bodyweight"], muscles: ["core"], level: 1, kind: "reps", reps: 15, met: 4, cue: "Legs vertical, reach for the toes." },
  { id: "reverse-crunch", name: "Reverse Crunch", equipment: ["bodyweight"], muscles: ["core"], level: 1, kind: "reps", reps: 15, met: 4.5, cue: "Curl the hips off the floor, not just the legs." },
  { id: "plank-up-down", name: "Plank Up-Down", equipment: ["bodyweight"], muscles: ["core", "arms"], level: 2, kind: "reps", reps: 12, met: 6, cue: "Elbow to hand and back, hips still." },
  { id: "copenhagen-plank", name: "Copenhagen Plank", equipment: ["bench"], muscles: ["core", "legs"], level: 3, kind: "time", sec: 20, met: 5, uni: true, cue: "Top leg on the bench — brutal for the groin." },
  { id: "wall-angel", name: "Wall Angel", equipment: ["bodyweight"], muscles: ["shoulders", "back"], level: 1, kind: "reps", reps: 12, met: 3, cue: "Back flat on the wall, slide the arms up." },
  { id: "prone-ytw", name: "Prone Y-T-W Raise", equipment: ["mat"], muscles: ["back", "shoulders"], level: 1, kind: "reps", reps: 10, met: 3.5, cue: "Face down, trace Y then T then W." },
  { id: "neck-isometric", name: "Neck Isometric Hold", equipment: ["bodyweight"], muscles: ["full"], level: 1, kind: "time", sec: 20, met: 2.5, uni: true, cue: "Light hand pressure, no movement at all." },
  { id: "calf-raise-single", name: "Single-Leg Calf Raise", equipment: ["bodyweight"], muscles: ["legs"], level: 2, kind: "reps", reps: 15, met: 4, uni: true, cue: "Full stretch at the bottom, pause on top.", load: "added", bwFactor: 0.85 },
  { id: "tibialis-raise", name: "Tibialis Raise", equipment: ["bodyweight"], muscles: ["legs"], level: 1, kind: "reps", reps: 20, met: 3, cue: "Heels down, lift the toes — protects the knees." },
  { id: "jefferson-curl", name: "Jefferson Curl", equipment: ["dumbbells"], muscles: ["back", "legs"], level: 3, kind: "reps", reps: 6, met: 4, cue: "Very light weight. Roll down one vertebra at a time." },

  /* -------------------------- Dumbbells · wave 2 ------------------------ */
  { id: "db-arnold-press", name: "Arnold Press", equipment: ["dumbbells"], muscles: ["shoulders"], level: 2, kind: "reps", reps: 10, met: 6, cue: "Rotate palms out as you press overhead." },
  { id: "db-upright-row", name: "Dumbbell Upright Row", equipment: ["dumbbells"], muscles: ["shoulders", "back"], level: 2, kind: "reps", reps: 12, met: 5, cue: "Elbows lead, stop at chest height." },
  { id: "db-rear-delt-fly", name: "Rear Delt Fly", equipment: ["dumbbells"], muscles: ["shoulders", "back"], level: 1, kind: "reps", reps: 15, met: 4.5, cue: "Hinge over, pinkies up, squeeze the rear delts." },
  { id: "db-shrug", name: "Dumbbell Shrug", equipment: ["dumbbells"], muscles: ["back", "shoulders"], level: 1, kind: "reps", reps: 15, met: 4.5, cue: "Straight up and down — no rolling." },
  { id: "db-pullover", name: "Dumbbell Pullover", equipment: ["dumbbells", "bench"], muscles: ["chest", "back"], level: 2, kind: "reps", reps: 12, met: 5.5, cue: "One bell, arc it behind your head and back." },
  { id: "db-concentration-curl", name: "Concentration Curl", equipment: ["dumbbells", "bench"], muscles: ["arms"], level: 1, kind: "reps", reps: 12, met: 4, uni: true, cue: "Elbow braced on the thigh, squeeze hard." },
  { id: "db-incline-curl", name: "Incline Dumbbell Curl", equipment: ["dumbbells", "inclinebench"], muscles: ["arms"], level: 2, kind: "reps", reps: 12, met: 4.5, cue: "Arms hang back — maximum bicep stretch." },
  { id: "db-kickback", name: "Triceps Kickback", equipment: ["dumbbells"], muscles: ["arms"], level: 1, kind: "reps", reps: 14, met: 4, uni: true, cue: "Upper arm locked parallel, extend fully." },
  { id: "db-skullcrusher", name: "Dumbbell Skullcrusher", equipment: ["dumbbells", "bench"], muscles: ["arms"], level: 2, kind: "reps", reps: 12, met: 5, cue: "Lower beside the ears, elbows pointing up." },
  { id: "db-step-up", name: "Weighted Step-Up", equipment: ["dumbbells", "bench"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 10, met: 7, uni: true, cue: "Drive through the heel, no push off the back foot." },
  { id: "db-bulgarian", name: "Dumbbell Bulgarian Split Squat", equipment: ["dumbbells", "bench"], muscles: ["legs", "glutes"], level: 3, kind: "reps", reps: 10, met: 7, uni: true, cue: "Rear foot elevated, torso tall." },
  { id: "db-sumo-squat", name: "Dumbbell Sumo Squat", equipment: ["dumbbells"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 15, met: 6, cue: "Wide stance, toes out, one bell between the legs." },
  { id: "db-single-rdl", name: "Single-Leg Dumbbell RDL", equipment: ["dumbbells"], muscles: ["glutes", "legs"], level: 3, kind: "reps", reps: 10, met: 6, uni: true, cue: "Slow and balanced — hips stay square." },
  { id: "db-snatch", name: "Dumbbell Snatch", equipment: ["dumbbells"], muscles: ["full", "cardio"], level: 3, kind: "reps", reps: 8, met: 9.5, uni: true, cue: "Floor to overhead in one explosive pull." },
  { id: "db-clean", name: "Dumbbell Clean", equipment: ["dumbbells"], muscles: ["full", "legs"], level: 2, kind: "reps", reps: 10, met: 8.5, cue: "Hinge, pull, catch at the shoulders." },
  { id: "db-man-maker", name: "Man Maker", equipment: ["dumbbells"], muscles: ["full", "cardio"], level: 3, kind: "reps", reps: 6, met: 10, cue: "Row, push-up, clean, press. The full package." },
  { id: "db-devils-press", name: "Devil's Press", equipment: ["dumbbells"], muscles: ["full", "cardio"], level: 3, kind: "reps", reps: 8, met: 10.5, cue: "Burpee into an overhead swing with both bells." },
  { id: "db-suitcase-carry", name: "Suitcase Carry", equipment: ["dumbbells"], muscles: ["core", "full"], level: 2, kind: "time", sec: 40, met: 7, uni: true, cue: "One bell only — resist leaning sideways." },
  { id: "db-overhead-carry", name: "Overhead Carry", equipment: ["dumbbells"], muscles: ["shoulders", "core"], level: 3, kind: "time", sec: 30, met: 7, uni: true, cue: "Arm locked out, ribs down, walk tall." },

  /* --------------------------- Barbell · wave 2 ------------------------- */
  { id: "bb-pause-squat", name: "Pause Squat", equipment: ["barbell"], muscles: ["legs", "core"], level: 3, kind: "reps", reps: 6, met: 7, cue: "Three seconds at the bottom, no bounce." },
  { id: "bb-box-squat", name: "Box Squat", equipment: ["barbell", "bench"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 8, met: 7, cue: "Sit back to the box, stay tight, drive up." },
  { id: "bb-good-morning", name: "Good Morning", equipment: ["barbell"], muscles: ["back", "glutes", "legs"], level: 3, kind: "reps", reps: 10, met: 6, cue: "Light bar, hinge with a flat back." },
  { id: "bb-rdl", name: "Barbell Romanian Deadlift", equipment: ["barbell"], muscles: ["glutes", "legs", "back"], level: 2, kind: "reps", reps: 10, met: 7, cue: "Bar hugs the thighs, feel the hamstrings load." },
  { id: "bb-sumo-deadlift", name: "Sumo Deadlift", equipment: ["barbell"], muscles: ["legs", "glutes", "back"], level: 3, kind: "reps", reps: 6, met: 8, cue: "Wide stance, knees out, chest up." },
  { id: "bb-deficit-deadlift", name: "Deficit Deadlift", equipment: ["barbell", "plyobox"], muscles: ["back", "legs"], level: 3, kind: "reps", reps: 6, met: 8, cue: "Stand on a plate — longer range, lighter load." },
  { id: "bb-floor-press", name: "Barbell Floor Press", equipment: ["barbell"], muscles: ["chest", "arms"], level: 2, kind: "reps", reps: 8, met: 6, cue: "Triceps touch, press from a dead stop." },
  { id: "bb-close-grip-bench", name: "Close-Grip Bench Press", equipment: ["barbell", "bench"], muscles: ["arms", "chest"], level: 2, kind: "reps", reps: 10, met: 6, cue: "Shoulder-width grip, elbows tucked." },
  { id: "bb-push-press", name: "Push Press", equipment: ["barbell"], muscles: ["shoulders", "legs"], level: 3, kind: "reps", reps: 6, met: 8, cue: "Dip, drive with the legs, punch overhead." },
  { id: "bb-landmine-press", name: "Landmine Press", equipment: ["barbell"], muscles: ["shoulders", "chest"], level: 2, kind: "reps", reps: 10, met: 6, uni: true, cue: "Bar in a corner — press up and slightly across." },
  { id: "bb-pendlay-row", name: "Pendlay Row", equipment: ["barbell"], muscles: ["back"], level: 3, kind: "reps", reps: 8, met: 7, cue: "Bar resets on the floor between every rep." },
  { id: "bb-hang-clean", name: "Hang Clean", equipment: ["barbell"], muscles: ["full", "legs"], level: 3, kind: "reps", reps: 6, met: 9, cue: "Explosive hip snap, catch in a quarter squat." },
  { id: "bb-thruster", name: "Barbell Thruster", equipment: ["barbell"], muscles: ["full", "cardio"], level: 3, kind: "reps", reps: 10, met: 9.5, cue: "Front squat straight into an overhead press." },
  { id: "bb-overhead-squat", name: "Overhead Squat", equipment: ["barbell"], muscles: ["legs", "shoulders", "core"], level: 3, kind: "reps", reps: 6, met: 7.5, cue: "Bar locked overhead the whole way down." },
  { id: "bb-calf-raise", name: "Barbell Calf Raise", equipment: ["barbell"], muscles: ["legs"], level: 1, kind: "reps", reps: 18, met: 4.5, cue: "Slow up, slower down, full stretch." },
  { id: "bb-wrist-curl", name: "Barbell Wrist Curl", equipment: ["barbell", "bench"], muscles: ["arms"], level: 1, kind: "reps", reps: 18, met: 3.5, cue: "Forearms on the bench, only the wrists move." },

  /* ------------------------- Kettlebell · wave 2 ------------------------ */
  { id: "kb-single-swing", name: "Single-Arm Kettlebell Swing", equipment: ["kettlebell"], muscles: ["glutes", "cardio"], level: 2, kind: "reps", reps: 12, met: 9, uni: true, cue: "Hips do the work, shoulder stays packed." },
  { id: "kb-snatch", name: "Kettlebell Snatch", equipment: ["kettlebell"], muscles: ["full", "cardio"], level: 3, kind: "reps", reps: 8, met: 10, uni: true, cue: "Swing high and punch through at the top." },
  { id: "kb-high-pull", name: "Kettlebell High Pull", equipment: ["kettlebell"], muscles: ["back", "shoulders"], level: 2, kind: "reps", reps: 10, met: 8, cue: "Swing to chest height and pull the elbow back." },
  { id: "kb-front-rack-squat", name: "Front Rack Squat", equipment: ["kettlebell"], muscles: ["legs", "core"], level: 2, kind: "reps", reps: 10, met: 6.5, cue: "Bells in the rack position, elbows tight." },
  { id: "kb-suitcase-deadlift", name: "Kettlebell Suitcase Deadlift", equipment: ["kettlebell"], muscles: ["back", "legs"], level: 1, kind: "reps", reps: 12, met: 6, uni: true, cue: "One bell beside the foot, stay square." },
  { id: "kb-around-world", name: "Kettlebell Around the World", equipment: ["kettlebell"], muscles: ["core", "shoulders"], level: 1, kind: "reps", reps: 12, met: 4.5, cue: "Pass the bell around the waist, hips still." },
  { id: "kb-figure-eight", name: "Kettlebell Figure Eight", equipment: ["kettlebell"], muscles: ["core", "legs"], level: 2, kind: "time", sec: 40, met: 7, cue: "Weave the bell through your legs in a figure eight." },
  { id: "kb-goblet-curl", name: "Kettlebell Goblet Curl", equipment: ["kettlebell"], muscles: ["arms"], level: 1, kind: "reps", reps: 12, met: 4, cue: "Horns of the bell, curl to the chin." },

  /* ---------------------------- Bands · wave 2 -------------------------- */
  { id: "band-lateral-walk", name: "Banded Lateral Walk", equipment: ["bands"], muscles: ["glutes"], level: 1, kind: "time", sec: 40, met: 5, cue: "Band above the knees, stay low, small steps." },
  { id: "band-monster-walk", name: "Monster Walk", equipment: ["bands"], muscles: ["glutes", "legs"], level: 1, kind: "time", sec: 40, met: 5.5, cue: "Walk diagonally forward against the band." },
  { id: "band-clamshell", name: "Banded Clamshell", equipment: ["bands"], muscles: ["glutes"], level: 1, kind: "reps", reps: 18, met: 4, uni: true, cue: "Heels together, open the top knee." },
  { id: "band-kickback", name: "Banded Glute Kickback", equipment: ["bands"], muscles: ["glutes"], level: 1, kind: "reps", reps: 15, met: 4.5, uni: true, cue: "Drive the heel straight back, squeeze." },
  { id: "band-good-morning", name: "Banded Good Morning", equipment: ["bands"], muscles: ["glutes", "back"], level: 1, kind: "reps", reps: 15, met: 5, cue: "Band on the shoulders, hinge with a flat back." },
  { id: "band-overhead-press", name: "Banded Overhead Press", equipment: ["bands"], muscles: ["shoulders"], level: 1, kind: "reps", reps: 14, met: 5, cue: "Stand on the band, press to lockout." },
  { id: "band-lat-pulldown", name: "Banded Lat Pulldown", equipment: ["bands", "pullupbar"], muscles: ["back"], level: 1, kind: "reps", reps: 14, met: 5, cue: "Anchor high, pull the elbows to your ribs." },
  { id: "band-tricep-overhead", name: "Banded Overhead Extension", equipment: ["bands"], muscles: ["arms"], level: 1, kind: "reps", reps: 15, met: 4, cue: "Band behind you, extend fully overhead." },
  { id: "band-chest-fly", name: "Banded Chest Fly", equipment: ["bands"], muscles: ["chest"], level: 1, kind: "reps", reps: 15, met: 4.5, cue: "Wide arc, meet the hands in front." },
  { id: "band-woodchop", name: "Banded Woodchop", equipment: ["bands"], muscles: ["core"], level: 2, kind: "reps", reps: 12, met: 5.5, uni: true, cue: "High to low, rotate through the trunk." },
  { id: "band-deadlift", name: "Banded Deadlift", equipment: ["bands"], muscles: ["back", "glutes", "legs"], level: 1, kind: "reps", reps: 15, met: 5.5, cue: "Stand on the band, drive the floor away." },

  /* ----------------------- Machines & cable · wave 2 -------------------- */
  { id: "cable-upright-row", name: "Cable Upright Row", equipment: ["cable"], muscles: ["shoulders"], level: 1, kind: "reps", reps: 14, met: 4.5, cue: "Elbows high, smooth cable tension." },
  { id: "cable-lateral-raise", name: "Cable Lateral Raise", equipment: ["cable"], muscles: ["shoulders"], level: 2, kind: "reps", reps: 14, met: 4.5, uni: true, cue: "Constant tension through the full arc." },
  { id: "cable-pull-through", name: "Cable Pull-Through", equipment: ["cable"], muscles: ["glutes", "back"], level: 1, kind: "reps", reps: 15, met: 5.5, cue: "Hinge away, snap the hips forward." },
  { id: "cable-kickback", name: "Cable Glute Kickback", equipment: ["cable"], muscles: ["glutes"], level: 1, kind: "reps", reps: 15, met: 5, uni: true, cue: "Ankle strap, kick back and squeeze." },
  { id: "cable-crunch", name: "Cable Crunch", equipment: ["cable"], muscles: ["core"], level: 2, kind: "reps", reps: 15, met: 5, cue: "Kneel and crunch the ribs toward the hips." },
  { id: "cable-reverse-fly", name: "Cable Reverse Fly", equipment: ["cable"], muscles: ["shoulders", "back"], level: 2, kind: "reps", reps: 14, met: 4.5, cue: "Cross the cables, open wide." },
  { id: "cable-hammer-curl", name: "Cable Rope Hammer Curl", equipment: ["cable"], muscles: ["arms"], level: 1, kind: "reps", reps: 14, met: 4.5, cue: "Neutral grip, elbows pinned." },
  { id: "machine-chest-press", name: "Machine Chest Press", equipment: ["pecdeck"], muscles: ["chest", "arms"], level: 1, kind: "reps", reps: 12, met: 5.5, cue: "Controlled range, full squeeze." },
  { id: "hack-squat", name: "Hack Squat (machine)", equipment: ["legpress"], muscles: ["legs"], level: 2, kind: "reps", reps: 12, met: 6.5, cue: "Feet high for glutes, low for quads." },
  { id: "smith-calf-raise", name: "Smith Machine Calf Raise", equipment: ["smithmachine"], muscles: ["legs"], level: 1, kind: "reps", reps: 18, met: 4.5, cue: "Big stretch at the bottom of every rep." },
  { id: "smith-shrug", name: "Smith Machine Shrug", equipment: ["smithmachine"], muscles: ["back"], level: 1, kind: "reps", reps: 15, met: 4.5, cue: "Hold the top for a full second." },
  { id: "smith-split-squat", name: "Smith Split Squat", equipment: ["smithmachine"], muscles: ["legs", "glutes"], level: 2, kind: "reps", reps: 10, met: 6.5, uni: true, cue: "The fixed path lets you really push the back leg." },
  { id: "assisted-pullup", name: "Assisted Pull-Up (machine)", equipment: ["latpulldown"], muscles: ["back", "arms"], level: 1, kind: "reps", reps: 10, met: 6, cue: "Use the minimum assistance you need." },
  { id: "straight-arm-pulldown", name: "Straight-Arm Pulldown", equipment: ["cable"], muscles: ["back"], level: 2, kind: "reps", reps: 14, met: 5, cue: "Arms locked, sweep the bar to your thighs." },

  /* ------------------------ Conditioning · wave 2 ----------------------- */
  { id: "rope-double-under", name: "Double Unders", equipment: ["jumprope"], muscles: ["cardio", "legs"], level: 3, kind: "time", sec: 30, met: 12, cue: "Two rope passes per jump — wrists, not arms." },
  { id: "rope-single-leg", name: "Single-Leg Rope Skips", equipment: ["jumprope"], muscles: ["cardio", "legs"], level: 2, kind: "time", sec: 30, met: 10, uni: true, cue: "Small hops, stay on the ball of the foot." },
  { id: "rope-crossover", name: "Rope Crossovers", equipment: ["jumprope"], muscles: ["cardio"], level: 2, kind: "time", sec: 30, met: 10, cue: "Cross the arms on alternating passes." },
  { id: "shadow-box-rounds", name: "Shadow Boxing Round", equipment: ["bodyweight"], muscles: ["cardio", "shoulders"], level: 1, kind: "time", sec: 120, met: 7.5, cue: "Move, punch, reset. Picture an opponent." },
  { id: "bag-body-shots", name: "Bag Body Shots", equipment: ["boxingbag"], muscles: ["core", "arms", "cardio"], level: 2, kind: "time", sec: 40, met: 8.5, cue: "Bend the knees and dig to the body." },
  { id: "bag-slip-counter", name: "Bag Slip & Counter", equipment: ["boxingbag"], muscles: ["cardio", "core"], level: 3, kind: "time", sec: 40, met: 9, cue: "Slip the imaginary jab, fire back instantly." },
  { id: "bag-teeps", name: "Bag Push Kicks", equipment: ["boxingbag"], muscles: ["legs", "core"], level: 2, kind: "time", sec: 30, met: 8.5, uni: true, cue: "Drive the ball of the foot through the bag." },
  { id: "bag-low-kicks", name: "Bag Low Kicks", equipment: ["boxingbag"], muscles: ["legs", "cardio"], level: 2, kind: "time", sec: 30, met: 9, uni: true, cue: "Turn the hip over, strike with the shin." },
  { id: "sled-lateral", name: "Lateral Sled Drag", equipment: ["sled"], muscles: ["legs", "cardio"], level: 2, kind: "time", sec: 30, met: 9.5, uni: true, cue: "Side-step and pull — hits the hips hard." },
  { id: "farmers-walk-heavy", name: "Heavy Farmer's Walk", equipment: ["trapbar"], muscles: ["full", "core"], level: 3, kind: "time", sec: 30, met: 8.5, cue: "As heavy as you can hold. Grip, posture, breathe." },
  { id: "bear-hug-carry", name: "Bear Hug Carry", equipment: ["sandbag"], muscles: ["full", "core"], level: 2, kind: "time", sec: 40, met: 8, cue: "Squeeze the bag to your chest and walk." },
  { id: "tabata-squats", name: "Tabata Air Squats", equipment: ["bodyweight"], muscles: ["legs", "cardio"], level: 2, kind: "time", sec: 20, met: 9.5, cue: "20s all out, 10s rest, eight rounds." },
  { id: "emom-burpees", name: "EMOM Burpees", equipment: ["bodyweight"], muscles: ["full", "cardio"], level: 3, kind: "time", sec: 60, met: 10, cue: "Set number every minute — rest is what's left." },

  /* --------------------- Mobility & recovery · wave 2 ------------------- */
  { id: "ninety-ninety", name: "90/90 Hip Switch", equipment: ["mat"], muscles: ["legs", "glutes"], level: 1, kind: "reps", reps: 12, met: 2.8, cue: "Both knees at right angles, switch sides slowly." },
  { id: "couch-stretch", name: "Couch Stretch", equipment: ["mat"], muscles: ["legs"], level: 2, kind: "time", sec: 60, met: 2.5, uni: true, cue: "Rear foot up the wall, squeeze the glute." },
  { id: "pigeon-stretch", name: "Pigeon Stretch", equipment: ["mat"], muscles: ["glutes"], level: 1, kind: "time", sec: 60, met: 2.5, uni: true, cue: "Front shin forward, sink the hips down." },
  { id: "thread-needle", name: "Thread the Needle", equipment: ["mat"], muscles: ["back", "shoulders"], level: 1, kind: "time", sec: 40, met: 2.5, uni: true, cue: "Reach one arm under the body and rotate." },
  { id: "childs-pose", name: "Child's Pose", equipment: ["mat"], muscles: ["back"], level: 1, kind: "time", sec: 60, met: 2.2, cue: "Hips to heels, arms long, breathe into the back." },
  { id: "downward-dog", name: "Downward Dog", equipment: ["mat"], muscles: ["full"], level: 1, kind: "time", sec: 45, met: 3, cue: "Push the floor away, pedal the heels." },
  { id: "deep-squat-hold", name: "Deep Squat Hold", equipment: ["bodyweight"], muscles: ["legs"], level: 1, kind: "time", sec: 60, met: 3, cue: "Heels down, elbows inside the knees." },
  { id: "scorpion-stretch", name: "Scorpion Stretch", equipment: ["mat"], muscles: ["back", "core"], level: 1, kind: "reps", reps: 10, met: 3, uni: true, cue: "Face down, reach the foot across to the opposite hand." },
  { id: "ankle-rocks", name: "Ankle Mobility Rocks", equipment: ["bodyweight"], muscles: ["legs"], level: 1, kind: "reps", reps: 15, met: 2.5, uni: true, cue: "Knee tracks over the toe, heel glued down." },
  { id: "shoulder-dislocates", name: "Band Shoulder Dislocates", equipment: ["bands"], muscles: ["shoulders"], level: 1, kind: "reps", reps: 12, met: 3, cue: "Wide grip, sweep overhead and behind slowly." },
  { id: "box-breathing", name: "Box Breathing", equipment: ["bodyweight"], muscles: ["full"], level: 1, kind: "time", sec: 120, met: 1.3, cue: "In 4, hold 4, out 4, hold 4. Drops the heart rate." },
  { id: "legs-up-wall", name: "Legs Up The Wall", equipment: ["mat"], muscles: ["legs"], level: 1, kind: "time", sec: 180, met: 1.5, cue: "Perfect post-session flush for tired legs." },
];

export const EXERCISE_BY_ID: ReadonlyMap<string, Exercise> = new Map(
  EXERCISES.map((e) => [e.id, e])
);

/* ------------------------------- Food DB ------------------------------ */

export interface Food {
  id: string;
  name: string;
  serving: string;
  cal: number;
  p: number;
  c: number;
  f: number;
  cat: string;
  custom?: boolean;
}

export const FOODS: Food[] = [
  /* Proteins */
  { id: "chicken-breast", name: "Chicken breast", serving: "100 g", cal: 165, p: 31, c: 0, f: 3.6, cat: "Protein" },
  { id: "chicken-thigh", name: "Chicken thigh (skinless)", serving: "100 g", cal: 209, p: 26, c: 0, f: 11, cat: "Protein" },
  { id: "egg", name: "Egg", serving: "1 large", cal: 72, p: 6.3, c: 0.4, f: 4.8, cat: "Protein" },
  { id: "egg-white", name: "Egg whites", serving: "3 whites", cal: 51, p: 11, c: 0.7, f: 0.2, cat: "Protein" },
  { id: "paneer", name: "Paneer", serving: "100 g", cal: 265, p: 18, c: 3.6, f: 20, cat: "Protein" },
  { id: "tuna", name: "Tuna (canned, drained)", serving: "100 g", cal: 116, p: 26, c: 0, f: 1, cat: "Protein" },
  { id: "fish", name: "Fish (rohu / seer)", serving: "100 g", cal: 120, p: 20, c: 0, f: 4, cat: "Protein" },
  { id: "soya-chunks", name: "Soya chunks (dry)", serving: "50 g", cal: 173, p: 26, c: 15, f: 0.5, cat: "Protein" },
  { id: "tofu", name: "Tofu", serving: "100 g", cal: 90, p: 10, c: 2, f: 4.5, cat: "Protein" },
  { id: "whey", name: "Whey protein", serving: "1 scoop (30 g)", cal: 120, p: 24, c: 3, f: 1, cat: "Protein" },
  { id: "sprouts", name: "Mixed sprouts", serving: "1 cup", cal: 85, p: 7, c: 15, f: 0.5, cat: "Protein" },

  /* Dairy */
  { id: "milk", name: "Milk (toned)", serving: "250 ml", cal: 120, p: 8, c: 12, f: 4.5, cat: "Dairy" },
  { id: "greek-yogurt", name: "Greek yogurt", serving: "170 g", cal: 100, p: 17, c: 6, f: 0.7, cat: "Dairy" },
  { id: "curd", name: "Curd / dahi", serving: "100 g", cal: 61, p: 3.5, c: 4.7, f: 3.3, cat: "Dairy" },
  { id: "buttermilk", name: "Buttermilk (chaas)", serving: "1 glass", cal: 40, p: 3, c: 5, f: 1, cat: "Dairy" },
  { id: "cheese", name: "Cheese slice", serving: "1 slice", cal: 60, p: 4, c: 1, f: 4.5, cat: "Dairy" },

  /* Grains & staples */
  { id: "rice", name: "Cooked rice", serving: "1 cup (158 g)", cal: 205, p: 4.3, c: 45, f: 0.4, cat: "Grains" },
  { id: "roti", name: "Roti / chapati", serving: "1 piece", cal: 120, p: 3.1, c: 18, f: 3.7, cat: "Grains" },
  { id: "oats", name: "Rolled oats", serving: "40 g", cal: 152, p: 5, c: 27, f: 2.6, cat: "Grains" },
  { id: "bread", name: "Whole wheat bread", serving: "1 slice", cal: 81, p: 4, c: 14, f: 1, cat: "Grains" },
  { id: "poha", name: "Poha", serving: "1 plate (150 g)", cal: 180, p: 3, c: 35, f: 3, cat: "Grains" },
  { id: "upma", name: "Upma", serving: "1 cup", cal: 180, p: 4, c: 28, f: 6, cat: "Grains" },
  { id: "idli", name: "Idli", serving: "1 piece", cal: 39, p: 2, c: 8, f: 0.1, cat: "Grains" },
  { id: "dosa", name: "Plain dosa", serving: "1 piece", cal: 133, p: 3, c: 17, f: 5.9, cat: "Grains" },
  { id: "paratha", name: "Plain paratha", serving: "1 piece", cal: 200, p: 4, c: 28, f: 8, cat: "Grains" },
  { id: "quinoa", name: "Cooked quinoa", serving: "1 cup", cal: 222, p: 8, c: 39, f: 3.6, cat: "Grains" },
  { id: "dal", name: "Dal (cooked)", serving: "1 cup", cal: 198, p: 12, c: 32, f: 0.8, cat: "Grains" },
  { id: "chana", name: "Boiled chana", serving: "1 cup", cal: 269, p: 14.5, c: 45, f: 4.2, cat: "Grains" },
  { id: "rajma", name: "Rajma (cooked)", serving: "1 cup", cal: 215, p: 13, c: 40, f: 1, cat: "Grains" },
  { id: "khichdi", name: "Khichdi", serving: "1 cup", cal: 220, p: 7, c: 36, f: 5, cat: "Grains" },

  /* Fruits */
  { id: "banana", name: "Banana", serving: "1 medium", cal: 105, p: 1.3, c: 27, f: 0.4, cat: "Fruits" },
  { id: "apple", name: "Apple", serving: "1 medium", cal: 95, p: 0.5, c: 25, f: 0.3, cat: "Fruits" },
  { id: "orange", name: "Orange", serving: "1 medium", cal: 62, p: 1.2, c: 15, f: 0.2, cat: "Fruits" },
  { id: "papaya", name: "Papaya", serving: "1 cup", cal: 62, p: 0.7, c: 16, f: 0.4, cat: "Fruits" },
  { id: "mango", name: "Mango", serving: "1 cup", cal: 99, p: 1.4, c: 25, f: 0.6, cat: "Fruits" },
  { id: "pomegranate", name: "Pomegranate", serving: "1 cup arils", cal: 144, p: 3, c: 32, f: 2, cat: "Fruits" },
  { id: "watermelon", name: "Watermelon", serving: "1 cup", cal: 46, p: 0.9, c: 12, f: 0.2, cat: "Fruits" },
  { id: "dates", name: "Dates", serving: "2 pieces", cal: 133, p: 0.8, c: 36, f: 0, cat: "Fruits" },

  /* Vegetables */
  { id: "potato", name: "Potato (boiled)", serving: "1 medium", cal: 161, p: 4.3, c: 37, f: 0.2, cat: "Vegetables" },
  { id: "sweet-potato", name: "Sweet potato", serving: "1 medium", cal: 112, p: 2, c: 26, f: 0.1, cat: "Vegetables" },
  { id: "mixed-veg", name: "Mixed veg sabzi", serving: "1 katori (100 g)", cal: 85, p: 3, c: 9, f: 4.5, cat: "Vegetables" },
  { id: "salad", name: "Garden salad", serving: "1 bowl", cal: 45, p: 2, c: 8, f: 0.8, cat: "Vegetables" },
  { id: "broccoli", name: "Broccoli", serving: "1 cup", cal: 55, p: 3.7, c: 11, f: 0.6, cat: "Vegetables" },
  { id: "palak", name: "Palak sabzi", serving: "1 katori", cal: 60, p: 4, c: 5, f: 2, cat: "Vegetables" },

  /* Fats & nuts */
  { id: "almonds", name: "Almonds", serving: "23 pieces", cal: 164, p: 6, c: 6, f: 14, cat: "Fats & nuts" },
  { id: "peanuts", name: "Peanuts", serving: "30 g", cal: 170, p: 7, c: 5, f: 14, cat: "Fats & nuts" },
  { id: "peanut-butter", name: "Peanut butter", serving: "1 tbsp", cal: 95, p: 3.5, c: 3.5, f: 8, cat: "Fats & nuts" },
  { id: "walnuts", name: "Walnuts", serving: "7 halves", cal: 93, p: 2.2, c: 2, f: 9, cat: "Fats & nuts" },
  { id: "ghee", name: "Ghee", serving: "1 tsp", cal: 45, p: 0, c: 0, f: 5, cat: "Fats & nuts" },
  { id: "olive-oil", name: "Olive oil", serving: "1 tbsp", cal: 119, p: 0, c: 0, f: 13.5, cat: "Fats & nuts" },
  { id: "seeds", name: "Mixed seeds", serving: "1 tbsp", cal: 60, p: 2.5, c: 3, f: 4.5, cat: "Fats & nuts" },

  /* Snacks */
  { id: "protein-bar", name: "Protein bar", serving: "1 bar", cal: 200, p: 10, c: 22, f: 8, cat: "Snacks" },
  { id: "popcorn", name: "Popcorn (air-popped)", serving: "3 cups", cal: 93, p: 3, c: 19, f: 1, cat: "Snacks" },
  { id: "samosa", name: "Samosa", serving: "1 piece", cal: 260, p: 5, c: 24, f: 17, cat: "Snacks" },
  { id: "biscuit", name: "Digestive biscuits", serving: "2 pieces", cal: 105, p: 1.5, c: 15, f: 4.5, cat: "Snacks" },
  { id: "namkeen", name: "Namkeen / mixture", serving: "1 handful (30 g)", cal: 160, p: 3, c: 15, f: 10, cat: "Snacks" },
  { id: "dark-choc", name: "Dark chocolate", serving: "2 squares", cal: 110, p: 1.5, c: 9, f: 8, cat: "Snacks" },

  /* Beverages */
  { id: "coffee", name: "Black coffee", serving: "1 cup", cal: 2, p: 0, c: 0, f: 0, cat: "Beverages" },
  { id: "tea", name: "Tea with milk", serving: "1 cup", cal: 40, p: 1.5, c: 6, f: 1, cat: "Beverages" },
  { id: "cola", name: "Cola", serving: "1 can (330 ml)", cal: 139, p: 0, c: 35, f: 0, cat: "Beverages" },
  { id: "juice", name: "Fruit juice", serving: "1 glass", cal: 112, p: 1, c: 26, f: 0, cat: "Beverages" },
  { id: "coconut-water", name: "Coconut water", serving: "1 glass", cal: 45, p: 0, c: 11, f: 0, cat: "Beverages" },
  { id: "smoothie", name: "Banana-oats smoothie", serving: "1 glass", cal: 190, p: 6, c: 36, f: 3, cat: "Beverages" },

  /* ---------------------- Indian breakfast ---------------------- */
  { id: "masala-dosa", name: "Masala dosa", serving: "1 piece", cal: 250, p: 5, c: 35, f: 10, cat: "Indian breakfast" },
  { id: "rava-dosa", name: "Rava dosa", serving: "1 piece", cal: 180, p: 3, c: 27, f: 7, cat: "Indian breakfast" },
  { id: "mysore-dosa", name: "Mysore masala dosa", serving: "1 piece", cal: 280, p: 5, c: 38, f: 12, cat: "Indian breakfast" },
  { id: "uttapam", name: "Onion uttapam", serving: "1 piece", cal: 150, p: 4, c: 26, f: 3.5, cat: "Indian breakfast" },
  { id: "medu-vada", name: "Medu vada", serving: "1 piece", cal: 97, p: 3, c: 9, f: 5.5, cat: "Indian breakfast" },
  { id: "pongal", name: "Ven pongal", serving: "1 cup", cal: 212, p: 6, c: 30, f: 8, cat: "Indian breakfast" },
  { id: "appam", name: "Appam", serving: "1 piece", cal: 120, p: 2, c: 20, f: 3, cat: "Indian breakfast" },
  { id: "besan-chilla", name: "Besan chilla", serving: "1 piece", cal: 130, p: 6, c: 15, f: 5, cat: "Indian breakfast" },
  { id: "moong-chilla", name: "Moong dal chilla", serving: "1 piece", cal: 120, p: 7, c: 14, f: 4, cat: "Indian breakfast" },
  { id: "thepla", name: "Methi thepla", serving: "1 piece", cal: 110, p: 3, c: 14, f: 5, cat: "Indian breakfast" },
  { id: "aloo-paratha", name: "Aloo paratha", serving: "1 piece", cal: 290, p: 6, c: 44, f: 10, cat: "Indian breakfast" },
  { id: "paneer-paratha", name: "Paneer paratha", serving: "1 piece", cal: 310, p: 10, c: 40, f: 12, cat: "Indian breakfast" },
  { id: "gobi-paratha", name: "Gobi paratha", serving: "1 piece", cal: 280, p: 6, c: 42, f: 10, cat: "Indian breakfast" },
  { id: "bread-pakora", name: "Bread pakora", serving: "1 piece", cal: 180, p: 4, c: 22, f: 8, cat: "Indian breakfast" },
  { id: "sabudana-khichdi", name: "Sabudana khichdi", serving: "1 cup", cal: 250, p: 2, c: 45, f: 7, cat: "Indian breakfast" },
  { id: "veg-vermicelli", name: "Veg vermicelli (seviyan upma)", serving: "1 cup", cal: 190, p: 4, c: 33, f: 5, cat: "Indian breakfast" },
  { id: "daliya", name: "Daliya (broken wheat porridge)", serving: "1 cup", cal: 150, p: 5, c: 27, f: 2, cat: "Indian breakfast" },

  /* --------------------- Curries, dals & sabzi -------------------- */
  { id: "dal-fry", name: "Dal fry", serving: "1 katori (150 g)", cal: 105, p: 5, c: 12, f: 4, cat: "Dals & curries" },
  { id: "dal-makhani", name: "Dal makhani", serving: "1 katori", cal: 150, p: 6, c: 14, f: 8, cat: "Dals & curries" },
  { id: "dal-tadka", name: "Dal tadka", serving: "1 katori", cal: 115, p: 6, c: 14, f: 4.5, cat: "Dals & curries" },
  { id: "sambar", name: "Sambar", serving: "1 katori", cal: 90, p: 4, c: 12, f: 2.5, cat: "Dals & curries" },
  { id: "rasam", name: "Rasam", serving: "1 katori", cal: 40, p: 2, c: 6, f: 1, cat: "Dals & curries" },
  { id: "kadhi", name: "Kadhi pakora", serving: "1 katori", cal: 95, p: 3, c: 9, f: 5, cat: "Dals & curries" },
  { id: "chole", name: "Chole masala", serving: "1 katori", cal: 160, p: 6, c: 20, f: 6, cat: "Dals & curries" },
  { id: "lobia", name: "Lobia (black-eyed peas curry)", serving: "1 katori", cal: 140, p: 7, c: 20, f: 4, cat: "Dals & curries" },
  { id: "palak-paneer", name: "Palak paneer", serving: "1 katori", cal: 170, p: 8, c: 7, f: 13, cat: "Dals & curries" },
  { id: "matar-paneer", name: "Matar paneer", serving: "1 katori", cal: 180, p: 8, c: 11, f: 12, cat: "Dals & curries" },
  { id: "shahi-paneer", name: "Shahi paneer", serving: "1 katori", cal: 240, p: 9, c: 10, f: 18, cat: "Dals & curries" },
  { id: "kadai-paneer", name: "Kadai paneer", serving: "1 katori", cal: 210, p: 9, c: 9, f: 15, cat: "Dals & curries" },
  { id: "paneer-bhurji", name: "Paneer bhurji", serving: "1 katori", cal: 200, p: 12, c: 6, f: 14, cat: "Dals & curries" },
  { id: "aloo-gobi", name: "Aloo gobi", serving: "1 katori", cal: 110, p: 3, c: 14, f: 5, cat: "Sabzi" },
  { id: "bhindi-masala", name: "Bhindi (okra) masala", serving: "1 katori", cal: 90, p: 2, c: 9, f: 5, cat: "Sabzi" },
  { id: "baingan-bharta", name: "Baingan bharta", serving: "1 katori", cal: 95, p: 2.5, c: 10, f: 5, cat: "Sabzi" },
  { id: "aloo-matar", name: "Aloo matar", serving: "1 katori", cal: 105, p: 3, c: 15, f: 4, cat: "Sabzi" },
  { id: "lauki", name: "Lauki (bottle gourd) sabzi", serving: "1 katori", cal: 60, p: 1.5, c: 8, f: 2.5, cat: "Sabzi" },
  { id: "tori", name: "Tori (ridge gourd) sabzi", serving: "1 katori", cal: 65, p: 1.5, c: 8, f: 3, cat: "Sabzi" },
  { id: "cabbage-sabzi", name: "Cabbage sabzi", serving: "1 katori", cal: 70, p: 2, c: 8, f: 3.5, cat: "Sabzi" },
  { id: "beans-poriyal", name: "Beans poriyal", serving: "1 katori", cal: 80, p: 2.5, c: 9, f: 4, cat: "Sabzi" },
  { id: "aloo-jeera", name: "Jeera aloo", serving: "1 katori", cal: 130, p: 2.5, c: 18, f: 5.5, cat: "Sabzi" },
  { id: "dum-aloo", name: "Dum aloo", serving: "1 katori", cal: 160, p: 3, c: 18, f: 9, cat: "Sabzi" },
  { id: "malai-kofta", name: "Malai kofta", serving: "1 katori (2 kofta)", cal: 280, p: 7, c: 16, f: 21, cat: "Sabzi" },
  { id: "bhature", name: "Bhature", serving: "1 piece", cal: 220, p: 5, c: 38, f: 5, cat: "Sabzi" },

  /* -------------------------- Non-veg ----------------------------- */
  { id: "egg-curry", name: "Egg curry", serving: "2 eggs + gravy", cal: 280, p: 15, c: 8, f: 20, cat: "Non-veg" },
  { id: "egg-bhurji", name: "Anda bhurji", serving: "2 eggs", cal: 210, p: 14, c: 3, f: 16, cat: "Non-veg" },
  { id: "omelette", name: "Masala omelette", serving: "2 eggs", cal: 180, p: 13, c: 3, f: 13, cat: "Non-veg" },
  { id: "chicken-curry", name: "Chicken curry (home style)", serving: "1 katori", cal: 240, p: 22, c: 6, f: 14, cat: "Non-veg" },
  { id: "butter-chicken", name: "Butter chicken", serving: "1 katori", cal: 320, p: 20, c: 9, f: 23, cat: "Non-veg" },
  { id: "chicken-biryani", name: "Chicken biryani", serving: "1 plate (300 g)", cal: 450, p: 22, c: 52, f: 16, cat: "Non-veg" },
  { id: "egg-biryani", name: "Egg biryani", serving: "1 plate", cal: 420, p: 15, c: 52, f: 16, cat: "Non-veg" },
  { id: "mutton-curry", name: "Mutton curry", serving: "1 katori", cal: 300, p: 22, c: 5, f: 22, cat: "Non-veg" },
  { id: "mutton-biryani", name: "Mutton biryani", serving: "1 plate", cal: 520, p: 24, c: 52, f: 23, cat: "Non-veg" },
  { id: "keema", name: "Keema matar", serving: "1 katori", cal: 230, p: 17, c: 6, f: 15, cat: "Non-veg" },
  { id: "fish-curry", name: "Fish curry", serving: "1 katori", cal: 180, p: 18, c: 6, f: 9, cat: "Non-veg" },
  { id: "fish-fry", name: "Fish fry", serving: "2 pieces", cal: 220, p: 22, c: 4, f: 12, cat: "Non-veg" },
  { id: "chicken-tikka", name: "Chicken tikka", serving: "4 pieces", cal: 190, p: 24, c: 3, f: 9, cat: "Non-veg" },
  { id: "tandoori-chicken", name: "Tandoori chicken", serving: "1 leg quarter", cal: 260, p: 27, c: 2, f: 16, cat: "Non-veg" },
  { id: "prawn-curry", name: "Prawn curry", serving: "1 katori", cal: 170, p: 20, c: 5, f: 7, cat: "Non-veg" },

  /* ------------------------ Breads & rice ------------------------- */
  { id: "phulka", name: "Phulka roti", serving: "1 piece", cal: 70, p: 2.4, c: 14, f: 0.6, cat: "Breads & rice" },
  { id: "tandoori-roti", name: "Tandoori roti", serving: "1 piece", cal: 120, p: 3.5, c: 22, f: 1, cat: "Breads & rice" },
  { id: "butter-naan", name: "Butter naan", serving: "1 piece", cal: 310, p: 8, c: 50, f: 8, cat: "Breads & rice" },
  { id: "missi-roti", name: "Missi roti", serving: "1 piece", cal: 135, p: 5, c: 20, f: 4, cat: "Breads & rice" },
  { id: "puri", name: "Puri", serving: "1 piece", cal: 100, p: 2, c: 12, f: 4.5, cat: "Breads & rice" },
  { id: "jeera-rice", name: "Jeera rice", serving: "1 cup", cal: 240, p: 4, c: 45, f: 4.5, cat: "Breads & rice" },
  { id: "veg-pulao", name: "Veg pulao", serving: "1 cup", cal: 250, p: 5, c: 42, f: 7, cat: "Breads & rice" },
  { id: "veg-biryani", name: "Veg biryani", serving: "1 plate", cal: 380, p: 8, c: 60, f: 12, cat: "Breads & rice" },
  { id: "curd-rice", name: "Curd rice", serving: "1 cup", cal: 180, p: 5, c: 30, f: 4, cat: "Breads & rice" },
  { id: "lemon-rice", name: "Lemon rice", serving: "1 cup", cal: 220, p: 4, c: 38, f: 6, cat: "Breads & rice" },
  { id: "bisi-bele-bath", name: "Bisi bele bath", serving: "1 cup", cal: 260, p: 8, c: 44, f: 6, cat: "Breads & rice" },

  /* ------------------------ Street & snacks ----------------------- */
  { id: "pakora", name: "Mixed pakora", serving: "4 pieces", cal: 170, p: 4, c: 16, f: 10, cat: "Street & snacks" },
  { id: "vada-pav", name: "Vada pav", serving: "1 piece", cal: 290, p: 6, c: 42, f: 11, cat: "Street & snacks" },
  { id: "pav-bhaji", name: "Pav bhaji", serving: "1 plate (2 pav)", cal: 400, p: 9, c: 58, f: 15, cat: "Street & snacks" },
  { id: "misal-pav", name: "Misal pav", serving: "1 plate", cal: 350, p: 11, c: 48, f: 12, cat: "Street & snacks" },
  { id: "pani-puri", name: "Pani puri", serving: "6 pieces", cal: 150, p: 3, c: 28, f: 3, cat: "Street & snacks" },
  { id: "bhel-puri", name: "Bhel puri", serving: "1 plate", cal: 140, p: 4, c: 26, f: 3, cat: "Street & snacks" },
  { id: "sev-puri", name: "Sev puri", serving: "4 pieces", cal: 220, p: 4, c: 28, f: 10, cat: "Street & snacks" },
  { id: "dahi-vada", name: "Dahi vada", serving: "2 pieces", cal: 200, p: 7, c: 26, f: 8, cat: "Street & snacks" },
  { id: "dhokla", name: "Dhokla", serving: "2 pieces", cal: 110, p: 4, c: 18, f: 2, cat: "Street & snacks" },
  { id: "aloo-tikki", name: "Aloo tikki", serving: "1 piece", cal: 120, p: 2, c: 18, f: 4.5, cat: "Street & snacks" },
  { id: "veg-cutlet", name: "Veg cutlet", serving: "1 piece", cal: 130, p: 3, c: 17, f: 6, cat: "Street & snacks" },
  { id: "spring-roll", name: "Veg spring roll", serving: "1 piece", cal: 120, p: 2, c: 16, f: 5, cat: "Street & snacks" },
  { id: "veg-sandwich", name: "Veg sandwich", serving: "1 (2 slices)", cal: 180, p: 5, c: 28, f: 5, cat: "Street & snacks" },
  { id: "chana-chaat", name: "Chana chaat", serving: "1 bowl", cal: 180, p: 8, c: 26, f: 4, cat: "Street & snacks" },
  { id: "fruit-chaat", name: "Fruit chaat", serving: "1 bowl", cal: 120, p: 2, c: 28, f: 1, cat: "Street & snacks" },
  { id: "momo-veg", name: "Veg momos (steamed)", serving: "4 pieces", cal: 200, p: 5, c: 36, f: 4, cat: "Street & snacks" },
  { id: "momo-chicken", name: "Chicken momos (steamed)", serving: "4 pieces", cal: 230, p: 12, c: 32, f: 5, cat: "Street & snacks" },
  { id: "maggi", name: "Maggi noodles", serving: "1 pack (70 g)", cal: 310, p: 8, c: 44, f: 11, cat: "Street & snacks" },
  { id: "khakhra", name: "Khakhra", serving: "1 piece", cal: 60, p: 2, c: 9, f: 2, cat: "Street & snacks" },
  { id: "murukku", name: "Murukku / chakli", serving: "2 pieces", cal: 130, p: 2, c: 16, f: 6.5, cat: "Street & snacks" },

  /* ---------------------------- Sweets ----------------------------- */
  { id: "gulab-jamun", name: "Gulab jamun", serving: "1 piece", cal: 150, p: 2, c: 25, f: 5, cat: "Sweets" },
  { id: "rasgulla", name: "Rasgulla", serving: "1 piece", cal: 110, p: 3, c: 22, f: 1.5, cat: "Sweets" },
  { id: "jalebi", name: "Jalebi", serving: "2 pieces", cal: 200, p: 1, c: 40, f: 5, cat: "Sweets" },
  { id: "kheer", name: "Rice kheer", serving: "1 katori", cal: 180, p: 5, c: 26, f: 6, cat: "Sweets" },
  { id: "suji-halwa", name: "Suji halwa", serving: "1 katori", cal: 220, p: 3, c: 32, f: 9, cat: "Sweets" },
  { id: "gajar-halwa", name: "Gajar (carrot) halwa", serving: "1 katori", cal: 250, p: 4, c: 34, f: 11, cat: "Sweets" },
  { id: "besan-ladoo", name: "Besan ladoo", serving: "1 piece", cal: 180, p: 3, c: 20, f: 10, cat: "Sweets" },
  { id: "motichoor-ladoo", name: "Motichoor ladoo", serving: "1 piece", cal: 170, p: 2, c: 24, f: 8, cat: "Sweets" },
  { id: "kaju-katli", name: "Kaju katli", serving: "1 piece", cal: 90, p: 2, c: 10, f: 5, cat: "Sweets" },
  { id: "coconut-barfi", name: "Coconut barfi", serving: "1 piece", cal: 130, p: 1.5, c: 16, f: 7, cat: "Sweets" },
  { id: "kulfi", name: "Kulfi", serving: "1 stick", cal: 150, p: 4, c: 18, f: 7, cat: "Sweets" },
  { id: "rasmalai", name: "Rasmalai", serving: "1 piece", cal: 140, p: 4, c: 18, f: 6, cat: "Sweets" },
  { id: "mysore-pak", name: "Mysore pak", serving: "1 piece", cal: 190, p: 2, c: 20, f: 12, cat: "Sweets" },
  { id: "payasam", name: "Payasam / sevai kheer", serving: "1 katori", cal: 200, p: 4, c: 30, f: 7, cat: "Sweets" },
  { id: "shrikhand", name: "Shrikhand", serving: "1 katori", cal: 200, p: 5, c: 28, f: 8, cat: "Sweets" },

  /* ------------------------- Drinks & sides ------------------------ */
  { id: "lassi-sweet", name: "Sweet lassi", serving: "1 glass", cal: 180, p: 6, c: 26, f: 6, cat: "Drinks & sides" },
  { id: "lassi-salted", name: "Salted lassi", serving: "1 glass", cal: 70, p: 4, c: 7, f: 3, cat: "Drinks & sides" },
  { id: "mango-lassi", name: "Mango lassi", serving: "1 glass", cal: 210, p: 6, c: 36, f: 5, cat: "Drinks & sides" },
  { id: "nimbu-pani", name: "Nimbu pani (shikanji)", serving: "1 glass", cal: 60, p: 0, c: 15, f: 0, cat: "Drinks & sides" },
  { id: "masala-chai", name: "Masala chai", serving: "1 cup", cal: 60, p: 2, c: 9, f: 2, cat: "Drinks & sides" },
  { id: "filter-coffee", name: "Filter coffee (with milk)", serving: "1 cup", cal: 60, p: 2, c: 6, f: 3, cat: "Drinks & sides" },
  { id: "badam-milk", name: "Badam milk", serving: "1 glass", cal: 190, p: 7, c: 20, f: 9, cat: "Drinks & sides" },
  { id: "aam-panna", name: "Aam panna", serving: "1 glass", cal: 80, p: 0, c: 20, f: 0, cat: "Drinks & sides" },
  { id: "papad", name: "Papad (roasted)", serving: "1 piece", cal: 30, p: 1.5, c: 5, f: 0.3, cat: "Drinks & sides" },
  { id: "papad-fried", name: "Papad (fried)", serving: "1 piece", cal: 55, p: 1.5, c: 5, f: 3.5, cat: "Drinks & sides" },
  { id: "mango-pickle", name: "Mango pickle", serving: "1 tsp", cal: 25, p: 0, c: 1, f: 2, cat: "Drinks & sides" },
  { id: "boondi-raita", name: "Boondi raita", serving: "1 katori", cal: 80, p: 4, c: 8, f: 4, cat: "Drinks & sides" },
  { id: "cucumber-raita", name: "Cucumber raita", serving: "1 katori", cal: 50, p: 3, c: 5, f: 2, cat: "Drinks & sides" },
  { id: "green-chutney", name: "Green chutney", serving: "1 tbsp", cal: 8, p: 0.3, c: 1.5, f: 0.1, cat: "Drinks & sides" },
  { id: "tamarind-chutney", name: "Tamarind chutney", serving: "1 tbsp", cal: 35, p: 0, c: 9, f: 0, cat: "Drinks & sides" },

  /* ------------------- Indian breakfast · wave 2 ------------------- */
  { id: "rava-idli", name: "Rava idli", serving: "1 piece", cal: 50, p: 2, c: 9, f: 0.5, cat: "Indian breakfast" },
  { id: "poha-peanut", name: "Poha with peanuts", serving: "1 plate (150 g)", cal: 210, p: 4, c: 36, f: 6, cat: "Indian breakfast" },
  { id: "masala-oats", name: "Masala oats", serving: "1 cup", cal: 140, p: 5, c: 22, f: 4, cat: "Indian breakfast" },
  { id: "methi-paratha", name: "Methi paratha", serving: "1 piece", cal: 210, p: 5, c: 30, f: 8, cat: "Indian breakfast" },
  { id: "mooli-paratha", name: "Mooli (radish) paratha", serving: "1 piece", cal: 270, p: 6, c: 40, f: 9, cat: "Indian breakfast" },
  { id: "onion-paratha", name: "Onion paratha", serving: "1 piece", cal: 240, p: 5, c: 36, f: 8, cat: "Indian breakfast" },
  { id: "bread-butter", name: "Bread butter toast", serving: "2 slices", cal: 190, p: 5, c: 28, f: 6.5, cat: "Indian breakfast" },
  { id: "french-toast", name: "French toast (savoury)", serving: "1 slice", cal: 160, p: 7, c: 15, f: 8, cat: "Indian breakfast" },
  { id: "aloo-puri", name: "Aloo puri", serving: "4 puri + aloo", cal: 450, p: 8, c: 60, f: 20, cat: "Indian breakfast" },
  { id: "chole-bhature", name: "Chole bhature", serving: "1 plate", cal: 520, p: 14, c: 80, f: 16, cat: "Indian breakfast" },
  { id: "sabudana-vada", name: "Sabudana vada", serving: "2 pieces", cal: 210, p: 3, c: 28, f: 10, cat: "Indian breakfast" },
  { id: "pesarattu", name: "Pesarattu (moong dosa)", serving: "1 piece", cal: 120, p: 6, c: 16, f: 3.5, cat: "Indian breakfast" },
  { id: "ragi-dosa", name: "Ragi dosa", serving: "1 piece", cal: 110, p: 3, c: 18, f: 2.5, cat: "Indian breakfast" },
  { id: "set-dosa", name: "Set dosa", serving: "2 pieces", cal: 200, p: 5, c: 34, f: 5, cat: "Indian breakfast" },
  { id: "neer-dosa", name: "Neer dosa", serving: "1 piece", cal: 90, p: 1.5, c: 17, f: 1.5, cat: "Indian breakfast" },
  { id: "ghee-roast", name: "Ghee roast / paper dosa", serving: "1 piece", cal: 220, p: 4, c: 30, f: 9, cat: "Indian breakfast" },
  { id: "egg-dosa", name: "Egg dosa", serving: "1 piece", cal: 200, p: 9, c: 20, f: 9, cat: "Indian breakfast" },
  { id: "cheese-dosa", name: "Cheese dosa", serving: "1 piece", cal: 320, p: 10, c: 28, f: 18, cat: "Indian breakfast" },
  { id: "kothu-parotta", name: "Kothu parotta", serving: "1 plate", cal: 480, p: 12, c: 60, f: 21, cat: "Indian breakfast" },
  { id: "idli-fry", name: "Masala idli fry", serving: "1 plate (6 idli)", cal: 280, p: 7, c: 44, f: 8, cat: "Indian breakfast" },

  /* ------------------------- Dal varieties ------------------------- */
  { id: "moong-dal", name: "Moong dal (cooked)", serving: "1 katori", cal: 105, p: 7, c: 16, f: 0.5, cat: "Dals & curries" },
  { id: "masoor-dal", name: "Masoor dal (cooked)", serving: "1 katori", cal: 115, p: 8, c: 18, f: 0.5, cat: "Dals & curries" },
  { id: "arhar-dal", name: "Toor / arhar dal (cooked)", serving: "1 katori", cal: 110, p: 7, c: 17, f: 0.8, cat: "Dals & curries" },
  { id: "chana-dal", name: "Chana dal (cooked)", serving: "1 katori", cal: 140, p: 7, c: 21, f: 2, cat: "Dals & curries" },
  { id: "urad-dal", name: "Urad dal (cooked)", serving: "1 katori", cal: 130, p: 7, c: 19, f: 1, cat: "Dals & curries" },
  { id: "panchmel-dal", name: "Panchmel / panchratna dal", serving: "1 katori", cal: 140, p: 8, c: 18, f: 4, cat: "Dals & curries" },
  { id: "dal-palak", name: "Dal palak", serving: "1 katori", cal: 120, p: 6, c: 14, f: 4.5, cat: "Dals & curries" },

  /* ------------------------- Sabzi · wave 2 ------------------------- */
  { id: "matar-mushroom", name: "Matar mushroom", serving: "1 katori", cal: 110, p: 5, c: 10, f: 5.5, cat: "Sabzi" },
  { id: "mushroom-masala", name: "Mushroom masala", serving: "1 katori", cal: 100, p: 5, c: 8, f: 5.5, cat: "Sabzi" },
  { id: "gobi-masala", name: "Gobi masala", serving: "1 katori", cal: 110, p: 3, c: 11, f: 6, cat: "Sabzi" },
  { id: "karela-fry", name: "Karela (bitter gourd) fry", serving: "1 katori", cal: 95, p: 2, c: 9, f: 6, cat: "Sabzi" },
  { id: "tinda-masala", name: "Tinda masala", serving: "1 katori", cal: 70, p: 1.5, c: 9, f: 3.5, cat: "Sabzi" },
  { id: "arbi-fry", name: "Arbi (colocasia) fry", serving: "1 katori", cal: 140, p: 1.5, c: 22, f: 6, cat: "Sabzi" },
  { id: "kathal-curry", name: "Kathal (jackfruit) curry", serving: "1 katori", cal: 130, p: 2.5, c: 18, f: 6, cat: "Sabzi" },
  { id: "kundru-fry", name: "Kundru (ivy gourd) fry", serving: "1 katori", cal: 75, p: 1.5, c: 9, f: 4, cat: "Sabzi" },
  { id: "methi-aloo", name: "Methi aloo", serving: "1 katori", cal: 120, p: 3, c: 15, f: 5.5, cat: "Sabzi" },
  { id: "sarson-saag", name: "Sarson ka saag", serving: "1 katori", cal: 110, p: 4, c: 9, f: 6.5, cat: "Sabzi" },
  { id: "gatte-sabzi", name: "Gatte ki sabzi", serving: "1 katori", cal: 180, p: 7, c: 15, f: 10, cat: "Sabzi" },
  { id: "soya-curry", name: "Soya chunks curry", serving: "1 katori", cal: 160, p: 13, c: 9, f: 7, cat: "Sabzi" },
  { id: "babycorn-masala", name: "Baby corn masala", serving: "1 katori", cal: 100, p: 3, c: 11, f: 5, cat: "Sabzi" },
  { id: "navratan-korma", name: "Navratan korma", serving: "1 katori", cal: 220, p: 6, c: 15, f: 15, cat: "Sabzi" },
  { id: "veg-jalfrezi", name: "Veg jalfrezi", serving: "1 katori", cal: 130, p: 4, c: 12, f: 7.5, cat: "Sabzi" },
  { id: "paneer-butter-masala", name: "Paneer butter masala", serving: "1 katori", cal: 300, p: 10, c: 10, f: 24, cat: "Sabzi" },
  { id: "paneer-do-pyaza", name: "Paneer do pyaza", serving: "1 katori", cal: 230, p: 9, c: 10, f: 17, cat: "Sabzi" },
  { id: "paneer-tikka", name: "Paneer tikka", serving: "4 pieces", cal: 220, p: 14, c: 6, f: 16, cat: "Sabzi" },
  { id: "chilli-paneer", name: "Chilli paneer", serving: "1 katori", cal: 260, p: 11, c: 14, f: 18, cat: "Sabzi" },
  { id: "aloo-baingan", name: "Aloo baingan", serving: "1 katori", cal: 110, p: 2, c: 14, f: 5.5, cat: "Sabzi" },
  { id: "pithla", name: "Pithla (besan curry)", serving: "1 katori", cal: 130, p: 5, c: 13, f: 6, cat: "Sabzi" },

  /* ------------------------- Non-veg · wave 2 ----------------------- */
  { id: "kadai-chicken", name: "Kadai chicken", serving: "1 katori", cal: 280, p: 22, c: 7, f: 18, cat: "Non-veg" },
  { id: "chicken-korma", name: "Chicken korma", serving: "1 katori", cal: 300, p: 21, c: 7, f: 21, cat: "Non-veg" },
  { id: "chettinad-chicken", name: "Chettinad chicken", serving: "1 katori", cal: 290, p: 24, c: 6, f: 18, cat: "Non-veg" },
  { id: "pepper-chicken", name: "Pepper chicken (dry)", serving: "1 katori", cal: 260, p: 25, c: 5, f: 15, cat: "Non-veg" },
  { id: "chicken-saagwala", name: "Chicken saagwala", serving: "1 katori", cal: 270, p: 24, c: 7, f: 16, cat: "Non-veg" },
  { id: "chicken-vindaloo", name: "Chicken vindaloo", serving: "1 katori", cal: 280, p: 23, c: 8, f: 17, cat: "Non-veg" },
  { id: "chicken-tikka-masala", name: "Chicken tikka masala", serving: "1 katori", cal: 310, p: 23, c: 9, f: 20, cat: "Non-veg" },
  { id: "chicken-65", name: "Chicken 65", serving: "6 pieces", cal: 280, p: 20, c: 10, f: 17, cat: "Non-veg" },
  { id: "chicken-manchurian", name: "Chicken manchurian", serving: "1 katori", cal: 300, p: 20, c: 14, f: 18, cat: "Non-veg" },
  { id: "chilli-chicken", name: "Chilli chicken", serving: "1 katori", cal: 280, p: 21, c: 12, f: 16, cat: "Non-veg" },
  { id: "egg-masala", name: "Egg masala curry", serving: "2 eggs + gravy", cal: 290, p: 14, c: 9, f: 21, cat: "Non-veg" },
  { id: "haleem", name: "Haleem", serving: "1 katori", cal: 320, p: 18, c: 22, f: 18, cat: "Non-veg" },
  { id: "chicken-stew", name: "Kerala chicken stew", serving: "1 katori", cal: 230, p: 20, c: 7, f: 13, cat: "Non-veg" },
  { id: "prawn-fry", name: "Prawn fry", serving: "6 pieces", cal: 170, p: 20, c: 3, f: 8, cat: "Non-veg" },
  { id: "prawn-biryani", name: "Prawn biryani", serving: "1 plate", cal: 430, p: 22, c: 52, f: 14, cat: "Non-veg" },
  { id: "fish-biryani", name: "Fish biryani", serving: "1 plate", cal: 440, p: 24, c: 50, f: 15, cat: "Non-veg" },
  { id: "paneer-biryani", name: "Paneer biryani", serving: "1 plate", cal: 470, p: 14, c: 55, f: 20, cat: "Non-veg" },
  { id: "keema-pav", name: "Keema pav", serving: "1 plate", cal: 430, p: 20, c: 40, f: 20, cat: "Non-veg" },

  /* ---------------------- Breads & rice · wave 2 -------------------- */
  { id: "laccha-paratha", name: "Laccha paratha", serving: "1 piece", cal: 260, p: 5, c: 34, f: 11, cat: "Breads & rice" },
  { id: "roomali-roti", name: "Roomali roti", serving: "1 piece", cal: 100, p: 3, c: 19, f: 1, cat: "Breads & rice" },
  { id: "bajra-roti", name: "Bajra roti", serving: "1 piece", cal: 120, p: 3.5, c: 19, f: 2.5, cat: "Breads & rice" },
  { id: "jowar-bhakri", name: "Jowar bhakri", serving: "1 piece", cal: 105, p: 3, c: 22, f: 0.8, cat: "Breads & rice" },
  { id: "ragi-roti", name: "Ragi roti", serving: "1 piece", cal: 110, p: 3, c: 20, f: 1.5, cat: "Breads & rice" },
  { id: "makki-roti", name: "Makki ki roti", serving: "1 piece", cal: 140, p: 3, c: 21, f: 5, cat: "Breads & rice" },
  { id: "amritsari-kulcha", name: "Amritsari kulcha", serving: "1 piece", cal: 290, p: 8, c: 46, f: 8, cat: "Breads & rice" },
  { id: "garlic-naan", name: "Garlic naan", serving: "1 piece", cal: 330, p: 9, c: 50, f: 10, cat: "Breads & rice" },
  { id: "tomato-rice", name: "Tomato rice", serving: "1 cup", cal: 230, p: 5, c: 42, f: 5, cat: "Breads & rice" },
  { id: "coconut-rice", name: "Coconut rice", serving: "1 cup", cal: 260, p: 4, c: 40, f: 10, cat: "Breads & rice" },
  { id: "tamarind-rice", name: "Tamarind rice (puliyodarai)", serving: "1 cup", cal: 250, p: 5, c: 42, f: 7, cat: "Breads & rice" },
  { id: "pudina-rice", name: "Pudina rice", serving: "1 cup", cal: 230, p: 5, c: 42, f: 4.5, cat: "Breads & rice" },
  { id: "ghee-rice", name: "Ghee rice", serving: "1 cup", cal: 270, p: 5, c: 42, f: 10, cat: "Breads & rice" },
  { id: "veg-fried-rice", name: "Veg fried rice", serving: "1 plate", cal: 350, p: 8, c: 58, f: 10, cat: "Breads & rice" },
  { id: "egg-fried-rice", name: "Egg fried rice", serving: "1 plate", cal: 400, p: 14, c: 58, f: 12, cat: "Breads & rice" },
  { id: "chicken-fried-rice", name: "Chicken fried rice", serving: "1 plate", cal: 450, p: 22, c: 55, f: 15, cat: "Breads & rice" },
  { id: "moong-khichdi", name: "Moong dal khichdi", serving: "1 cup", cal: 200, p: 8, c: 32, f: 4.5, cat: "Breads & rice" },

  /* ----------------------- Combos & thalis -------------------------- */
  { id: "dal-chawal", name: "Dal chawal", serving: "1 plate (dal + rice)", cal: 320, p: 10, c: 55, f: 6, cat: "Combos & thalis" },
  { id: "rajma-chawal", name: "Rajma chawal", serving: "1 plate", cal: 420, p: 14, c: 70, f: 10, cat: "Combos & thalis" },
  { id: "chole-chawal", name: "Chole chawal", serving: "1 plate", cal: 400, p: 12, c: 64, f: 11, cat: "Combos & thalis" },
  { id: "kadhi-chawal", name: "Kadhi chawal", serving: "1 plate", cal: 340, p: 8, c: 55, f: 9, cat: "Combos & thalis" },
  { id: "sambar-rice", name: "Sambar rice", serving: "1 plate", cal: 300, p: 9, c: 55, f: 4.5, cat: "Combos & thalis" },
  { id: "rasam-rice", name: "Rasam rice", serving: "1 plate", cal: 250, p: 6, c: 48, f: 3.5, cat: "Combos & thalis" },
  { id: "curd-rice-combo", name: "Curd rice + pickle + papad", serving: "1 plate", cal: 280, p: 8, c: 44, f: 7, cat: "Combos & thalis" },
  { id: "home-thali", name: "Home thali (2 roti + dal + sabzi + rice)", serving: "1 thali", cal: 600, p: 18, c: 95, f: 16, cat: "Combos & thalis" },
  { id: "roti-sabzi-meal", name: "2 roti + sabzi + salad", serving: "1 meal", cal: 420, p: 12, c: 60, f: 13, cat: "Combos & thalis" },
  { id: "khichdi-combo", name: "Khichdi + kadhi + papad", serving: "1 plate", cal: 400, p: 12, c: 62, f: 11, cat: "Combos & thalis" },
  { id: "idli-sambar-combo", name: "Idli sambar (3 idli + sambar + chutney)", serving: "1 plate", cal: 260, p: 10, c: 44, f: 4, cat: "Combos & thalis" },
  { id: "dosa-combo", name: "Dosa + sambar + chutney", serving: "1 plate", cal: 340, p: 9, c: 56, f: 9, cat: "Combos & thalis" },

  /* ------------------------- Indo-Chinese --------------------------- */
  { id: "veg-noodles", name: "Veg hakka noodles", serving: "1 plate", cal: 340, p: 8, c: 56, f: 9, cat: "Indo-Chinese" },
  { id: "egg-noodles", name: "Egg noodles", serving: "1 plate", cal: 390, p: 13, c: 56, f: 11, cat: "Indo-Chinese" },
  { id: "chicken-noodles", name: "Chicken noodles", serving: "1 plate", cal: 440, p: 20, c: 54, f: 14, cat: "Indo-Chinese" },
  { id: "gobi-manchurian", name: "Gobi manchurian", serving: "1 plate", cal: 330, p: 7, c: 40, f: 16, cat: "Indo-Chinese" },
  { id: "veg-manchurian", name: "Veg manchurian", serving: "6 balls", cal: 300, p: 7, c: 36, f: 14, cat: "Indo-Chinese" },
  { id: "veg-manchow", name: "Veg manchow soup", serving: "1 bowl", cal: 90, p: 2, c: 14, f: 3, cat: "Indo-Chinese" },
  { id: "sweet-corn-soup", name: "Sweet corn soup", serving: "1 bowl", cal: 110, p: 3, c: 18, f: 2.5, cat: "Indo-Chinese" },
  { id: "tomato-soup", name: "Tomato soup", serving: "1 bowl", cal: 90, p: 2, c: 14, f: 2.5, cat: "Indo-Chinese" },
  { id: "chicken-soup", name: "Chicken clear soup", serving: "1 bowl", cal: 90, p: 10, c: 6, f: 3, cat: "Indo-Chinese" },
  { id: "hot-sour-soup", name: "Hot & sour soup", serving: "1 bowl", cal: 100, p: 4, c: 14, f: 3, cat: "Indo-Chinese" },

  /* ---------------------- Street & snacks · wave 2 ------------------ */
  { id: "kachori", name: "Moong dal kachori", serving: "1 piece", cal: 190, p: 4, c: 22, f: 9, cat: "Street & snacks" },
  { id: "samosa-chaat", name: "Samosa chaat", serving: "1 plate", cal: 320, p: 7, c: 40, f: 15, cat: "Street & snacks" },
  { id: "papdi-chaat", name: "Papdi chaat", serving: "1 plate", cal: 260, p: 6, c: 36, f: 10, cat: "Street & snacks" },
  { id: "dahi-papdi", name: "Dahi papdi chaat", serving: "1 plate", cal: 240, p: 6, c: 34, f: 9, cat: "Street & snacks" },
  { id: "ragda-pattice", name: "Ragda pattice", serving: "1 plate", cal: 330, p: 9, c: 48, f: 11, cat: "Street & snacks" },
  { id: "dabeli", name: "Dabeli", serving: "1 piece", cal: 200, p: 4, c: 34, f: 6, cat: "Street & snacks" },
  { id: "aloo-bonda", name: "Aloo bonda", serving: "1 piece", cal: 150, p: 3, c: 18, f: 7, cat: "Street & snacks" },
  { id: "mirchi-bajji", name: "Mirchi bajji", serving: "2 pieces", cal: 160, p: 3, c: 18, f: 8, cat: "Street & snacks" },
  { id: "roasted-chana", name: "Roasted chana", serving: "30 g", cal: 110, p: 6, c: 18, f: 1, cat: "Street & snacks" },
  { id: "makhana", name: "Roasted makhana (fox nuts)", serving: "1 cup", cal: 105, p: 4, c: 17, f: 1, cat: "Street & snacks" },
  { id: "masala-makhana", name: "Masala makhana", serving: "1 cup", cal: 130, p: 4, c: 17, f: 4.5, cat: "Street & snacks" },
  { id: "kurmura", name: "Puffed rice (kurmura)", serving: "2 cups", cal: 110, p: 2, c: 24, f: 0.3, cat: "Street & snacks" },
  { id: "peanut-chikki", name: "Peanut chikki", serving: "1 piece", cal: 110, p: 3, c: 12, f: 6, cat: "Street & snacks" },
  { id: "bhutta", name: "Roasted corn (bhutta)", serving: "1 cob", cal: 120, p: 4, c: 24, f: 2, cat: "Street & snacks" },
  { id: "corn-chaat", name: "Corn chaat", serving: "1 bowl", cal: 150, p: 4, c: 26, f: 3.5, cat: "Street & snacks" },
  { id: "peanut-chaat", name: "Peanut masala chaat", serving: "1 bowl", cal: 220, p: 9, c: 10, f: 15, cat: "Street & snacks" },
  { id: "bun-maska", name: "Bun maska", serving: "1 piece", cal: 250, p: 5, c: 38, f: 9, cat: "Street & snacks" },
  { id: "poha-chivda", name: "Poha chivda", serving: "1 handful (30 g)", cal: 150, p: 3, c: 18, f: 7, cat: "Street & snacks" },
  { id: "mathri", name: "Mathri", serving: "1 piece", cal: 130, p: 2.5, c: 15, f: 7, cat: "Street & snacks" },
  { id: "namak-para", name: "Namak para", serving: "6 pieces", cal: 140, p: 2, c: 18, f: 6.5, cat: "Street & snacks" },
  { id: "cheese-toast", name: "Cheese toast", serving: "1 piece", cal: 150, p: 6, c: 15, f: 7, cat: "Street & snacks" },
  { id: "bread-omelette", name: "Bread omelette", serving: "1 plate", cal: 300, p: 14, c: 28, f: 14, cat: "Street & snacks" },

  /* -------------------------- Sweets · wave 2 ----------------------- */
  { id: "moong-dal-halwa", name: "Moong dal halwa", serving: "1 katori", cal: 280, p: 6, c: 34, f: 14, cat: "Sweets" },
  { id: "rava-kesari", name: "Rava kesari", serving: "1 katori", cal: 230, p: 3, c: 34, f: 10, cat: "Sweets" },
  { id: "atta-halwa", name: "Atta halwa", serving: "1 katori", cal: 240, p: 4, c: 32, f: 11, cat: "Sweets" },
  { id: "coconut-ladoo", name: "Nariyal (coconut) ladoo", serving: "1 piece", cal: 140, p: 1.5, c: 15, f: 8.5, cat: "Sweets" },
  { id: "atta-ladoo", name: "Atta ladoo", serving: "1 piece", cal: 190, p: 3, c: 22, f: 10, cat: "Sweets" },
  { id: "til-ladoo", name: "Til (sesame) ladoo", serving: "1 piece", cal: 120, p: 2, c: 12, f: 7, cat: "Sweets" },
  { id: "gujiya", name: "Gujiya / karanji", serving: "1 piece", cal: 180, p: 3, c: 24, f: 9, cat: "Sweets" },
  { id: "modak", name: "Modak (steamed)", serving: "1 piece", cal: 130, p: 2, c: 20, f: 5, cat: "Sweets" },
  { id: "puran-poli", name: "Puran poli", serving: "1 piece", cal: 260, p: 7, c: 44, f: 7, cat: "Sweets" },
  { id: "peda", name: "Doodh peda", serving: "1 piece", cal: 90, p: 2, c: 10, f: 4.5, cat: "Sweets" },
  { id: "sandesh", name: "Sandesh", serving: "1 piece", cal: 80, p: 3, c: 12, f: 2, cat: "Sweets" },
  { id: "cham-cham", name: "Cham cham", serving: "1 piece", cal: 130, p: 3, c: 22, f: 3.5, cat: "Sweets" },
  { id: "malpua", name: "Malpua", serving: "1 piece", cal: 210, p: 4, c: 30, f: 9, cat: "Sweets" },
  { id: "rabri", name: "Rabri", serving: "1 katori", cal: 220, p: 8, c: 22, f: 11, cat: "Sweets" },
  { id: "basundi", name: "Basundi", serving: "1 katori", cal: 240, p: 9, c: 26, f: 11, cat: "Sweets" },
  { id: "phirni", name: "Phirni", serving: "1 katori", cal: 170, p: 4, c: 26, f: 5, cat: "Sweets" },
  { id: "seviyan-kheer", name: "Seviyan kheer", serving: "1 katori", cal: 210, p: 5, c: 30, f: 8, cat: "Sweets" },
  { id: "kalakand", name: "Kalakand", serving: "1 piece", cal: 150, p: 5, c: 16, f: 7, cat: "Sweets" },
  { id: "milk-cake", name: "Milk cake", serving: "1 piece", cal: 170, p: 6, c: 18, f: 8, cat: "Sweets" },
  { id: "petha", name: "Petha", serving: "2 pieces", cal: 100, p: 0, c: 25, f: 0, cat: "Sweets" },
  { id: "soan-papdi", name: "Soan papdi", serving: "2 pieces", cal: 150, p: 2, c: 20, f: 7, cat: "Sweets" },
  { id: "balushahi", name: "Balushahi / badusha", serving: "1 piece", cal: 250, p: 3, c: 33, f: 12, cat: "Sweets" },
  { id: "jangiri", name: "Jangiri", serving: "2 pieces", cal: 220, p: 1, c: 40, f: 7, cat: "Sweets" },
  { id: "shahi-tukda", name: "Shahi tukda", serving: "1 piece", cal: 280, p: 6, c: 34, f: 13, cat: "Sweets" },
  { id: "kulfi-falooda", name: "Kulfi falooda", serving: "1 glass", cal: 300, p: 7, c: 50, f: 8, cat: "Sweets" },
  { id: "ice-cream", name: "Vanilla ice cream", serving: "1 scoop", cal: 137, p: 2.3, c: 16, f: 7, cat: "Sweets" },

  /* ---------------- Drinks, sides & packaged cereals ---------------- */
  { id: "thandai", name: "Thandai", serving: "1 glass", cal: 180, p: 6, c: 22, f: 8, cat: "Drinks & sides" },
  { id: "jal-jeera", name: "Jal jeera", serving: "1 glass", cal: 40, p: 0.5, c: 9, f: 0.3, cat: "Drinks & sides" },
  { id: "sugarcane-juice", name: "Sugarcane juice", serving: "1 glass", cal: 180, p: 0, c: 44, f: 0, cat: "Drinks & sides" },
  { id: "sattu-drink", name: "Sattu drink", serving: "1 glass", cal: 120, p: 6, c: 18, f: 1.5, cat: "Drinks & sides" },
  { id: "mango-shake", name: "Mango milkshake", serving: "1 glass", cal: 210, p: 7, c: 32, f: 6, cat: "Drinks & sides" },
  { id: "banana-shake", name: "Banana milkshake", serving: "1 glass", cal: 220, p: 7, c: 34, f: 6, cat: "Drinks & sides" },
  { id: "cold-coffee", name: "Cold coffee", serving: "1 glass", cal: 160, p: 4, c: 24, f: 5, cat: "Drinks & sides" },
  { id: "rose-milk", name: "Rose milk", serving: "1 glass", cal: 160, p: 6, c: 24, f: 4, cat: "Drinks & sides" },
  { id: "malt-milk", name: "Bournvita / Horlicks milk", serving: "1 glass", cal: 170, p: 8, c: 24, f: 4.5, cat: "Drinks & sides" },
  { id: "coconut-chutney", name: "Coconut chutney", serving: "2 tbsp", cal: 60, p: 1, c: 2, f: 5.5, cat: "Drinks & sides" },
  { id: "peanut-chutney", name: "Peanut chutney", serving: "1 tbsp", cal: 50, p: 2, c: 2, f: 4, cat: "Drinks & sides" },
  { id: "onion-tomato-chutney", name: "Onion-tomato chutney", serving: "2 tbsp", cal: 25, p: 1, c: 4, f: 0.7, cat: "Drinks & sides" },
  { id: "masala-papad", name: "Masala papad", serving: "1 piece", cal: 70, p: 2, c: 8, f: 3.5, cat: "Drinks & sides" },
  { id: "corn-flakes", name: "Corn flakes with milk", serving: "1 bowl", cal: 190, p: 6, c: 36, f: 3, cat: "Drinks & sides" },
  { id: "chocos", name: "Chocos with milk", serving: "1 bowl", cal: 220, p: 5, c: 38, f: 5, cat: "Drinks & sides" },
  { id: "muesli-milk", name: "Muesli with milk", serving: "1 bowl", cal: 230, p: 8, c: 36, f: 6, cat: "Drinks & sides" },
  { id: "marie-biscuit", name: "Marie biscuits", serving: "4 pieces", cal: 110, p: 2, c: 19, f: 3, cat: "Snacks" },
  { id: "glucose-biscuit", name: "Glucose biscuits", serving: "4 pieces", cal: 170, p: 2.5, c: 28, f: 5.5, cat: "Snacks" },
  { id: "cream-biscuit", name: "Cream biscuit", serving: "2 pieces", cal: 130, p: 1.5, c: 18, f: 6, cat: "Snacks" },
  { id: "cake-slice", name: "Cake slice", serving: "1 slice", cal: 240, p: 4, c: 34, f: 10, cat: "Snacks" },
  { id: "choc-pastry", name: "Chocolate pastry", serving: "1 piece", cal: 290, p: 4, c: 36, f: 15, cat: "Snacks" },

  /* ---------------- Everyday ghar-ka-khana sabzi ---------------- */
  { id: "aloo-tamatar", name: "Aloo tamatar ki sabzi", serving: "1 katori (150 g)", cal: 115, p: 2.5, c: 18, f: 4, cat: "Everyday sabzi" },
  { id: "aloo-tamatar-rasedar", name: "Aloo tamatar rasedar (gravy)", serving: "1 katori", cal: 125, p: 2.5, c: 19, f: 4.5, cat: "Everyday sabzi" },
  { id: "sukha-aloo", name: "Sukha aloo sabzi", serving: "1 katori", cal: 145, p: 3, c: 21, f: 5.5, cat: "Everyday sabzi" },
  { id: "aloo-pyaz", name: "Aloo pyaz ki sabzi", serving: "1 katori", cal: 135, p: 2.5, c: 19, f: 5.5, cat: "Everyday sabzi" },
  { id: "aloo-palak", name: "Aloo palak", serving: "1 katori", cal: 105, p: 3.5, c: 14, f: 4.5, cat: "Everyday sabzi" },
  { id: "aloo-shimla-mirch", name: "Aloo shimla mirch", serving: "1 katori", cal: 120, p: 2.5, c: 17, f: 5, cat: "Everyday sabzi" },
  { id: "aloo-beans", name: "Aloo beans ki sabzi", serving: "1 katori", cal: 105, p: 3, c: 15, f: 4, cat: "Everyday sabzi" },
  { id: "aloo-patta-gobhi", name: "Aloo patta gobhi (potato cabbage)", serving: "1 katori", cal: 100, p: 2.5, c: 14, f: 4, cat: "Everyday sabzi" },
  { id: "aloo-soya", name: "Aloo soya / dill sabzi", serving: "1 katori", cal: 110, p: 3, c: 15, f: 4.5, cat: "Everyday sabzi" },
  { id: "aloo-chana", name: "Aloo chana curry", serving: "1 katori", cal: 175, p: 6, c: 26, f: 5.5, cat: "Everyday sabzi" },
  { id: "aloo-karela", name: "Aloo karela", serving: "1 katori", cal: 115, p: 2.5, c: 14, f: 5.5, cat: "Everyday sabzi" },
  { id: "gobi-matar", name: "Gobi matar ki sabzi", serving: "1 katori", cal: 100, p: 4, c: 12, f: 4.5, cat: "Everyday sabzi" },
  { id: "gobi-aloo-matar", name: "Aloo gobi matar", serving: "1 katori", cal: 120, p: 3.5, c: 16, f: 5, cat: "Everyday sabzi" },
  { id: "patta-gobhi-matar", name: "Patta gobhi matar", serving: "1 katori", cal: 85, p: 3.5, c: 10, f: 3.5, cat: "Everyday sabzi" },
  { id: "patta-gobhi-chana-dal", name: "Patta gobhi chana dal", serving: "1 katori", cal: 125, p: 6, c: 16, f: 4, cat: "Everyday sabzi" },
  { id: "bhindi-pyaz", name: "Bhindi do pyaza", serving: "1 katori", cal: 105, p: 2.5, c: 10, f: 6, cat: "Everyday sabzi" },
  { id: "bharwa-bhindi", name: "Bharwa bhindi (stuffed okra)", serving: "1 katori", cal: 130, p: 3, c: 11, f: 8, cat: "Everyday sabzi" },
  { id: "bharwa-karela", name: "Bharwa karela", serving: "1 katori", cal: 125, p: 3, c: 10, f: 8, cat: "Everyday sabzi" },
  { id: "bharwa-shimla", name: "Bharwa shimla mirch", serving: "1 piece", cal: 155, p: 5, c: 18, f: 7, cat: "Everyday sabzi" },
  { id: "shimla-mirch-besan", name: "Shimla mirch besan sabzi", serving: "1 katori", cal: 140, p: 6, c: 13, f: 7, cat: "Everyday sabzi" },
  { id: "lauki-tamatar", name: "Lauki tamatar ki sabzi", serving: "1 katori", cal: 65, p: 2, c: 8, f: 3, cat: "Everyday sabzi" },
  { id: "lauki-chana-dal", name: "Lauki chana dal", serving: "1 katori", cal: 120, p: 6, c: 16, f: 3.5, cat: "Everyday sabzi" },
  { id: "lauki-kofta", name: "Lauki kofta curry", serving: "1 katori (2 kofta)", cal: 175, p: 5, c: 16, f: 10, cat: "Everyday sabzi" },
  { id: "lauki-raita", name: "Lauki raita", serving: "1 katori", cal: 65, p: 4, c: 7, f: 2.5, cat: "Everyday sabzi" },
  { id: "tori-tamatar", name: "Tori tamatar / turai sabzi", serving: "1 katori", cal: 70, p: 2, c: 8, f: 3.5, cat: "Everyday sabzi" },
  { id: "tori-chana-dal", name: "Tori chana dal", serving: "1 katori", cal: 120, p: 6, c: 16, f: 3.5, cat: "Everyday sabzi" },
  { id: "parwal-aloo", name: "Parwal aloo ki sabzi", serving: "1 katori", cal: 115, p: 2.5, c: 15, f: 5, cat: "Everyday sabzi" },
  { id: "parwal-masala", name: "Parwal masala", serving: "1 katori", cal: 95, p: 2.5, c: 10, f: 5.5, cat: "Everyday sabzi" },
  { id: "sem-aloo", name: "Sem aloo / flat beans potato", serving: "1 katori", cal: 115, p: 3.5, c: 16, f: 4.5, cat: "Everyday sabzi" },
  { id: "gawar-phali", name: "Gawar phali / cluster beans sabzi", serving: "1 katori", cal: 90, p: 3.5, c: 11, f: 4, cat: "Everyday sabzi" },
  { id: "chaulai-sabzi", name: "Chaulai / amaranth leaves sabzi", serving: "1 katori", cal: 75, p: 4, c: 7, f: 3.5, cat: "Everyday sabzi" },
  { id: "bathua-sabzi", name: "Bathua saag", serving: "1 katori", cal: 75, p: 4, c: 8, f: 3, cat: "Everyday sabzi" },
  { id: "mooli-patta", name: "Mooli patta ki sabzi", serving: "1 katori", cal: 70, p: 3, c: 8, f: 3, cat: "Everyday sabzi" },
  { id: "palak-corn", name: "Palak corn", serving: "1 katori", cal: 120, p: 5, c: 14, f: 5, cat: "Everyday sabzi" },
  { id: "palak-chana", name: "Palak chana", serving: "1 katori", cal: 145, p: 7, c: 18, f: 5, cat: "Everyday sabzi" },
  { id: "palak-mushroom", name: "Palak mushroom", serving: "1 katori", cal: 105, p: 5, c: 8, f: 6, cat: "Everyday sabzi" },
  { id: "methi-matar-malai", name: "Methi matar malai", serving: "1 katori", cal: 210, p: 6, c: 14, f: 15, cat: "Everyday sabzi" },
  { id: "matar-nimona", name: "Matar ka nimona", serving: "1 katori", cal: 145, p: 7, c: 19, f: 5, cat: "Everyday sabzi" },
  { id: "green-peas-masala", name: "Matar masala / green peas curry", serving: "1 katori", cal: 135, p: 7, c: 19, f: 4, cat: "Everyday sabzi" },
  { id: "kacche-kele-sabzi", name: "Kacche kele ki sabzi (raw banana)", serving: "1 katori", cal: 135, p: 2, c: 24, f: 4, cat: "Everyday sabzi" },
  { id: "kaddu-sabzi", name: "Kaddu / pumpkin sabzi", serving: "1 katori", cal: 85, p: 2, c: 12, f: 3.5, cat: "Everyday sabzi" },
  { id: "khatta-meetha-kaddu", name: "Khatta meetha kaddu", serving: "1 katori", cal: 105, p: 2, c: 17, f: 3.5, cat: "Everyday sabzi" },
  { id: "shakarkandi-sabzi", name: "Shakarkandi / sweet potato sabzi", serving: "1 katori", cal: 150, p: 2.5, c: 28, f: 3.5, cat: "Everyday sabzi" },
  { id: "beetroot-sabzi", name: "Beetroot sabzi", serving: "1 katori", cal: 90, p: 2.5, c: 13, f: 3.5, cat: "Everyday sabzi" },
  { id: "carrot-peas-sabzi", name: "Gajar matar ki sabzi", serving: "1 katori", cal: 100, p: 3.5, c: 13, f: 4, cat: "Everyday sabzi" },
  { id: "mixed-sprouts-sabzi", name: "Mixed sprouts sabzi", serving: "1 katori", cal: 130, p: 9, c: 18, f: 3, cat: "Everyday sabzi" },
  { id: "besan-gatta-dry", name: "Sukhe besan ke gatte", serving: "1 katori", cal: 170, p: 8, c: 17, f: 8, cat: "Everyday sabzi" },
  { id: "sev-tamatar", name: "Sev tamatar / sev tameta sabzi", serving: "1 katori", cal: 185, p: 5, c: 20, f: 10, cat: "Everyday sabzi" },
  { id: "papad-ki-sabzi", name: "Papad ki sabzi", serving: "1 katori", cal: 145, p: 5, c: 12, f: 8, cat: "Everyday sabzi" },
  { id: "mangodi-aloo", name: "Mangodi aloo ki sabzi", serving: "1 katori", cal: 165, p: 7, c: 21, f: 6, cat: "Everyday sabzi" },
  { id: "mangodi-lauki", name: "Mangodi lauki", serving: "1 katori", cal: 125, p: 7, c: 15, f: 4.5, cat: "Everyday sabzi" },

  /* ---------------- Beans, dals & home curries ---------------- */
  { id: "kala-chana-curry", name: "Kala chana curry", serving: "1 katori", cal: 165, p: 8, c: 24, f: 4.5, cat: "Beans & dals" },
  { id: "sukha-kala-chana", name: "Sukha kala chana", serving: "1 katori", cal: 175, p: 9, c: 25, f: 4.5, cat: "Beans & dals" },
  { id: "safed-matar-curry", name: "Safed matar / white peas curry", serving: "1 katori", cal: 155, p: 8, c: 24, f: 3.5, cat: "Beans & dals" },
  { id: "hara-chana", name: "Hara chana / chholiya curry", serving: "1 katori", cal: 145, p: 8, c: 20, f: 4, cat: "Beans & dals" },
  { id: "whole-moong-curry", name: "Sabut moong curry", serving: "1 katori", cal: 150, p: 9, c: 23, f: 3, cat: "Beans & dals" },
  { id: "whole-masoor", name: "Sabut masoor dal", serving: "1 katori", cal: 155, p: 9, c: 23, f: 3.5, cat: "Beans & dals" },
  { id: "moth-bean-curry", name: "Moth / matki curry", serving: "1 katori", cal: 155, p: 9, c: 22, f: 3.5, cat: "Beans & dals" },
  { id: "matki-usal", name: "Matki usal", serving: "1 katori", cal: 150, p: 9, c: 21, f: 3.5, cat: "Beans & dals" },
  { id: "moong-usal", name: "Moong usal", serving: "1 katori", cal: 145, p: 9, c: 20, f: 3.5, cat: "Beans & dals" },
  { id: "chana-usal", name: "Chana usal", serving: "1 katori", cal: 165, p: 8, c: 23, f: 4.5, cat: "Beans & dals" },
  { id: "kulthi-dal", name: "Kulthi / horse gram dal", serving: "1 katori", cal: 140, p: 9, c: 20, f: 2.5, cat: "Beans & dals" },
  { id: "moong-dal-tadka", name: "Moong dal tadka", serving: "1 katori", cal: 130, p: 7, c: 17, f: 4.5, cat: "Beans & dals" },
  { id: "masoor-dal-tadka", name: "Masoor dal tadka", serving: "1 katori", cal: 140, p: 8, c: 19, f: 4.5, cat: "Beans & dals" },
  { id: "toor-dal-tadka", name: "Toor / arhar dal tadka", serving: "1 katori", cal: 135, p: 7, c: 18, f: 4.5, cat: "Beans & dals" },
  { id: "chana-dal-tadka", name: "Chana dal tadka", serving: "1 katori", cal: 155, p: 8, c: 21, f: 4.5, cat: "Beans & dals" },
  { id: "dhaba-dal", name: "Dhaba dal", serving: "1 katori", cal: 160, p: 8, c: 19, f: 6, cat: "Beans & dals" },
  { id: "maa-ki-dal", name: "Maa ki dal (whole urad)", serving: "1 katori", cal: 165, p: 8, c: 20, f: 6, cat: "Beans & dals" },
  { id: "dal-dhokli", name: "Dal dhokli", serving: "1 bowl", cal: 260, p: 10, c: 42, f: 6, cat: "Beans & dals" },
  { id: "gujarati-dal", name: "Gujarati dal", serving: "1 katori", cal: 130, p: 6, c: 18, f: 4, cat: "Beans & dals" },
  { id: "gujarati-kadhi", name: "Gujarati kadhi", serving: "1 katori", cal: 90, p: 4, c: 10, f: 4, cat: "Beans & dals" },
  { id: "maharashtrian-amti", name: "Maharashtrian amti dal", serving: "1 katori", cal: 135, p: 7, c: 18, f: 4.5, cat: "Beans & dals" },
  { id: "varan", name: "Varan dal", serving: "1 katori", cal: 110, p: 7, c: 17, f: 1.5, cat: "Beans & dals" },
  { id: "cholar-dal", name: "Bengali cholar dal", serving: "1 katori", cal: 165, p: 7, c: 22, f: 6, cat: "Beans & dals" },
  { id: "biuli-dal", name: "Biuli / urad dal Bengali style", serving: "1 katori", cal: 135, p: 7, c: 18, f: 4.5, cat: "Beans & dals" },
  { id: "dalma", name: "Odia dalma (dal with vegetables)", serving: "1 bowl", cal: 165, p: 8, c: 23, f: 5, cat: "Beans & dals" },
  { id: "kootu", name: "Vegetable kootu", serving: "1 katori", cal: 135, p: 6, c: 15, f: 6, cat: "Beans & dals" },
  { id: "keerai-kootu", name: "Keerai kootu (greens and dal)", serving: "1 katori", cal: 125, p: 7, c: 14, f: 5, cat: "Beans & dals" },
  { id: "mor-kuzhambu", name: "Mor kuzhambu", serving: "1 katori", cal: 95, p: 4, c: 9, f: 5, cat: "Beans & dals" },
  { id: "kara-kuzhambu", name: "Kara kuzhambu", serving: "1 katori", cal: 105, p: 3, c: 12, f: 5, cat: "Beans & dals" },
  { id: "puli-kuzhambu", name: "Puli kuzhambu", serving: "1 katori", cal: 100, p: 3, c: 13, f: 4.5, cat: "Beans & dals" },
  { id: "majjige-huli", name: "Majjige huli", serving: "1 katori", cal: 100, p: 4, c: 10, f: 5, cat: "Beans & dals" },

  /* ---------------- Gujarati & Rajasthani home food ---------------- */
  { id: "undhiyu", name: "Undhiyu", serving: "1 katori", cal: 190, p: 6, c: 22, f: 9, cat: "Gujarati & Rajasthani" },
  { id: "ringna-bateta", name: "Ringna bateta / baingan aloo", serving: "1 katori", cal: 115, p: 2.5, c: 15, f: 5.5, cat: "Gujarati & Rajasthani" },
  { id: "bharela-ringna", name: "Bharela ringna (stuffed brinjal)", serving: "1 katori", cal: 145, p: 4, c: 13, f: 9, cat: "Gujarati & Rajasthani" },
  { id: "gujarati-tuvar", name: "Tuvar lilva sabzi", serving: "1 katori", cal: 145, p: 8, c: 20, f: 4, cat: "Gujarati & Rajasthani" },
  { id: "dudhi-muthia", name: "Dudhi muthia", serving: "4 pieces", cal: 155, p: 5, c: 23, f: 5, cat: "Gujarati & Rajasthani" },
  { id: "handvo", name: "Handvo", serving: "1 medium slice", cal: 170, p: 7, c: 25, f: 5, cat: "Gujarati & Rajasthani" },
  { id: "khandvi", name: "Khandvi", serving: "6 rolls", cal: 125, p: 5, c: 14, f: 5.5, cat: "Gujarati & Rajasthani" },
  { id: "patra", name: "Patra / alu vadi", serving: "4 pieces", cal: 150, p: 4, c: 22, f: 5.5, cat: "Gujarati & Rajasthani" },
  { id: "fafda", name: "Fafda", serving: "50 g", cal: 250, p: 8, c: 28, f: 12, cat: "Gujarati & Rajasthani" },
  { id: "khichu", name: "Khichu", serving: "1 bowl", cal: 165, p: 3, c: 31, f: 3, cat: "Gujarati & Rajasthani" },
  { id: "bajra-khichdi", name: "Bajra khichdi", serving: "1 bowl", cal: 230, p: 8, c: 40, f: 5, cat: "Gujarati & Rajasthani" },
  { id: "ker-sangri", name: "Ker sangri", serving: "1 katori", cal: 145, p: 4, c: 13, f: 9, cat: "Gujarati & Rajasthani" },
  { id: "rajasthani-kadhi", name: "Rajasthani kadhi", serving: "1 katori", cal: 110, p: 5, c: 10, f: 6, cat: "Gujarati & Rajasthani" },
  { id: "panchkuta", name: "Panchkuta sabzi", serving: "1 katori", cal: 150, p: 4, c: 14, f: 9, cat: "Gujarati & Rajasthani" },
  { id: "raab", name: "Bajra raab", serving: "1 bowl", cal: 150, p: 4, c: 24, f: 4.5, cat: "Gujarati & Rajasthani" },
  { id: "dal-baati", name: "Dal baati", serving: "2 baati + dal", cal: 520, p: 15, c: 72, f: 20, cat: "Gujarati & Rajasthani" },
  { id: "dal-baati-churma", name: "Dal baati churma", serving: "1 plate", cal: 750, p: 18, c: 105, f: 30, cat: "Gujarati & Rajasthani" },

  /* ---------------- Maharashtrian home food ---------------- */
  { id: "bharli-vangi", name: "Bharli vangi (stuffed brinjal)", serving: "1 katori", cal: 160, p: 5, c: 14, f: 10, cat: "Maharashtrian" },
  { id: "zunka", name: "Zunka / jhunka", serving: "1 katori", cal: 160, p: 8, c: 15, f: 7.5, cat: "Maharashtrian" },
  { id: "bharli-bhendi", name: "Bharli bhendi", serving: "1 katori", cal: 135, p: 3, c: 11, f: 8.5, cat: "Maharashtrian" },
  { id: "batata-bhaji", name: "Batata bhaji", serving: "1 katori", cal: 140, p: 3, c: 20, f: 5.5, cat: "Maharashtrian" },
  { id: "kanda-batata", name: "Kanda batata bhaji", serving: "1 katori", cal: 145, p: 3, c: 20, f: 6, cat: "Maharashtrian" },
  { id: "val-usal", name: "Val usal", serving: "1 katori", cal: 165, p: 9, c: 22, f: 5, cat: "Maharashtrian" },
  { id: "sprouted-moong-usal", name: "Sprouted moong usal", serving: "1 katori", cal: 140, p: 9, c: 19, f: 3.5, cat: "Maharashtrian" },
  { id: "thalipeeth", name: "Thalipeeth", serving: "1 piece", cal: 190, p: 6, c: 29, f: 6, cat: "Maharashtrian" },
  { id: "sabudana-thalipeeth", name: "Sabudana thalipeeth", serving: "1 piece", cal: 220, p: 3, c: 36, f: 7.5, cat: "Maharashtrian" },
  { id: "kothimbir-vadi", name: "Kothimbir vadi", serving: "4 pieces", cal: 170, p: 6, c: 20, f: 8, cat: "Maharashtrian" },
  { id: "ukadiche-modak", name: "Ukadiche modak", serving: "1 piece", cal: 125, p: 2, c: 20, f: 4.5, cat: "Maharashtrian" },
  { id: "sol-kadhi", name: "Sol kadhi", serving: "1 glass", cal: 70, p: 1, c: 5, f: 5, cat: "Maharashtrian" },
  { id: "pithla-bhakri", name: "Pithla bhakri", serving: "1 plate", cal: 390, p: 12, c: 60, f: 11, cat: "Maharashtrian" },

  /* ---------------- Bengali, Odia & eastern home food ---------------- */
  { id: "aloo-posto", name: "Aloo posto", serving: "1 katori", cal: 165, p: 4, c: 17, f: 10, cat: "Eastern Indian" },
  { id: "begun-bhaja", name: "Begun bhaja", serving: "4 slices", cal: 145, p: 2, c: 11, f: 11, cat: "Eastern Indian" },
  { id: "shukto", name: "Shukto", serving: "1 katori", cal: 120, p: 3, c: 13, f: 6.5, cat: "Eastern Indian" },
  { id: "labra", name: "Labra mixed vegetable", serving: "1 katori", cal: 105, p: 3, c: 14, f: 4.5, cat: "Eastern Indian" },
  { id: "dhokar-dalna", name: "Dhokar dalna", serving: "1 katori", cal: 180, p: 8, c: 20, f: 8, cat: "Eastern Indian" },
  { id: "chanar-dalna", name: "Chanar dalna", serving: "1 katori", cal: 190, p: 10, c: 14, f: 11, cat: "Eastern Indian" },
  { id: "potol-dorma", name: "Potol dorma", serving: "1 katori", cal: 155, p: 5, c: 13, f: 9, cat: "Eastern Indian" },
  { id: "ghugni", name: "Ghugni (yellow peas curry)", serving: "1 bowl", cal: 170, p: 9, c: 27, f: 3.5, cat: "Eastern Indian" },
  { id: "luchi", name: "Luchi", serving: "1 piece", cal: 100, p: 2, c: 13, f: 4.5, cat: "Eastern Indian" },
  { id: "radha-ballabhi", name: "Radha ballabhi", serving: "1 piece", cal: 170, p: 5, c: 23, f: 7, cat: "Eastern Indian" },
  { id: "machher-jhol", name: "Machher jhol (Bengali fish curry)", serving: "1 piece + gravy", cal: 190, p: 19, c: 7, f: 10, cat: "Eastern Indian" },
  { id: "shorshe-mach", name: "Shorshe mach (mustard fish)", serving: "1 piece + gravy", cal: 220, p: 20, c: 5, f: 14, cat: "Eastern Indian" },
  { id: "doi-mach", name: "Doi mach", serving: "1 piece + gravy", cal: 215, p: 20, c: 7, f: 13, cat: "Eastern Indian" },
  { id: "bhapa-ilish", name: "Bhapa ilish", serving: "1 piece", cal: 260, p: 20, c: 3, f: 19, cat: "Eastern Indian" },
  { id: "chingri-malai", name: "Chingri malai curry", serving: "1 katori", cal: 255, p: 20, c: 7, f: 17, cat: "Eastern Indian" },
  { id: "chicken-kosha", name: "Bengali chicken kosha", serving: "1 katori", cal: 295, p: 23, c: 8, f: 19, cat: "Eastern Indian" },
  { id: "mutton-kosha", name: "Mutton kosha", serving: "1 katori", cal: 345, p: 23, c: 7, f: 25, cat: "Eastern Indian" },
  { id: "odia-santula", name: "Odia santula", serving: "1 katori", cal: 80, p: 3, c: 11, f: 3, cat: "Eastern Indian" },
  { id: "besara", name: "Odia besara vegetable curry", serving: "1 katori", cal: 115, p: 4, c: 12, f: 6, cat: "Eastern Indian" },
  { id: "pakhala-bhata", name: "Pakhala bhata", serving: "1 bowl", cal: 180, p: 4, c: 38, f: 1, cat: "Eastern Indian" },
  { id: "litti-chokha", name: "Litti chokha", serving: "2 litti + chokha", cal: 430, p: 13, c: 67, f: 12, cat: "Eastern Indian" },
  { id: "baingan-chokha", name: "Baingan chokha", serving: "1 katori", cal: 95, p: 2.5, c: 10, f: 5, cat: "Eastern Indian" },
  { id: "aloo-chokha", name: "Aloo chokha", serving: "1 katori", cal: 135, p: 3, c: 21, f: 5, cat: "Eastern Indian" },
  { id: "sattu-paratha", name: "Sattu paratha", serving: "1 piece", cal: 260, p: 10, c: 38, f: 8, cat: "Eastern Indian" },
  { id: "dal-pitha", name: "Dal pitha", serving: "4 pieces", cal: 210, p: 8, c: 39, f: 2.5, cat: "Eastern Indian" },

  /* ---------------- South Indian home food ---------------- */
  { id: "avial", name: "Avial", serving: "1 katori", cal: 145, p: 4, c: 14, f: 8.5, cat: "South Indian home food" },
  { id: "olan", name: "Olan", serving: "1 katori", cal: 115, p: 3, c: 12, f: 6.5, cat: "South Indian home food" },
  { id: "erissery", name: "Erissery", serving: "1 katori", cal: 155, p: 6, c: 20, f: 6, cat: "South Indian home food" },
  { id: "cabbage-thoran", name: "Cabbage thoran", serving: "1 katori", cal: 105, p: 3, c: 9, f: 6.5, cat: "South Indian home food" },
  { id: "beans-thoran", name: "Beans thoran", serving: "1 katori", cal: 110, p: 3.5, c: 10, f: 6.5, cat: "South Indian home food" },
  { id: "beetroot-thoran", name: "Beetroot thoran", serving: "1 katori", cal: 115, p: 3, c: 13, f: 6, cat: "South Indian home food" },
  { id: "carrot-poriyal", name: "Carrot poriyal", serving: "1 katori", cal: 95, p: 2.5, c: 11, f: 5, cat: "South Indian home food" },
  { id: "cabbage-poriyal", name: "Cabbage poriyal", serving: "1 katori", cal: 90, p: 2.5, c: 8, f: 5.5, cat: "South Indian home food" },
  { id: "beetroot-poriyal", name: "Beetroot poriyal", serving: "1 katori", cal: 105, p: 2.5, c: 12, f: 5.5, cat: "South Indian home food" },
  { id: "raw-banana-poriyal", name: "Raw banana poriyal", serving: "1 katori", cal: 135, p: 2, c: 22, f: 4.5, cat: "South Indian home food" },
  { id: "potato-podimas", name: "Urulai potato podimas", serving: "1 katori", cal: 135, p: 3, c: 20, f: 5.5, cat: "South Indian home food" },
  { id: "sundal-chana", name: "Chana sundal", serving: "1 katori", cal: 160, p: 8, c: 22, f: 5, cat: "South Indian home food" },
  { id: "sundal-moong", name: "Green gram sundal", serving: "1 katori", cal: 145, p: 9, c: 20, f: 4, cat: "South Indian home food" },
  { id: "kadala-curry", name: "Kerala kadala curry", serving: "1 katori", cal: 185, p: 8, c: 23, f: 7, cat: "South Indian home food" },
  { id: "veg-stew", name: "Kerala vegetable stew", serving: "1 katori", cal: 140, p: 4, c: 14, f: 8, cat: "South Indian home food" },
  { id: "idiyappam", name: "Idiyappam", serving: "2 pieces", cal: 140, p: 3, c: 30, f: 0.5, cat: "South Indian home food" },
  { id: "puttu", name: "Puttu", serving: "1 cylinder", cal: 210, p: 5, c: 42, f: 2.5, cat: "South Indian home food" },
  { id: "appam-stew", name: "Appam with vegetable stew", serving: "2 appam + stew", cal: 350, p: 8, c: 51, f: 12, cat: "South Indian home food" },
  { id: "idiyappam-kadala", name: "Idiyappam with kadala curry", serving: "2 idiyappam + curry", cal: 330, p: 11, c: 53, f: 8, cat: "South Indian home food" },
  { id: "puttu-kadala", name: "Puttu with kadala curry", serving: "1 plate", cal: 395, p: 13, c: 65, f: 9, cat: "South Indian home food" },
  { id: "kerala-parotta", name: "Kerala parotta", serving: "1 piece", cal: 260, p: 5, c: 36, f: 11, cat: "South Indian home food" },
  { id: "akki-roti", name: "Akki roti", serving: "1 piece", cal: 150, p: 3, c: 28, f: 3, cat: "South Indian home food" },
  { id: "ragi-mudde", name: "Ragi mudde", serving: "1 ball", cal: 180, p: 5, c: 38, f: 1.5, cat: "South Indian home food" },
  { id: "chow-chow-bath", name: "Chow chow bath", serving: "1 plate", cal: 320, p: 6, c: 49, f: 12, cat: "South Indian home food" },
  { id: "lemon-sevai", name: "Lemon sevai", serving: "1 cup", cal: 210, p: 4, c: 36, f: 6, cat: "South Indian home food" },
  { id: "coconut-sevai", name: "Coconut sevai", serving: "1 cup", cal: 240, p: 4, c: 36, f: 9, cat: "South Indian home food" },
  { id: "tamarind-sevai", name: "Tamarind sevai", serving: "1 cup", cal: 225, p: 4, c: 38, f: 6.5, cat: "South Indian home food" },
  { id: "adai", name: "Adai dosa", serving: "1 piece", cal: 155, p: 7, c: 22, f: 4.5, cat: "South Indian home food" },
  { id: "kuzhi-paniyaram", name: "Kuzhi paniyaram", serving: "6 pieces", cal: 210, p: 5, c: 32, f: 7, cat: "South Indian home food" },
  { id: "appe", name: "Appe / paddu", serving: "6 pieces", cal: 200, p: 5, c: 31, f: 6.5, cat: "South Indian home food" },
  { id: "akki-shavige", name: "Akki shavige upma", serving: "1 cup", cal: 205, p: 4, c: 35, f: 6, cat: "South Indian home food" },

  /* ---------------- Himalayan, Kashmiri & Northeast ---------------- */
  { id: "haak-saag", name: "Kashmiri haak saag", serving: "1 katori", cal: 80, p: 4, c: 8, f: 3.5, cat: "Himalayan & Northeast" },
  { id: "nadru-yakhni", name: "Nadru yakhni", serving: "1 katori", cal: 145, p: 4, c: 17, f: 7, cat: "Himalayan & Northeast" },
  { id: "rajma-gogji", name: "Rajma gogji", serving: "1 katori", cal: 180, p: 9, c: 27, f: 4.5, cat: "Himalayan & Northeast" },
  { id: "kashmiri-rajma", name: "Kashmiri rajma", serving: "1 katori", cal: 175, p: 9, c: 26, f: 4, cat: "Himalayan & Northeast" },
  { id: "rogan-josh", name: "Rogan josh", serving: "1 katori", cal: 330, p: 24, c: 6, f: 24, cat: "Himalayan & Northeast" },
  { id: "mutton-yakhni", name: "Mutton yakhni", serving: "1 katori", cal: 285, p: 23, c: 6, f: 19, cat: "Himalayan & Northeast" },
  { id: "thukpa-veg", name: "Veg thukpa", serving: "1 bowl", cal: 240, p: 8, c: 41, f: 5, cat: "Himalayan & Northeast" },
  { id: "thukpa-chicken", name: "Chicken thukpa", serving: "1 bowl", cal: 295, p: 20, c: 40, f: 6, cat: "Himalayan & Northeast" },
  { id: "tingmo", name: "Tingmo steamed bread", serving: "1 piece", cal: 145, p: 4, c: 29, f: 1, cat: "Himalayan & Northeast" },
  { id: "sel-roti", name: "Sel roti", serving: "1 piece", cal: 170, p: 3, c: 27, f: 6, cat: "Himalayan & Northeast" },
  { id: "aloo-datshi", name: "Aloo datshi", serving: "1 katori", cal: 180, p: 7, c: 18, f: 10, cat: "Himalayan & Northeast" },

  /* ---------------- Home-style non-vegetarian dishes ---------------- */
  { id: "home-chicken-light", name: "Home-style chicken curry (light oil)", serving: "1 katori", cal: 205, p: 23, c: 5, f: 10, cat: "Home non-veg" },
  { id: "chicken-bhuna", name: "Chicken bhuna", serving: "1 katori", cal: 285, p: 25, c: 7, f: 18, cat: "Home non-veg" },
  { id: "chicken-do-pyaza", name: "Chicken do pyaza", serving: "1 katori", cal: 270, p: 23, c: 8, f: 17, cat: "Home non-veg" },
  { id: "chicken-palak", name: "Chicken palak", serving: "1 katori", cal: 245, p: 25, c: 6, f: 14, cat: "Home non-veg" },
  { id: "chicken-keema", name: "Chicken keema", serving: "1 katori", cal: 230, p: 23, c: 5, f: 13, cat: "Home non-veg" },
  { id: "chicken-sukka", name: "Chicken sukka", serving: "1 katori", cal: 295, p: 24, c: 6, f: 20, cat: "Home non-veg" },
  { id: "chicken-roast", name: "Home-style chicken roast", serving: "150 g", cal: 280, p: 31, c: 3, f: 16, cat: "Home non-veg" },
  { id: "mutton-keema", name: "Mutton keema", serving: "1 katori", cal: 285, p: 20, c: 5, f: 21, cat: "Home non-veg" },
  { id: "mutton-stew", name: "Mutton stew", serving: "1 katori", cal: 255, p: 21, c: 8, f: 16, cat: "Home non-veg" },
  { id: "egg-tamatar", name: "Anda tamatar / egg tomato curry", serving: "2 eggs + gravy", cal: 245, p: 14, c: 8, f: 17, cat: "Home non-veg" },
  { id: "egg-potato-curry", name: "Egg potato curry", serving: "1 egg + potato + gravy", cal: 220, p: 8, c: 18, f: 13, cat: "Home non-veg" },
  { id: "boiled-egg-masala", name: "Boiled egg masala", serving: "2 eggs", cal: 205, p: 14, c: 5, f: 14, cat: "Home non-veg" },
  { id: "fish-jhol-light", name: "Home-style fish jhol (light)", serving: "1 piece + gravy", cal: 165, p: 19, c: 5, f: 8, cat: "Home non-veg" },
  { id: "fish-masala", name: "Fish masala", serving: "1 piece + gravy", cal: 215, p: 21, c: 6, f: 12, cat: "Home non-veg" },
  { id: "fish-tawa", name: "Tawa fish", serving: "150 g", cal: 225, p: 29, c: 3, f: 11, cat: "Home non-veg" },
  { id: "fish-coconut-curry", name: "Coconut fish curry", serving: "1 katori", cal: 240, p: 20, c: 6, f: 16, cat: "Home non-veg" },
  { id: "prawn-masala", name: "Prawn masala", serving: "1 katori", cal: 205, p: 23, c: 6, f: 10, cat: "Home non-veg" },
  { id: "omelette-one", name: "Masala omelette (1 egg)", serving: "1 egg", cal: 105, p: 7, c: 2, f: 8, cat: "Home non-veg" },
  { id: "half-fry-eggs", name: "Half fry / sunny-side eggs", serving: "2 eggs", cal: 190, p: 13, c: 1, f: 15, cat: "Home non-veg" },
  { id: "boiled-eggs-two", name: "Boiled eggs", serving: "2 large", cal: 144, p: 12.6, c: 0.8, f: 9.6, cat: "Home non-veg" },

  /* ---------------- Everyday breads, grains & breakfast ---------------- */
  { id: "roti-no-oil", name: "Roti / chapati (no oil)", serving: "1 medium", cal: 85, p: 3, c: 17, f: 0.7, cat: "Everyday staples" },
  { id: "roti-ghee", name: "Roti with ghee", serving: "1 medium", cal: 125, p: 3, c: 17, f: 5, cat: "Everyday staples" },
  { id: "small-roti", name: "Small roti / chapati", serving: "1 small", cal: 65, p: 2.2, c: 13, f: 0.5, cat: "Everyday staples" },
  { id: "multigrain-roti", name: "Multigrain roti", serving: "1 medium", cal: 100, p: 4, c: 18, f: 1.5, cat: "Everyday staples" },
  { id: "soy-roti", name: "Soya atta roti", serving: "1 medium", cal: 105, p: 6, c: 16, f: 2, cat: "Everyday staples" },
  { id: "rice-half-cup", name: "Cooked white rice", serving: "1/2 cup (80 g)", cal: 103, p: 2.2, c: 22.5, f: 0.2, cat: "Everyday staples" },
  { id: "rice-katori", name: "Cooked rice", serving: "1 medium katori", cal: 170, p: 3.5, c: 37, f: 0.3, cat: "Everyday staples" },
  { id: "brown-rice", name: "Cooked brown rice", serving: "1 cup", cal: 216, p: 5, c: 45, f: 1.8, cat: "Everyday staples" },
  { id: "hand-pounded-rice", name: "Hand-pounded red rice", serving: "1 cup", cal: 215, p: 5, c: 45, f: 1.5, cat: "Everyday staples" },
  { id: "millet-khichdi", name: "Mixed millet khichdi", serving: "1 bowl", cal: 225, p: 8, c: 40, f: 4, cat: "Everyday staples" },
  { id: "foxtail-millet-upma", name: "Foxtail millet upma", serving: "1 cup", cal: 200, p: 6, c: 35, f: 4.5, cat: "Everyday staples" },
  { id: "ragi-porridge", name: "Ragi porridge", serving: "1 bowl", cal: 160, p: 5, c: 30, f: 2.5, cat: "Everyday staples" },
  { id: "savory-daliya", name: "Namkeen vegetable daliya", serving: "1 bowl", cal: 180, p: 6, c: 31, f: 4, cat: "Everyday staples" },
  { id: "milk-daliya", name: "Milk daliya", serving: "1 bowl", cal: 220, p: 8, c: 36, f: 5, cat: "Everyday staples" },
  { id: "oats-upma", name: "Oats upma", serving: "1 bowl", cal: 180, p: 6, c: 27, f: 5.5, cat: "Everyday staples" },
  { id: "oats-chilla", name: "Oats chilla", serving: "1 piece", cal: 125, p: 5, c: 17, f: 4.5, cat: "Everyday staples" },
  { id: "paneer-chilla", name: "Paneer stuffed chilla", serving: "1 piece", cal: 210, p: 12, c: 16, f: 11, cat: "Everyday staples" },
  { id: "suji-chilla", name: "Suji chilla", serving: "1 piece", cal: 135, p: 4, c: 20, f: 4.5, cat: "Everyday staples" },
  { id: "veg-suji-toast", name: "Vegetable suji toast", serving: "1 slice", cal: 145, p: 4, c: 20, f: 5.5, cat: "Everyday staples" },
  { id: "paneer-sandwich", name: "Paneer sandwich", serving: "1 sandwich", cal: 300, p: 15, c: 34, f: 12, cat: "Everyday staples" },
  { id: "egg-sandwich", name: "Egg sandwich", serving: "1 sandwich", cal: 275, p: 14, c: 31, f: 11, cat: "Everyday staples" },
  { id: "aloo-sandwich", name: "Aloo sandwich", serving: "1 sandwich", cal: 255, p: 7, c: 42, f: 7, cat: "Everyday staples" },
  { id: "sprouts-sandwich", name: "Sprouts sandwich", serving: "1 sandwich", cal: 235, p: 10, c: 38, f: 5, cat: "Everyday staples" },
  { id: "moong-dal-dosa", name: "Moong dal dosa", serving: "1 piece", cal: 125, p: 7, c: 17, f: 3.5, cat: "Everyday staples" },
  { id: "paneer-dosa", name: "Paneer dosa", serving: "1 piece", cal: 310, p: 13, c: 30, f: 16, cat: "Everyday staples" },
  { id: "upma-veg", name: "Vegetable upma", serving: "1 bowl", cal: 205, p: 5, c: 31, f: 7, cat: "Everyday staples" },
  { id: "vermicelli-kheer", name: "Milk vermicelli / seviyan", serving: "1 bowl", cal: 210, p: 6, c: 32, f: 7, cat: "Everyday staples" },

  /* ---------------- Practical home meal combinations ---------------- */
  { id: "combo-roti-aloo-tamatar", name: "2 roti + aloo tamatar", serving: "1 meal", cal: 335, p: 8.5, c: 53, f: 9, cat: "Home meal combos" },
  { id: "combo-roti-dal", name: "2 roti + 1 katori dal", serving: "1 meal", cal: 330, p: 13, c: 52, f: 7, cat: "Home meal combos" },
  { id: "combo-roti-dal-sabzi", name: "2 roti + dal + sabzi", serving: "1 meal", cal: 440, p: 16, c: 65, f: 12, cat: "Home meal combos" },
  { id: "combo-roti-paneer", name: "2 roti + paneer sabzi", serving: "1 meal", cal: 460, p: 18, c: 44, f: 23, cat: "Home meal combos" },
  { id: "combo-roti-chicken", name: "2 roti + home chicken curry", serving: "1 meal", cal: 410, p: 29, c: 39, f: 15, cat: "Home meal combos" },
  { id: "combo-rice-dal-sabzi", name: "Rice + dal + sabzi", serving: "1 meal", cal: 440, p: 14, c: 72, f: 10, cat: "Home meal combos" },
  { id: "combo-rice-fish", name: "Rice + fish curry", serving: "1 meal", cal: 385, p: 23, c: 50, f: 10, cat: "Home meal combos" },
  { id: "combo-rice-chicken", name: "Rice + home chicken curry", serving: "1 meal", cal: 410, p: 27, c: 50, f: 11, cat: "Home meal combos" },
  { id: "combo-rice-egg", name: "Rice + egg curry", serving: "1 meal", cal: 425, p: 18, c: 53, f: 16, cat: "Home meal combos" },
  { id: "combo-roti-bhindi", name: "2 roti + bhindi sabzi", serving: "1 meal", cal: 275, p: 8.5, c: 44, f: 7.5, cat: "Home meal combos" },
  { id: "combo-roti-lauki", name: "2 roti + lauki sabzi", serving: "1 meal", cal: 235, p: 8, c: 42, f: 4.5, cat: "Home meal combos" },
  { id: "combo-roti-chana", name: "2 roti + kala chana", serving: "1 meal", cal: 335, p: 14, c: 58, f: 6, cat: "Home meal combos" },
  { id: "combo-roti-rajma", name: "2 roti + rajma", serving: "1 meal", cal: 345, p: 14, c: 58, f: 6.5, cat: "Home meal combos" },
  { id: "combo-khichdi-curd", name: "Moong khichdi + curd", serving: "1 meal", cal: 290, p: 13, c: 43, f: 8, cat: "Home meal combos" },
  { id: "combo-paratha-curd", name: "1 aloo paratha + curd", serving: "1 meal", cal: 350, p: 9.5, c: 49, f: 13, cat: "Home meal combos" },
  { id: "combo-poha-tea", name: "Poha + masala chai", serving: "1 breakfast", cal: 240, p: 5, c: 44, f: 5, cat: "Home meal combos" },
  { id: "combo-idli-sambar", name: "2 idli + sambar", serving: "1 meal", cal: 168, p: 8, c: 28, f: 2.7, cat: "Home meal combos" },
  { id: "combo-dosa-sambar", name: "Plain dosa + sambar", serving: "1 meal", cal: 223, p: 7, c: 29, f: 8.4, cat: "Home meal combos" },
  { id: "combo-egg-roti", name: "2 eggs + 2 roti", serving: "1 meal", cal: 314, p: 18.6, c: 34.8, f: 11, cat: "Home meal combos" },
  { id: "combo-paneer-rice", name: "Paneer curry + rice", serving: "1 meal", cal: 405, p: 13, c: 55, f: 15, cat: "Home meal combos" },

  /* ---------------- Salads, raitas, pickles & small sides ---------------- */
  { id: "kachumber-salad", name: "Kachumber salad", serving: "1 bowl", cal: 45, p: 2, c: 9, f: 0.5, cat: "Salads & sides" },
  { id: "onion-salad", name: "Onion salad with lemon", serving: "1 small bowl", cal: 35, p: 1, c: 8, f: 0.1, cat: "Salads & sides" },
  { id: "cucumber-salad", name: "Cucumber salad", serving: "1 bowl", cal: 30, p: 1.2, c: 6, f: 0.2, cat: "Salads & sides" },
  { id: "sprouts-chaat-light", name: "Sprouts salad / chaat (light)", serving: "1 bowl", cal: 110, p: 8, c: 19, f: 1.5, cat: "Salads & sides" },
  { id: "beetroot-carrot-salad", name: "Beetroot carrot salad", serving: "1 bowl", cal: 70, p: 2, c: 15, f: 0.5, cat: "Salads & sides" },
  { id: "plain-raita", name: "Plain curd raita", serving: "1 katori", cal: 65, p: 4, c: 5, f: 3.5, cat: "Salads & sides" },
  { id: "mixed-veg-raita", name: "Mixed vegetable raita", serving: "1 katori", cal: 75, p: 4, c: 8, f: 3, cat: "Salads & sides" },
  { id: "mint-raita", name: "Pudina raita", serving: "1 katori", cal: 60, p: 3.5, c: 5, f: 3, cat: "Salads & sides" },
  { id: "onion-raita", name: "Onion raita", serving: "1 katori", cal: 70, p: 4, c: 7, f: 3, cat: "Salads & sides" },
  { id: "pineapple-raita", name: "Pineapple raita", serving: "1 katori", cal: 100, p: 4, c: 16, f: 2.5, cat: "Salads & sides" },
  { id: "tomato-chutney", name: "Tomato chutney", serving: "2 tbsp", cal: 30, p: 1, c: 5, f: 1, cat: "Salads & sides" },
  { id: "garlic-chutney", name: "Lahsun / garlic chutney", serving: "1 tbsp", cal: 45, p: 1, c: 4, f: 3, cat: "Salads & sides" },
  { id: "dry-garlic-chutney", name: "Dry garlic chutney", serving: "1 tbsp", cal: 60, p: 2, c: 4, f: 4.5, cat: "Salads & sides" },
  { id: "flaxseed-chutney", name: "Alsi / flaxseed chutney", serving: "1 tbsp", cal: 55, p: 2, c: 2, f: 4.5, cat: "Salads & sides" },
  { id: "lemon-pickle", name: "Nimbu / lemon pickle", serving: "1 tsp", cal: 15, p: 0.2, c: 2, f: 0.7, cat: "Salads & sides" },
  { id: "mixed-pickle", name: "Mixed vegetable pickle", serving: "1 tsp", cal: 20, p: 0.2, c: 1.5, f: 1.5, cat: "Salads & sides" },
  { id: "green-chilli-pickle", name: "Green chilli pickle", serving: "1 tsp", cal: 18, p: 0.2, c: 1, f: 1.4, cat: "Salads & sides" },
  { id: "homemade-ghee", name: "Ghee", serving: "1 tbsp", cal: 135, p: 0, c: 0, f: 15, cat: "Salads & sides" },
  { id: "homemade-butter", name: "White butter / makhan", serving: "1 tbsp", cal: 102, p: 0.1, c: 0, f: 11.5, cat: "Salads & sides" },

  /* ---------------- More street food & chaat ---------------- */
  { id: "aloo-tikki-chaat", name: "Aloo tikki chaat", serving: "1 plate", cal: 290, p: 6, c: 42, f: 11, cat: "Street & snacks" },
  { id: "dahi-bhalla", name: "Dahi bhalla", serving: "2 pieces", cal: 220, p: 8, c: 28, f: 8, cat: "Street & snacks" },
  { id: "chole-kulche", name: "Chole kulche", serving: "1 plate", cal: 450, p: 14, c: 68, f: 14, cat: "Street & snacks" },
  { id: "chole-tikki", name: "Chole tikki", serving: "1 plate", cal: 340, p: 10, c: 48, f: 12, cat: "Street & snacks" },
  { id: "kathi-roll-veg", name: "Veg kathi roll", serving: "1 roll", cal: 300, p: 8, c: 40, f: 12, cat: "Street & snacks" },
  { id: "kathi-roll-egg", name: "Egg kathi roll", serving: "1 roll", cal: 360, p: 15, c: 40, f: 16, cat: "Street & snacks" },
  { id: "kathi-roll-chicken", name: "Chicken kathi roll", serving: "1 roll", cal: 400, p: 22, c: 40, f: 17, cat: "Street & snacks" },
  { id: "frankie", name: "Veg frankie", serving: "1 roll", cal: 310, p: 8, c: 44, f: 11, cat: "Street & snacks" },
  { id: "shawarma-chicken", name: "Chicken shawarma", serving: "1 roll", cal: 430, p: 26, c: 42, f: 18, cat: "Street & snacks" },
  { id: "chicken-roll", name: "Chicken roll", serving: "1 roll", cal: 380, p: 20, c: 38, f: 16, cat: "Street & snacks" },
  { id: "paneer-roll", name: "Paneer roll", serving: "1 roll", cal: 390, p: 15, c: 40, f: 19, cat: "Street & snacks" },
  { id: "veg-burger", name: "Veg burger", serving: "1 burger", cal: 350, p: 9, c: 52, f: 12, cat: "Street & snacks" },
  { id: "chicken-burger", name: "Chicken burger", serving: "1 burger", cal: 430, p: 22, c: 46, f: 18, cat: "Street & snacks" },
  { id: "veg-pizza-slice", name: "Veg pizza", serving: "1 slice", cal: 210, p: 8, c: 26, f: 8, cat: "Street & snacks" },
  { id: "paneer-pizza-slice", name: "Paneer pizza", serving: "1 slice", cal: 250, p: 11, c: 26, f: 11, cat: "Street & snacks" },
  { id: "french-fries", name: "French fries", serving: "1 medium", cal: 320, p: 4, c: 43, f: 15, cat: "Street & snacks" },
  { id: "honey-chilli-potato", name: "Honey chilli potato", serving: "1 plate", cal: 380, p: 5, c: 54, f: 16, cat: "Street & snacks" },
  { id: "cheese-fries", name: "Cheese fries", serving: "1 plate", cal: 420, p: 9, c: 45, f: 23, cat: "Street & snacks" },
  { id: "masala-maggi", name: "Masala / veg Maggi", serving: "1 plate", cal: 350, p: 9, c: 48, f: 13, cat: "Street & snacks" },
  { id: "egg-maggi", name: "Egg Maggi", serving: "1 plate", cal: 420, p: 16, c: 48, f: 18, cat: "Street & snacks" },
  { id: "pasta-red", name: "Red sauce pasta", serving: "1 plate", cal: 380, p: 11, c: 58, f: 11, cat: "Street & snacks" },
  { id: "pasta-white", name: "White sauce pasta", serving: "1 plate", cal: 450, p: 13, c: 54, f: 20, cat: "Street & snacks" },
  { id: "grilled-sandwich", name: "Grilled cheese sandwich", serving: "1 sandwich", cal: 330, p: 12, c: 36, f: 15, cat: "Street & snacks" },
  { id: "club-sandwich", name: "Club sandwich", serving: "1 sandwich", cal: 420, p: 18, c: 44, f: 19, cat: "Street & snacks" },
  { id: "garlic-bread", name: "Garlic bread", serving: "2 pieces", cal: 220, p: 6, c: 30, f: 9, cat: "Street & snacks" },
  { id: "momo-fried", name: "Fried momos", serving: "4 pieces", cal: 280, p: 7, c: 34, f: 13, cat: "Street & snacks" },
  { id: "momo-tandoori", name: "Tandoori momos", serving: "4 pieces", cal: 300, p: 12, c: 32, f: 14, cat: "Street & snacks" },
  { id: "chilli-potato", name: "Chilli potato", serving: "1 plate", cal: 360, p: 5, c: 48, f: 17, cat: "Street & snacks" },
  { id: "paneer-pakora", name: "Paneer pakora", serving: "3 pieces", cal: 230, p: 10, c: 14, f: 15, cat: "Street & snacks" },
  { id: "onion-pakora", name: "Pyaz pakora", serving: "4 pieces", cal: 180, p: 4, c: 18, f: 10, cat: "Street & snacks" },
  { id: "aloo-pakora", name: "Aloo pakora", serving: "4 pieces", cal: 190, p: 4, c: 22, f: 10, cat: "Street & snacks" },
  { id: "palak-pakora", name: "Palak pakora", serving: "4 pieces", cal: 165, p: 5, c: 16, f: 9, cat: "Street & snacks" },

  /* ---------------- More regional mains ---------------- */
  { id: "paneer-lababdar", name: "Paneer lababdar", serving: "1 katori", cal: 290, p: 11, c: 12, f: 22, cat: "Sabzi" },
  { id: "paneer-kolhapuri", name: "Paneer kolhapuri", serving: "1 katori", cal: 250, p: 10, c: 12, f: 18, cat: "Sabzi" },
  { id: "paneer-jalfrezi", name: "Paneer jalfrezi", serving: "1 katori", cal: 235, p: 10, c: 12, f: 16, cat: "Sabzi" },
  { id: "veg-kolhapuri", name: "Veg kolhapuri", serving: "1 katori", cal: 180, p: 5, c: 16, f: 11, cat: "Sabzi" },
  { id: "veg-handi", name: "Veg handi", serving: "1 katori", cal: 200, p: 6, c: 16, f: 13, cat: "Sabzi" },
  { id: "mushroom-matar", name: "Mushroom matar masala", serving: "1 katori", cal: 150, p: 6, c: 14, f: 8, cat: "Sabzi" },
  { id: "corn-palak", name: "Corn palak", serving: "1 katori", cal: 165, p: 6, c: 18, f: 8, cat: "Sabzi" },
  { id: "chana-masala-dry", name: "Sukha chana masala", serving: "1 katori", cal: 185, p: 9, c: 26, f: 5, cat: "Sabzi" },
  { id: "rajma-masala", name: "Rajma masala", serving: "1 katori", cal: 185, p: 10, c: 27, f: 4.5, cat: "Dals & curries" },
  { id: "dal-fry-ghee", name: "Dal fry with ghee tadka", serving: "1 katori", cal: 165, p: 7, c: 18, f: 7, cat: "Dals & curries" },
  { id: "dal-khichdi", name: "Dal khichdi", serving: "1 bowl", cal: 240, p: 9, c: 40, f: 5, cat: "Beans & dals" },
  { id: "sambar-dal", name: "Sambar with vegetables", serving: "1 katori", cal: 110, p: 5, c: 15, f: 3, cat: "Dals & curries" },
  { id: "butter-paneer-rice", name: "Butter paneer + rice", serving: "1 plate", cal: 520, p: 16, c: 60, f: 24, cat: "Combos & thalis" },
  { id: "chicken-curry-rice-plate", name: "Chicken curry + rice plate", serving: "1 plate", cal: 520, p: 30, c: 58, f: 17, cat: "Combos & thalis" },
  { id: "veg-thali-small", name: "Small veg thali", serving: "1 thali", cal: 480, p: 15, c: 72, f: 14, cat: "Combos & thalis" },
  { id: "veg-thali-large", name: "Large veg thali", serving: "1 thali", cal: 780, p: 24, c: 112, f: 26, cat: "Combos & thalis" },
  { id: "nonveg-thali", name: "Non-veg thali", serving: "1 thali", cal: 850, p: 38, c: 100, f: 32, cat: "Combos & thalis" },
  { id: "south-thali", name: "South Indian meals (thali)", serving: "1 plate", cal: 650, p: 18, c: 108, f: 16, cat: "Combos & thalis" },
  { id: "tiffin-combo", name: "Idli + vada + sambar", serving: "1 plate", cal: 330, p: 11, c: 50, f: 9, cat: "Combos & thalis" },

  /* ---------------- Fruits & dry fruits ---------------- */
  { id: "guava", name: "Guava", serving: "1 medium", cal: 68, p: 2.6, c: 14, f: 1, cat: "Fruits" },
  { id: "chikoo", name: "Chikoo / sapota", serving: "1 medium", cal: 83, p: 0.4, c: 20, f: 1.1, cat: "Fruits" },
  { id: "custard-apple", name: "Custard apple / sitaphal", serving: "1 medium", cal: 100, p: 2, c: 24, f: 0.5, cat: "Fruits" },
  { id: "jamun", name: "Jamun", serving: "1 cup", cal: 60, p: 0.8, c: 15, f: 0.2, cat: "Fruits" },
  { id: "lychee", name: "Lychee", serving: "10 pieces", cal: 66, p: 0.8, c: 17, f: 0.4, cat: "Fruits" },
  { id: "muskmelon", name: "Muskmelon", serving: "1 cup", cal: 54, p: 1.3, c: 13, f: 0.3, cat: "Fruits" },
  { id: "pear", name: "Pear", serving: "1 medium", cal: 101, p: 0.6, c: 27, f: 0.2, cat: "Fruits" },
  { id: "kiwi", name: "Kiwi", serving: "1 medium", cal: 42, p: 0.8, c: 10, f: 0.4, cat: "Fruits" },
  { id: "strawberries", name: "Strawberries", serving: "1 cup", cal: 49, p: 1, c: 12, f: 0.5, cat: "Fruits" },
  { id: "grapes", name: "Grapes", serving: "1 cup", cal: 104, p: 1.1, c: 27, f: 0.2, cat: "Fruits" },
  { id: "pineapple", name: "Pineapple", serving: "1 cup", cal: 82, p: 0.9, c: 22, f: 0.2, cat: "Fruits" },
  { id: "amla", name: "Amla", serving: "2 pieces", cal: 30, p: 0.6, c: 7, f: 0.3, cat: "Fruits" },
  { id: "raisins", name: "Raisins / kishmish", serving: "30 g", cal: 90, p: 0.9, c: 24, f: 0.1, cat: "Fats & nuts" },
  { id: "cashews", name: "Cashews", serving: "18 pieces", cal: 157, p: 5, c: 9, f: 12, cat: "Fats & nuts" },
  { id: "pistachios", name: "Pistachios", serving: "30 g", cal: 159, p: 6, c: 8, f: 13, cat: "Fats & nuts" },
  { id: "anjeer", name: "Dried figs / anjeer", serving: "2 pieces", cal: 95, p: 1.2, c: 24, f: 0.4, cat: "Fats & nuts" },
  { id: "apricot-dried", name: "Dried apricots", serving: "4 pieces", cal: 67, p: 0.9, c: 17, f: 0.1, cat: "Fats & nuts" },
  { id: "coconut-fresh", name: "Fresh coconut", serving: "50 g", cal: 177, p: 1.7, c: 7.6, f: 17, cat: "Fats & nuts" },
  { id: "chia-seeds", name: "Chia seeds", serving: "1 tbsp", cal: 60, p: 2, c: 5, f: 4, cat: "Fats & nuts" },
  { id: "pumpkin-seeds", name: "Pumpkin seeds", serving: "1 tbsp", cal: 75, p: 3.5, c: 2, f: 6, cat: "Fats & nuts" },
  { id: "sunflower-seeds", name: "Sunflower seeds", serving: "1 tbsp", cal: 70, p: 2.5, c: 2.5, f: 6, cat: "Fats & nuts" },

  /* ---------------- Protein & fitness staples ---------------- */
  { id: "whey-isolate", name: "Whey isolate", serving: "1 scoop (30 g)", cal: 110, p: 27, c: 1, f: 0.5, cat: "Protein" },
  { id: "mass-gainer", name: "Mass gainer", serving: "1 scoop (100 g)", cal: 380, p: 20, c: 70, f: 3, cat: "Protein" },
  { id: "casein", name: "Casein protein", serving: "1 scoop", cal: 120, p: 24, c: 4, f: 1, cat: "Protein" },
  { id: "plant-protein", name: "Plant protein powder", serving: "1 scoop", cal: 120, p: 22, c: 5, f: 2, cat: "Protein" },
  { id: "peanut-butter-2tbsp", name: "Peanut butter", serving: "2 tbsp", cal: 190, p: 7, c: 7, f: 16, cat: "Protein" },
  { id: "chicken-breast-150", name: "Chicken breast", serving: "150 g", cal: 248, p: 46, c: 0, f: 5.4, cat: "Protein" },
  { id: "chicken-breast-200", name: "Chicken breast", serving: "200 g", cal: 330, p: 62, c: 0, f: 7.2, cat: "Protein" },
  { id: "egg-whites-6", name: "Egg whites", serving: "6 whites", cal: 102, p: 22, c: 1.4, f: 0.4, cat: "Protein" },
  { id: "paneer-50", name: "Paneer", serving: "50 g", cal: 133, p: 9, c: 1.8, f: 10, cat: "Protein" },
  { id: "low-fat-paneer", name: "Low-fat paneer", serving: "100 g", cal: 160, p: 22, c: 4, f: 6, cat: "Protein" },
  { id: "greek-yogurt-200", name: "Greek yogurt", serving: "200 g", cal: 118, p: 20, c: 7, f: 0.8, cat: "Dairy" },
  { id: "skimmed-milk", name: "Skimmed milk", serving: "250 ml", cal: 85, p: 8.5, c: 12, f: 0.2, cat: "Dairy" },
  { id: "full-cream-milk", name: "Full cream milk", serving: "250 ml", cal: 160, p: 8, c: 12, f: 8.5, cat: "Dairy" },
  { id: "soy-milk", name: "Soy milk", serving: "250 ml", cal: 100, p: 7, c: 8, f: 4, cat: "Dairy" },
  { id: "almond-milk", name: "Almond milk (unsweetened)", serving: "250 ml", cal: 35, p: 1, c: 2, f: 2.5, cat: "Dairy" },
  { id: "cottage-cheese", name: "Cottage cheese", serving: "100 g", cal: 98, p: 11, c: 3.4, f: 4.3, cat: "Dairy" },
  { id: "tofu-200", name: "Tofu", serving: "200 g", cal: 180, p: 20, c: 4, f: 9, cat: "Protein" },
  { id: "tempeh", name: "Tempeh", serving: "100 g", cal: 192, p: 20, c: 8, f: 11, cat: "Protein" },
  { id: "soya-chunks-100", name: "Soya chunks (dry)", serving: "100 g", cal: 345, p: 52, c: 30, f: 1, cat: "Protein" },
  { id: "fish-salmon", name: "Salmon", serving: "100 g", cal: 208, p: 20, c: 0, f: 13, cat: "Protein" },
  { id: "fish-basa", name: "Basa fillet", serving: "100 g", cal: 90, p: 15, c: 0, f: 3, cat: "Protein" },
  { id: "prawns-100", name: "Prawns", serving: "100 g", cal: 99, p: 24, c: 0.2, f: 0.3, cat: "Protein" },
  { id: "mutton-100", name: "Mutton (cooked)", serving: "100 g", cal: 258, p: 26, c: 0, f: 17, cat: "Protein" },
  { id: "chicken-sausage", name: "Chicken sausage", serving: "2 pieces", cal: 180, p: 14, c: 3, f: 12, cat: "Protein" },
  { id: "chicken-salami", name: "Chicken salami", serving: "4 slices", cal: 130, p: 12, c: 2, f: 8, cat: "Protein" },

  /* ---------------- Packaged & convenience ---------------- */
  { id: "brown-bread", name: "Brown bread", serving: "2 slices", cal: 140, p: 6, c: 24, f: 2, cat: "Grains" },
  { id: "multigrain-bread", name: "Multigrain bread", serving: "2 slices", cal: 160, p: 7, c: 26, f: 3, cat: "Grains" },
  { id: "pav", name: "Pav", serving: "1 piece", cal: 115, p: 3.5, c: 22, f: 1.5, cat: "Grains" },
  { id: "rusk", name: "Rusk / toast", serving: "2 pieces", cal: 110, p: 2.5, c: 20, f: 2.5, cat: "Snacks" },
  { id: "khari-biscuit", name: "Khari puff biscuit", serving: "2 pieces", cal: 130, p: 2, c: 14, f: 7.5, cat: "Snacks" },
  { id: "instant-oats-packet", name: "Instant oats (flavoured)", serving: "1 packet", cal: 160, p: 4, c: 30, f: 3, cat: "Grains" },
  { id: "protein-bar-20g", name: "Protein bar (20 g protein)", serving: "1 bar", cal: 230, p: 20, c: 22, f: 7, cat: "Snacks" },
  { id: "granola-bar", name: "Granola bar", serving: "1 bar", cal: 150, p: 3, c: 24, f: 5, cat: "Snacks" },
  { id: "chips-packet", name: "Potato chips", serving: "1 small packet (30 g)", cal: 160, p: 2, c: 16, f: 10, cat: "Snacks" },
  { id: "nachos", name: "Nachos with dip", serving: "1 plate", cal: 350, p: 7, c: 40, f: 18, cat: "Snacks" },
  { id: "chocolate-bar", name: "Milk chocolate bar", serving: "1 small bar (40 g)", cal: 210, p: 3, c: 24, f: 12, cat: "Snacks" },
  { id: "energy-drink", name: "Energy drink", serving: "1 can", cal: 110, p: 0, c: 28, f: 0, cat: "Beverages" },
  { id: "diet-cola", name: "Diet cola", serving: "1 can", cal: 2, p: 0, c: 0, f: 0, cat: "Beverages" },
  { id: "green-tea", name: "Green tea", serving: "1 cup", cal: 2, p: 0, c: 0, f: 0, cat: "Beverages" },
  { id: "black-tea-sugar", name: "Tea with sugar", serving: "1 cup", cal: 70, p: 1.5, c: 12, f: 1.5, cat: "Beverages" },
  { id: "lemon-water", name: "Lemon water (no sugar)", serving: "1 glass", cal: 10, p: 0, c: 3, f: 0, cat: "Beverages" },
  { id: "protein-shake-milk", name: "Protein shake with milk", serving: "1 glass", cal: 240, p: 32, c: 15, f: 5.5, cat: "Beverages" },
  { id: "electrolyte-drink", name: "Electrolyte drink", serving: "1 glass", cal: 60, p: 0, c: 15, f: 0, cat: "Beverages" },
  { id: "curd-rice-bowl", name: "Curd with rice bowl", serving: "1 bowl", cal: 230, p: 8, c: 38, f: 5, cat: "Everyday staples" },

  /* ------------------- Eggs & quick protein · wave 3 ------------------- */
  { id: "egg-bhurji-3", name: "Egg bhurji (3 eggs)", serving: "3 eggs", cal: 300, p: 20, c: 5, f: 22, cat: "Home non-veg" },
  { id: "egg-poached", name: "Poached egg", serving: "1 egg", cal: 72, p: 6.3, c: 0.4, f: 4.8, cat: "Protein" },
  { id: "egg-scrambled-butter", name: "Scrambled eggs with butter", serving: "2 eggs", cal: 230, p: 13, c: 2, f: 19, cat: "Home non-veg" },
  { id: "egg-curry-single", name: "Egg curry (1 egg)", serving: "1 egg + gravy", cal: 140, p: 7, c: 4, f: 10, cat: "Home non-veg" },
  { id: "chicken-tikka-100", name: "Chicken tikka (boneless)", serving: "100 g", cal: 160, p: 25, c: 3, f: 6, cat: "Protein" },
  { id: "chicken-shredded", name: "Boiled shredded chicken", serving: "100 g", cal: 150, p: 28, c: 0, f: 4, cat: "Protein" },
  { id: "chicken-leg", name: "Chicken leg (curry cut)", serving: "1 leg", cal: 185, p: 22, c: 0, f: 11, cat: "Protein" },
  { id: "fish-tandoori", name: "Tandoori fish tikka", serving: "150 g", cal: 215, p: 30, c: 3, f: 9, cat: "Protein" },
  { id: "soya-granules", name: "Soya granules (cooked)", serving: "1 katori", cal: 145, p: 16, c: 12, f: 3, cat: "Protein" },
  { id: "rajma-protein", name: "Rajma (boiled, plain)", serving: "1 katori", cal: 130, p: 8, c: 22, f: 0.5, cat: "Protein" },
  { id: "chana-boiled-plain", name: "Boiled chana (plain)", serving: "1 katori", cal: 160, p: 9, c: 27, f: 2.5, cat: "Protein" },
  { id: "peanut-boiled", name: "Boiled peanuts", serving: "1 katori", cal: 200, p: 9, c: 14, f: 12, cat: "Protein" },
  { id: "curd-protein", name: "Curd (full bowl)", serving: "1 bowl (200 g)", cal: 122, p: 7, c: 9.4, f: 6.6, cat: "Dairy" },
  { id: "hung-curd", name: "Hung curd", serving: "100 g", cal: 95, p: 10, c: 5, f: 4, cat: "Dairy" },
  { id: "chaas-masala", name: "Masala chaas", serving: "1 glass", cal: 50, p: 3, c: 6, f: 1.5, cat: "Dairy" },

  /* ---------------------- Regional mains · wave 3 ---------------------- */
  { id: "kadhi-pakoda-punjabi", name: "Punjabi kadhi pakoda", serving: "1 katori", cal: 165, p: 6, c: 14, f: 9, cat: "Dals & curries" },
  { id: "aloo-methi", name: "Aloo methi", serving: "1 katori", cal: 125, p: 3, c: 16, f: 5.5, cat: "Everyday sabzi" },
  { id: "aloo-capsicum-dry", name: "Sukhi aloo capsicum", serving: "1 katori", cal: 130, p: 2.5, c: 18, f: 5.5, cat: "Everyday sabzi" },
  { id: "jeera-aloo-dry", name: "Sukhe jeera aloo", serving: "1 katori", cal: 135, p: 2.5, c: 20, f: 5, cat: "Everyday sabzi" },
  { id: "matar-paneer-dry", name: "Sukha matar paneer", serving: "1 katori", cal: 195, p: 10, c: 12, f: 12, cat: "Sabzi" },
  { id: "paneer-capsicum", name: "Paneer capsicum masala", serving: "1 katori", cal: 215, p: 11, c: 10, f: 15, cat: "Sabzi" },
  { id: "paneer-bhurji-dry", name: "Paneer bhurji (dry)", serving: "1 katori", cal: 215, p: 14, c: 6, f: 15, cat: "Sabzi" },
  { id: "soya-keema", name: "Soya keema", serving: "1 katori", cal: 175, p: 15, c: 14, f: 6, cat: "Sabzi" },
  { id: "mushroom-do-pyaza", name: "Mushroom do pyaza", serving: "1 katori", cal: 125, p: 5, c: 11, f: 7, cat: "Sabzi" },
  { id: "egg-masala-dry", name: "Sukha egg masala", serving: "2 eggs", cal: 230, p: 14, c: 6, f: 17, cat: "Home non-veg" },
  { id: "chicken-curry-dhaba", name: "Dhaba chicken curry", serving: "1 katori", cal: 310, p: 24, c: 7, f: 21, cat: "Home non-veg" },
  { id: "andhra-chicken", name: "Andhra chicken curry", serving: "1 katori", cal: 300, p: 24, c: 7, f: 20, cat: "Non-veg" },
  { id: "malabar-fish-curry", name: "Malabar fish curry", serving: "1 katori", cal: 230, p: 20, c: 6, f: 14, cat: "Non-veg" },
  { id: "goan-fish-curry", name: "Goan fish curry", serving: "1 katori", cal: 240, p: 20, c: 7, f: 15, cat: "Non-veg" },
  { id: "chicken-stew-kerala-2", name: "Chicken ishtu", serving: "1 katori", cal: 240, p: 21, c: 8, f: 13, cat: "Non-veg" },
  { id: "mutton-rogan-home", name: "Home mutton curry (light)", serving: "1 katori", cal: 260, p: 23, c: 5, f: 17, cat: "Home non-veg" },
  { id: "bhuna-khichuri", name: "Bhuna khichuri", serving: "1 bowl", cal: 290, p: 10, c: 44, f: 8, cat: "Eastern Indian" },
  { id: "tehri", name: "Tehri (veg pulao)", serving: "1 plate", cal: 320, p: 7, c: 52, f: 9, cat: "Breads & rice" },
  { id: "masala-bhaat", name: "Masala bhaat", serving: "1 cup", cal: 265, p: 6, c: 44, f: 7, cat: "Breads & rice" },
  { id: "vangi-bhaat", name: "Vangi bhaat", serving: "1 cup", cal: 275, p: 6, c: 45, f: 8, cat: "Breads & rice" },
  { id: "dal-khichdi-ghee", name: "Dal khichdi with ghee", serving: "1 bowl", cal: 300, p: 10, c: 44, f: 9, cat: "Beans & dals" },

  /* ---------------------- Breakfast & tiffin · wave 3 ------------------ */
  { id: "besan-toast", name: "Besan toast", serving: "2 slices", cal: 220, p: 9, c: 26, f: 9, cat: "Indian breakfast" },
  { id: "moong-dosa-plain", name: "Moong dal cheela (plain)", serving: "1 piece", cal: 110, p: 6, c: 14, f: 3, cat: "Indian breakfast" },
  { id: "paneer-bhurji-toast", name: "Paneer bhurji with toast", serving: "1 plate", cal: 350, p: 18, c: 30, f: 18, cat: "Indian breakfast" },
  { id: "aloo-poha", name: "Aloo poha", serving: "1 plate", cal: 230, p: 4, c: 40, f: 6, cat: "Indian breakfast" },
  { id: "sprout-poha", name: "Sprouts poha", serving: "1 plate", cal: 220, p: 8, c: 36, f: 5, cat: "Indian breakfast" },
  { id: "vermicelli-upma", name: "Vermicelli upma", serving: "1 cup", cal: 200, p: 5, c: 34, f: 5, cat: "Indian breakfast" },
  { id: "rava-upma-ghee", name: "Rava upma with ghee", serving: "1 cup", cal: 230, p: 5, c: 32, f: 9, cat: "Indian breakfast" },
  { id: "idli-ghee", name: "Idli with ghee podi", serving: "2 idli", cal: 160, p: 4, c: 24, f: 6, cat: "Indian breakfast" },
  { id: "dosa-podi", name: "Podi dosa", serving: "1 piece", cal: 210, p: 5, c: 28, f: 9, cat: "Indian breakfast" },
  { id: "uttapam-tomato", name: "Tomato uttapam", serving: "1 piece", cal: 155, p: 4, c: 27, f: 3.5, cat: "Indian breakfast" },
  { id: "oats-idli", name: "Oats idli", serving: "2 pieces", cal: 120, p: 5, c: 20, f: 2, cat: "Indian breakfast" },
  { id: "ragi-porridge-milk", name: "Ragi malt with milk", serving: "1 glass", cal: 200, p: 7, c: 34, f: 4, cat: "Indian breakfast" },
  { id: "banana-oats-bowl", name: "Oats with banana & milk", serving: "1 bowl", cal: 310, p: 11, c: 54, f: 6, cat: "Everyday staples" },
  { id: "peanut-butter-toast", name: "Peanut butter toast", serving: "2 slices", cal: 350, p: 12, c: 34, f: 19, cat: "Everyday staples" },
  { id: "egg-bhurji-roti", name: "Egg bhurji + 2 roti", serving: "1 meal", cal: 380, p: 20, c: 36, f: 18, cat: "Home meal combos" },

  /* ------------------------ Snacks & street · wave 3 ------------------- */
  { id: "masala-peanuts", name: "Masala peanuts (fried)", serving: "30 g", cal: 180, p: 7, c: 7, f: 14, cat: "Street & snacks" },
  { id: "moong-dal-namkeen", name: "Moong dal namkeen", serving: "30 g", cal: 155, p: 6, c: 15, f: 8, cat: "Street & snacks" },
  { id: "bhujia", name: "Aloo bhujia", serving: "30 g", cal: 165, p: 3, c: 15, f: 10, cat: "Street & snacks" },
  { id: "banana-chips", name: "Banana chips", serving: "30 g", cal: 160, p: 1, c: 18, f: 10, cat: "Street & snacks" },
  { id: "sweet-corn-cup", name: "Steamed sweet corn cup", serving: "1 cup", cal: 130, p: 4, c: 27, f: 1.5, cat: "Street & snacks" },
  { id: "egg-chaat", name: "Egg chaat", serving: "2 eggs", cal: 200, p: 13, c: 6, f: 14, cat: "Street & snacks" },
  { id: "paneer-tikka-roll", name: "Paneer tikka roll", serving: "1 roll", cal: 400, p: 16, c: 42, f: 18, cat: "Street & snacks" },
  { id: "egg-roll-kolkata", name: "Kolkata egg roll", serving: "1 roll", cal: 370, p: 14, c: 40, f: 17, cat: "Street & snacks" },
  { id: "chicken-momos-fried", name: "Fried chicken momos", serving: "4 pieces", cal: 320, p: 13, c: 32, f: 15, cat: "Street & snacks" },
  { id: "veg-pulao-plate", name: "Veg pulao plate with raita", serving: "1 plate", cal: 380, p: 10, c: 58, f: 12, cat: "Combos & thalis" },
  { id: "idli-podi-combo", name: "Idli + podi + chutney", serving: "1 plate", cal: 250, p: 7, c: 38, f: 8, cat: "Combos & thalis" },
  { id: "paratha-chai", name: "Paratha + chai", serving: "1 breakfast", cal: 260, p: 6, c: 34, f: 10, cat: "Home meal combos" },

  /* ---------------------- Drinks & supplements · wave 3 ---------------- */
  { id: "black-coffee-sugar", name: "Coffee with sugar", serving: "1 cup", cal: 45, p: 0.5, c: 10, f: 0.3, cat: "Beverages" },
  { id: "milk-coffee", name: "Milk coffee", serving: "1 cup", cal: 90, p: 4, c: 10, f: 3.5, cat: "Beverages" },
  { id: "green-tea-lemon", name: "Green tea with lemon", serving: "1 cup", cal: 5, p: 0, c: 1, f: 0, cat: "Beverages" },
  { id: "herbal-kadha", name: "Herbal kadha", serving: "1 cup", cal: 35, p: 0.3, c: 8, f: 0.2, cat: "Beverages" },
  { id: "buttermilk-jeera", name: "Jeera buttermilk", serving: "1 glass", cal: 45, p: 3, c: 5, f: 1.2, cat: "Beverages" },
  { id: "coconut-water-tender", name: "Tender coconut water", serving: "1 whole", cal: 60, p: 1, c: 14, f: 0.2, cat: "Beverages" },
  { id: "orange-juice-fresh", name: "Fresh orange juice", serving: "1 glass", cal: 110, p: 2, c: 26, f: 0.5, cat: "Beverages" },
  { id: "watermelon-juice", name: "Watermelon juice", serving: "1 glass", cal: 80, p: 1.5, c: 20, f: 0.2, cat: "Beverages" },
  { id: "whey-water", name: "Whey protein with water", serving: "1 scoop", cal: 120, p: 24, c: 3, f: 1, cat: "Beverages" },
  { id: "bcaa-drink", name: "BCAA / EAA drink", serving: "1 serving", cal: 25, p: 5, c: 1, f: 0, cat: "Beverages" },
  { id: "creatine", name: "Creatine monohydrate", serving: "5 g", cal: 0, p: 0, c: 0, f: 0, cat: "Protein" },
  { id: "multivitamin", name: "Multivitamin tablet", serving: "1 tablet", cal: 5, p: 0, c: 1, f: 0, cat: "Protein" },
  { id: "fish-oil", name: "Fish oil capsule", serving: "1 capsule", cal: 10, p: 0, c: 0, f: 1, cat: "Fats & nuts" },
  { id: "pre-workout", name: "Pre-workout scoop", serving: "1 scoop", cal: 15, p: 0, c: 3, f: 0, cat: "Beverages" },

  /* ------------------------- Vegetables · wave 3 ----------------------- */
  { id: "cucumber-raw", name: "Cucumber", serving: "1 medium", cal: 30, p: 1.3, c: 7, f: 0.2, cat: "Vegetables" },
  { id: "tomato-raw", name: "Tomato", serving: "1 medium", cal: 22, p: 1.1, c: 4.8, f: 0.2, cat: "Vegetables" },
  { id: "onion-raw", name: "Onion", serving: "1 medium", cal: 44, p: 1.2, c: 10, f: 0.1, cat: "Vegetables" },
  { id: "carrot-raw", name: "Carrot", serving: "1 medium", cal: 25, p: 0.6, c: 6, f: 0.1, cat: "Vegetables" },
  { id: "beetroot-raw", name: "Beetroot", serving: "1 medium", cal: 44, p: 1.6, c: 10, f: 0.2, cat: "Vegetables" },
  { id: "capsicum-raw", name: "Capsicum", serving: "1 medium", cal: 25, p: 1, c: 6, f: 0.2, cat: "Vegetables" },
  { id: "spinach-raw", name: "Raw spinach", serving: "1 cup", cal: 7, p: 0.9, c: 1.1, f: 0.1, cat: "Vegetables" },
  { id: "cabbage-raw", name: "Raw cabbage", serving: "1 cup", cal: 22, p: 1.1, c: 5, f: 0.1, cat: "Vegetables" },
  { id: "mushroom-raw", name: "Mushrooms", serving: "100 g", cal: 22, p: 3.1, c: 3.3, f: 0.3, cat: "Vegetables" },
  { id: "green-peas-raw", name: "Green peas", serving: "1 cup", cal: 118, p: 8, c: 21, f: 0.6, cat: "Vegetables" },
  { id: "corn-sweet", name: "Sweet corn kernels", serving: "1 cup", cal: 132, p: 5, c: 29, f: 1.8, cat: "Vegetables" },
  { id: "bottle-gourd-raw", name: "Lauki (raw)", serving: "100 g", cal: 14, p: 0.6, c: 3.4, f: 0.02, cat: "Vegetables" },

  /* ---------------------- Kashmiri & Himalayan North ------------------ */
  { id: "kashmiri-yakhni-pulao", name: "Kashmiri yakhni pulao", serving: "1 plate", cal: 420, p: 20, c: 55, f: 14, cat: "Regional Indian" },
  { id: "goshtaba", name: "Goshtaba", serving: "1 katori", cal: 300, p: 22, c: 8, f: 20, cat: "Regional Indian" },
  { id: "marchwangan-korma", name: "Marchwangan korma", serving: "1 katori", cal: 320, p: 22, c: 8, f: 23, cat: "Regional Indian" },
  { id: "nadru-monje", name: "Nadru monje (lotus stem fritters)", serving: "4 pieces", cal: 220, p: 5, c: 24, f: 12, cat: "Regional Indian" },
  { id: "zarda-pulao", name: "Zarda pulao (sweet rice)", serving: "1 cup", cal: 280, p: 4, c: 50, f: 8, cat: "Regional Indian" },
  { id: "kashmiri-dum-alingo", name: "Dum aloo (Kashmiri style)", serving: "1 katori", cal: 180, p: 4, c: 16, f: 11, cat: "Regional Indian" },
  { id: "shabdeg", name: "Shabdeg (Kashmiri lamb)", serving: "1 katori", cal: 290, p: 24, c: 6, f: 19, cat: "Regional Indian" },
  { id: "dohaz", name: "Dohaz (Kashmiri lamb stew)", serving: "1 katori", cal: 310, p: 24, c: 7, f: 21, cat: "Regional Indian" },
  { id: "kashmiri-rogan-gosht", name: "Rogan gosht (home style)", serving: "1 katori", cal: 330, p: 23, c: 6, f: 24, cat: "Regional Indian" },

  /* --------------------------- Bengali classics ------------------------ */
  { id: "ilish-bhapa", name: "Ilish bhapa (steamed hilsa)", serving: "1 piece", cal: 260, p: 21, c: 3, f: 18, cat: "Eastern Indian" },
  { id: "chingri-malaikari", name: "Chingri malaikari", serving: "1 katori", cal: 250, p: 20, c: 6, f: 16, cat: "Eastern Indian" },
  { id: "doi-begun", name: "Doi begun (yogurt eggplant)", serving: "1 katori", cal: 160, p: 4, c: 10, f: 12, cat: "Eastern Indian" },
  { id: "koi-macher-jhol", name: "Koi macher jhol", serving: "1 katori", cal: 180, p: 17, c: 5, f: 10, cat: "Eastern Indian" },
  { id: "luchi-alur-dom", name: "Luchi with alur dom", serving: "2 luchi + aloo", cal: 430, p: 8, c: 60, f: 17, cat: "Eastern Indian" },
  { id: "alur-dom", name: "Alur dom", serving: "1 katori", cal: 135, p: 3, c: 19, f: 5.5, cat: "Eastern Indian" },
  { id: "payesh", name: "Payesh (Bengali kheer)", serving: "1 katori", cal: 190, p: 5, c: 26, f: 8, cat: "Sweets" },
  { id: "mishti-doi", name: "Mishti doi", serving: "1 katori", cal: 150, p: 4, c: 22, f: 5.5, cat: "Dairy" },
  { id: "shondesh", name: "Shondesh", serving: "1 piece", cal: 90, p: 3, c: 12, f: 4, cat: "Sweets" },
  { id: "patishapta", name: "Patishapta", serving: "1 piece", cal: 160, p: 4, c: 22, f: 6.5, cat: "Sweets" },
  { id: "puli-pitha", name: "Puli pitha", serving: "2 pieces", cal: 210, p: 4, c: 34, f: 7, cat: "Sweets" },
  { id: "chingri-pulao", name: "Chingri pulao", serving: "1 plate", cal: 430, p: 20, c: 56, f: 14, cat: "Eastern Indian" },
  { id: "beguni", name: "Beguni (eggplant fritters)", serving: "4 pieces", cal: 165, p: 4, c: 16, f: 9, cat: "Street & snacks" },
  { id: "mochar-ghonto", name: "Mochar ghonto (banana blossom)", serving: "1 katori", cal: 120, p: 4, c: 13, f: 6, cat: "Sabzi" },
  { id: "daler-paturi", name: "Daler paturi", serving: "1 katori", cal: 150, p: 7, c: 16, f: 7, cat: "Sabzi" },
  { id: "bengali-fish-fry", name: "Bengali fish fry", serving: "1 piece", cal: 210, p: 22, c: 5, f: 11, cat: "Non-veg" },
  { id: "dim-er-dev", name: "Dim er dev (egg curry)", serving: "1 katori", cal: 170, p: 10, c: 6, f: 12, cat: "Non-veg" },
  { id: "chingri-chingri", name: "Chingri chingri (prawn masala)", serving: "1 katori", cal: 225, p: 21, c: 6, f: 13, cat: "Non-veg" },

  /* ------------------------------ Odia --------------------------------- */
  { id: "chenna-poda", name: "Chenna poda", serving: "1 piece", cal: 230, p: 6, c: 30, f: 10, cat: "Sweets" },
  { id: "enduri-pitha", name: "Enduri pitha", serving: "2 pieces", cal: 190, p: 4, c: 30, f: 6.5, cat: "Sweets" },
  { id: "gupchup", name: "Gupchup (Odia panipuri)", serving: "6 pieces", cal: 170, p: 4, c: 28, f: 5, cat: "Street & snacks" },
  { id: "chakuli-pitha", name: "Chakuli pitha", serving: "2 pieces", cal: 160, p: 4, c: 26, f: 4.5, cat: "Indian breakfast" },
  { id: "aloo-bhaja", name: "Aloo bhaja (Odia fried potato)", serving: "1 katori", cal: 120, p: 2.5, c: 18, f: 4.5, cat: "Sabzi" },
  { id: "saga-bhaja", name: "Saga bhaja (fried greens)", serving: "1 katori", cal: 75, p: 3, c: 7, f: 4, cat: "Sabzi" },
  { id: "badi-chura", name: "Badi chura", serving: "1 katori", cal: 170, p: 7, c: 18, f: 8, cat: "Sabzi" },
  { id: "chhena-tikki", name: "Chhena tikki", serving: "1 piece", cal: 120, p: 4, c: 15, f: 5, cat: "Sweets" },
  { id: "oda-dahi-bara", name: "Odia dahi bara", serving: "2 pieces", cal: 205, p: 7, c: 26, f: 8, cat: "Street & snacks" },

  /* --------------------- Assamese & North-East ------------------------- */
  { id: "khar", name: "Khar (Assamese alkaline dish)", serving: "1 katori", cal: 80, p: 3, c: 9, f: 3.5, cat: "Regional Indian" },
  { id: "kahudi", name: "Kahudi (mustard seed curry)", serving: "1 katori", cal: 140, p: 5, c: 14, f: 7, cat: "Regional Indian" },
  { id: "masor-tenga", name: "Masor tenga (sour fish curry)", serving: "1 katori", cal: 180, p: 17, c: 7, f: 10, cat: "Non-veg" },
  { id: "ou-tenga", name: "Ou tenga (elephant apple fish)", serving: "1 katori", cal: 150, p: 15, c: 8, f: 8, cat: "Non-veg" },
  { id: "jolpan", name: "Jolpan (Assamese breakfast bowl)", serving: "1 bowl", cal: 210, p: 4, c: 40, f: 4, cat: "Indian breakfast" },
  { id: "til-pitha", name: "Til pitha", serving: "2 pieces", cal: 170, p: 3, c: 24, f: 7, cat: "Sweets" },
  { id: "narikol-laru", name: "Narikol laru", serving: "2 pieces", cal: 140, p: 2, c: 16, f: 8, cat: "Sweets" },
  { id: "axone-pork", name: "Axone pork", serving: "1 katori", cal: 290, p: 20, c: 6, f: 21, cat: "Regional Indian" },
  { id: "bamboo-shoot-pork", name: "Bamboo shoot pork", serving: "1 katori", cal: 280, p: 19, c: 8, f: 19, cat: "Regional Indian" },
  { id: "smoked-pork-chutney", name: "Smoked pork with chutney", serving: "1 katori", cal: 240, p: 18, c: 7, f: 16, cat: "Regional Indian" },
  { id: "erombi", name: "Erombi (frog leg curry)", serving: "1 katori", cal: 90, p: 12, c: 4, f: 3, cat: "Regional Indian" },
  { id: "iromba", name: "Iromba (fermented veg curry)", serving: "1 katori", cal: 110, p: 5, c: 12, f: 4.5, cat: "Regional Indian" },
  { id: "chakhwi", name: "Chakhwi (bamboo and pork)", serving: "1 katori", cal: 100, p: 5, c: 12, f: 4, cat: "Regional Indian" },
  { id: "jadoh", name: "Jadoh (Khasi rice and meat)", serving: "1 plate", cal: 380, p: 15, c: 55, f: 11, cat: "Regional Indian" },
  { id: "tungrymbai", name: "Tungrymbai", serving: "1 katori", cal: 160, p: 9, c: 14, f: 7, cat: "Regional Indian" },
  { id: "putho", name: "Putho (rice with meat)", serving: "1 plate", cal: 350, p: 12, c: 52, f: 10, cat: "Regional Indian" },
  { id: "gundruk-ki-sabzi", name: "Gundruk ki sabzi", serving: "1 katori", cal: 90, p: 4, c: 10, f: 4, cat: "Sabzi" },
  { id: "kinema", name: "Kinema (fermented soybean)", serving: "1 katori", cal: 150, p: 12, c: 16, f: 5, cat: "Regional Indian" },

  /* ---------------------------- Kerala -------------------------------- */
  { id: "meen-pollichathu", name: "Meen pollichathu", serving: "1 piece", cal: 270, p: 22, c: 6, f: 18, cat: "Non-veg" },
  { id: "fish-molee", name: "Fish molee", serving: "1 katori", cal: 230, p: 20, c: 7, f: 14, cat: "Non-veg" },
  { id: "beef-fry", name: "Kerala beef fry", serving: "1 katori", cal: 300, p: 24, c: 7, f: 20, cat: "Non-veg" },
  { id: "kerala-prawn-curry", name: "Kerala prawn curry", serving: "1 katori", cal: 240, p: 20, c: 6, f: 15, cat: "Non-veg" },
  { id: "kallappam", name: "Kallappam", serving: "1 piece", cal: 120, p: 3, c: 20, f: 3, cat: "Indian breakfast" },
  { id: "pazham-pori", name: "Pazham pori (banana fritters)", serving: "2 pieces", cal: 175, p: 2, c: 24, f: 8, cat: "Street & snacks" },
  { id: "parippu-vada", name: "Parippu vada", serving: "2 pieces", cal: 150, p: 6, c: 16, f: 7.5, cat: "Street & snacks" },
  { id: "unnakai", name: "Unnakai", serving: "2 pieces", cal: 180, p: 3, c: 28, f: 6.5, cat: "Sweets" },
  { id: "kerala-pachadi", name: "Kerala pachadi", serving: "1 katori", cal: 85, p: 3, c: 8, f: 4.5, cat: "Sabzi" },
  { id: "inji-puli", name: "Inji puli (ginger pickle)", serving: "1 tbsp", cal: 35, p: 0.5, c: 7, f: 0.5, cat: "Pickles & chutneys" },
  { id: "manga-pachadi-kerala", name: "Manga pachadi", serving: "1 katori", cal: 80, p: 2, c: 10, f: 3.5, cat: "Sabzi" },
  { id: "kaipola", name: "Kaipola", serving: "1 piece", cal: 170, p: 4, c: 24, f: 6.5, cat: "Sweets" },
  { id: "neyyappam", name: "Neyyappam", serving: "2 pieces", cal: 190, p: 3, c: 30, f: 7, cat: "Sweets" },
  { id: "kuzhalappam", name: "Kuzhalappam", serving: "4 pieces", cal: 160, p: 3, c: 20, f: 8, cat: "Snacks" },
  { id: "achappam", name: "Achappam", serving: "4 pieces", cal: 155, p: 3, c: 18, f: 8.5, cat: "Snacks" },
  { id: "elaneer-payasam", name: "Elaneer payasam", serving: "1 katori", cal: 160, p: 4, c: 24, f: 5.5, cat: "Sweets" },
  { id: "palada-payasam", name: "Palada payasam", serving: "1 katori", cal: 200, p: 5, c: 28, f: 7.5, cat: "Sweets" },

  /* ----------------------------- Tamil -------------------------------- */
  { id: "vada-curry", name: "Vada curry", serving: "1 katori", cal: 175, p: 8, c: 18, f: 8, cat: "Dals & curries" },
  { id: "keerai-masial", name: "Keerai masiyal (mashed greens)", serving: "1 katori", cal: 110, p: 6, c: 11, f: 5, cat: "Sabzi" },
  { id: "paruppu-usili", name: "Paruppu usili", serving: "1 katori", cal: 165, p: 9, c: 15, f: 7.5, cat: "Sabzi" },
  { id: "thayir-sadam", name: "Thayir sadam (curd rice)", serving: "1 cup", cal: 190, p: 6, c: 32, f: 4.5, cat: "Everyday staples" },
  { id: "vathal-kuzhambu", name: "Vathal kuzhambu", serving: "1 katori", cal: 130, p: 3, c: 14, f: 6.5, cat: "Dals & curries" },
  { id: "kathirikai-gothsu", name: "Kathirikai gothsu", serving: "1 katori", cal: 95, p: 3, c: 11, f: 4.5, cat: "Sabzi" },
  { id: "pavakkai-pitlai", name: "Pavakkai pitlai", serving: "1 katori", cal: 125, p: 4, c: 13, f: 6, cat: "Dals & curries" },
  { id: "manga-thokku", name: "Manga thokku (mango pickle)", serving: "1 katori", cal: 95, p: 2, c: 12, f: 4.5, cat: "Pickles & chutneys" },
  { id: "appalam-fried", name: "Fried appalam", serving: "1 piece", cal: 55, p: 1.5, c: 5, f: 3.5, cat: "Snacks" },
  { id: "kanjipuram-idli", name: "Kanchipuram idli", serving: "2 pieces", cal: 160, p: 5, c: 26, f: 4, cat: "Indian breakfast" },
  { id: "chettinad-pepper-chicken", name: "Chettinad pepper chicken", serving: "1 katori", cal: 285, p: 24, c: 6, f: 18, cat: "Non-veg" },
  { id: "meen-kuzhambu", name: "Meen kuzhambu", serving: "1 katori", cal: 210, p: 19, c: 7, f: 12, cat: "Non-veg" },
  { id: "gunpowder-podi", name: "Gunpowder podi (idli milagai)", serving: "1 tbsp", cal: 50, p: 2, c: 4.5, f: 3.2, cat: "Pickles & chutneys" },

  /* --------------------------- Karnataka ------------------------------- */
  { id: "jolada-rotti", name: "Jolada rotti (jowar roti)", serving: "1 roti", cal: 110, p: 3, c: 22, f: 1.5, cat: "Breads & rice" },
  { id: "enne-badnekai", name: "Enne badnekai (eggplant)", serving: "1 katori", cal: 135, p: 3, c: 15, f: 7, cat: "Sabzi" },
  { id: "karnataka-huli", name: "Huli (Karnataka dal)", serving: "1 katori", cal: 125, p: 4, c: 15, f: 6, cat: "Dals & curries" },
  { id: "saaru", name: "Saaru (Karnataka rasam)", serving: "1 katori", cal: 95, p: 4, c: 11, f: 4, cat: "Dals & curries" },
  { id: "kosambari", name: "Kosambari", serving: "1 katori", cal: 110, p: 5, c: 14, f: 4, cat: "Sabzi" },
  { id: "khara-bath", name: "Khara bath", serving: "1 cup", cal: 220, p: 5, c: 32, f: 8, cat: "Indian breakfast" },
  { id: "kesari-bath", name: "Kesari bath", serving: "1 cup", cal: 250, p: 3, c: 40, f: 9, cat: "Sweets" },
  { id: "puliyogare", name: "Puliyogare (tamarind rice)", serving: "1 cup", cal: 250, p: 5, c: 44, f: 7, cat: "Breads & rice" },
  { id: "ragi-sankatte", name: "Ragi sankatte", serving: "2 pieces", cal: 140, p: 4, c: 27, f: 1.5, cat: "Indian breakfast" },
  { id: "kadubu", name: "Kadubu (steamed rice cake)", serving: "2 pieces", cal: 175, p: 4, c: 30, f: 4.5, cat: "Indian breakfast" },
  { id: "dharwad-peda", name: "Dharwad peda", serving: "2 pieces", cal: 150, p: 4, c: 20, f: 6, cat: "Sweets" },
  { id: "chiroti", name: "Chiroti", serving: "2 pieces", cal: 200, p: 3, c: 26, f: 10, cat: "Sweets" },
  { id: "holige", name: "Holige / obbattu", serving: "1 piece", cal: 230, p: 6, c: 36, f: 7.5, cat: "Sweets" },
  { id: "thatte-idli", name: "Thatte idli", serving: "1 piece", cal: 140, p: 4, c: 24, f: 3, cat: "Indian breakfast" },
  { id: "benne-masala-dosa", name: "Benne masala dosa", serving: "1 piece", cal: 265, p: 5, c: 34, f: 12, cat: "Indian breakfast" },

  /* -------------------------- Andhra & Telangana ---------------------- */
  { id: "gongura-mutton", name: "Gongura mutton", serving: "1 katori", cal: 310, p: 23, c: 7, f: 21, cat: "Non-veg" },
  { id: "gongura-pappu", name: "Gongura pappu", serving: "1 katori", cal: 140, p: 7, c: 16, f: 5.5, cat: "Dals & curries" },
  { id: "pachi-pulusu", name: "Pachi pulusu (raw tamarind)", serving: "1 katori", cal: 80, p: 3, c: 10, f: 3.5, cat: "Dals & curries" },
  { id: "natu-kodi-pulusu", name: "Natu kodi pulusu (country chicken)", serving: "1 katori", cal: 270, p: 23, c: 7, f: 17, cat: "Non-veg" },
  { id: "andhra-pappu", name: "Andhra pappu (toor dal)", serving: "1 katori", cal: 130, p: 7, c: 17, f: 4, cat: "Dals & curries" },
  { id: "sarva-pindi", name: "Sarva pindi", serving: "1 piece", cal: 180, p: 4, c: 28, f: 6.5, cat: "Indian breakfast" },
  { id: "garelu", name: "Garelu (Andhra vada)", serving: "2 pieces", cal: 165, p: 5, c: 20, f: 8, cat: "Street & snacks" },
  { id: "sakinalu", name: "Sakinalu", serving: "4 pieces", cal: 170, p: 3, c: 24, f: 7.5, cat: "Snacks" },
  { id: "chegodilu", name: "Chegodilu", serving: "4 pieces", cal: 155, p: 3, c: 19, f: 8, cat: "Snacks" },
  { id: "janthikalu", name: "Janthikalu", serving: "4 pieces", cal: 160, p: 3, c: 21, f: 7.5, cat: "Snacks" },
  { id: "malidalu", name: "Malidalu", serving: "3 pieces", cal: 150, p: 3, c: 20, f: 7, cat: "Snacks" },
  { id: "bobbattu", name: "Bobbattu (sweet stuffed paratha)", serving: "1 piece", cal: 240, p: 6, c: 38, f: 7.5, cat: "Sweets" },
  { id: "pulihora", name: "Pulihora (Andhra tamarind rice)", serving: "1 cup", cal: 245, p: 5, c: 43, f: 7, cat: "Breads & rice" },
  { id: "daddojanam", name: "Daddojanam (tempered curd rice)", serving: "1 cup", cal: 190, p: 6, c: 32, f: 4.5, cat: "Everyday staples" },

  /* --------------------- Punjab, Awadh & Mughlai ---------------------- */
  { id: "amritsari-fish-tikka", name: "Amritsari fish tikka", serving: "3 pieces", cal: 230, p: 24, c: 7, f: 12, cat: "Non-veg" },
  { id: "tandoori-paneer", name: "Tandoori paneer tikka", serving: "4 pieces", cal: 240, p: 14, c: 8, f: 17, cat: "Sabzi" },
  { id: "stuffed-naan", name: "Stuffed naan", serving: "1 piece", cal: 330, p: 9, c: 48, f: 11, cat: "Breads & rice" },
  { id: "bedmi-puri", name: "Bedmi puri", serving: "2 pieces", cal: 190, p: 5, c: 28, f: 7.5, cat: "Breads & rice" },
  { id: "pinni", name: "Pinni", serving: "2 pieces", cal: 190, p: 4, c: 24, f: 9.5, cat: "Sweets" },
  { id: "makki-di-kheer", name: "Makki di kheer", serving: "1 katori", cal: 210, p: 5, c: 32, f: 7, cat: "Sweets" },
  { id: "atte-ka-halwa", name: "Atte ka halwa", serving: "1 katori", cal: 240, p: 4, c: 32, f: 11, cat: "Sweets" },
  { id: "kada-prasad", name: "Kada prasad (halwa)", serving: "1 katori", cal: 260, p: 3, c: 34, f: 13, cat: "Sweets" },
  { id: "imarti", name: "Imarti", serving: "2 pieces", cal: 210, p: 2, c: 36, f: 7, cat: "Sweets" },
  { id: "shakarkandi-halwa", name: "Shakarkandi halwa", serving: "1 katori", cal: 230, p: 3, c: 36, f: 9, cat: "Sweets" },
  { id: "rabri-lassi", name: "Rabri lassi", serving: "1 glass", cal: 240, p: 7, c: 30, f: 11, cat: "Beverages" },
  { id: "kesar-milk", name: "Kesar milk", serving: "1 glass", cal: 150, p: 6, c: 17, f: 7, cat: "Beverages" },
  { id: "haldi-doodh", name: "Haldi doodh (turmeric milk)", serving: "1 glass", cal: 140, p: 6, c: 16, f: 6, cat: "Beverages" },
  { id: "nihari", name: "Nihari", serving: "1 katori", cal: 320, p: 24, c: 8, f: 22, cat: "Non-veg" },
  { id: "paya", name: "Paya (trotter soup)", serving: "1 bowl", cal: 290, p: 22, c: 8, f: 19, cat: "Non-veg" },
  { id: "bheja-fry", name: "Bheja fry (brain fry)", serving: "1 katori", cal: 270, p: 18, c: 6, f: 20, cat: "Non-veg" },
  { id: "kaleji-fry", name: "Kaleji fry (liver fry)", serving: "1 katori", cal: 240, p: 22, c: 5, f: 15, cat: "Non-veg" },
  { id: "boti-fry", name: "Boti fry", serving: "1 katori", cal: 280, p: 21, c: 6, f: 20, cat: "Non-veg" },
  { id: "galouti-kebab", name: "Galouti kebab", serving: "2 pieces", cal: 230, p: 18, c: 6, f: 15, cat: "Non-veg" },
  { id: "kakori-kebab", name: "Kakori kebab", serving: "2 pieces", cal: 240, p: 19, c: 7, f: 15, cat: "Non-veg" },
  { id: "shami-kebab", name: "Shami kebab", serving: "2 pieces", cal: 220, p: 17, c: 9, f: 13, cat: "Non-veg" },
  { id: "chapli-kebab", name: "Chapli kebab", serving: "1 piece", cal: 260, p: 19, c: 10, f: 17, cat: "Non-veg" },
  { id: "seekh-kebab-chicken", name: "Chicken seekh kebab", serving: "2 pieces", cal: 220, p: 22, c: 7, f: 13, cat: "Non-veg" },
  { id: "tandoori-mutton-chops", name: "Tandoori mutton chops", serving: "2 pieces", cal: 320, p: 28, c: 6, f: 21, cat: "Non-veg" },
  { id: "chicken-kali-mirch", name: "Chicken kali mirch", serving: "1 katori", cal: 280, p: 24, c: 6, f: 18, cat: "Non-veg" },
  { id: "chicken-handi", name: "Chicken handi", serving: "1 katori", cal: 300, p: 23, c: 8, f: 19, cat: "Non-veg" },
  { id: "mutton-handi", name: "Mutton handi", serving: "1 katori", cal: 330, p: 24, c: 7, f: 23, cat: "Non-veg" },
  { id: "prawn-koliwada", name: "Prawn koliwada", serving: "6 pieces", cal: 240, p: 21, c: 9, f: 13, cat: "Non-veg" },
  { id: "bombil-fry", name: "Bombil fry (Bombay duck)", serving: "3 pieces", cal: 210, p: 20, c: 7, f: 11, cat: "Non-veg" },
  { id: "surmai-fry", name: "Surmai fry (king fish)", serving: "1 piece", cal: 225, p: 24, c: 4, f: 13, cat: "Non-veg" },
  { id: "bangda-fry", name: "Bangda fry (mackerel)", serving: "1 piece", cal: 215, p: 23, c: 4, f: 13, cat: "Non-veg" },
  { id: "pomfret-fry", name: "Pomfret fry", serving: "1 piece", cal: 205, p: 23, c: 3, f: 12, cat: "Non-veg" },

  /* ------------------- Maharashtrian & Goan extras -------------------- */
  { id: "bhakri", name: "Bhakri (millet flatbread)", serving: "1 piece", cal: 120, p: 3.5, c: 20, f: 2.5, cat: "Breads & rice" },
  { id: "varan-bhaat", name: "Varan bhaat", serving: "1 plate", cal: 280, p: 8, c: 48, f: 6, cat: "Everyday staples" },
  { id: "vatanyachi-usal", name: "Vatanyachi usal (dried peas)", serving: "1 katori", cal: 155, p: 8, c: 20, f: 5, cat: "Beans & dals" },
  { id: "tambda-rassa", name: "Tambda rassa (red mutton curry)", serving: "1 katori", cal: 280, p: 22, c: 7, f: 18, cat: "Non-veg" },
  { id: "pandra-rassa", name: "Pandra rassa (white mutton curry)", serving: "1 katori", cal: 260, p: 21, c: 7, f: 17, cat: "Non-veg" },
  { id: "mutton-rassa", name: "Mutton rassa", serving: "1 katori", cal: 310, p: 23, c: 6, f: 22, cat: "Non-veg" },
  { id: "fara", name: "Fara (steamed rice rolls)", serving: "1 katori", cal: 175, p: 6, c: 26, f: 5.5, cat: "Indian breakfast" },
  { id: "bombay-sandwich", name: "Bombay sandwich", serving: "1 sandwich", cal: 280, p: 9, c: 38, f: 11, cat: "Street & snacks" },
  { id: "muthia", name: "Muthia", serving: "4 pieces", cal: 160, p: 5, c: 22, f: 6, cat: "Indian breakfast" },
  { id: "ghughra", name: "Ghughra (sweet dumpling)", serving: "2 pieces", cal: 180, p: 4, c: 24, f: 8, cat: "Sweets" },
  { id: "sev-khaman", name: "Sev khaman", serving: "1 piece", cal: 140, p: 5, c: 20, f: 5.5, cat: "Street & snacks" },
  { id: "methi-na-gota", name: "Methi na gota", serving: "4 pieces", cal: 165, p: 5, c: 21, f: 7.5, cat: "Street & snacks" },
  { id: "surti-locho", name: "Surti locho", serving: "1 katori", cal: 175, p: 6, c: 27, f: 5.5, cat: "Indian breakfast" },
  { id: "kumro-chokha", name: "Kumro chokha (mashed pumpkin)", serving: "1 katori", cal: 120, p: 3, c: 15, f: 5.5, cat: "Sabzi" },
  { id: "bajre-ki-roti", name: "Bajre ki roti", serving: "1 roti", cal: 115, p: 3.5, c: 21, f: 2, cat: "Breads & rice" },
  { id: "rabodi", name: "Rabodi (corn papad curry)", serving: "1 katori", cal: 145, p: 4, c: 22, f: 5, cat: "Sabzi" },

  /* ---------------------- Festival foods & prasad -------------------- */
  { id: "panchamrit", name: "Panchamrit", serving: "1 katori", cal: 120, p: 3, c: 18, f: 4.5, cat: "Festival & prasad" },
  { id: "tirupati-laddu", name: "Tirupati laddu", serving: "1 piece", cal: 190, p: 4, c: 26, f: 8.5, cat: "Festival & prasad" },
  { id: "sabudana-kheer", name: "Sabudana kheer", serving: "1 katori", cal: 175, p: 3, c: 27, f: 6, cat: "Sweets" },
  { id: "anarsa", name: "Anarsa", serving: "2 pieces", cal: 170, p: 3, c: 24, f: 7.5, cat: "Festival & prasad" },
  { id: "panakam", name: "Panakam (jaggery drink)", serving: "1 glass", cal: 90, p: 0.5, c: 22, f: 0.1, cat: "Beverages" },
  { id: "kokum-sarbat", name: "Kokum sarbat", serving: "1 glass", cal: 70, p: 0.5, c: 17, f: 0.2, cat: "Beverages" },
  { id: "til-gul", name: "Til gul", serving: "3 pieces", cal: 130, p: 2.5, c: 16, f: 6.5, cat: "Festival & prasad" },
  { id: "maa-ki-prasad-kheer", name: "Prasad kheer", serving: "1 katori", cal: 185, p: 5, c: 27, f: 6.5, cat: "Festival & prasad" },

  /* ------------------------- More Indian street ----------------------- */
  { id: "paneer-65", name: "Paneer 65", serving: "6 pieces", cal: 230, p: 12, c: 12, f: 16, cat: "Street & snacks" },
  { id: "egg-65", name: "Egg 65", serving: "4 pieces", cal: 210, p: 14, c: 8, f: 14, cat: "Street & snacks" },
  { id: "fish-65", name: "Fish 65", serving: "6 pieces", cal: 220, p: 20, c: 9, f: 12, cat: "Street & snacks" },
  { id: "chilli-gobi", name: "Chilli gobi", serving: "1 katori", cal: 320, p: 7, c: 38, f: 15, cat: "Street & snacks" },
  { id: "chilli-soya", name: "Chilli soya chunks", serving: "1 katori", cal: 260, p: 18, c: 16, f: 14, cat: "Street & snacks" },
  { id: "crispy-corn", name: "Crispy corn", serving: "1 bowl", cal: 210, p: 5, c: 26, f: 10, cat: "Street & snacks" },
  { id: "masala-corn", name: "Masala corn cup", serving: "1 cup", cal: 150, p: 4, c: 28, f: 3.5, cat: "Street & snacks" },
  { id: "cheese-garlic-bread", name: "Cheese garlic bread", serving: "1 piece", cal: 280, p: 9, c: 32, f: 14, cat: "Street & snacks" },
  { id: "veg-cheese-toastie", name: "Veg cheese toastie", serving: "1 sandwich", cal: 300, p: 10, c: 36, f: 13, cat: "Street & snacks" },
  { id: "paneer-kathi-roll", name: "Paneer kathi roll", serving: "1 roll", cal: 390, p: 15, c: 40, f: 19, cat: "Street & snacks" },
  { id: "chicken-kathi-roll", name: "Chicken kathi roll", serving: "1 roll", cal: 400, p: 22, c: 40, f: 17, cat: "Street & snacks" },
  { id: "egg-kathi-roll", name: "Egg kathi roll", serving: "1 roll", cal: 360, p: 15, c: 40, f: 16, cat: "Street & snacks" },
  { id: "veg-kofta-curry", name: "Veg kofta curry", serving: "1 katori (2 kofta)", cal: 190, p: 6, c: 17, f: 10, cat: "Sabzi" },
  { id: "kathal-ki-sabzi", name: "Kathal ki sabzi (jackfruit)", serving: "1 katori", cal: 135, p: 3, c: 19, f: 6, cat: "Sabzi" },
  { id: "arbi-ki-sabzi", name: "Arbi ki sabzi (colocasia)", serving: "1 katori", cal: 140, p: 2, c: 22, f: 6, cat: "Sabzi" },
  { id: "turai-ki-sabzi", name: "Turai ki sabzi (ridge gourd)", serving: "1 katori", cal: 75, p: 2, c: 9, f: 3.5, cat: "Sabzi" },
  { id: "jhinga-masala", name: "Jhinga masala (prawn masala)", serving: "1 katori", cal: 215, p: 21, c: 7, f: 12, cat: "Non-veg" },
  { id: "egg-curry-spicy", name: "Spicy egg curry", serving: "2 eggs + gravy", cal: 265, p: 14, c: 7, f: 19, cat: "Non-veg" },

  /* ---------------------- Global: Italian & European ------------------ */
  { id: "margherita-pizza", name: "Margherita pizza", serving: "1 slice", cal: 250, p: 10, c: 30, f: 10, cat: "Global cuisine" },
  { id: "pepperoni-pizza", name: "Pepperoni pizza", serving: "1 slice", cal: 290, p: 12, c: 30, f: 14, cat: "Global cuisine" },
  { id: "pasta-bolognese", name: "Pasta bolognese", serving: "1 plate", cal: 480, p: 22, c: 62, f: 17, cat: "Global cuisine" },
  { id: "spaghetti-carbonara", name: "Spaghetti carbonara", serving: "1 plate", cal: 520, p: 24, c: 60, f: 22, cat: "Global cuisine" },
  { id: "pasta-alfredo", name: "Pasta alfredo", serving: "1 plate", cal: 550, p: 20, c: 62, f: 26, cat: "Global cuisine" },
  { id: "pesto-pasta", name: "Pesto pasta", serving: "1 plate", cal: 480, p: 16, c: 60, f: 21, cat: "Global cuisine" },
  { id: "pasta-arrabiata", name: "Pasta arrabiata", serving: "1 plate", cal: 420, p: 15, c: 62, f: 14, cat: "Global cuisine" },
  { id: "lasagna", name: "Lasagna", serving: "1 slice", cal: 350, p: 20, c: 30, f: 17, cat: "Global cuisine" },
  { id: "mac-and-cheese", name: "Mac and cheese", serving: "1 cup", cal: 380, p: 14, c: 45, f: 17, cat: "Global cuisine" },
  { id: "ravioli", name: "Cheese ravioli", serving: "6 pieces", cal: 350, p: 15, c: 42, f: 14, cat: "Global cuisine" },
  { id: "gnocchi", name: "Gnocchi", serving: "1 plate", cal: 380, p: 10, c: 55, f: 14, cat: "Global cuisine" },
  { id: "risotto", name: "Risotto", serving: "1 plate", cal: 400, p: 12, c: 55, f: 14, cat: "Global cuisine" },
  { id: "paella", name: "Paella", serving: "1 plate", cal: 420, p: 25, c: 50, f: 15, cat: "Global cuisine" },
  { id: "croque-monsieur", name: "Croque monsieur", serving: "1 sandwich", cal: 400, p: 20, c: 34, f: 21, cat: "Global cuisine" },
  { id: "quiche", name: "Quiche lorraine", serving: "1 slice", cal: 300, p: 12, c: 22, f: 19, cat: "Global cuisine" },
  { id: "french-onion-soup", name: "French onion soup", serving: "1 bowl", cal: 180, p: 6, c: 20, f: 8, cat: "Global cuisine" },
  { id: "potato-gratin", name: "Potato gratin", serving: "1 serving", cal: 320, p: 8, c: 34, f: 17, cat: "Global cuisine" },
  { id: "shepherds-pie", name: "Shepherd's pie", serving: "1 serving", cal: 350, p: 18, c: 32, f: 16, cat: "Global cuisine" },
  { id: "fish-and-chips", name: "Fish and chips", serving: "1 serving", cal: 480, p: 25, c: 50, f: 22, cat: "Global cuisine" },
  { id: "baked-potato", name: "Baked potato", serving: "1 medium", cal: 280, p: 7, c: 45, f: 6, cat: "Global cuisine" },
  { id: "mashed-potato", name: "Mashed potato", serving: "1 cup", cal: 240, p: 5, c: 35, f: 9, cat: "Global cuisine" },
  { id: "sweet-potato-fries", name: "Sweet potato fries", serving: "1 serving", cal: 300, p: 4, c: 45, f: 13, cat: "Global cuisine" },

  /* ---------------- Global: Americas, Asia, Middle East --------------- */
  { id: "cheese-burger", name: "Cheeseburger", serving: "1 burger", cal: 520, p: 25, c: 42, f: 28, cat: "Global cuisine" },
  { id: "chicken-nuggets", name: "Chicken nuggets", serving: "6 pieces", cal: 280, p: 16, c: 24, f: 13, cat: "Global cuisine" },
  { id: "fried-chicken", name: "Fried chicken", serving: "2 pieces", cal: 380, p: 26, c: 24, f: 20, cat: "Global cuisine" },
  { id: "hot-dog", name: "Hot dog", serving: "1 hot dog", cal: 290, p: 11, c: 24, f: 17, cat: "Global cuisine" },
  { id: "meatball-sub", name: "Meatball sub", serving: "1 sub", cal: 450, p: 22, c: 48, f: 20, cat: "Global cuisine" },
  { id: "onion-rings", name: "Onion rings", serving: "6 rings", cal: 280, p: 4, c: 34, f: 15, cat: "Global cuisine" },
  { id: "mozzarella-sticks", name: "Mozzarella sticks", serving: "4 pieces", cal: 300, p: 14, c: 24, f: 17, cat: "Global cuisine" },
  { id: "grilled-cheese", name: "Grilled cheese sandwich", serving: "1 sandwich", cal: 360, p: 14, c: 34, f: 19, cat: "Global cuisine" },
  { id: "tacos", name: "Beef tacos", serving: "2 tacos", cal: 340, p: 18, c: 32, f: 14, cat: "Global cuisine" },
  { id: "burrito", name: "Chicken burrito", serving: "1 burrito", cal: 480, p: 25, c: 58, f: 17, cat: "Global cuisine" },
  { id: "quesadilla", name: "Cheese quesadilla", serving: "1 quesadilla", cal: 380, p: 16, c: 40, f: 18, cat: "Global cuisine" },
  { id: "ramen", name: "Chicken ramen", serving: "1 bowl", cal: 500, p: 25, c: 65, f: 16, cat: "Global cuisine" },
  { id: "pho", name: "Pho (Vietnamese noodle soup)", serving: "1 bowl", cal: 350, p: 25, c: 45, f: 8, cat: "Global cuisine" },
  { id: "pad-thai", name: "Pad Thai", serving: "1 plate", cal: 430, p: 16, c: 58, f: 15, cat: "Global cuisine" },
  { id: "green-curry", name: "Thai green curry with rice", serving: "1 katori + rice", cal: 280, p: 18, c: 12, f: 19, cat: "Global cuisine" },
  { id: "tom-yum", name: "Tom yum soup", serving: "1 bowl", cal: 120, p: 8, c: 10, f: 5, cat: "Global cuisine" },
  { id: "miso-soup", name: "Miso soup", serving: "1 bowl", cal: 40, p: 3, c: 4, f: 1.5, cat: "Global cuisine" },
  { id: "sushi-roll", name: "Sushi roll", serving: "4 pieces", cal: 240, p: 10, c: 38, f: 5, cat: "Global cuisine" },
  { id: "chicken-teriyaki", name: "Chicken teriyaki with rice", serving: "1 plate", cal: 350, p: 30, c: 30, f: 11, cat: "Global cuisine" },
  { id: "kimchi", name: "Kimchi", serving: "1 katori", cal: 30, p: 1.5, c: 4, f: 1, cat: "Global cuisine" },
  { id: "bibimbap", name: "Bibimbap", serving: "1 bowl", cal: 430, p: 18, c: 60, f: 13, cat: "Global cuisine" },
  { id: "chinese-fried-rice", name: "Chinese fried rice", serving: "1 plate", cal: 380, p: 12, c: 56, f: 12, cat: "Global cuisine" },
  { id: "dumplings-chinese", name: "Chinese dumplings", serving: "4 pieces", cal: 230, p: 9, c: 30, f: 8, cat: "Global cuisine" },
  { id: "mapo-tofu", name: "Mapo tofu with rice", serving: "1 katori + rice", cal: 230, p: 13, c: 12, f: 15, cat: "Global cuisine" },
  { id: "kung-pao-chicken", name: "Kung pao chicken", serving: "1 plate", cal: 320, p: 26, c: 20, f: 16, cat: "Global cuisine" },
  { id: "sweet-sour-chicken", name: "Sweet and sour chicken", serving: "1 plate", cal: 350, p: 24, c: 40, f: 11, cat: "Global cuisine" },
  { id: "chicken-satay", name: "Chicken satay", serving: "2 skewers", cal: 220, p: 20, c: 10, f: 12, cat: "Global cuisine" },
  { id: "hummus", name: "Hummus", serving: "2 tbsp", cal: 70, p: 2, c: 6, f: 4.5, cat: "Global cuisine" },
  { id: "falafel", name: "Falafel", serving: "4 pieces", cal: 200, p: 8, c: 20, f: 10, cat: "Global cuisine" },
  { id: "kebab-platter", name: "Chicken kebab platter", serving: "2 skewers", cal: 280, p: 25, c: 8, f: 16, cat: "Global cuisine" },
  { id: "baba-ganoush", name: "Baba ganoush", serving: "2 tbsp", cal: 45, p: 1, c: 4, f: 3, cat: "Global cuisine" },
  { id: "baklava", name: "Baklava", serving: "2 pieces", cal: 200, p: 3, c: 22, f: 12, cat: "Global cuisine" },

  /* --------------------- Global breakfast & bakery -------------------- */
  { id: "english-breakfast", name: "English breakfast", serving: "1 plate", cal: 550, p: 28, c: 45, f: 28, cat: "Global cuisine" },
  { id: "eggs-benedict", name: "Eggs benedict", serving: "1 serving", cal: 350, p: 18, c: 24, f: 20, cat: "Global cuisine" },
  { id: "scrambled-eggs-plain", name: "Scrambled eggs", serving: "2 eggs", cal: 190, p: 12, c: 2, f: 15, cat: "Protein" },
  { id: "french-omelette", name: "French omelette", serving: "2 eggs", cal: 210, p: 14, c: 2, f: 16, cat: "Protein" },
  { id: "hash-browns", name: "Hash browns", serving: "2 pieces", cal: 250, p: 3, c: 32, f: 12, cat: "Global cuisine" },
  { id: "bagel-cream-cheese", name: "Bagel with cream cheese", serving: "1 bagel", cal: 320, p: 11, c: 48, f: 9, cat: "Global cuisine" },
  { id: "avocado-toast", name: "Avocado toast", serving: "1 slice", cal: 250, p: 7, c: 24, f: 15, cat: "Global cuisine" },
  { id: "pancakes", name: "Pancakes", serving: "2 pieces", cal: 260, p: 7, c: 38, f: 9, cat: "Global cuisine" },
  { id: "banana-pancakes", name: "Banana pancakes", serving: "2 pieces", cal: 250, p: 7, c: 40, f: 8, cat: "Global cuisine" },
  { id: "waffles", name: "Waffles", serving: "1 waffle", cal: 220, p: 6, c: 29, f: 9, cat: "Global cuisine" },
  { id: "croissant", name: "Croissant", serving: "1 piece", cal: 270, p: 6, c: 31, f: 14, cat: "Global cuisine" },
  { id: "cinnamon-roll", name: "Cinnamon roll", serving: "1 roll", cal: 320, p: 6, c: 44, f: 14, cat: "Global cuisine" },
  { id: "blueberry-muffin", name: "Blueberry muffin", serving: "1 muffin", cal: 340, p: 6, c: 48, f: 14, cat: "Global cuisine" },
  { id: "chocolate-muffin", name: "Chocolate muffin", serving: "1 muffin", cal: 370, p: 6, c: 50, f: 16, cat: "Global cuisine" },
  { id: "donut-glazed", name: "Glazed donut", serving: "1 donut", cal: 240, p: 4, c: 34, f: 11, cat: "Global cuisine" },
  { id: "donut-chocolate", name: "Chocolate donut", serving: "1 donut", cal: 270, p: 4, c: 36, f: 13, cat: "Global cuisine" },
  { id: "granola-bowl", name: "Granola bowl with milk", serving: "1 bowl", cal: 330, p: 8, c: 52, f: 11, cat: "Everyday staples" },
  { id: "chia-pudding", name: "Chia pudding", serving: "1 jar", cal: 280, p: 9, c: 32, f: 14, cat: "Everyday staples" },
  { id: "overnight-oats", name: "Overnight oats", serving: "1 jar", cal: 320, p: 12, c: 48, f: 9, cat: "Everyday staples" },
  { id: "smoothie-bowl", name: "Smoothie bowl", serving: "1 bowl", cal: 320, p: 8, c: 52, f: 10, cat: "Beverages" },
  { id: "greek-yogurt-honey", name: "Greek yogurt with honey", serving: "1 bowl", cal: 180, p: 12, c: 22, f: 4, cat: "Dairy" },

  /* ---------------------- Global desserts & snacks ------------------- */
  { id: "brownie", name: "Chocolate brownie", serving: "1 piece", cal: 260, p: 4, c: 34, f: 13, cat: "Global cuisine" },
  { id: "chocolate-cake", name: "Chocolate cake", serving: "1 slice", cal: 280, p: 4, c: 40, f: 12, cat: "Global cuisine" },
  { id: "vanilla-cake", name: "Vanilla cake", serving: "1 slice", cal: 250, p: 4, c: 38, f: 10, cat: "Global cuisine" },
  { id: "red-velvet-cake", name: "Red velvet cake", serving: "1 slice", cal: 300, p: 5, c: 40, f: 14, cat: "Global cuisine" },
  { id: "cheesecake", name: "Cheesecake", serving: "1 slice", cal: 320, p: 6, c: 34, f: 19, cat: "Global cuisine" },
  { id: "tiramisu", name: "Tiramisu", serving: "1 slice", cal: 300, p: 5, c: 30, f: 18, cat: "Global cuisine" },
  { id: "apple-pie", name: "Apple pie", serving: "1 slice", cal: 280, p: 3, c: 40, f: 12, cat: "Global cuisine" },
  { id: "chocolate-chip-cookie", name: "Chocolate chip cookies", serving: "2 cookies", cal: 180, p: 3, c: 24, f: 9, cat: "Global cuisine" },
  { id: "oatmeal-cookie", name: "Oatmeal cookies", serving: "2 cookies", cal: 160, p: 3, c: 24, f: 7, cat: "Global cuisine" },
  { id: "ice-cream-cone", name: "Ice cream cone", serving: "1 cone", cal: 160, p: 3, c: 20, f: 8, cat: "Global cuisine" },

  /* ---------------- Global soups, sauces & condiments ---------------- */
  { id: "minestrone", name: "Minestrone soup", serving: "1 bowl", cal: 180, p: 8, c: 26, f: 5, cat: "Global cuisine" },
  { id: "tomato-basil-soup", name: "Tomato basil soup", serving: "1 bowl", cal: 150, p: 4, c: 18, f: 7, cat: "Global cuisine" },
  { id: "chicken-noodle-soup", name: "Chicken noodle soup", serving: "1 bowl", cal: 180, p: 14, c: 20, f: 5, cat: "Global cuisine" },
  { id: "lentil-soup", name: "Lentil soup", serving: "1 bowl", cal: 190, p: 10, c: 28, f: 4, cat: "Global cuisine" },
  { id: "pumpkin-soup", name: "Pumpkin soup", serving: "1 bowl", cal: 140, p: 4, c: 20, f: 5, cat: "Global cuisine" },
  { id: "broccoli-cheddar-soup", name: "Broccoli cheddar soup", serving: "1 bowl", cal: 230, p: 8, c: 20, f: 14, cat: "Global cuisine" },
  { id: "guacamole", name: "Guacamole", serving: "2 tbsp", cal: 60, p: 1, c: 4, f: 5, cat: "Global cuisine" },
  { id: "salsa", name: "Salsa", serving: "2 tbsp", cal: 20, p: 0.5, c: 4, f: 0.2, cat: "Global cuisine" },
  { id: "sour-cream", name: "Sour cream", serving: "1 tbsp", cal: 30, p: 0.5, c: 1, f: 3, cat: "Global cuisine" },
  { id: "ketchup", name: "Ketchup", serving: "1 tbsp", cal: 20, p: 0, c: 5, f: 0, cat: "Condiments" },
  { id: "mustard-sauce", name: "Mustard sauce", serving: "1 tsp", cal: 5, p: 0, c: 0.5, f: 0.3, cat: "Condiments" },
  { id: "mayo", name: "Mayonnaise", serving: "1 tbsp", cal: 95, p: 0, c: 0, f: 10, cat: "Condiments" },
  { id: "bbq-sauce", name: "BBQ sauce", serving: "1 tbsp", cal: 30, p: 0, c: 7, f: 0.2, cat: "Condiments" },
  { id: "hot-sauce", name: "Hot sauce", serving: "1 tsp", cal: 5, p: 0, c: 1, f: 0, cat: "Condiments" },
  { id: "ranch-dressing", name: "Ranch dressing", serving: "1 tbsp", cal: 70, p: 0, c: 1, f: 7, cat: "Condiments" },
  { id: "caesar-dressing", name: "Caesar dressing", serving: "1 tbsp", cal: 80, p: 0, c: 1, f: 9, cat: "Condiments" },
  { id: "vinaigrette", name: "Vinaigrette", serving: "1 tbsp", cal: 45, p: 0, c: 1, f: 4.5, cat: "Condiments" },
  { id: "peanut-sauce", name: "Peanut sauce", serving: "1 tbsp", cal: 60, p: 3, c: 3, f: 5, cat: "Condiments" },
  { id: "sambal-olek", name: "Sambal oelek", serving: "1 tsp", cal: 10, p: 0, c: 2, f: 0.5, cat: "Condiments" },
  { id: "tzatziki", name: "Tzatziki", serving: "2 tbsp", cal: 35, p: 2, c: 2, f: 2.5, cat: "Condiments" },
  { id: "pesto", name: "Basil pesto", serving: "1 tbsp", cal: 45, p: 1, c: 1, f: 4.5, cat: "Condiments" },
  { id: "mint-yogurt", name: "Mint yogurt dip", serving: "2 tbsp", cal: 30, p: 2, c: 3, f: 1.5, cat: "Condiments" },
  { id: "garlic-pickle", name: "Garlic pickle", serving: "1 tsp", cal: 25, p: 0.5, c: 2, f: 1.5, cat: "Pickles & chutneys" },
  { id: "chilli-garlic-chutney", name: "Chilli garlic chutney", serving: "1 tbsp", cal: 40, p: 1, c: 4, f: 2.5, cat: "Pickles & chutneys" },
  { id: "tomato-pickle", name: "Tomato pickle", serving: "1 tsp", cal: 20, p: 0.3, c: 2, f: 1.2, cat: "Pickles & chutneys" },
  { id: "onion-pickle", name: "Onion pickle", serving: "1 tsp", cal: 18, p: 0.3, c: 2, f: 1, cat: "Pickles & chutneys" },
  { id: "ginger-pickle", name: "Ginger pickle", serving: "1 tsp", cal: 22, p: 0.3, c: 3, f: 1, cat: "Pickles & chutneys" },
  { id: "thecha", name: "Thecha (chilli garlic relish)", serving: "1 tbsp", cal: 45, p: 1, c: 4, f: 3, cat: "Pickles & chutneys" },
  { id: "kairi-chunda", name: "Kairi chunda (raw mango)", serving: "1 tbsp", cal: 35, p: 0.3, c: 8, f: 0.5, cat: "Pickles & chutneys" },
  { id: "shalgam-ka-achaar", name: "Shalgam ka achaar", serving: "1 tsp", cal: 20, p: 0.3, c: 2, f: 1.2, cat: "Pickles & chutneys" },

  /* ------------------------ More global mains ------------------------ */
  { id: "coleslaw", name: "Coleslaw", serving: "1 cup", cal: 150, p: 2, c: 15, f: 10, cat: "Global cuisine" },
  { id: "baked-beans", name: "Baked beans", serving: "1/2 cup", cal: 140, p: 6, c: 26, f: 2, cat: "Global cuisine" },
  { id: "potato-salad", name: "Potato salad", serving: "1 cup", cal: 180, p: 4, c: 24, f: 8, cat: "Global cuisine" },
  { id: "caesar-salad", name: "Caesar salad", serving: "1 bowl", cal: 280, p: 15, c: 12, f: 20, cat: "Global cuisine" },
  { id: "greek-salad", name: "Greek salad", serving: "1 bowl", cal: 180, p: 6, c: 10, f: 14, cat: "Global cuisine" },
  { id: "caprese-salad", name: "Caprese salad", serving: "1 bowl", cal: 200, p: 10, c: 6, f: 16, cat: "Global cuisine" },
  { id: "quinoa-bowl", name: "Quinoa power bowl", serving: "1 bowl", cal: 350, p: 14, c: 50, f: 11, cat: "Global cuisine" },
  { id: "buddha-bowl", name: "Buddha bowl", serving: "1 bowl", cal: 400, p: 15, c: 52, f: 15, cat: "Global cuisine" },
  { id: "grilled-chicken-breast", name: "Grilled chicken breast", serving: "150 g", cal: 250, p: 46, c: 0, f: 7, cat: "Protein" },
  { id: "salmon-fillet", name: "Grilled salmon fillet", serving: "120 g", cal: 250, p: 25, c: 0, f: 16, cat: "Protein" },
  { id: "steak-beef", name: "Beef steak", serving: "150 g", cal: 300, p: 34, c: 0, f: 18, cat: "Protein" },
  { id: "turkey-slice", name: "Roast turkey slice", serving: "100 g", cal: 120, p: 24, c: 2, f: 2, cat: "Protein" },
  { id: "roast-beef-slice", name: "Roast beef slice", serving: "100 g", cal: 150, p: 25, c: 0, f: 6, cat: "Protein" },
  { id: "protein-pancakes", name: "Protein pancakes", serving: "2 pieces", cal: 240, p: 24, c: 26, f: 5, cat: "Protein" },
  { id: "cottage-cheese-bowl", name: "Cottage cheese bowl", serving: "1 cup", cal: 180, p: 20, c: 8, f: 8, cat: "Protein" },

  /* ------------------------- Drinks & shakes -------------------------- */
  { id: "cappuccino", name: "Cappuccino", serving: "1 cup", cal: 80, p: 4, c: 8, f: 4, cat: "Beverages" },
  { id: "latte", name: "Latte", serving: "1 cup", cal: 120, p: 6, c: 12, f: 6, cat: "Beverages" },
  { id: "espresso", name: "Espresso", serving: "1 shot", cal: 5, p: 0, c: 0.5, f: 0, cat: "Beverages" },
  { id: "iced-coffee", name: "Iced coffee", serving: "1 glass", cal: 120, p: 3, c: 18, f: 4, cat: "Beverages" },
  { id: "hot-chocolate", name: "Hot chocolate", serving: "1 cup", cal: 230, p: 7, c: 30, f: 9, cat: "Beverages" },
  { id: "matcha-latte", name: "Matcha latte", serving: "1 cup", cal: 90, p: 4, c: 12, f: 3.5, cat: "Beverages" },
  { id: "bubble-tea", name: "Bubble tea", serving: "1 glass", cal: 300, p: 4, c: 58, f: 6, cat: "Beverages" },
  { id: "lemonade", name: "Lemonade", serving: "1 glass", cal: 90, p: 0, c: 23, f: 0, cat: "Beverages" },
  { id: "iced-tea", name: "Iced tea", serving: "1 glass", cal: 70, p: 0, c: 18, f: 0, cat: "Beverages" },
  { id: "orange-soda", name: "Orange soda", serving: "1 glass", cal: 110, p: 0, c: 28, f: 0, cat: "Beverages" },
  { id: "ginger-ale", name: "Ginger ale", serving: "1 glass", cal: 95, p: 0, c: 24, f: 0, cat: "Beverages" },
  { id: "milkshake-vanilla", name: "Vanilla milkshake", serving: "1 glass", cal: 300, p: 7, c: 44, f: 11, cat: "Beverages" },
  { id: "milkshake-chocolate", name: "Chocolate milkshake", serving: "1 glass", cal: 330, p: 7, c: 48, f: 13, cat: "Beverages" },
  { id: "milkshake-strawberry", name: "Strawberry milkshake", serving: "1 glass", cal: 290, p: 6, c: 44, f: 10, cat: "Beverages" },
  { id: "oreo-shake", name: "Oreo shake", serving: "1 glass", cal: 320, p: 6, c: 44, f: 14, cat: "Beverages" },
  { id: "cold-cocoa", name: "Cold cocoa", serving: "1 glass", cal: 190, p: 6, c: 26, f: 7, cat: "Beverages" },
  { id: "lemon-soda", name: "Lemon soda", serving: "1 glass", cal: 80, p: 0, c: 21, f: 0, cat: "Beverages" },
  { id: "protein-lassi", name: "Protein lassi", serving: "1 glass", cal: 230, p: 22, c: 28, f: 5, cat: "Beverages" },
];

export const MEALS = [
  { id: "breakfast", label: "Breakfast" },
  { id: "lunch", label: "Lunch" },
  { id: "dinner", label: "Dinner" },
  { id: "snacks", label: "Snacks" },
] as const;

export type MealType = (typeof MEALS)[number]["id"];
