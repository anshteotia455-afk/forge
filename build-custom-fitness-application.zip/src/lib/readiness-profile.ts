/* ------------- Training history & body type personalisation ------------ */

/** How long since their last real workout, asked at setup. */
export type TrainingGap =
  | "active"
  | "weeks2"
  | "months1"
  | "months3"
  | "months6"
  | "year"
  | "never";

export interface GapOption {
  id: TrainingGap;
  label: string;
  hint: string;
}

export const TRAINING_GAPS: GapOption[] = [
  { id: "active", label: "I'm training now", hint: "Trained within the last week" },
  { id: "weeks2", label: "A couple of weeks", hint: "Short break — holiday or busy spell" },
  { id: "months1", label: "About a month", hint: "Starting to lose conditioning" },
  { id: "months3", label: "Around 3 months", hint: "Noticeable strength and fitness loss" },
  { id: "months6", label: "6 months or so", hint: "Essentially starting over, but faster" },
  { id: "year", label: "A year or more", hint: "Long layoff — rebuild carefully" },
  { id: "never", label: "I've never trained", hint: "Complete beginner — welcome" },
];

/** Classic somatotypes, used as a soft tendency rather than a rigid rule. */
export type BodyType = "ecto" | "meso" | "endo" | "unsure";

export interface BodyTypeOption {
  id: BodyType;
  label: string;
  hint: string;
  icon: string;
}

export const BODY_TYPES: BodyTypeOption[] = [
  {
    id: "ecto",
    label: "Lean / hard gainer",
    hint: "Naturally slim, struggles to add weight or muscle",
    icon: "🪶",
  },
  {
    id: "meso",
    label: "Athletic build",
    hint: "Gains muscle fairly easily, responds fast to training",
    icon: "🪨",
  },
  {
    id: "endo",
    label: "Softer / gains easily",
    hint: "Builds strength well but stores fat more readily",
    icon: "🛡️",
  },
  {
    id: "unsure",
    label: "Not sure",
    hint: "We'll use balanced defaults and adapt to your data",
    icon: "❓",
  },
];

/* --------------------------- Training status --------------------------- */

export interface TrainingStatus {
  gap: TrainingGap;
  /** 0 = fully detrained, 1 = fully trained */
  conditioning: number;
  /** intensity the generator should start at */
  startLevel: 1 | 2 | 3;
  /** percentage of a "normal" session to attempt in week 1 */
  startVolumePct: number;
  /** sessions per week to begin with */
  weeklySessions: number;
  /** how many weeks to ramp back to full training */
  rampWeeks: number;
  /** recommended split template id from splits.ts */
  splitId: string;
  headline: string;
  guidance: string;
  /** shown while they are still ramping up */
  caution: string | null;
}

const GAP_TABLE: Record<TrainingGap, Omit<TrainingStatus, "gap">> = {
  active: {
    conditioning: 1,
    startLevel: 2,
    startVolumePct: 100,
    weeklySessions: 4,
    rampWeeks: 0,
    splitId: "ul4",
    headline: "Carry on where you are",
    guidance:
      "You're already training, so we'll keep your usual intensity and progress from there.",
    caution: null,
  },
  weeks2: {
    conditioning: 0.85,
    startLevel: 2,
    startVolumePct: 85,
    weeklySessions: 3,
    rampWeeks: 1,
    splitId: "ul4",
    headline: "Quick ramp back",
    guidance:
      "A short break barely dents your fitness. Ease in for one week, then resume normal training.",
    caution: "Expect some soreness for the first two sessions — that's normal.",
  },
  months1: {
    conditioning: 0.7,
    startLevel: 2,
    startVolumePct: 70,
    weeklySessions: 3,
    rampWeeks: 2,
    splitId: "full3",
    headline: "Two-week rebuild",
    guidance:
      "Strength returns quickly thanks to muscle memory. Start with full-body sessions at moderate intensity.",
    caution: "Leave 2–3 reps in reserve for the first two weeks.",
  },
  months3: {
    conditioning: 0.5,
    startLevel: 1,
    startVolumePct: 55,
    weeklySessions: 3,
    rampWeeks: 4,
    splitId: "full3",
    headline: "Four-week rebuild",
    guidance:
      "Your muscles recover faster than your tendons and joints. Lighter loads, full range, strict form.",
    caution: "Avoid training to failure for the first month.",
  },
  months6: {
    conditioning: 0.35,
    startLevel: 1,
    startVolumePct: 45,
    weeklySessions: 3,
    rampWeeks: 6,
    splitId: "full3",
    headline: "Six-week foundation",
    guidance:
      "Rebuild the base before chasing numbers. Movement quality first, load second.",
    caution: "Expect significant soreness early — add a rest day whenever you need it.",
  },
  year: {
    conditioning: 0.2,
    startLevel: 1,
    startVolumePct: 35,
    weeklySessions: 3,
    rampWeeks: 8,
    splitId: "full3",
    headline: "Eight-week return",
    guidance:
      "Treat this as a fresh start with an advantage: your body relearns movement patterns fast.",
    caution: "Start lighter than feels necessary. The first month is about consistency, not effort.",
  },
  never: {
    conditioning: 0.15,
    startLevel: 1,
    startVolumePct: 40,
    weeklySessions: 3,
    rampWeeks: 8,
    splitId: "full3",
    headline: "Beginner foundation",
    guidance:
      "Full-body sessions three times a week build strength fastest when you're new to training.",
    caution: "Master the bodyweight version of a movement before adding load.",
  },
};

export function trainingStatusOf(gap: TrainingGap | undefined): TrainingStatus {
  const key: TrainingGap = gap ?? "months3";
  return { gap: key, ...GAP_TABLE[key] };
}

/**
 * How far through the comeback ramp they are. Progress is driven by sessions
 * actually completed, not calendar time, so missed weeks don't inflate it.
 */
export interface RampState {
  active: boolean;
  weeksDone: number;
  rampWeeks: number;
  progress: number;
  /** intensity + volume for right now */
  level: 1 | 2 | 3;
  volumePct: number;
  message: string;
}

export function rampStateOf(
  status: TrainingStatus,
  sessionsLogged: number
): RampState {
  if (status.rampWeeks === 0) {
    return {
      active: false,
      weeksDone: 0,
      rampWeeks: 0,
      progress: 1,
      level: status.startLevel,
      volumePct: 100,
      message: "Training at full intensity.",
    };
  }
  const perWeek = Math.max(2, status.weeklySessions);
  const weeksDone = Math.floor(sessionsLogged / perWeek);
  const progress = Math.min(1, weeksDone / status.rampWeeks);
  const done = progress >= 1;

  const volumePct = Math.round(
    status.startVolumePct + (100 - status.startVolumePct) * progress
  );
  // Step intensity up once they're past the halfway point of the ramp.
  const level: 1 | 2 | 3 = done
    ? 3
    : progress >= 0.5
      ? (Math.min(3, status.startLevel + 1) as 1 | 2 | 3)
      : status.startLevel;

  return {
    active: !done,
    weeksDone,
    rampWeeks: status.rampWeeks,
    progress,
    level: done ? ((status.startLevel === 1 ? 2 : status.startLevel) as 1 | 2 | 3) : level,
    volumePct: done ? 100 : volumePct,
    message: done
      ? "Rebuild complete — you're back to full training."
      : `Week ${Math.min(weeksDone + 1, status.rampWeeks)} of ${status.rampWeeks} · ${volumePct}% volume`,
  };
}

/* ----------------------------- Body types ------------------------------ */

export interface BodyTypePlan {
  id: BodyType;
  label: string;
  /** multiplier applied to maintenance calories */
  calorieBias: number;
  /** grams of protein per kg bodyweight */
  proteinPerKg: number;
  /** share of calories from fat */
  fatPct: number;
  /** typical working rep range */
  repRange: [number, number];
  /** seconds of rest between hard sets */
  restSec: number;
  /** recommended cardio sessions per week */
  cardioPerWeek: number;
  training: string;
  nutrition: string;
}

const BODY_PLANS: Record<BodyType, BodyTypePlan> = {
  ecto: {
    id: "ecto",
    label: "Lean / hard gainer",
    calorieBias: 1.06,
    proteinPerKg: 1.9,
    fatPct: 0.27,
    repRange: [6, 10],
    restSec: 120,
    cardioPerWeek: 1,
    training:
      "Prioritise heavy compound lifts with longer rests. Keep cardio light so it doesn't eat your surplus.",
    nutrition:
      "You burn through calories quickly. Eat slightly above maintenance and don't skip meals.",
  },
  meso: {
    id: "meso",
    label: "Athletic build",
    calorieBias: 1.0,
    proteinPerKg: 2.0,
    fatPct: 0.25,
    repRange: [8, 12],
    restSec: 90,
    cardioPerWeek: 2,
    training:
      "You respond well to balanced training. Mix strength and hypertrophy work and progress steadily.",
    nutrition: "Standard targets suit you. Keep protein high and adjust by the scale every fortnight.",
  },
  endo: {
    id: "endo",
    label: "Softer / gains easily",
    calorieBias: 0.95,
    proteinPerKg: 2.1,
    fatPct: 0.23,
    repRange: [10, 15],
    restSec: 60,
    cardioPerWeek: 3,
    training:
      "Shorter rests and circuit-style work keep the heart rate up while you build strength.",
    nutrition:
      "Slightly lower carbs with high protein works well. Daily steps matter as much as workouts.",
  },
  unsure: {
    id: "unsure",
    label: "Balanced",
    calorieBias: 1.0,
    proteinPerKg: 2.0,
    fatPct: 0.25,
    repRange: [8, 12],
    restSec: 90,
    cardioPerWeek: 2,
    training: "Balanced programming until your logged data shows how you respond.",
    nutrition: "Standard evidence-based targets, adjusted as your weight trend develops.",
  },
};

export function bodyTypePlan(t: BodyType | undefined): BodyTypePlan {
  return BODY_PLANS[t ?? "unsure"];
}
