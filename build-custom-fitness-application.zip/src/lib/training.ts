import { addDays, dateKey } from "./engine";
import type { WorkoutLog } from "./store";

/* ------------------- Training load & plateau analysis ------------------ */

export type AcwrZone =
  | "insufficient"
  | "undertrained"
  | "optimal"
  | "caution"
  | "high";

export interface AcwrResult {
  /** total volume (kg) over the last 7 days */
  acute7: number;
  /** average weekly volume over the last 28 days */
  chronicWeek: number;
  /** acute / chronic — null without enough data */
  ratio: number | null;
  zone: AcwrZone;
  label: string;
  advice: string;
  color: string;
  /** distinct days with logged volume in the 28-day window */
  daysWithData: number;
}

/**
 * Acute:Chronic Workload Ratio — the standard fatigue monitor.
 *
 * acute   = 7-day total volume
 * chronic = average weekly volume across the last 28 days
 * ratio   = acute / chronic
 *
 * Zones follow commonly used training guidelines (<0.8 undertrained,
 * 0.8–1.3 optimal, 1.3–1.5 caution, >1.5 high risk).
 */
export function acwrOf(logs: WorkoutLog[], now = new Date()): AcwrResult {
  const volByDay = new Map<string, number>();
  for (const l of logs) {
    volByDay.set(l.date, (volByDay.get(l.date) ?? 0) + (l.volumeKg ?? 0));
  }

  let acute7 = 0;
  let total28 = 0;
  const daysWithData = new Set<string>();
  for (let i = 0; i < 28; i++) {
    const key = dateKey(addDays(now, -i));
    const v = volByDay.get(key) ?? 0;
    if (v > 0) daysWithData.add(key);
    if (i < 7) acute7 += v;
    total28 += v;
  }

  const chronicWeek = Math.round(total28 / 4);
  const base = {
    acute7: Math.round(acute7),
    chronicWeek,
    daysWithData: daysWithData.size,
  };

  if (chronicWeek <= 0 || daysWithData.size < 5) {
    return {
      ...base,
      ratio: null,
      zone: "insufficient",
      label: "Building data",
      advice:
        "Log at least a week of sessions and we'll balance your training load for you.",
      color: "var(--muted)",
    };
  }

  const ratio = Math.round((acute7 / chronicWeek) * 100) / 100;

  if (ratio < 0.8) {
    return {
      ...base,
      ratio,
      zone: "undertrained",
      label: "Underloading",
      advice:
        "Your recent volume is below your recent average — a good week to add a set or two.",
      color: "var(--aqua)",
    };
  }
  if (ratio <= 1.3) {
    return {
      ...base,
      ratio,
      zone: "optimal",
      label: "Sweet spot",
      advice: "Progressive but recoverable. This is the zone where gains happen.",
      color: "var(--volt)",
    };
  }
  if (ratio <= 1.5) {
    return {
      ...base,
      ratio,
      zone: "caution",
      label: "Ramping fast",
      advice: "Volume is climbing quickly — watch sleep, soreness and readiness.",
      color: "#ffc740",
    };
  }
  return {
    ...base,
    ratio,
    zone: "high",
    label: "High strain",
    advice:
      "Well above your chronic load — schedule a deload week before fatigue becomes injury.",
    color: "var(--ember)",
  };
}

/* ---------------------------- Plateau detection ------------------------ */

export interface Plateau {
  exerciseId: string;
  name: string;
  bestKg: number;
  /** consecutive sessions with no progress */
  stuckSessions: number;
  suggestion: string;
}

/**
 * Finds lifts whose best load and reps haven't moved for several sessions.
 * Needs ≥4 sessions, with the last 3 all within 1 kg and no rep improvement.
 */
export function plateausOf(logs: WorkoutLog[], limit = 4): Plateau[] {
  // Oldest → newest so the trailing-stuck walk works naturally.
  const byExercise = new Map<string, { kg: number; reps: number }[]>();
  const names = new Map<string, string>();

  for (const l of [...logs].reverse()) {
    for (const d of l.detail ?? []) {
      let bestKg = 0;
      let bestReps = 0;
      for (const s of d.sets) {
        if (!s.done) continue;
        const kg = s.kg ?? 0;
        const r = s.reps ?? 0;
        if (kg > bestKg || (kg === bestKg && r > bestReps)) {
          bestKg = kg;
          bestReps = r;
        }
      }
      if (bestKg <= 0) continue;
      const arr = byExercise.get(d.exerciseId) ?? [];
      arr.push({ kg: bestKg, reps: bestReps });
      byExercise.set(d.exerciseId, arr);
      names.set(d.exerciseId, d.name);
    }
  }

  const out: Plateau[] = [];
  for (const [exerciseId, sessions] of byExercise) {
    if (sessions.length < 4) continue;
    const last = sessions[sessions.length - 1];

    // Walk backwards while the best load never really improved.
    let stuck = 0;
    for (let i = sessions.length - 1; i >= 0; i--) {
      const s = sessions[i];
      const sameLoad = Math.abs(s.kg - last.kg) <= 1;
      const notBetter = s.reps <= last.reps;
      if (sameLoad && notBetter) stuck += 1;
      else break;
    }
    if (stuck < 3) continue;

    const suggestion =
      stuck >= 5
        ? "Long stall — change the variation for two weeks (pause reps, tempo or a different grip)."
        : stuck >= 4
          ? "Add a set of a complementary movement, then retry this load with one more rep."
          : "Deload 10% for one session, then attack the same load with one more rep.";

    out.push({
      exerciseId,
      name: names.get(exerciseId) ?? exerciseId,
      bestKg: last.kg,
      stuckSessions: stuck,
      suggestion,
    });
  }

  return out
    .sort((a, b) => b.stuckSessions - a.stuckSessions || b.bestKg - a.bestKg)
    .slice(0, limit);
}
