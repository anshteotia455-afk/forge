import "server-only";

import { randomBytes, randomUUID, scryptSync, timingSafeEqual } from "node:crypto";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { and, eq, gt } from "drizzle-orm";

/* ----------------------------- Passwords ------------------------------- */

const KEYLEN = 64;

export function hashPassword(password: string, salt?: string) {
  const useSalt = salt ?? randomBytes(16).toString("hex");
  const hash = scryptSync(password, useSalt, KEYLEN).toString("hex");
  return { hash, salt: useSalt };
}

/** Constant-time comparison so timing can't leak the hash. */
export function verifyPassword(password: string, salt: string, expected: string): boolean {
  try {
    const actual = scryptSync(password, salt, KEYLEN);
    const want = Buffer.from(expected, "hex");
    if (actual.length !== want.length) return false;
    return timingSafeEqual(actual, want);
  } catch {
    return false;
  }
}

/* ------------------------------ Sessions ------------------------------- */

export const SESSION_DAYS = 180;

export async function createSession(userId: string): Promise<{ token: string; expiresAt: string }> {
  const token = `${randomUUID().replace(/-/g, "")}${randomBytes(16).toString("hex")}`;
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400000).toISOString();
  await db.insert(sessions).values({ token, userId, expiresAt });
  return { token, expiresAt };
}

export interface AuthedUser {
  id: string;
  email: string;
  displayName: string | null;
}

/** Resolves the bearer token on a request to a live user, or null. */
export async function userFromRequest(req: Request): Promise<AuthedUser | null> {
  const header = req.headers.get("authorization") ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  if (!token) return null;

  const rows = await db
    .select({
      id: users.id,
      email: users.email,
      displayName: users.displayName,
    })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date().toISOString())))
    .limit(1);

  return rows[0] ?? null;
}

export async function destroySession(req: Request): Promise<void> {
  const header = req.headers.get("authorization") ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  if (token) await db.delete(sessions).where(eq(sessions.token, token));
}

/* ----------------------------- Validation ------------------------------ */

export function normaliseEmail(raw: string): string {
  return raw.trim().toLowerCase();
}

export function validateCredentials(email: string, password: string): string | null {
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
    return "Enter a valid email address.";
  }
  if (!password || password.length < 8) {
    return "Password must be at least 8 characters.";
  }
  if (password.length > 200) return "Password is too long.";
  return null;
}

export function newUserId(): string {
  return `u_${randomUUID().replace(/-/g, "").slice(0, 20)}`;
}
