import { e1rm, setLoad, Sex } from "./engine";
import { SKILLS } from "./skills";
import type { WorkoutLog } from "./store";

/* ---------------------- Strength standards engine ---------------------- */

export interface StrengthLevel {
  id: string;
  name: string;
  blurb: string;
  color: string;
}

/** Six-step ladder applied per lift and overall. */
export const LEVELS: StrengthLevel[] = [
  { id: "untrained", name: "Untrained", blurb: "Just getting started", color: "#9aa3ad" },
  { id: "novice", name: "Novice", blurb: "A few months of practice", color: "#c58b5c" },
  { id: "intermediate", name: "Intermediate", blurb: "A year or two of solid work", color: "#c0c8d4" },
  { id: "advanced", name: "Advanced", blurb: "Stronger than most who lift", color: "#ffc740" },
  { id: "elite", name: "Elite", blurb: "Competitive-level strength", color: "#ff7a2f" },
  { id: "freak", name: "Freak", blurb: "Genuinely rare territory", color: "#cdf83f" },
];

export interface LiftDef {
  id: string;
  name: string;
  /** exercise ids that count toward this lift */
  matches: string[];
  /** bodyweight multipliers for novice→freak (male) */
  male: [number, number, number, number, number];
  female: [number, number, number, number, number];
  icon: string;
}

/**
 * Multipliers are ×bodyweight for a 1-rep max, loosely following
 * widely used strength-standard tables.
 */
export const LIFTS: LiftDef[] = [
  {
    id: "squat",
    name: "Squat",
    icon: "🦵",
    matches: ["bb-squat", "rack-front-squat"],
    male: [0.75, 1.25, 1.75, 2.25, 2.75],
    female: [0.6, 1.0, 1.35, 1.75, 2.15],
  },
  {
    id: "bench",
    name: "Bench Press",
    icon: "🏋️",
    matches: ["bb-bench", "db-bench-press", "db-floor-press"],
    male: [0.6, 1.0, 1.4, 1.8, 2.2],
    female: [0.4, 0.65, 0.9, 1.2, 1.5],
  },
  {
    id: "deadlift",
    name: "Deadlift",
    icon: "⚓",
    matches: ["bb-deadlift", "rack-pull"],
    male: [1.0, 1.5, 2.1, 2.75, 3.25],
    female: [0.75, 1.2, 1.6, 2.1, 2.6],
  },
  {
    id: "press",
    name: "Overhead Press",
    icon: "🙌",
    matches: ["bb-ohp", "db-shoulder-press", "kb-clean-press", "rack-pin-press"],
    male: [0.4, 0.65, 0.9, 1.15, 1.4],
    female: [0.25, 0.45, 0.65, 0.85, 1.05],
  },
  {
    id: "row",
    name: "Barbell Row",
    icon: "🪢",
    matches: ["bb-row", "db-row", "cable-row"],
    male: [0.55, 0.9, 1.25, 1.6, 2.0],
    female: [0.4, 0.65, 0.9, 1.15, 1.45],
  },
  {
    id: "curl",
    name: "Curl",
    icon: "💪",
    matches: ["bb-curl", "ez-curl", "db-curl", "db-hammer-curl"],
    male: [0.25, 0.45, 0.65, 0.85, 1.05],
    female: [0.15, 0.3, 0.45, 0.6, 0.75],
  },
  {
    id: "wpullup",
    name: "Weighted Pull-Up",
    icon: "🧗",
    matches: ["pull-up", "chin-up"],
    male: [1.0, 1.2, 1.45, 1.7, 2.0],
    female: [0.85, 1.0, 1.2, 1.45, 1.7],
  },
  {
    id: "wdip",
    name: "Weighted Dip",
    icon: "🔻",
    matches: ["parallel-dip", "ring-dip"],
    male: [1.0, 1.25, 1.55, 1.85, 2.2],
    female: [0.8, 1.0, 1.25, 1.5, 1.8],
  },
  {
    id: "wpushup",
    name: "Weighted Push-Up",
    icon: "🤜",
    matches: ["push-up", "pushup-bar-deep", "parallette-pushup"],
    male: [0.64, 0.8, 1.0, 1.2, 1.45],
    female: [0.55, 0.7, 0.85, 1.05, 1.25],
  },
  {
    id: "frontsquat",
    name: "Front Squat",
    icon: "🛡️",
    matches: ["rack-front-squat", "kb-front-rack-squat"],
    male: [0.6, 1.0, 1.4, 1.8, 2.25],
    female: [0.45, 0.8, 1.1, 1.45, 1.8],
  },
  {
    id: "ohpress-push",
    name: "Push Press",
    icon: "🚀",
    matches: ["bb-push-press"],
    male: [0.5, 0.8, 1.1, 1.4, 1.7],
    female: [0.35, 0.55, 0.8, 1.05, 1.3],
  },
  {
    id: "trapdeadlift",
    name: "Trap Bar Deadlift",
    icon: "⬢",
    matches: ["trap-deadlift"],
    male: [1.1, 1.6, 2.2, 2.85, 3.4],
    female: [0.8, 1.25, 1.7, 2.2, 2.7],
  },
  {
    id: "legpress-std",
    name: "Leg Press",
    icon: "🦿",
    matches: ["leg-press"],
    male: [1.5, 2.5, 3.5, 4.5, 5.5],
    female: [1.2, 2.0, 2.8, 3.6, 4.5],
  },
  {
    id: "latpull",
    name: "Lat Pulldown",
    icon: "🪂",
    matches: ["lat-pulldown-machine", "cable-pulldown"],
    male: [0.5, 0.8, 1.1, 1.4, 1.7],
    female: [0.35, 0.6, 0.85, 1.1, 1.35],
  },
  {
    id: "hipthrust",
    name: "Hip Thrust",
    icon: "🍑",
    matches: ["bb-hip-thrust"],
    male: [1.0, 1.6, 2.2, 2.9, 3.5],
    female: [0.85, 1.4, 2.0, 2.6, 3.2],
  },
];

export interface LiftRating {
  lift: LiftDef;
  best1rm: number;
  ratio: number;
  levelIndex: number; // 0..5
  level: StrengthLevel;
  next: StrengthLevel | null;
  /** kg needed for the next level */
  toNextKg: number;
  /** progress within the current band, 0..1 */
  progress: number;
  tested: boolean;
}

function thresholds(lift: LiftDef, sex: Sex): number[] {
  return sex === "female" ? lift.female : lift.male;
}

/** Best estimated 1RM recorded for a lift across all history. */
export function best1rmFor(logs: WorkoutLog[], lift: LiftDef): number {
  let best = 0;
  for (const l of logs) {
    for (const ex of l.detail ?? []) {
      if (!lift.matches.includes(ex.exerciseId)) continue;
      for (const s of ex.sets) {
        if (!s.done || !s.reps) continue;
        const load = setLoad(s);
        if (load > 0) best = Math.max(best, e1rm(load, s.reps));
      }
    }
  }
  return Math.round(best * 10) / 10;
}

export function rateLift(
  logs: WorkoutLog[],
  lift: LiftDef,
  bodyweightKg: number,
  sex: Sex
): LiftRating {
  const best1rm = best1rmFor(logs, lift);
  const bw = Math.max(1, bodyweightKg);
  const ratio = best1rm / bw;
  const t = thresholds(lift, sex);

  let levelIndex = 0;
  for (let i = 0; i < t.length; i++) if (ratio >= t[i]) levelIndex = i + 1;

  const level = LEVELS[levelIndex];
  const next = LEVELS[levelIndex + 1] ?? null;
  const nextRatio = levelIndex < t.length ? t[levelIndex] : null;
  const prevRatio = levelIndex === 0 ? 0 : t[levelIndex - 1];
  const toNextKg = nextRatio ? Math.max(0, Math.round((nextRatio * bw - best1rm) * 10) / 10) : 0;
  const span = nextRatio ? nextRatio - prevRatio : 1;
  const progress = nextRatio ? Math.max(0, Math.min(1, (ratio - prevRatio) / span)) : 1;

  return {
    lift,
    best1rm,
    ratio: Math.round(ratio * 100) / 100,
    levelIndex,
    level,
    next,
    toNextKg,
    progress,
    tested: best1rm > 0,
  };
}

export interface StrengthClass {
  ratings: LiftRating[];
  tested: LiftRating[];
  /** average level index across tested lifts */
  score: number;
  level: StrengthLevel;
  strongest: LiftRating | null;
  weakest: LiftRating | null;
}

export function strengthClass(
  logs: WorkoutLog[],
  bodyweightKg: number,
  sex: Sex
): StrengthClass {
  const ratings = LIFTS.map((l) => rateLift(logs, l, bodyweightKg, sex));
  const tested = ratings.filter((r) => r.tested);
  const score = tested.length
    ? tested.reduce((a, r) => a + r.levelIndex, 0) / tested.length
    : 0;
  const level = LEVELS[Math.max(0, Math.min(LEVELS.length - 1, Math.round(score)))];
  const sorted = [...tested].sort((a, b) => b.levelIndex + b.progress - (a.levelIndex + a.progress));
  return {
    ratings,
    tested,
    score: Math.round(score * 100) / 100,
    level,
    strongest: sorted[0] ?? null,
    weakest: sorted.length > 1 ? sorted[sorted.length - 1] : null,
  };
}

/* ------------------------ Bodyweight benchmarks ------------------------ */

export interface BodyweightFeat {
  id: string;
  name: string;
  icon: string;
  exerciseIds: string[];
  unit: "reps" | "sec";
  /** novice → freak thresholds */
  male: [number, number, number, number, number];
  female: [number, number, number, number, number];
}

export const FEATS: BodyweightFeat[] = [
  {
    id: "pullups",
    name: "Pull-Ups",
    icon: "🧗",
    exerciseIds: ["pull-up", "chin-up"],
    unit: "reps",
    male: [1, 5, 12, 20, 30],
    female: [1, 3, 7, 12, 20],
  },
  {
    id: "pushups",
    name: "Push-Ups",
    icon: "🤜",
    exerciseIds: ["push-up"],
    unit: "reps",
    male: [10, 25, 45, 70, 100],
    female: [5, 15, 30, 50, 75],
  },
  {
    id: "dips",
    name: "Dips",
    icon: "🔻",
    exerciseIds: ["parallel-dip", "chair-dip", "ring-dip"],
    unit: "reps",
    male: [3, 10, 20, 30, 45],
    female: [1, 5, 12, 20, 30],
  },
  {
    id: "squats-bw",
    name: "Bodyweight Squats",
    icon: "🦵",
    exerciseIds: ["squat"],
    unit: "reps",
    male: [20, 40, 60, 90, 130],
    female: [15, 30, 50, 75, 110],
  },
  {
    id: "burpees-feat",
    name: "Burpees",
    icon: "🔥",
    exerciseIds: ["burpees"],
    unit: "reps",
    male: [10, 20, 35, 50, 75],
    female: [8, 16, 28, 42, 62],
  },
  {
    id: "lsit-feat",
    name: "L-Sit Hold",
    icon: "📐",
    exerciseIds: ["l-sit", "tuck-hold"],
    unit: "sec",
    male: [5, 12, 20, 35, 60],
    female: [5, 12, 20, 35, 60],
  },
  {
    id: "wallsit-feat",
    name: "Wall Sit",
    icon: "🧱",
    exerciseIds: ["wall-sit"],
    unit: "sec",
    male: [30, 60, 120, 180, 300],
    female: [30, 60, 120, 180, 300],
  },
  {
    id: "plank",
    name: "Plank Hold",
    icon: "🪵",
    exerciseIds: ["plank", "ball-plank", "vest-plank"],
    unit: "sec",
    male: [30, 60, 120, 180, 300],
    female: [30, 60, 120, 180, 300],
  },
  {
    id: "hang",
    name: "Dead Hang",
    icon: "🖐️",
    exerciseIds: ["dead-hang"],
    unit: "sec",
    male: [20, 45, 75, 120, 180],
    female: [20, 40, 70, 110, 160],
  },
];

export interface FeatRating {
  feat: BodyweightFeat;
  best: number;
  levelIndex: number;
  level: StrengthLevel;
  next: StrengthLevel | null;
  toNext: number;
  progress: number;
  tested: boolean;
}

export function rateFeat(logs: WorkoutLog[], feat: BodyweightFeat, sex: Sex): FeatRating {
  let best = 0;
  for (const l of logs) {
    for (const ex of l.detail ?? []) {
      if (!feat.exerciseIds.includes(ex.exerciseId)) continue;
      for (const s of ex.sets) {
        if (!s.done) continue;
        const v = feat.unit === "reps" ? (s.reps ?? 0) : (s.sec ?? 0);
        best = Math.max(best, v);
      }
    }
  }
  const t = feat.unit === "sec" || sex === "male" ? feat.male : feat.female;
  let levelIndex = 0;
  for (let i = 0; i < t.length; i++) if (best >= t[i]) levelIndex = i + 1;
  const level = LEVELS[levelIndex];
  const next = LEVELS[levelIndex + 1] ?? null;
  const nextVal = levelIndex < t.length ? t[levelIndex] : null;
  const prevVal = levelIndex === 0 ? 0 : t[levelIndex - 1];
  const span = nextVal ? nextVal - prevVal : 1;
  return {
    feat,
    best,
    levelIndex,
    level,
    next,
    toNext: nextVal ? Math.max(0, nextVal - best) : 0,
    progress: nextVal ? Math.max(0, Math.min(1, (best - prevVal) / span)) : 1,
    tested: best > 0,
  };
}

/* --------------------------- Skill class ------------------------------- */

export interface SkillClass {
  stagesDone: number;
  stagesTotal: number;
  mastered: number;
  level: StrengthLevel;
  progress: number;
  perSkill: { id: string; name: string; icon: string; color: string; done: number; total: number }[];
}

export function skillClass(skillProgress: Record<string, string[]> | undefined): SkillClass {
  const perSkill = SKILLS.map((s) => ({
    id: s.id,
    name: s.name,
    icon: s.icon,
    color: s.color,
    done: (skillProgress?.[s.id] ?? []).length,
    total: s.stages.length,
  }));
  const stagesDone = perSkill.reduce((a, s) => a + s.done, 0);
  const stagesTotal = perSkill.reduce((a, s) => a + s.total, 0);
  const mastered = perSkill.filter((s) => s.done >= s.total).length;

  // Level thresholds based on stages completed
  const t = [1, 5, 12, 22, 32];
  let levelIndex = 0;
  for (let i = 0; i < t.length; i++) if (stagesDone >= t[i]) levelIndex = i + 1;

  return {
    stagesDone,
    stagesTotal,
    mastered,
    level: LEVELS[levelIndex],
    progress: stagesTotal ? stagesDone / stagesTotal : 0,
    perSkill,
  };
}
