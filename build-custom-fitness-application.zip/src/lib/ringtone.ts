"use client";

import { Capacitor, registerPlugin } from "@capacitor/core";

/* ---------------------------- Sound choices ---------------------------- */

export type RingtoneId = "forge" | "pulse" | "gentle" | "custom";

export interface ToneOption {
  id: RingtoneId;
  label: string;
  hint: string;
  icon: string;
}

export const TONES: ToneOption[] = [
  { id: "forge", label: "Forge Bell", hint: "Bold three-note alarm", icon: "🔔" },
  { id: "pulse", label: "Power Pulse", hint: "Fast digital workout cue", icon: "⚡" },
  { id: "gentle", label: "Gentle Rise", hint: "Soft ascending chime", icon: "🌅" },
  { id: "custom", label: "My ringtone", hint: "Pick an audio file from your device", icon: "🎵" },
];

/* ------------------------- IndexedDB custom file ----------------------- */

const DB = "forge-ringtone";
const STORE = "audio";
const KEY = "custom";

interface SavedAudio {
  id: string;
  name: string;
  type: string;
  blob: Blob;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) {
        req.result.createObjectStore(STORE, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveCustomTone(file: File): Promise<{ name: string }> {
  if (!file.type.startsWith("audio/") && !/\.(mp3|wav|m4a|aac|ogg|flac)$/i.test(file.name)) {
    throw new Error("Choose an audio file (MP3, WAV, M4A, AAC or OGG). ");
  }
  if (file.size > 12 * 1024 * 1024) {
    throw new Error("The ringtone must be under 12 MB.");
  }
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put({ id: KEY, name: file.name, type: file.type, blob: file });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
  return { name: file.name };
}

async function getCustomTone(): Promise<SavedAudio | null> {
  if (typeof indexedDB === "undefined") return null;
  const db = await openDb();
  const value = await new Promise<SavedAudio | undefined>((resolve, reject) => {
    const tx = db.transaction(STORE, "readonly");
    const req = tx.objectStore(STORE).get(KEY);
    req.onsuccess = () => resolve(req.result as SavedAudio | undefined);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return value ?? null;
}

export async function deleteCustomTone(): Promise<void> {
  if (typeof indexedDB === "undefined") return;
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

/* ---------------------------- Web playback ----------------------------- */

let stopCurrent: (() => void) | null = null;

function oscillatorTone(id: Exclude<RingtoneId, "custom">): () => void {
  const AudioCtx = window.AudioContext ||
    (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtx) return () => undefined;
  const ctx = new AudioCtx();
  const master = ctx.createGain();
  master.gain.value = 0.14;
  master.connect(ctx.destination);

  const notes =
    id === "forge"
      ? [
          [392, 0, 0.32],
          [523, 0.38, 0.34],
          [659, 0.78, 0.6],
        ]
      : id === "pulse"
        ? [
            [740, 0, 0.12],
            [520, 0.16, 0.12],
            [740, 0.32, 0.12],
            [880, 0.48, 0.22],
          ]
        : [
            [330, 0, 0.4],
            [440, 0.35, 0.45],
            [550, 0.75, 0.7],
          ];

  const oscillators: OscillatorNode[] = [];
  for (const [freq, start, duration] of notes) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = id === "pulse" ? "square" : "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0, ctx.currentTime + start);
    gain.gain.linearRampToValueAtTime(1, ctx.currentTime + start + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + duration);
    osc.connect(gain);
    gain.connect(master);
    osc.start(ctx.currentTime + start);
    osc.stop(ctx.currentTime + start + duration);
    oscillators.push(osc);
  }
  const timer = setTimeout(() => void ctx.close(), 2200);
  return () => {
    clearTimeout(timer);
    for (const o of oscillators) {
      try {
        o.stop();
      } catch {
        // already stopped
      }
    }
    void ctx.close();
  };
}

async function playCustomWeb(): Promise<() => void> {
  const saved = await getCustomTone();
  if (!saved) throw new Error("Choose your ringtone file first.");
  const url = URL.createObjectURL(saved.blob);
  const audio = new Audio(url);
  audio.volume = 0.75;
  await audio.play();
  const cleanup = () => {
    audio.pause();
    audio.currentTime = 0;
    URL.revokeObjectURL(url);
  };
  audio.onended = cleanup;
  return cleanup;
}

/* ------------------------- Android native bridge ----------------------- */

interface ForgeReminderPlugin {
  pickRingtone(): Promise<{ name: string; uri: string }>;
  preview(): Promise<void>;
  schedule(options: {
    hour: number;
    minute: number;
    enabled: boolean;
    vibrate: boolean;
    snoozeMinutes: number;
    soundId: RingtoneId;
    title: string;
    body: string;
  }): Promise<{ scheduled: boolean }>;
  cancel(): Promise<void>;
}

const NativeReminder = registerPlugin<ForgeReminderPlugin>("ForgeReminder");

export function isNativeAndroid(): boolean {
  return Capacitor.isNativePlatform() && Capacitor.getPlatform() === "android";
}

export async function chooseNativeRingtone(): Promise<{ name: string; uri: string }> {
  return NativeReminder.pickRingtone();
}

/** Preview selected sound. On Android, custom URI playback is handled natively. */
export async function previewRingtone(id: RingtoneId): Promise<void> {
  stopRingtone();
  if (id === "custom" && isNativeAndroid()) {
    await NativeReminder.preview();
    return;
  }
  if (id === "custom") {
    stopCurrent = await playCustomWeb();
    return;
  }
  stopCurrent = oscillatorTone(id);
}

export function stopRingtone(): void {
  stopCurrent?.();
  stopCurrent = null;
}

/**
 * Android AlarmManager can wake a closed app and use the chosen content URI.
 * Web/Windows relies on Shell's live process timer and IndexedDB audio.
 */
export async function scheduleNativeReminder(options: {
  time: string;
  enabled: boolean;
  vibrate: boolean;
  snoozeMinutes?: number;
  soundId?: RingtoneId;
}): Promise<boolean> {
  if (!isNativeAndroid()) return false;
  const [hour, minute] = options.time.split(":").map(Number);
  try {
    const res = await NativeReminder.schedule({
      hour: hour ?? 7,
      minute: minute ?? 0,
      enabled: options.enabled,
      vibrate: options.vibrate,
      snoozeMinutes: options.snoozeMinutes ?? 10,
      soundId: options.soundId ?? "forge",
      title: "Time to forge",
      body: "Today's session is waiting — keep the streak alive.",
    });
    return res.scheduled;
  } catch {
    return false;
  }
}

export async function cancelNativeReminder(): Promise<void> {
  if (isNativeAndroid()) await NativeReminder.cancel();
}
