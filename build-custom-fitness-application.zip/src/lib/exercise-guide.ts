import { Exercise, MUSCLE_LABEL, Muscle } from "./data";

/* ----------------------- Exercise how-to generator --------------------- */

export interface ExerciseGuide {
  setup: string;
  steps: string[];
  tips: string[];
  mistakes: string[];
  breathing: string;
  targets: Muscle[];
}

/** Hand-written guides for the most common movements. */
const CURATED: Record<string, Partial<ExerciseGuide>> = {
  "push-up": {
    setup: "Hands slightly wider than shoulders, body in a straight line from head to heels.",
    steps: [
      "Brace your core and squeeze your glutes so your body stays rigid.",
      "Bend the elbows to about 45° and lower until your chest nearly touches the floor.",
      "Pause for a moment just above the ground.",
      "Press back up powerfully until the arms are straight.",
    ],
    tips: ["Keep your neck neutral — look at the floor just ahead of you.", "Elbows point back, not flared straight out."],
    mistakes: ["Hips sagging or piking up.", "Only going halfway down.", "Head dropping toward the floor first."],
    breathing: "Inhale as you lower, exhale as you press up.",
  },
  "squat": {
    setup: "Feet shoulder-width apart, toes turned slightly out, chest tall.",
    steps: [
      "Take a breath and brace your core.",
      "Push your hips back and bend the knees as if sitting into a chair.",
      "Descend until your thighs are at least parallel to the floor.",
      "Drive through your whole foot to stand back tall.",
    ],
    tips: ["Knees track in line with your toes.", "Keep your heels planted throughout."],
    mistakes: ["Heels lifting off the floor.", "Knees caving inward.", "Rounding the lower back."],
    breathing: "Inhale at the top, hold during the descent, exhale as you stand.",
  },
  "bb-deadlift": {
    setup: "Bar over mid-foot, feet hip-width, grip just outside the knees.",
    steps: [
      "Hinge down and grip the bar, shins touching it.",
      "Set a flat back, chest up, and take the slack out of the bar.",
      "Drive the floor away and stand tall, keeping the bar against your legs.",
      "Lock out hips and knees together, then control it back down.",
    ],
    tips: ["Think 'push the floor' rather than 'pull the bar'.", "Keep the bar as close to your body as possible."],
    mistakes: ["Rounding the lower back.", "Hips shooting up first.", "Bar drifting away from the shins."],
    breathing: "Big breath and brace before each rep, exhale at the top.",
  },
  "pull-up": {
    setup: "Hang from the bar with hands just wider than shoulders, palms facing away.",
    steps: [
      "Start from a dead hang with shoulders active, not slumped.",
      "Pull your elbows down and back, leading with the chest.",
      "Continue until your chin clears the bar.",
      "Lower under control to a full hang.",
    ],
    tips: ["Squeeze your shoulder blades down and together.", "Avoid swinging or kipping for strict reps."],
    mistakes: ["Half reps that don't reach the bar.", "Not returning to a full hang.", "Using momentum to swing up."],
    breathing: "Exhale as you pull up, inhale as you lower.",
  },
  "plank": {
    setup: "Forearms on the floor under your shoulders, body in one straight line.",
    steps: [
      "Set your elbows directly beneath your shoulders.",
      "Tuck the pelvis slightly and squeeze your glutes.",
      "Hold the straight line, breathing steadily, for the target time.",
    ],
    tips: ["Push the floor away so your upper back stays flat.", "Keep ribs down — don't let the lower back dip."],
    mistakes: ["Hips sagging toward the floor.", "Butt lifting too high.", "Holding your breath."],
    breathing: "Breathe slowly and continuously — never hold your breath.",
  },
  "bb-squat": {
    setup: "Bar on your upper back, feet shoulder-width, braced and tall.",
    steps: [
      "Unrack the bar and take two steps back into a stable stance.",
      "Breathe in, brace hard, and sit down between your hips.",
      "Descend to at least parallel with knees tracking your toes.",
      "Drive up through mid-foot to stand tall.",
    ],
    tips: ["Keep the bar over mid-foot the whole way.", "Spread the floor with your feet to keep knees out."],
    mistakes: ["Knees caving in.", "Heels rising.", "Good-morning-ing the weight up with the hips."],
    breathing: "Breath held on the way down, exhale forcefully standing up.",
  },
  "bb-bench": {
    setup: "Lie back with eyes under the bar, shoulder blades pinched, feet planted.",
    steps: [
      "Grip just wider than shoulder-width and unrack over your chest.",
      "Lower the bar under control to mid-chest, elbows ~45°.",
      "Touch lightly, then press up and slightly back toward the rack.",
    ],
    tips: ["Keep your shoulder blades retracted and down.", "Drive your feet into the floor for a stable base."],
    mistakes: ["Bouncing the bar off the chest.", "Flaring elbows straight out.", "Lifting the hips off the bench."],
    breathing: "Inhale lowering, exhale pressing up.",
  },
};

/* --------------------------- Generic builder --------------------------- */

function positionFor(ex: Exercise): string {
  const eq = ex.equipment;
  if (eq.includes("barbell")) return "Set up the barbell and take a braced, balanced stance.";
  if (eq.includes("dumbbells")) return "Hold a dumbbell in each hand with a firm, neutral grip.";
  if (eq.includes("kettlebell")) return "Set the kettlebell down in front of you and take a stable stance.";
  if (eq.includes("pullupbar")) return "Reach up and take a secure grip on the bar.";
  if (eq.includes("bands")) return "Anchor the band securely and take up the slack before you start.";
  if (eq.includes("bench") || eq.includes("inclinebench")) return "Get into position on the bench, stable and supported.";
  if (eq.includes("boxingbag")) return "Stand an arm's length from the bag in a staggered fighting stance.";
  if (eq.includes("cable")) return "Set the pulley height and select a controllable weight.";
  if (eq.includes("kettlebell")) return "Grip the handle firmly with a packed shoulder.";
  if (eq.includes("mat")) return "Set up on your mat with enough space around you.";
  return "Start from a stable, athletic position with your core braced.";
}

function genericSteps(ex: Exercise): string[] {
  const steps: string[] = [];
  const unilateral = ex.uni ? " on one side" : "";

  if (ex.kind === "time") {
    steps.push("Move into the start position and set your posture.");
    steps.push(ex.cue);
    steps.push(`Hold or keep moving with control for the full ${ex.sec ?? 30} seconds${unilateral}.`);
    if (ex.uni) steps.push("Switch sides and repeat for the same duration.");
  } else {
    steps.push("Set your start position and brace your core.");
    steps.push("Move through the first half of the rep under control.");
    steps.push(ex.cue);
    steps.push(`Return to the start and repeat for ${ex.reps ?? 10} reps${unilateral}.`);
    if (ex.uni) steps.push("Complete all reps on one side, then switch.");
  }
  return steps;
}

function genericTips(ex: Exercise): string[] {
  const tips = [ex.cue];
  if (ex.load === "added") tips.push("Add weight (vest, belt or pack) only once your form is clean.");
  if (ex.muscles.includes("core")) tips.push("Keep your ribs down and your spine neutral throughout.");
  if (ex.muscles.includes("cardio")) tips.push("Find a pace you can sustain for the whole interval.");
  if (ex.level === 3) tips.push("This is an advanced move — master the easier variation first.");
  return tips.slice(0, 3);
}

const COMMON_MISTAKES: Record<Muscle, string> = {
  chest: "Letting the elbows flare straight out to the sides.",
  back: "Rounding the spine instead of hinging from the hips.",
  shoulders: "Shrugging the shoulders up toward the ears.",
  arms: "Swinging the weight with momentum instead of control.",
  legs: "Letting the knees cave inward.",
  glutes: "Arching the lower back instead of squeezing the glutes.",
  core: "Holding your breath or letting the hips sag.",
  cardio: "Going too hard too early and burning out.",
  full: "Rushing reps and losing positional control.",
};

function genericMistakes(ex: Exercise): string[] {
  const seen = new Set<string>();
  for (const m of ex.muscles) {
    const mistake = COMMON_MISTAKES[m];
    if (mistake) seen.add(mistake);
  }
  seen.add("Using a range of motion that's too short.");
  return [...seen].slice(0, 3);
}

export function buildGuide(ex: Exercise): ExerciseGuide {
  const curated = CURATED[ex.id];
  return {
    setup: curated?.setup ?? positionFor(ex),
    steps: curated?.steps ?? genericSteps(ex),
    tips: curated?.tips ?? genericTips(ex),
    mistakes: curated?.mistakes ?? genericMistakes(ex),
    breathing:
      curated?.breathing ??
      (ex.kind === "time"
        ? "Breathe slowly and steadily — never hold your breath."
        : "Exhale on the effort, inhale on the way back."),
    targets: ex.muscles,
  };
}

/** YouTube demonstration search — opens in the browser, online only. */
export function videoSearchUrl(name: string): string {
  return `https://www.youtube.com/results?search_query=${encodeURIComponent(
    `how to do ${name} exercise proper form`
  )}`;
}

export function muscleSummary(muscles: Muscle[]): string {
  return muscles.map((m) => MUSCLE_LABEL[m]).join(", ");
}
