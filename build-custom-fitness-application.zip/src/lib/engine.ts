import { EquipmentId, Exercise, EXERCISES, Muscle } from "./data";
import { bodyTypePlan, type BodyType } from "./readiness-profile";

/* ------------------------------ Dates -------------------------------- */

export function dateKey(d: Date = new Date()): string {
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function parseKey(key: string): Date {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1);
}

export function addDays(d: Date, n: number): Date {
  const c = new Date(d);
  c.setDate(c.getDate() + n);
  return c;
}

export interface WeekDay {
  date: Date;
  key: string;
  dow: string;
  num: number;
  isToday: boolean;
}

export function weekDates(offsetWeeks = 0): WeekDay[] {
  const now = new Date();
  const dow = (now.getDay() + 6) % 7; // Monday = 0
  const monday = addDays(now, -dow + offsetWeeks * 7);
  const letters = ["M", "T", "W", "T", "F", "S", "S"];
  return Array.from({ length: 7 }, (_, i) => {
    const d = addDays(monday, i);
    return {
      date: d,
      key: dateKey(d),
      dow: letters[i],
      num: d.getDate(),
      isToday: dateKey(d) === dateKey(now),
    };
  });
}

export function displayDate(key: string): string {
  return parseKey(key).toLocaleDateString(undefined, {
    weekday: "long",
    month: "short",
    day: "numeric",
  });
}

/** Consecutive-day streak ending today (or yesterday) from a set of date keys. */
export function streakOf(dayKeys: Iterable<string>): number {
  const set = new Set(dayKeys);
  let cursor = new Date();
  if (!set.has(dateKey(cursor))) cursor = addDays(cursor, -1);
  let streak = 0;
  while (set.has(dateKey(cursor))) {
    streak += 1;
    cursor = addDays(cursor, -1);
  }
  return streak;
}

/* ------------------------- Calorie calculations ---------------------- */

export type Sex = "male" | "female";
export type Goal = "lose" | "maintain" | "gain";

export interface ProfileStats {
  name: string;
  age: number;
  sex: Sex;
  heightCm: number;
  weightKg: number;
  activity: number; // 1.2 – 1.9 multiplier
  goal: Goal;
  /** optional body-type tendency, nudges calories and macros */
  bodyType?: BodyType;
}

/** Mifflin–St Jeor resting metabolism. */
export function bmr(p: Pick<ProfileStats, "weightKg" | "heightCm" | "age" | "sex">): number {
  const base = 10 * p.weightKg + 6.25 * p.heightCm - 5 * p.age;
  return Math.round(base + (p.sex === "male" ? 5 : -161));
}

export function tdee(p: ProfileStats): number {
  return Math.round(bmr(p) * p.activity);
}

export interface Targets {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  bmr: number;
  maintenance: number;
  delta: number;
}

/**
 * Daily calorie + macro targets.
 * Lose: −500 kcal, Gain: +300 kcal (lean), Maintain: 0.
 * Protein is anchored to bodyweight, fat to 25% of kcal, carbs fill the rest.
 */
export function calcTargets(p: ProfileStats): Targets {
  const b = bmr(p);
  const maintenance = Math.round(b * p.activity);
  const plan = bodyTypePlan(p.bodyType);
  const baseDelta = p.goal === "lose" ? -500 : p.goal === "gain" ? 300 : 0;

  // Body type nudges the surplus/deficit rather than overriding the goal:
  // hard gainers get a little more, easy gainers a little less.
  const biased = Math.round(maintenance * plan.calorieBias) + baseDelta;
  const floor = p.sex === "male" ? 1500 : 1200;
  const calories = Math.max(biased, floor);
  const delta = calories - maintenance;

  const goalBump = p.goal === "lose" ? 0.1 : 0;
  const protein = Math.round((plan.proteinPerKg + goalBump) * p.weightKg);
  const fat = Math.round((calories * plan.fatPct) / 9);
  const carbs = Math.max(0, Math.round((calories - protein * 4 - fat * 9) / 4));

  return { calories, protein, carbs, fat, bmr: b, maintenance, delta };
}

/* ---------------------------- Hydration ------------------------------ */

export interface Hydration {
  /** capacity of the glass / bottle the user actually drinks from */
  vesselMl: number;
  /** daily intake target in ml */
  goalMl: number;
  /** what they call it — "Glass", "Bottle", "Sipper"… */
  vesselLabel: string;
}

export const DEFAULT_HYDRATION: Hydration = {
  vesselMl: 250,
  goalMl: 2500,
  vesselLabel: "Glass",
};

/** Common vessels people actually own, for one-tap setup. */
export const VESSEL_PRESETS: { label: string; ml: number; icon: string }[] = [
  { label: "Small glass", ml: 200, icon: "🥛" },
  { label: "Glass", ml: 250, icon: "🥛" },
  { label: "Large glass", ml: 300, icon: "🥤" },
  { label: "Steel tumbler", ml: 350, icon: "🥤" },
  { label: "Small bottle", ml: 500, icon: "🍶" },
  { label: "Bottle", ml: 750, icon: "🍶" },
  { label: "Large bottle", ml: 1000, icon: "🫙" },
  { label: "Jug", ml: 1500, icon: "🫙" },
];

/**
 * Evidence-based daily water target: ~35 ml per kg of bodyweight, nudged up
 * for training load, then clamped to a sane range.
 */
export function recommendedWaterMl(weightKg: number, activity = 1.375): number {
  const base = weightKg * 35;
  const extra = (activity - 1.2) * 900; // more movement → more sweat loss
  return Math.round(Math.min(5000, Math.max(1500, base + extra)) / 50) * 50;
}

/** How many vessels make up the goal (rounded up — you can't drink 0.3 glasses). */
export function vesselsForGoal(h: Hydration): number {
  if (h.vesselMl <= 0) return 0;
  return Math.max(1, Math.ceil(h.goalMl / h.vesselMl));
}

export function mlToLitres(ml: number): string {
  return (ml / 1000).toFixed(ml % 1000 === 0 ? 1 : 2).replace(/\.0+$/, "") + " L";
}

export const ACTIVITY_LEVELS: { value: number; label: string; hint: string }[] = [
  { value: 1.2, label: "Sedentary", hint: "Desk job, little movement" },
  { value: 1.375, label: "Light", hint: "Walks or 1–2 workouts / week" },
  { value: 1.55, label: "Moderate", hint: "3–5 workouts / week" },
  { value: 1.725, label: "Very active", hint: "6–7 sessions / week" },
  { value: 1.9, label: "Athlete", hint: "Physical job + daily training" },
];

/* --------------------------- RNG (seeded) ---------------------------- */

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0 || 1;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ------------------------- Workout generator ------------------------- */

export interface GenOptions {
  equipment: EquipmentId[];
  muscles: Muscle[];
  minutes: number; // 15 | 30 | 45 | 60
  level: 1 | 2 | 3;
  custom?: Exercise[];
}

export interface GenItem {
  ex: Exercise;
  sets: number;
  reps: number | null;
  sec: number | null;
  rest: number;
}

export interface GeneratedWorkout {
  name: string;
  items: GenItem[];
  minutes: number;
  kcal: number;
  focus: Muscle[];
}

const LEVEL_PARAMS = {
  1: { sets: 3, rest: 60, repBoost: -2, secBoost: -10 },
  2: { sets: 4, rest: 45, repBoost: 0, secBoost: 0 },
  3: { sets: 4, rest: 30, repBoost: 2, secBoost: 10 },
} as const;

export function estimateMinutes(items: GenItem[]): number {
  let totalSec = 0;
  for (const it of items) {
    const workSec = it.sec ?? (it.reps ?? 10) * 3.3;
    totalSec += it.sets * workSec + (it.sets - 1) * it.rest + 15; // 15s transition
  }
  return Math.max(5, Math.round(totalSec / 60));
}

export function estimateKcal(items: GenItem[], weightKg: number, minutes: number): number {
  if (!items.length) return 0;
  const avgMet = items.reduce((s, it) => s + it.ex.met, 0) / items.length;
  return Math.round(avgMet * weightKg * (minutes / 60) * 0.9);
}

const NAME_ADJ: Record<Muscle, string[]> = {
  chest: ["Iron", "Pressing", "Torch"],
  back: ["Pull", "Wingspan", "Anchor"],
  shoulders: ["Boulder", "Capstone"],
  arms: ["Python", "Gunpowder"],
  legs: ["Pillar", "Piston"],
  glutes: ["Anchor", "Bedrock"],
  core: ["Steel", "Furnace"],
  cardio: ["Engine", "Inferno"],
  full: ["Hybrid", "Total", "Apex"],
};

const NAME_NOUN = ["Circuit", "Protocol", "Forge", "Complex", "Builder", "Session"];

export function generateWorkout(opts: GenOptions, seed: number, weightKg = 70): GeneratedWorkout {
  const lvl = LEVEL_PARAMS[opts.level];
  const rng = mulberry32(seed || 1);

  const available = new Set<EquipmentId>(["bodyweight", ...opts.equipment]);
  const wanted: Muscle[] = opts.muscles.filter((m) => m !== "full");

  const library = [...EXERCISES, ...(opts.custom ?? [])];
  const pool = library.filter(
    (e) => e.equipment.every((q) => available.has(q)) && e.level <= Math.min(3, opts.level + 1)
  );
  const matched = wanted.length
    ? pool.filter((e) => e.muscles.some((m) => wanted.includes(m)))
    : pool;
  const usable = matched.length >= 4 ? matched : pool;

  const shuffled = [...usable].sort(() => rng() - 0.5);

  // Round-robin across primary muscle buckets for variety
  const buckets = new Map<Muscle, Exercise[]>();
  for (const e of shuffled) {
    const key = wanted.find((m) => e.muscles.includes(m)) ?? e.muscles[0];
    const arr = buckets.get(key) ?? [];
    arr.push(e);
    buckets.set(key, arr);
  }
  const keys = [...buckets.keys()];
  const picked: Exercise[] = [];
  const target = Math.max(4, Math.min(10, Math.round(opts.minutes / 4.5)));
  let round = 0;
  while (picked.length < target && picked.length < shuffled.length) {
    let progressed = false;
    for (const k of keys) {
      const arr = buckets.get(k)!;
      if (round < arr.length) {
        picked.push(arr[round]);
        progressed = true;
        if (picked.length >= target) break;
      }
    }
    if (!progressed) break;
    round += 1;
  }

  const items: GenItem[] = picked.map((ex) => ({
    ex,
    sets: ex.met >= 9 ? Math.max(3, lvl.sets - 1) : lvl.sets,
    reps: ex.kind === "reps" ? Math.max(6, (ex.reps ?? 10) + lvl.repBoost) : null,
    sec: ex.kind === "time" ? Math.max(15, (ex.sec ?? 30) + lvl.secBoost) : null,
    rest: lvl.rest,
  }));

  const minutes = estimateMinutes(items);
  const kcal = estimateKcal(items, weightKg, minutes);

  const tally = new Map<Muscle, number>();
  for (const it of items) {
    for (const m of it.ex.muscles) tally.set(m, (tally.get(m) ?? 0) + (wanted.includes(m) ? 2 : 1));
  }
  const focus = [...tally.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([m]) => m);
  const dominant = focus[0] ?? "full";
  const adjs = NAME_ADJ[dominant] ?? NAME_ADJ.full;
  const name = `${adjs[Math.floor(rng() * adjs.length)]} ${NAME_NOUN[Math.floor(rng() * NAME_NOUN.length)]}`;

  return { name, items, minutes, kcal, focus };
}

/* --------------------- Workout results & records --------------------- */

export interface SetResult {
  reps: number | null;
  sec: number | null;
  /** logged weight — absolute for "external", extra load for "added" */
  kg: number | null;
  done: boolean;
  /** how kg should be interpreted (absent on older logs = external) */
  mode?: "external" | "added";
  /** bodyweight fraction captured at log time */
  bwf?: number;
  /** bodyweight on the day, so historic effective loads stay correct */
  bw?: number;
}

/** Effective load of a stored set, honouring weighted-calisthenics math. */
export function setLoad(s: SetResult, fallbackBw = 70): number {
  const kg = s.kg ?? 0;
  if (s.mode !== "added") return kg;
  return (s.bw ?? fallbackBw) * (s.bwf ?? 0) + kg;
}

export interface ExResult {
  exerciseId: string;
  name: string;
  sets: SetResult[];
}

export interface LogLike {
  date: string;
  detail?: ExResult[];
}

/** Estimated 1-rep max (Epley). */
export function e1rm(kg: number, reps: number): number {
  return kg * (1 + reps / 30);
}

const EXTERNAL_LOAD = new Set([
  "dumbbells",
  "barbell",
  "kettlebell",
  "ezbar",
  "trapbar",
  "plates",
  "macebell",
  "clubbell",
  "powerbag",
  "slamball",
  "sandbag",
  "medicineball",
  "cable",
  "smithmachine",
  "legpress",
  "latpulldown",
  "legextension",
  "pecdeck",
  "preachercurl",
  "wristroller",
  "neckharness",
]);

/** Can this movement carry weight at all? */
export function isLoadable(ex: Exercise): boolean {
  return ex.load === "added" || ex.equipment.some((e) => EXTERNAL_LOAD.has(e));
}

/**
 * "external" → the number you log IS the load (barbell, dumbbells…)
 * "added"    → the number is EXTRA weight on top of bodyweight
 *              (weighted vest, dip belt, backpack, plate on the back)
 */
export function loadModeOf(ex: Exercise): "external" | "added" {
  if (ex.load === "added") return "added";
  return "external";
}

/** Fraction of bodyweight the movement actually lifts. */
export function bwFactorOf(ex: Exercise): number {
  return ex.bwFactor ?? 0;
}

/**
 * True load of a set in kg. For weighted calisthenics this is
 * (bodyweight × leverage factor) + any added weight, so a +20 kg pull-up
 * rates honestly against a barbell lift.
 */
export function effectiveLoad(
  kg: number,
  mode: "external" | "added",
  bwFactor: number,
  bodyweightKg: number
): number {
  if (mode === "external") return kg;
  return Math.round((bodyweightKg * bwFactor + kg) * 10) / 10;
}

/** Most recent logged performance of an exercise (logs are newest-first). */
export function lastPerformance(logs: LogLike[], exerciseId: string): ExResult | null {
  for (const l of logs) {
    const hit = l.detail?.find((d) => d.exerciseId === exerciseId);
    if (hit) return hit;
  }
  return null;
}

export interface PersonalRecord {
  exerciseId: string;
  name: string;
  kg: number;
  reps: number;
  est1rm: number;
  date: string;
  /** kg was ADDED weight on a bodyweight movement */
  added?: boolean;
}

/** Best set per exercise across history, ranked by estimated 1RM. */
export function personalRecords(logs: LogLike[], limit = 8): PersonalRecord[] {
  const best = new Map<string, PersonalRecord>();
  for (const l of logs) {
    for (const ex of l.detail ?? []) {
      for (const s of ex.sets) {
        if (!s.done || !s.reps) continue;
        const load = setLoad(s);
        if (load <= 0) continue;
        const est = e1rm(load, s.reps);
        const cur = best.get(ex.exerciseId);
        if (!cur || est > cur.est1rm) {
          best.set(ex.exerciseId, {
            exerciseId: ex.exerciseId,
            name: ex.name,
            kg: s.mode === "added" ? (s.kg ?? 0) : load,
            reps: s.reps,
            est1rm: Math.round(est),
            date: l.date,
            added: s.mode === "added",
          });
        }
      }
    }
  }
  return [...best.values()].sort((a, b) => b.est1rm - a.est1rm).slice(0, limit);
}

export const PLATE_SIZES = [25, 20, 15, 10, 5, 2.5, 1.25] as const;

/**
 * Greedy plate breakdown per side. `inventory` maps plate size to the TOTAL
 * number owned (pairs are derived), so the result is actually loadable.
 */
export function platesFor(
  totalKg: number,
  barKg: number,
  inventory?: Record<number, number>
): { perSide: number[]; exact: boolean; loadedTotal: number } {
  let side = (totalKg - barKg) / 2;
  const perSide: number[] = [];
  const used: Record<number, number> = {};
  for (const s of PLATE_SIZES) {
    const pairsOwned = inventory ? Math.floor((inventory[s] ?? 0) / 2) : Infinity;
    while (side >= s - 1e-9 && (used[s] ?? 0) < pairsOwned) {
      perSide.push(s);
      used[s] = (used[s] ?? 0) + 1;
      side = Math.round((side - s) * 100) / 100;
    }
  }
  const loadedTotal = barKg + 2 * perSide.reduce((a, b) => a + b, 0);
  return { perSide, exact: side < 1e-9, loadedTotal };
}

/** Closest achievable load given a set of fixed dumbbells/kettlebells. */
export function nearestFixedWeight(target: number, available: number[]): number | null {
  if (!available.length) return null;
  return available.reduce((best, w) =>
    Math.abs(w - target) < Math.abs(best - target) ? w : best
  );
}

/* --------------------- Body composition (US Navy) -------------------- */

/** US Navy body-fat estimate. Requires waist + neck; hip too for women. */
export function navyBodyFat(
  sex: Sex,
  m: { heightCm: number; waistCm: number; neckCm: number; hipCm?: number }
): number | null {
  try {
    if (sex === "male") {
      if (m.waistCm <= m.neckCm) return null;
      return Math.round(
        (86.01 * Math.log10(m.waistCm - m.neckCm) - 70.041 * Math.log10(m.heightCm) + 36.76) * 10
      ) / 10;
    }
    if (!m.hipCm) return null;
    if (m.waistCm + m.hipCm <= m.neckCm) return null;
    return Math.round(
      (163.205 * Math.log10(m.waistCm + m.hipCm - m.neckCm) -
        97.684 * Math.log10(m.heightCm) -
        78.387) *
        10
    ) / 10;
  } catch {
    return null;
  }
}

export function fatCategory(pct: number, sex: Sex): string {
  const t =
    sex === "male"
      ? ([[6, "Essential"], [14, "Athletic"], [18, "Fit"], [25, "Average"], [99, "High"]] as const)
      : ([[14, "Essential"], [21, "Athletic"], [25, "Fit"], [32, "Average"], [99, "High"]] as const);
  for (const [cap, label] of t) if (pct < cap) return label;
  return "High";
}

/* ------------------------- Recovery coach ---------------------------- */

export interface RecoveryVerdict {
  lastWeekSets: number;
  prevWeekSets: number;
  ratio: number | null;
  verdict: "recharge" | "hold" | "push" | "deload";
  label: string;
  hint: string;
}

/** Compares this week's volume to last week's to guide intensity. */
export function recoveryAdvice(logs: { date: string; setsDone: number }[]): RecoveryVerdict {
  const today = new Date();
  const inLast7 = new Date(today);
  inLast7.setDate(today.getDate() - 6);
  const inLast14 = new Date(today);
  inLast14.setDate(today.getDate() - 13);
  let last = 0;
  let prev = 0;
  for (const l of logs) {
    const d = parseKey(l.date);
    if (d >= inLast7 && d <= today) last += l.setsDone;
    else if (d >= inLast14 && d < inLast7) prev += l.setsDone;
  }
  if (prev === 0) {
    return {
      lastWeekSets: last,
      prevWeekSets: prev,
      ratio: null,
      verdict: last > 0 ? "push" : "recharge",
      label: last > 0 ? "Fresh build" : "Prime the engine",
      hint:
        last > 0
          ? "New training week — keep sessions smooth and leave 2 reps in the tank."
          : "No sessions in two weeks. Start with a light 15-minute forge today.",
    };
  }
  const ratio = last / prev;
  if (ratio >= 1.6)
    return {
      lastWeekSets: last,
      prevWeekSets: prev,
      ratio,
      verdict: "deload",
      label: "Ease off",
      hint: "Volume spiked hard — cut sets by a third this week and let the gains settle.",
    };
  if (ratio >= 1.05)
    return {
      lastWeekSets: last,
      prevWeekSets: prev,
      ratio,
      verdict: "push",
      label: "Push on",
      hint: "Volume is climbing steadily — keep the same intensity and add a rep or two.",
    };
  if (ratio >= 0.8)
    return {
      lastWeekSets: last,
      prevWeekSets: prev,
      ratio,
      verdict: "hold",
      label: "Hold steady",
      hint: "Right in the sweet spot. Consistency beats hero workouts.",
    };
  return {
    lastWeekSets: last,
    prevWeekSets: prev,
    ratio,
    verdict: "recharge",
    label: "Reload",
    hint: "Volume dipped — book one solid session today to restart momentum.",
  };
}

/* ------------------------ Exercise history --------------------------- */

export interface ExHistoryPoint {
  date: string;
  setsDone: number;
  totalReps: number;
  bestKg: number;
  bestRepsAtKg: number;
  est1rm: number;
}

/** Chronological performance points for one exercise. */
export function exerciseHistory(logs: LogLike[], exerciseId: string): ExHistoryPoint[] {
  const out: ExHistoryPoint[] = [];
  for (const l of logs) {
    const d = l.detail?.find((x) => x.exerciseId === exerciseId);
    if (!d) continue;
    const doneSets = d.sets.filter((s) => s.done);
    if (!doneSets.length) continue;
    let bestKg = 0;
    let bestRepsAtKg = 0;
    let bestE = 0;
    for (const s of doneSets) {
      const load = setLoad(s);
      if (load > 0 && s.reps) {
        const e = e1rm(load, s.reps);
        const shown = s.mode === "added" ? (s.kg ?? 0) : load;
        if (shown > bestKg || e > bestE) {
          if (shown >= bestKg) {
            bestKg = shown;
            bestRepsAtKg = s.reps;
          }
          bestE = Math.max(bestE, e);
        }
      }
    }
    out.push({
      date: l.date,
      setsDone: doneSets.length,
      totalReps: doneSets.reduce((s, x) => s + (x.reps ?? 0), 0),
      bestKg,
      bestRepsAtKg,
      est1rm: Math.round(bestE * 10) / 10,
    });
  }
  return out.sort((a, b) => a.date.localeCompare(b.date));
}

/* ------------------------- Shared small types ------------------------ */

export interface PlannedItem {
  exerciseId: string;
  sets: number;
  reps: number | null;
  sec: number | null;
  rest: number;
  /** exercises sharing this id are performed back-to-back (superset/circuit) */
  group?: number;
}

export function totalSets(items: { sets: number }[]): number {
  return items.reduce((s, it) => s + it.sets, 0);
}

export function totalReps(items: { sets: number; reps: number | null }[]): number {
  return items.reduce((s, it) => s + it.sets * (it.reps ?? 0), 0);
}

export function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

/* -------------------- Next-session progression target ------------------ */

/**
 * Double-progression target for an exercise's NEXT session, returned as
 * structured numbers so the UI can render them in kg or lb.
 *
 * Reps-only: add reps until the top of the band, then +2 (or a vest).
 * Loaded: add reps within the band, then jump the weight and reset reps.
 * Always based on the most recent logged session — logs are newest-first.
 */
export interface NextTarget {
  mode: "external" | "added" | "reps" | "time";
  /** next session's kg (absolute for external, ADDED load for weighted moves) */
  kg: number | null;
  reps: number | null;
  sec: number | null;
  /** the weight jump this target represents, in stored kg */
  incKg: number | null;
  /** true when the weight goes up and reps reset to the bottom of the band */
  weightJump: boolean;
  /** bodyweight-only moves: reps exceeded the band */
  clearedBand: boolean;
  lastKg: number | null;
  lastReps: number | null;
  lastSec: number | null;
}

export function nextTarget(logs: LogLike[], ex: Exercise): NextTarget | null {
  let lastSets: SetResult[] | null = null;
  for (const l of logs) {
    const d = l.detail?.find((x) => x.exerciseId === ex.id);
    const done = d?.sets.filter((s) => s.done) ?? [];
    if (done.length) {
      lastSets = done;
      break;
    }
  }

  const base = ex.reps ?? 10;

  if (!lastSets) {
    if (ex.kind === "time") {
      const t = ex.sec ?? 30;
      return {
        mode: "time", kg: null, reps: null, sec: t, incKg: null,
        weightJump: false, clearedBand: false,
        lastKg: null, lastReps: null, lastSec: null,
      };
    }
    const mode: NextTarget["mode"] = ex.load === "added" ? "added" : "reps";
    return {
      mode, kg: null, reps: base, sec: null, incKg: null,
      weightJump: false, clearedBand: false,
      lastKg: null, lastReps: null, lastSec: null,
    };
  }

  if (ex.kind === "time") {
    const bestSec = Math.max(...lastSets.map((s) => s.sec ?? 0));
    const next = Math.min(bestSec + Math.max(5, Math.round(bestSec * 0.1)), (ex.sec ?? 30) + 45);
    return {
      mode: "time", kg: null, reps: null, sec: next, incKg: next - bestSec,
      weightJump: false, clearedBand: false,
      lastKg: null, lastReps: null, lastSec: bestSec,
    };
  }

  let topKg = 0;
  let topReps = 0;
  for (const s of lastSets) {
    const k = s.kg ?? 0;
    const r = s.reps ?? 0;
    if (r <= 0) continue;
    if (k > topKg || (k === topKg && r > topReps)) {
      topKg = k;
      topReps = r;
    }
  }

  const bandTop = base + 2;
  const bandBottom = Math.max(4, base - 2);
  const mode: NextTarget["mode"] = ex.load === "added" ? "added" : topKg > 0 ? "external" : "reps";

  if (topKg > 0) {
    const inc =
      mode === "added"
        ? topKg === 0
          ? 2
          : topKg < 10
            ? 1
            : 2.5
        : topKg < 15
          ? 1
          : topKg < 50
            ? 2.5
            : 5;

    if (topReps >= bandTop) {
      return {
        mode, kg: topKg + inc, reps: bandBottom, sec: null,
        incKg: inc, weightJump: true, clearedBand: false,
        lastKg: topKg, lastReps: topReps, lastSec: null,
      };
    }
    return {
      mode, kg: topKg, reps: Math.min(topReps + 1, bandTop), sec: null,
      incKg: 0, weightJump: false, clearedBand: false,
      lastKg: topKg, lastReps: topReps, lastSec: null,
    };
  }

  return {
    mode: "reps", kg: null, reps: topReps >= bandTop ? topReps + 2 : topReps + 1, sec: null,
    incKg: null, weightJump: false, clearedBand: topReps >= bandTop,
    lastKg: 0, lastReps: topReps, lastSec: null,
  };
}

/* --------------------- Warm-up & cooldown flows ------------------------ */

interface FlowMove {
  id: string;
  muscles: Muscle[];
  sec: number;
}

/** Dynamic prep moves — general + muscle specific. */
const WARMUP_POOL: FlowMove[] = [
  { id: "cat-cow", muscles: ["back", "core"], sec: 40 },
  { id: "world-stretch", muscles: ["legs", "full"], sec: 45 },
  { id: "ankle-rocks", muscles: ["legs"], sec: 30 },
  { id: "deep-squat-hold", muscles: ["legs", "glutes"], sec: 40 },
  { id: "ninety-ninety", muscles: ["glutes", "legs"], sec: 40 },
  { id: "wall-angel", muscles: ["shoulders", "back"], sec: 40 },
  { id: "band-pull-apart", muscles: ["shoulders", "back"], sec: 35 },
  { id: "dead-bug", muscles: ["core"], sec: 40 },
  { id: "bird-dog", muscles: ["core", "back"], sec: 40 },
  { id: "inchworm", muscles: ["full", "core"], sec: 45 },
  { id: "thread-needle", muscles: ["back", "shoulders"], sec: 35 },
  { id: "shoulder-dislocates", muscles: ["shoulders"], sec: 35 },
  { id: "scorpion-stretch", muscles: ["core", "back"], sec: 40 },
  { id: "jumping-jacks", muscles: ["cardio"], sec: 40 },
  { id: "prone-ytw", muscles: ["back", "shoulders"], sec: 35 },
];

/** Static holds and stretches for after the session. */
const COOLDOWN_POOL: FlowMove[] = [
  { id: "couch-stretch", muscles: ["legs"], sec: 50 },
  { id: "pigeon-stretch", muscles: ["glutes"], sec: 50 },
  { id: "world-stretch", muscles: ["legs", "full"], sec: 50 },
  { id: "legs-up-wall", muscles: ["legs"], sec: 60 },
  { id: "childs-pose", muscles: ["back"], sec: 60 },
  { id: "thread-needle", muscles: ["back", "shoulders"], sec: 45 },
  { id: "foam-quads", muscles: ["legs"], sec: 45 },
  { id: "foam-back", muscles: ["back"], sec: 45 },
  { id: "foam-glutes", muscles: ["glutes"], sec: 45 },
  { id: "downward-dog", muscles: ["full"], sec: 45 },
  { id: "box-breathing", muscles: ["full"], sec: 60 },
  { id: "legs-up-wall", muscles: ["legs", "core"], sec: 60 },
];

/**
 * Builds a 5–7 minute mobility flow for the targeted muscles using only
 * equipment the user owns. Always opens with general prep and closes with a
 * down-regulation move.
 */
export function generateFlow(
  kind: "warmup" | "cooldown",
  muscles: Muscle[],
  available: ReadonlySet<EquipmentId>,
  seed = 1
): { name: string; items: PlannedItem[]; minutes: number } {
  const pool = kind === "warmup" ? WARMUP_POOL : COOLDOWN_POOL;
  const wanted = new Set(muscles);

  const eligible = pool.filter((m) => {
    const ex = EXERCISES.find((e) => e.id === m.id);
    if (!ex) return false;
    return ex.equipment.every((g) => available.has(g));
  });

  const specific = eligible.filter((m) => m.muscles.some((x) => wanted.has(x)));
  const general = eligible.filter((m) => !m.muscles.some((x) => wanted.has(x)));

  const rng = mulberry32(seed);
  const pick = (arr: FlowMove[], n: number) => {
    const copy = [...arr];
    const out: FlowMove[] = [];
    while (copy.length && out.length < n) {
      out.push(copy.splice(Math.floor(rng() * copy.length), 1)[0]);
    }
    return out;
  };

  const chosen: FlowMove[] = [
    ...(kind === "warmup" ? pick(general, 1) : []),
    ...pick(specific, 3),
    ...(kind === "warmup" ? pick(general, 1) : pick(general, 1)),
  ];
  // De-duplicate while keeping order.
  const seen = new Set<string>();
  const moves = chosen.filter((m) => (seen.has(m.id) ? false : (seen.add(m.id), true)));

  const items: PlannedItem[] = moves.map((m) => ({
    exerciseId: m.id,
    sets: 1,
    reps: null,
    sec: m.sec,
    rest: kind === "warmup" ? 10 : 15,
  }));

  const minutes = Math.max(4, Math.round(items.reduce((s, it) => s + (it.sec ?? 0) + (it.rest ?? 0), 0) / 60));

  return {
    name: kind === "warmup" ? "Warm-up flow" : "Cooldown flow",
    items,
    minutes,
  };
}

/* --------------------------- Goal projection --------------------------- */

export interface GoalProjection {
  goalWeightKg: number;
  currentKg: number;
  /** expected daily change in kg (signed) */
  kgPerDay: number;
  /** signed kg per week */
  weeklyRate: number;
  basis: "trend" | "intake" | "none";
  /** null when stable, wrong direction, or no data */
  daysLeft: number | null;
  /** ETA date label like "12 Mar" */
  eta: string | null;
  direction: "toward" | "away" | "stable" | "unknown";
  message: string;
}

/**
 * Projects the date the goal weight is reached.
 *
 * Prefers the OBSERVED weight trend (least-squares slope over the last 30
 * weigh-ins) because it reflects real-world adherence; falls back to the
 * intake-implied rate (maintenance − average intake) ÷ 7700 kcal/kg.
 */
export function projectGoal(opts: {
  /** newest first */
  weights: { date: string; kg: number }[];
  goal: Goal;
  goalWeightKg?: number | null;
  profile: { heightCm: number; weightKg: number; sex: Sex; age: number; activity: number } | null;
  avgIntake7: number;
  now?: Date;
}): GoalProjection {
  const { weights, goal, goalWeightKg, profile, avgIntake7 } = opts;
  const now = opts.now ?? new Date();
  const current = Math.round((weights[0]?.kg ?? profile?.weightKg ?? 70) * 10) / 10;
  const goalW = goalWeightKg ?? 0;

  const base = {
    goalWeightKg: goalW,
    currentKg: current,
    kgPerDay: 0,
    weeklyRate: 0,
    daysLeft: null as number | null,
    eta: null as string | null,
  };

  if (goal === "maintain") {
    return {
      ...base,
      basis: "none" as const,
      direction: "stable" as const,
      message: "Maintaining — your weight should hold steady. Log weekly to confirm the trend.",
    };
  }
  if (!goalW) {
    return {
      ...base,
      basis: "none" as const,
      direction: "unknown" as const,
      message: "Set a goal weight to see when you'll reach it.",
    };
  }

  // Observed slope: least squares over up to 30 weigh-ins (oldest → newest).
  const recent = [...weights].slice(0, 30).reverse();
  let observed: number | null = null;
  if (recent.length >= 3) {
    const n = recent.length;
    const meanX = (n - 1) / 2;
    const meanY = recent.reduce((a, w) => a + w.kg, 0) / n;
    let num = 0;
    let den = 0;
    recent.forEach((w, i) => {
      num += (i - meanX) * (w.kg - meanY);
      den += (i - meanX) * (i - meanX);
    });
    observed = den ? num / den : null;
  }

  // Intake-implied slope: 7700 kcal ≈ 1 kg.
  const maintenance = profile ? Math.round(bmr(profile) * profile.activity) : null;
  // Positive when eating above maintenance (gain), negative when below (loss).
  const intakeSlope =
    maintenance && avgIntake7 > 0 ? (avgIntake7 - maintenance) / 7700 : null;

  let kgPerDay = 0;
  let basis: GoalProjection["basis"] = "none";
  if (observed !== null && recent.length >= 4 && Math.abs(observed) >= 0.002) {
    kgPerDay = observed;
    basis = "trend";
  } else if (intakeSlope !== null && Math.abs(intakeSlope) >= 0.001) {
    kgPerDay = intakeSlope;
    basis = "intake";
  } else if (observed !== null) {
    kgPerDay = observed;
    basis = "trend";
  }

  const weeklyRate = Math.round(kgPerDay * 7 * 100) / 100;
  const delta = goalW - current; // negative when goal is below current

  if (basis === "none" || Math.abs(kgPerDay) < 0.0005) {
    return {
      ...base,
      kgPerDay: 0,
      weeklyRate: 0,
      basis,
      direction: "stable",
      message:
        basis === "none"
          ? "Log weigh-ins and food for a few days to project your goal date."
          : "Weight is stable — adjust your intake to start trending toward your goal.",
    };
  }

  const movingToward = delta < 0 ? kgPerDay < 0 : kgPerDay > 0;
  if (!movingToward) {
    return {
      ...base,
      kgPerDay,
      weeklyRate,
      basis,
      direction: "away",
      message:
        delta < 0
          ? "You're trending away from your goal — intake is above target."
          : "You're trending below your goal — eat a little more.",
    };
  }

  const days = Math.max(1, Math.round(delta / kgPerDay));
  const etaDate = addDays(now, days);
  const eta = etaDate.toLocaleDateString(undefined, { day: "numeric", month: "short" });
  const rateAbs = Math.abs(weeklyRate).toFixed(2);

  return {
    ...base,
    kgPerDay,
    weeklyRate,
    basis,
    daysLeft: days,
    eta,
    direction: "toward",
    message:
      days > 730
        ? `Over 2 years at this pace (${rateAbs} kg/week) — tighten the gap to speed it up.`
        : `At ${rateAbs} kg/week you'll reach ${goalW} kg around ${eta}.`,
  };
}
