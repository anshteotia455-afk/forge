/* ------------------------------------------------------------------ *
 * Unit system helpers.
 *
 * Everything is STORED in kg / cm (imperial-free internals: BMR, body
 * fat, standards ratios, volume). These helpers convert only at the
 * display/input boundary so a single toggle re-labels the whole app.
 * ------------------------------------------------------------------ */

export type UnitSystem = "metric" | "imperial";

const KG_LB = 2.2046226218;
const CM_IN = 0.3937007874;

const r1 = (n: number) => Math.round(n * 10) / 10;

export const wUnit = (s: UnitSystem) => (s === "metric" ? "kg" : "lb");
export const lUnit = (s: UnitSystem) => (s === "metric" ? "cm" : "in");

/** stored kg -> display number */
export const wOut = (kg: number, s: UnitSystem): number =>
  s === "metric" ? r1(kg) : r1(kg * KG_LB);

/** display number -> stored kg */
export const wIn = (display: number, s: UnitSystem): number =>
  s === "metric" ? display : display / KG_LB;

/** stored kg delta -> display delta (for trend chips) */
export const wDeltaOut = (kg: number, s: UnitSystem): number =>
  s === "metric" ? r1(kg) : r1(kg * KG_LB);

/** stored cm -> display number */
export const lOut = (cm: number, s: UnitSystem): number =>
  s === "metric" ? r1(cm) : r1(cm * CM_IN);

/** display number -> stored cm */
export const lIn = (display: number, s: UnitSystem): number =>
  s === "metric" ? display : display / CM_IN;

/** Height as a human label: "178 cm" or 5'10" (inputs stay numeric). */
export function heightLabel(cm: number, s: UnitSystem): string {
  if (s === "metric") return `${r1(cm)} cm`;
  const totalIn = Math.round(cm * CM_IN);
  return `${Math.floor(totalIn / 12)}'${totalIn % 12}"`;
}

/** Range helpers for number inputs that accept display units. */
export const wRange = (kgMin: number, kgMax: number, s: UnitSystem) => ({
  min: wOut(kgMin, s),
  max: wOut(kgMax, s),
});

export const lRange = (cmMin: number, cmMax: number, s: UnitSystem) => ({
  min: lOut(cmMin, s),
  max: lOut(cmMax, s),
});

/* ------------------- Progression target formatting -------------------- */

import type { NextTarget } from "./engine";

/** "105 lb × 8" / "12 reps" / "45 s" — rendered in the user's units. */
export function targetHeadline(t: NextTarget, sys: UnitSystem): string {
  if (t.mode === "time") return `${t.sec} s`;
  if (t.kg != null && t.kg > 0) {
    return `${t.mode === "added" ? "+" : ""}${wOut(t.kg, sys)} ${wUnit(sys)} × ${t.reps ?? 0}`;
  }
  return `${t.reps ?? 0} reps`;
}

export function targetNote(t: NextTarget, sys: UnitSystem): string {
  if (t.mode === "time") {
    if (t.lastSec == null) return "First session — smooth, controlled form.";
    if ((t.sec ?? 0) > t.lastSec) return `+${(t.sec ?? 0) - t.lastSec}s over your last best`;
    return `hold ${t.sec}s again`;
  }
  if (t.lastReps == null) return "First session — clean form over load.";
  if (t.weightJump && t.incKg) {
    return `+${wOut(t.incKg, sys)} ${wUnit(sys)} jump — reset reps at the new weight`;
  }
  if (t.kg != null && t.kg > 0) {
    return (t.reps ?? 0) > t.lastReps
      ? `same weight, +1 rep (last: ${t.lastReps})`
      : `hold ${wOut(t.kg, sys)} ${wUnit(sys)}, aim for ${t.reps}`;
  }
  return t.clearedBand
    ? `you cleared the band — add a vest or +2 reps (last: ${t.lastReps})`
    : `+1 rep over last (last: ${t.lastReps})`;
}

export function targetLastLabel(t: NextTarget, sys: UnitSystem): string | null {
  if (t.lastKg != null && t.lastKg > 0) {
    return `${t.mode === "added" ? "+" : ""}${wOut(t.lastKg, sys)} ${wUnit(sys)} × ${t.lastReps ?? 0}`;
  }
  if (t.lastSec != null) return `${t.lastSec} s`;
  if (t.lastReps != null) return `${t.lastReps} reps`;
  return null;
}
