/* ---------------------- Daily recovery & readiness -------------------- */

export interface DailyCheckin {
  id: string;
  date: string; // yyyy-mm-dd
  sleepHours: number;
  sleepQuality: 1 | 2 | 3 | 4 | 5;
  energy: 1 | 2 | 3 | 4 | 5;
  soreness: 1 | 2 | 3 | 4 | 5;
  stress: 1 | 2 | 3 | 4 | 5;
  steps: number;
  restingHr: number | null;
  painAreas: string[];
  note: string;
}

export const PAIN_AREAS = [
  "Neck",
  "Shoulder",
  "Elbow",
  "Wrist",
  "Upper back",
  "Lower back",
  "Hip",
  "Knee",
  "Ankle",
] as const;

export interface ReadinessResult {
  score: number;
  label: "Excellent" | "Ready" | "Moderate" | "Low" | "Rest";
  color: string;
  headline: string;
  guidance: string;
  /** suggested generator intensity */
  level: 1 | 2 | 3;
  /** suggested percentage of normal training volume */
  volumePct: number;
  sleepScore: number;
  bodyScore: number;
  mindScore: number;
}

function clamp(n: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, n));
}

/** Sleep duration score peaks at 8h and declines outside 7–9h. */
function durationScore(hours: number): number {
  if (hours >= 7 && hours <= 9) return 100;
  if (hours < 7) return clamp(100 - (7 - hours) * 22);
  return clamp(100 - (hours - 9) * 15);
}

/**
 * Transparent readiness model:
 *   sleep 35% · energy 25% · soreness 20% · stress 20%
 * Pain flags cap the score because a good mood doesn't cancel an injury.
 */
export function readinessOf(c: DailyCheckin | null | undefined): ReadinessResult {
  if (!c) {
    return {
      score: 0,
      label: "Moderate",
      color: "var(--muted)",
      headline: "Check in first",
      guidance: "Log sleep, energy and soreness to get today's training recommendation.",
      level: 2,
      volumePct: 100,
      sleepScore: 0,
      bodyScore: 0,
      mindScore: 0,
    };
  }

  const sleepScore = Math.round(durationScore(c.sleepHours) * 0.6 + (c.sleepQuality / 5) * 100 * 0.4);
  const energyScore = (c.energy / 5) * 100;
  const sorenessScore = ((6 - c.soreness) / 5) * 100;
  const stressScore = ((6 - c.stress) / 5) * 100;
  const bodyScore = Math.round(energyScore * 0.55 + sorenessScore * 0.45);
  const mindScore = Math.round(stressScore);

  let score = Math.round(
    sleepScore * 0.35 + energyScore * 0.25 + sorenessScore * 0.2 + stressScore * 0.2
  );
  if (c.painAreas.length > 0) score = Math.min(score, c.painAreas.length >= 2 ? 42 : 55);

  if (score >= 85)
    return {
      score,
      label: "Excellent",
      color: "var(--volt)",
      headline: "Green light",
      guidance: "You are well recovered. Push intensity or chase a small personal best today.",
      level: 3,
      volumePct: 110,
      sleepScore,
      bodyScore,
      mindScore,
    };
  if (score >= 70)
    return {
      score,
      label: "Ready",
      color: "var(--aqua)",
      headline: "Train as planned",
      guidance: "Good recovery. Keep your normal session and leave one rep in reserve.",
      level: 2,
      volumePct: 100,
      sleepScore,
      bodyScore,
      mindScore,
    };
  if (score >= 50)
    return {
      score,
      label: "Moderate",
      color: "#ffc740",
      headline: "Dial it back",
      guidance: "Train, but cut one set per movement and avoid all-out efforts.",
      level: 2,
      volumePct: 75,
      sleepScore,
      bodyScore,
      mindScore,
    };
  if (score >= 30)
    return {
      score,
      label: "Low",
      color: "var(--ember)",
      headline: "Recovery session",
      guidance:
        c.painAreas.length > 0
          ? `Pain flagged: ${c.painAreas.join(", ")}. Choose mobility or unaffected body parts only.`
          : "Keep it easy: walking, mobility, technique work or a short starter workout.",
      level: 1,
      volumePct: 50,
      sleepScore,
      bodyScore,
      mindScore,
    };
  return {
    score,
    label: "Rest",
    color: "var(--red)",
    headline: "Take the day off",
    guidance:
      c.painAreas.length > 0
        ? "Rest and monitor the pain. Seek a qualified clinician if it persists or worsens."
        : "Sleep, eat, hydrate and walk gently. One rest day protects the next ten training days.",
    level: 1,
    volumePct: 0,
    sleepScore,
    bodyScore,
    mindScore,
  };
}

export interface RecoveryTrend {
  averageReadiness: number;
  averageSleep: number;
  averageSteps: number;
  checkins: number;
  direction: "up" | "down" | "steady";
  sleepDebtHours: number;
}

export function recoveryTrend(checkins: DailyCheckin[], limit = 7): RecoveryTrend {
  const recent = [...checkins].sort((a, b) => b.date.localeCompare(a.date)).slice(0, limit);
  if (!recent.length) {
    return {
      averageReadiness: 0,
      averageSleep: 0,
      averageSteps: 0,
      checkins: 0,
      direction: "steady",
      sleepDebtHours: 0,
    };
  }
  const scores = recent.map((c) => readinessOf(c).score);
  const averageReadiness = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  const averageSleep = Math.round((recent.reduce((a, c) => a + c.sleepHours, 0) / recent.length) * 10) / 10;
  const averageSteps = Math.round(recent.reduce((a, c) => a + c.steps, 0) / recent.length);
  const sleepDebtHours =
    Math.round(recent.reduce((a, c) => a + Math.max(0, 8 - c.sleepHours), 0) * 10) / 10;

  const half = Math.max(1, Math.floor(scores.length / 2));
  const newer = scores.slice(0, half).reduce((a, b) => a + b, 0) / half;
  const olderSlice = scores.slice(half);
  const older = olderSlice.length
    ? olderSlice.reduce((a, b) => a + b, 0) / olderSlice.length
    : newer;
  const delta = newer - older;

  return {
    averageReadiness,
    averageSleep,
    averageSteps,
    checkins: recent.length,
    direction: delta > 5 ? "up" : delta < -5 ? "down" : "steady",
    sleepDebtHours,
  };
}
