"use client";

import { useMemo } from "react";
import { useStore } from "./store";

export type Lang = "en" | "hi";

/**
 * Core UI translations. Keys are dotted and English is the fallback, so any
 * untranslated string renders in English rather than a raw key.
 */
const DICT: Record<string, Record<Lang, string>> = {
  /* Navigation */
  "nav.home": { en: "Home", hi: "होम" },
  "nav.plan": { en: "Plan", hi: "योजना" },
  "nav.forge": { en: "Forge", hi: "वर्कआउट" },
  "nav.food": { en: "Food", hi: "खाना" },
  "nav.you": { en: "You", hi: "आप" },

  /* Sync badge */
  "sync.syncing": { en: "Syncing", hi: "सिंक हो रहा" },
  "sync.synced": { en: "Synced", hi: "सिंक्ड" },
  "sync.offline": { en: "Offline", hi: "ऑफ़लाइन" },
  "sync.cloud": { en: "Cloud", hi: "क्लाउड" },

  /* Dashboard */
  "greet.morning": { en: "Morning", hi: "सुप्रभात" },
  "greet.afternoon": { en: "Afternoon", hi: "नमस्कार" },
  "greet.evening": { en: "Evening", hi: "शुभ संध्या" },
  "dash.readiness": { en: "Today's readiness", hi: "आज की तैयारी" },
  "dash.howRecovered": { en: "How recovered are you?", hi: "आप कितने ताज़ा हैं?" },
  "dash.checkinCta": {
    en: "Check in with sleep, energy and soreness for a smarter workout.",
    hi: "स्मार्ट वर्कआउट के लिए नींद, ऊर्जा और दर्द की जाँच करें।",
  },
  "dash.training": { en: "Today · Training", hi: "आज · ट्रेनिंग" },
  "dash.restDay": { en: "Rest day", hi: "आराम का दिन" },
  "dash.recoverHint": {
    en: "Recover hard. Walk, stretch, hydrate.",
    hi: "अच्छी तरह रिकवर करें। टहलें, स्ट्रेच करें, पानी पिएँ।",
  },
  "dash.nothingPlanned": { en: "Nothing planned", hi: "कुछ नियोजित नहीं" },
  "dash.generateCta": {
    en: "Generate a workout from the equipment you own.",
    hi: "अपने उपकरणों से वर्कआउट बनाएँ।",
  },
  "dash.forgeWorkout": { en: "Forge a workout", hi: "वर्कआउट बनाएँ" },
  "dash.startWorkout": { en: "Start workout", hi: "वर्कआउट शुरू करें" },
  "dash.changePlan": { en: "Change plan", hi: "योजना बदलें" },
  "dash.fuel": { en: "Fuel today", hi: "आज का ईंधन" },
  "dash.logFood": { en: "Log food", hi: "खाना दर्ज करें" },
  "dash.kcalLeft": { en: "kcal left", hi: "कैलोरी शेष" },
  "dash.eaten": { en: "Eaten", hi: "खाया" },
  "dash.goal": { en: "goal", hi: "लक्ष्य" },
  "dash.water": { en: "Water", hi: "पानी" },
  "dash.thisWeek": { en: "This week", hi: "यह सप्ताह" },
  "dash.recent": { en: "Recent sessions", hi: "हाल के सत्र" },
  "dash.goalProjection": { en: "Goal projection", hi: "लक्ष्य का अनुमान" },
  "dash.sessions": { en: "sessions", hi: "सत्र" },
  "dash.sets": { en: "sets", hi: "सेट" },
  "dash.min": { en: "min", hi: "मिनट" },
  "dash.moves": { en: "moves", hi: "मूव्स" },
  "dash.volume": { en: "volume", hi: "वॉल्यूम" },
  "dash.holding": { en: "Holding steady", hi: "स्थिर बना हुआ" },
  "dash.offPace": { en: "Off pace", hi: "गति बिगड़ी" },
  "dash.setAGoal": { en: "Set a goal", hi: "लक्ष्य तय करें" },
  "dash.fromWeighins": { en: "from your weigh-ins", hi: "आपके वज़न से" },
  "dash.fromIntake": { en: "from your intake", hi: "आपके खाने से" },
  "dash.days": { en: "days", hi: "दिन" },

  /* Page titles */
  "pg.plannerEyebrow": { en: "Routine planner", hi: "रूटीन प्लानर" },
  "pg.plannerTitle": { en: "Program your week", hi: "अपना हफ़्ता तय करें" },
  "pg.genEyebrow": { en: "Workout generator", hi: "वर्कआउट जेनरेटर" },
  "pg.genTitle": { en: "Forge your session", hi: "अपना सत्र बनाएँ" },
  "pg.nutEyebrow": { en: "Nutrition", hi: "पोषण" },
  "pg.nutTitle": { en: "Fuel log", hi: "खाना लॉग" },
  "pg.ranksEyebrow": { en: "Progression", hi: "प्रगति" },
  "pg.ranksTitle": { en: "Rank & badges", hi: "रैंक और बैज" },
  "pg.skillEyebrow": { en: "Skill trees", hi: "स्किल ट्री" },
  "pg.skillTitle": { en: "Learn a skill", hi: "स्किल सीखें" },
  "pg.recEyebrow": { en: "Daily check-in", hi: "दैनिक चेक-इन" },
  "pg.recTitle": { en: "Recovery", hi: "रिकवरी" },
  "pg.libEyebrow": { en: "Exercise library", hi: "एक्सरसाइज़ लाइब्रेरी" },
  "pg.libTitle": { en: "How-to & form", hi: "तरीका और फ़ॉर्म" },
  "pg.profileEyebrow": { en: "Athlete", hi: "एथलीट" },

  /* Profile language card */
  "profile.language": { en: "Language", hi: "भाषा" },
  "profile.languageHint": {
    en: "Interface language — switches instantly",
    hi: "इंटरफ़ेस की भाषा — तुरंत बदलें",
  },

  /* Common controls */
  "common.back": { en: "Back", hi: "वापस" },
  "common.save": { en: "Save", hi: "सेव" },
  "common.cancel": { en: "Cancel", hi: "रद्द करें" },
  "common.done": { en: "Done", hi: "हो गया" },
  "common.new": { en: "New", hi: "नया" },
  "common.add": { en: "Add", hi: "जोड़ें" },
  "common.log": { en: "Log", hi: "दर्ज करें" },
  "common.edit": { en: "Edit", hi: "बदलें" },
  "common.settings": { en: "Settings", hi: "सेटिंग्स" },
};

export function translate(key: string, lang: Lang): string {
  return DICT[key]?.[lang] ?? DICT[key]?.en ?? key;
}

/** Translation function bound to the persisted language preference. */
export function useT(): (key: string) => string {
  const lang = useStore((s) => s.lang) ?? "en";
  return useMemo(() => (key: string) => translate(key, lang), [lang]);
}
