"use client";

export interface ShareStats {
  name: string;
  minutes: number;
  kcal: number;
  sets: number;
  /** volume already converted to the user's display unit */
  volume: number;
  volumeUnit?: string;
}

function wrapLines(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const words = text.split(" ");
  const lines: string[] = [];
  let line = "";
  for (const w of words) {
    const test = line ? `${line} ${w}` : w;
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line);
      line = w;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  return lines.slice(0, 2);
}

/** Renders a 1080×1350 workout story card and shares/downloads it. */
export async function shareWorkoutCard(s: ShareStats): Promise<"shared" | "saved" | "failed"> {
  try {
    const W = 1080;
    const H = 1350;
    const canvas = document.createElement("canvas");
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");
    if (!ctx) return "failed";

    const volt = "#cdf83f";
    const bg = "#0a0b0d";
    const muted = "#949aa3";

    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // frame
    ctx.strokeStyle = "rgba(244,245,240,0.14)";
    ctx.lineWidth = 2;
    roundRect(ctx, 40, 40, W - 80, H - 80, 36);
    ctx.stroke();

    // brand bar
    ctx.fillStyle = volt;
    roundRect(ctx, 90, 110, 460, 90, 20);
    ctx.fill();
    ctx.fillStyle = bg;
    ctx.font = "900 56px Arial, system-ui, sans-serif";
    ctx.textBaseline = "middle";
    ctx.fillText("FORGE", 130, 158);

    ctx.fillStyle = muted;
    ctx.font = "600 34px Arial, system-ui, sans-serif";
    ctx.fillText(
      new Date().toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" }).toUpperCase(),
      92,
      290
    );

    // workout name
    ctx.fillStyle = "#f4f5f0";
    ctx.font = "900 120px 'Arial Narrow', Arial, system-ui, sans-serif";
    const lines = wrapLines(ctx, s.name.toUpperCase(), W - 180);
    lines.forEach((ln, i) => ctx.fillText(ln, 90, 400 + i * 128));

    // stat cards
    const stats: { v: string; l: string }[] = [
      { v: String(s.minutes), l: "MINUTES" },
      { v: String(s.kcal), l: "KCAL BURNED" },
      { v: String(s.sets), l: "SETS" },
      {
        v:
          s.volume >= 1000 && s.volumeUnit !== "lb"
            ? `${(s.volume / 1000).toFixed(1)}t`
            : `${Math.round(s.volume)} ${s.volumeUnit ?? "kg"}`,
        l: "VOLUME",
      },
    ];
    const cw = (W - 180 - 3 * 24) / 4;
    stats.forEach((st, i) => {
      const x = 90 + i * (cw + 24);
      const y = 640;
      ctx.fillStyle = "#121419";
      roundRect(ctx, x, y, cw, 240, 28);
      ctx.fill();
      ctx.strokeStyle = "rgba(244,245,240,0.1)";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = volt;
      ctx.font = "900 72px 'Arial Narrow', Arial, system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(st.v, x + cw / 2, y + 108);
      ctx.fillStyle = muted;
      ctx.font = "700 26px Arial, system-ui, sans-serif";
      ctx.fillText(st.l, x + cw / 2, y + 180);
      ctx.textAlign = "left";
    });

    // rule
    ctx.fillStyle = "rgba(244,245,240,0.14)";
    ctx.fillRect(90, 1010, W - 180, 2);

    // footer
    ctx.fillStyle = "#f4f5f0";
    ctx.font = "800 44px Arial, system-ui, sans-serif";
    ctx.fillText("SESSION CRUSHED.", 90, 1100);
    ctx.fillStyle = muted;
    ctx.font = "500 30px Arial, system-ui, sans-serif";
    ctx.fillText("Tracked offline-first with FORGE — Home Fitness OS", 90, 1160);

    // volt footer strip
    ctx.fillStyle = volt;
    roundRect(ctx, 90, 1220, 140, 14, 7);
    ctx.fill();

    const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/png"));
    if (!blob) return "failed";
    const file = new File([blob], "forge-workout.png", { type: "image/png" });

    const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
    if (nav.canShare?.({ files: [file] })) {
      await navigator.share({ files: [file], title: "FORGE workout", text: `${s.name} — logged with FORGE` });
      return "shared";
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "forge-workout.png";
    a.click();
    URL.revokeObjectURL(url);
    return "saved";
  } catch {
    return "failed";
  }
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/* -------------------------- Monthly report card ------------------------ */

export interface MonthStats {
  month: string;
  sessions: number;
  minutes: number;
  sets: number;
  /** volume already in the user's display unit */
  volume: number;
  volumeUnit: string;
  waterDays: number;
  prs: number;
  rankName: string;
  rankTier: string;
  rankColor: string;
  topExercise: string | null;
}

/** Renders a shareable 1080×1350 month-in-review card. */
export async function shareMonthlyCard(s: MonthStats): Promise<"shared" | "saved" | "failed"> {
  try {
    const W = 1080;
    const H = 1350;
    const canvas = document.createElement("canvas");
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");
    if (!ctx) return "failed";

    const volt = "#cdf83f";
    const bg = "#0a0b0d";
    const muted = "#949aa3";

    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);
    ctx.strokeStyle = "rgba(244,245,240,0.14)";
    ctx.lineWidth = 2;
    roundRect(ctx, 40, 40, W - 80, H - 80, 36);
    ctx.stroke();

    // Brand + month
    ctx.fillStyle = volt;
    roundRect(ctx, 90, 110, 460, 90, 20);
    ctx.fill();
    ctx.fillStyle = bg;
    ctx.font = "900 56px Arial, system-ui, sans-serif";
    ctx.textBaseline = "middle";
    ctx.fillText("FORGE", 130, 158);

    ctx.fillStyle = "#f4f5f0";
    ctx.font = "900 96px 'Arial Narrow', Arial, system-ui, sans-serif";
    ctx.fillText(s.month.toUpperCase(), 90, 330);

    // Headline stat
    ctx.fillStyle = s.rankColor;
    ctx.font = "900 150px 'Arial Narrow', Arial, system-ui, sans-serif";
    ctx.fillText(`${s.sessions}`, 90, 520);
    ctx.fillStyle = muted;
    ctx.font = "700 36px Arial, system-ui, sans-serif";
    ctx.fillText("SESSIONS CRUSHED", 330, 520);

    // Stat grid 2×3
    const stats: { v: string; l: string }[] = [
      { v: s.minutes.toLocaleString(), l: "MINUTES" },
      { v: s.sets.toLocaleString(), l: "SETS" },
      {
        v: s.volume >= 1000 && s.volumeUnit !== "lb"
          ? `${(s.volume / 1000).toFixed(1)}t`
          : `${Math.round(s.volume)} ${s.volumeUnit}`,
        l: "VOLUME",
      },
      { v: String(s.waterDays), l: "WATER DAYS" },
      { v: String(s.prs), l: "NEW PRs" },
      { v: `${s.rankName}`, l: `TIER ${s.rankTier}` },
    ];
    const cols = 3;
    const cw = (W - 180 - 2 * 28) / cols;
    const ch = 190;
    stats.forEach((st, i) => {
      const x = 90 + (i % cols) * (cw + 28);
      const y = 610 + Math.floor(i / cols) * (ch + 28);
      ctx.fillStyle = "#121419";
      roundRect(ctx, x, y, cw, ch, 24);
      ctx.fill();
      ctx.strokeStyle = "rgba(244,245,240,0.1)";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.textAlign = "center";
      ctx.fillStyle = i === 5 ? s.rankColor : "#f4f5f0";
      ctx.font = "900 58px 'Arial Narrow', Arial, system-ui, sans-serif";
      const val = st.v.length > 9 ? `${st.v.slice(0, 8)}…` : st.v;
      ctx.fillText(val, x + cw / 2, y + 80);
      ctx.fillStyle = muted;
      ctx.font = "700 24px Arial, system-ui, sans-serif";
      ctx.fillText(st.l, x + cw / 2, y + 145);
      ctx.textAlign = "left";
    });

    // Top exercise
    ctx.fillStyle = "rgba(244,245,240,0.12)";
    ctx.fillRect(90, 1105, W - 180, 2);
    ctx.fillStyle = "#f4f5f0";
    ctx.font = "800 40px Arial, system-ui, sans-serif";
    ctx.fillText(
      s.topExercise ? `Most trained: ${s.topExercise}` : "Consistency beats intensity.",
      90,
      1180
    );
    ctx.fillStyle = muted;
    ctx.font = "500 30px Arial, system-ui, sans-serif";
    ctx.fillText("Tracked offline-first with FORGE — Home Fitness OS", 90, 1245);

    const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/png"));
    if (!blob) return "failed";
    const file = new File([blob], "forge-month.png", { type: "image/png" });

    const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
    if (nav.canShare?.({ files: [file] })) {
      await navigator.share({ files: [file], title: "FORGE monthly report", text: `${s.month} in FORGE` });
      return "shared";
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "forge-month.png";
    a.click();
    URL.revokeObjectURL(url);
    return "saved";
  } catch {
    return "failed";
  }
}
