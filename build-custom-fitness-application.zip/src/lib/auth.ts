"use client";

/**
 * Client-side auth + per-account local storage.
 *
 * Design goals:
 *  - Offline-first. Once you've logged in on a device, your data lives in a
 *    local store for that account and keeps working with no connection.
 *  - Isolated. Each account (and the signed-out "guest" profile) gets its own
 *    saved dataset, so two people sharing a phone never see each other's logs.
 *  - Non-destructive. Logging out archives the data locally rather than
 *    deleting it, so logging back in restores instantly.
 */

export interface AuthUser {
  id: string;
  email: string;
  displayName: string | null;
}

export interface AuthSession {
  token: string;
  expiresAt: string;
  user: AuthUser;
}

/** True inside the self-contained Capacitor APK (no Node.js API server). */
export const BUNDLED_MOBILE = process.env.NEXT_PUBLIC_MOBILE_BUILD === "1";

const SESSION_KEY = "forge:session";
const DEVICE_KEY = "forge:deviceId";
const STORE_KEY = "forge@1"; // the zustand persist key
const ACCOUNT_PREFIX = "forge:data:"; // per-account archives

/* ------------------------------ Session -------------------------------- */

export function loadSession(): AuthSession | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as AuthSession;
    if (!s?.token || !s?.user?.id) return null;
    if (s.expiresAt && new Date(s.expiresAt) < new Date()) return null;
    return s;
  } catch {
    return null;
  }
}

export function saveSession(s: AuthSession): void {
  localStorage.setItem(SESSION_KEY, JSON.stringify(s));
}

export function clearSession(): void {
  localStorage.removeItem(SESSION_KEY);
}

export function authHeaders(): Record<string, string> {
  const s = loadSession();
  return s ? { Authorization: `Bearer ${s.token}` } : {};
}

/** Stable per-device id so signed-out users still get a cloud backup slot. */
export function deviceId(): string {
  if (typeof localStorage === "undefined") return "unknown";
  let id = localStorage.getItem(DEVICE_KEY);
  if (!id) {
    id =
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID().replace(/-/g, "")
        : Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem(DEVICE_KEY, id);
  }
  return id;
}

/* --------------------- Per-account local datasets ---------------------- */

function slotFor(userId: string | null): string {
  return `${ACCOUNT_PREFIX}${userId ?? "guest"}`;
}

/** Copies the live store into the given account's local archive. */
export function archiveCurrentInto(userId: string | null): void {
  try {
    const live = localStorage.getItem(STORE_KEY);
    if (live) localStorage.setItem(slotFor(userId), live);
  } catch {
    /* storage full or unavailable — non-fatal */
  }
}

/** Loads an account's archived dataset into the live store slot. */
export function restoreFrom(userId: string | null): boolean {
  try {
    const saved = localStorage.getItem(slotFor(userId));
    if (saved) {
      localStorage.setItem(STORE_KEY, saved);
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

/** Wipes the live slot so a fresh account starts clean. */
export function clearLiveStore(): void {
  try {
    localStorage.removeItem(STORE_KEY);
  } catch {
    /* ignore */
  }
}

export function hasLocalDataFor(userId: string | null): boolean {
  try {
    return Boolean(localStorage.getItem(slotFor(userId)));
  } catch {
    return false;
  }
}

/**
 * Switches the active local dataset. Returns true when existing data for the
 * target account was restored. The caller reloads so the store rehydrates.
 */
export function switchAccount(fromUserId: string | null, toUserId: string | null): boolean {
  archiveCurrentInto(fromUserId);
  const restored = restoreFrom(toUserId);
  if (!restored) clearLiveStore();
  return restored;
}

/* ------------------------------ Requests ------------------------------- */

export interface AuthResult {
  ok: boolean;
  error?: string;
  session?: AuthSession;
}

async function post(path: string, body: unknown): Promise<AuthResult> {
  try {
    const res = await fetch(path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = (await res.json()) as {
      token?: string;
      expiresAt?: string;
      user?: AuthUser;
      error?: string;
    };
    if (!res.ok || !data.token || !data.user) {
      return { ok: false, error: data.error ?? "Something went wrong." };
    }
    return {
      ok: true,
      session: { token: data.token, expiresAt: data.expiresAt ?? "", user: data.user },
    };
  } catch {
    return {
      ok: false,
      error: "Can't reach the server. Check your connection and try again.",
    };
  }
}

export function signup(email: string, password: string, displayName?: string) {
  return post("/api/auth/signup", { email, password, displayName });
}

export function login(email: string, password: string) {
  return post("/api/auth/login", { email, password });
}

/** Confirms the saved token is still valid. Offline → keep trusting cache. */
export async function verifySession(): Promise<"valid" | "invalid" | "offline"> {
  const s = loadSession();
  if (!s) return "invalid";
  try {
    const res = await fetch("/api/auth/me", { headers: authHeaders() });
    if (res.status === 401) return "invalid";
    if (!res.ok) return "offline";
    return "valid";
  } catch {
    return "offline";
  }
}

export async function logout(): Promise<void> {
  try {
    await fetch("/api/auth/me", { method: "DELETE", headers: authHeaders() });
  } catch {
    /* best effort — token still cleared locally */
  }
  clearSession();
}
