import { EquipmentId, EXERCISES } from "./data";

/* --------------------------- Skill roadmaps ---------------------------- */

export interface SkillStage {
  id: string;
  name: string;
  /** The measurable standard that marks this stage as owned. */
  goal: string;
  /** Coaching focus for the stage. */
  focus: string;
  /** Exercise ids practised at this stage. */
  drills: string[];
  /** Suggested practice frequency. */
  frequency: string;
}

export interface Skill {
  id: string;
  name: string;
  tagline: string;
  icon: string;
  color: string;
  /** Gear needed for the full path (bodyweight implied). */
  equipment: EquipmentId[];
  weeks: string;
  stages: SkillStage[];
}

export const SKILLS: Skill[] = [
  {
    id: "boxing",
    name: "Boxing",
    tagline: "Stance, punches, combinations and ring conditioning",
    icon: "🥊",
    color: "#ff7a2f",
    equipment: ["boxingbag", "jumprope"],
    weeks: "12–16 weeks",
    stages: [
      {
        id: "box-1",
        name: "Stance & Guard",
        goal: "Hold a clean guard and move 3 minutes without dropping your hands",
        focus: "Feet shoulder-width, lead foot forward, chin tucked, hands at cheekbones. Never cross your feet.",
        frequency: "3× per week · 15 min",
        drills: ["bag-footwork", "jump-rope", "plank", "shadow-rounds"],
      },
      {
        id: "box-2",
        name: "Jab & Cross",
        goal: "100 clean jab-cross pairs with full hip rotation",
        focus: "The jab snaps and returns. The cross turns the back foot — power comes from the ground, not the arm.",
        frequency: "3× per week · 20 min",
        drills: ["bag-jab-cross", "jump-rope", "push-up", "bag-footwork"],
      },
      {
        id: "box-3",
        name: "Hooks & Uppercuts",
        goal: "Throw 4-punch combos for 3 rounds without gassing",
        focus: "Turn from the hips. Elbow level with the fist on hooks, drive up from the knees on uppercuts.",
        frequency: "3–4× per week · 25 min",
        drills: ["bag-hooks", "bag-combos", "mb-russian-twist", "rope-intervals"],
      },
      {
        id: "box-4",
        name: "Defence & Movement",
        goal: "Slip, roll and pivot through 5 continuous rounds",
        focus: "Head off the centreline after every combination. Punch, move, reset — never admire your work.",
        frequency: "4× per week · 30 min",
        drills: ["bag-combos", "bag-footwork", "bag-knees", "burpees"],
      },
      {
        id: "box-5",
        name: "Fight Conditioning",
        goal: "10 full-intensity rounds with 60s rest",
        focus: "Pace is a skill. Breathe out on every punch, stay relaxed until the moment of impact.",
        frequency: "4–5× per week · 40 min",
        drills: ["bag-speed-burst", "bag-combos", "rope-intervals", "burpees", "mb-slam"],
      },
    ],
  },
  {
    id: "pullup",
    name: "Pull-Up Mastery",
    tagline: "From dead hang to clean reps, then weighted and one-arm work",
    icon: "🧗",
    color: "#cdf83f",
    equipment: ["pullupbar", "bands"],
    weeks: "10–20 weeks",
    stages: [
      {
        id: "pu-1",
        name: "Hang & Scapular Control",
        goal: "60-second dead hang + 10 scapular pulls",
        focus: "Build the grip and teach the shoulders to engage before the arms ever bend.",
        frequency: "3× per week",
        drills: ["dead-hang", "scap-pull", "band-row", "superman"],
      },
      {
        id: "pu-2",
        name: "Negatives & Assisted",
        goal: "5 slow 5-second negatives",
        focus: "Jump to the top, then resist the descent. Negatives build the strength reps can't yet.",
        frequency: "3× per week",
        drills: ["chin-up", "band-row", "db-row", "scap-pull"],
      },
      {
        id: "pu-3",
        name: "First Clean Rep",
        goal: "1 strict chin-up from a dead hang",
        focus: "No kipping, no swinging. Chin clears the bar, full extension at the bottom.",
        frequency: "4× per week, low volume",
        drills: ["chin-up", "pull-up", "band-row", "db-curl"],
      },
      {
        id: "pu-4",
        name: "Volume Builder",
        goal: "3 sets of 8 strict pull-ups",
        focus: "Grease the groove — frequent sub-maximal sets beat occasional grinders.",
        frequency: "4× per week",
        drills: ["pull-up", "chin-up", "hanging-leg-raise", "ring-row"],
      },
      {
        id: "pu-5",
        name: "Weighted & Advanced",
        goal: "5 pull-ups with +10 kg, or 3 archer pull-ups per side",
        focus: "Add load slowly. Keep the strict standard as the weight climbs.",
        frequency: "3× per week",
        drills: ["pull-up", "weighted-pullup", "ring-row", "hanging-leg-raise"],
      },
    ],
  },
  {
    id: "handstand",
    name: "Handstand",
    tagline: "Wrist prep, wall holds, then the freestanding balance",
    icon: "🤸",
    color: "#5cd6ff",
    equipment: ["mat"],
    weeks: "16–24 weeks",
    stages: [
      {
        id: "hs-1",
        name: "Wrists & Shoulders",
        goal: "2-minute plank + pain-free wrist circles",
        focus: "Prepare the wrists every session. Overhead shoulder flexion is the real gatekeeper.",
        frequency: "Daily · 10 min",
        drills: ["plank", "pike-push-up", "cat-cow", "wrist-prep"],
      },
      {
        id: "hs-2",
        name: "Wall Plank & Pike",
        goal: "60-second chest-to-wall hold",
        focus: "Walk your feet up the wall, ribs tucked, body in one straight line. Push the floor away.",
        frequency: "4× per week",
        drills: ["wall-handstand", "pike-push-up", "plank", "hollow-hold"],
      },
      {
        id: "hs-3",
        name: "Kick-Up & Balance",
        goal: "10-second freestanding hold",
        focus: "Kick up lightly and find balance with your fingertips — not your shoulders.",
        frequency: "5× per week, short sessions",
        drills: ["wall-handstand", "handstand-kickup", "hollow-hold", "pike-push-up"],
      },
      {
        id: "hs-4",
        name: "Consistent Hold",
        goal: "30-second freestanding handstand",
        focus: "Stack wrists, shoulders and hips. Small finger corrections, no banana back.",
        frequency: "5× per week",
        drills: ["handstand-kickup", "wall-handstand", "hollow-hold", "l-sit"],
      },
      {
        id: "hs-5",
        name: "Handstand Push-Up",
        goal: "5 wall handstand push-ups",
        focus: "Lower under control to the floor, press back to lockout without arching.",
        frequency: "3× per week",
        drills: ["hspu-wall", "pike-push-up", "parallette-pushup", "db-shoulder-press"],
      },
    ],
  },
  {
    id: "core",
    name: "L-Sit & Levers",
    tagline: "Elite core strength: hollow, L-sit, then front lever",
    icon: "🪵",
    color: "#b98cff",
    equipment: ["dipbars", "pullupbar"],
    weeks: "12–20 weeks",
    stages: [
      {
        id: "cr-1",
        name: "Hollow Body",
        goal: "45-second hollow hold",
        focus: "Low back pressed flat into the floor. This shape underpins every advanced skill.",
        frequency: "4× per week",
        drills: ["hollow-hold", "plank", "leg-raise", "bicycle-crunch"],
      },
      {
        id: "cr-2",
        name: "Tuck Support",
        goal: "30-second tuck hold on bars",
        focus: "Arms locked, shoulders pressed down, knees pulled to chest.",
        frequency: "4× per week",
        drills: ["tuck-hold", "hollow-hold", "hanging-leg-raise", "parallel-dip"],
      },
      {
        id: "cr-3",
        name: "L-Sit",
        goal: "20-second L-sit with legs locked",
        focus: "Depress the shoulders hard, point the toes, legs parallel to the floor.",
        frequency: "4–5× per week",
        drills: ["l-sit", "tuck-hold", "hanging-leg-raise", "ab-rollout-knee"],
      },
      {
        id: "cr-4",
        name: "Tuck Front Lever",
        goal: "15-second tuck front lever",
        focus: "Pull the bar toward your hips, body horizontal, knees tucked tight.",
        frequency: "3–4× per week",
        drills: ["tuck-front-lever", "scap-pull", "pull-up", "hollow-hold"],
      },
      {
        id: "cr-5",
        name: "Advanced Lever",
        goal: "10-second straddle front lever",
        focus: "Open the legs to a straddle to reduce leverage before going full.",
        frequency: "3× per week",
        drills: ["tuck-front-lever", "pull-up", "ab-rollout-stand", "l-sit"],
      },
    ],
  },
  {
    id: "barbell",
    name: "Barbell Strength",
    tagline: "Squat, bench, deadlift and press with real technique",
    icon: "🏋️",
    color: "#ffc740",
    equipment: ["barbell", "plates", "squatrack", "bench"],
    weeks: "12–24 weeks",
    stages: [
      {
        id: "bb-1",
        name: "Movement Patterns",
        goal: "20 clean bodyweight squats + 20 hip hinges",
        focus: "Learn the hinge and the squat with no load. Technique debt compounds fast.",
        frequency: "3× per week",
        drills: ["squat", "glute-bridge", "db-rdl", "plank"],
      },
      {
        id: "bb-2",
        name: "Empty Bar Technique",
        goal: "3×8 on squat, bench and deadlift with the bar only",
        focus: "Bar path over midfoot, brace before every rep. Film yourself from the side.",
        frequency: "3× per week",
        drills: ["bb-squat", "bb-bench", "bb-deadlift", "bb-ohp"],
      },
      {
        id: "bb-3",
        name: "Linear Progression",
        goal: "Add 2.5 kg per session for 8 weeks straight",
        focus: "Small jumps, perfect reps. Leave 2 reps in the tank on every set.",
        frequency: "3× per week",
        drills: ["bb-squat", "bb-bench", "bb-row", "bb-deadlift"],
      },
      {
        id: "bb-4",
        name: "Bodyweight Milestones",
        goal: "Squat 1× bodyweight, deadlift 1.5× bodyweight",
        focus: "Now strength is real. Warm up properly, respect the heavy sets.",
        frequency: "4× per week",
        drills: ["bb-squat", "bb-deadlift", "bb-bench", "rack-front-squat"],
      },
      {
        id: "bb-5",
        name: "Intermediate Programming",
        goal: "Run a full 8-week block with planned deloads",
        focus: "Periodise: heavy, volume and light days. Track every set.",
        frequency: "4× per week",
        drills: ["bb-squat", "bb-bench", "bb-deadlift", "bb-ohp", "rack-pull"],
      },
    ],
  },
  {
    id: "kettlebell",
    name: "Kettlebell Flow",
    tagline: "Swing, clean, press and the Turkish get-up",
    icon: "🔔",
    color: "#ff6b6b",
    equipment: ["kettlebell"],
    weeks: "8–14 weeks",
    stages: [
      {
        id: "kb-1",
        name: "The Hinge",
        goal: "30 clean deadlifts with the bell",
        focus: "Hips back, not down. Shins vertical, spine neutral.",
        frequency: "3× per week",
        drills: ["kb-goblet", "glute-bridge", "db-rdl", "plank"],
      },
      {
        id: "kb-2",
        name: "Two-Hand Swing",
        goal: "5×20 swings with crisp hip snap",
        focus: "The bell floats — your hips throw it, your arms just guide.",
        frequency: "3–4× per week",
        drills: ["kb-swing", "kb-goblet", "kb-halo", "plank"],
      },
      {
        id: "kb-3",
        name: "Clean & Press",
        goal: "5×5 clean and press per side",
        focus: "Zip the elbow to the ribs on the clean, punch straight up on the press.",
        frequency: "3× per week",
        drills: ["kb-clean-press", "kb-swing", "kb-halo", "db-shoulder-press"],
      },
      {
        id: "kb-4",
        name: "Turkish Get-Up",
        goal: "3 get-ups per side, no wobble",
        focus: "Seven positions, each one owned. Eyes on the bell the whole way.",
        frequency: "3× per week",
        drills: ["turkish-getup", "kb-windmill", "kb-halo", "side-plank"],
      },
      {
        id: "kb-5",
        name: "Complexes & Flow",
        goal: "10-minute unbroken swing/clean/press complex",
        focus: "Chain the movements without putting the bell down. Pure conditioning.",
        frequency: "3–4× per week",
        drills: ["kb-clean-press", "kb-swing", "kb-windmill", "kb-goblet"],
      },
    ],
  },
  {
    id: "mobility",
    name: "Mobility & Flexibility",
    tagline: "Touch your toes, sit deep, open the shoulders",
    icon: "🧘",
    color: "#7de2a8",
    equipment: ["mat", "foamroller"],
    weeks: "8–16 weeks",
    stages: [
      {
        id: "mo-1",
        name: "Daily Baseline",
        goal: "10 minutes of mobility, 7 days straight",
        focus: "Consistency beats intensity. Breathe into every position.",
        frequency: "Daily · 10 min",
        drills: ["cat-cow", "world-stretch", "foam-back", "foam-quads"],
      },
      {
        id: "mo-2",
        name: "Hips & Hamstrings",
        goal: "Palms flat on the floor in a forward fold",
        focus: "Hinge from the hips with a long spine — don't round to cheat depth.",
        frequency: "5× per week",
        drills: ["world-stretch", "foam-quads", "foam-glutes", "glute-bridge"],
      },
      {
        id: "mo-3",
        name: "Deep Squat Hold",
        goal: "3-minute resting squat, heels down",
        focus: "Feet flat, chest up, elbows inside knees. Sit here while you scroll.",
        frequency: "Daily",
        drills: ["squat", "world-stretch", "wall-sit", "cat-cow"],
      },
      {
        id: "mo-4",
        name: "Shoulders & T-Spine",
        goal: "Full overhead reach against a wall with ribs down",
        focus: "Most overhead problems are thoracic, not shoulder. Extend the upper back.",
        frequency: "5× per week",
        drills: ["foam-chest-open", "band-pull-apart", "cat-cow", "band-face-pull"],
      },
      {
        id: "mo-5",
        name: "Active Flexibility",
        goal: "Hold an L-sit pike or a 90-second couch stretch per side",
        focus: "Strength at end range is what actually protects the joint.",
        frequency: "4× per week",
        drills: ["l-sit", "world-stretch", "foam-quads", "leg-raise"],
      },
    ],
  },
  {
    id: "engine",
    name: "Conditioning Engine",
    tagline: "Build a cardio base, then intervals and real work capacity",
    icon: "🫁",
    color: "#5cd6ff",
    equipment: ["jumprope"],
    weeks: "8–16 weeks",
    stages: [
      {
        id: "en-1",
        name: "Aerobic Base",
        goal: "30 continuous minutes at conversational pace",
        focus: "Nose breathing if you can. This builds the engine everything else runs on.",
        frequency: "3× per week",
        drills: ["jumping-jacks", "high-knees", "tread-steady-run", "bike-steady"],
      },
      {
        id: "en-2",
        name: "Rope Rhythm",
        goal: "5 unbroken minutes of jump rope",
        focus: "Wrists turn the rope, not the arms. Tiny bounces off the balls of the feet.",
        frequency: "4× per week",
        drills: ["jump-rope", "rope-intervals", "calf-raise", "high-knees"],
      },
      {
        id: "en-3",
        name: "Interval Work",
        goal: "10 rounds of 30s hard / 30s easy",
        focus: "Hard means hard. The easy minute is for recovery, not collapse.",
        frequency: "3× per week",
        drills: ["rope-intervals", "burpees", "mountain-climbers", "tread-intervals"],
      },
      {
        id: "en-4",
        name: "Threshold Push",
        goal: "4×4 minutes at hard-but-holdable pace",
        focus: "Sits right at the edge of comfortable. This raises your ceiling.",
        frequency: "3× per week",
        drills: ["tread-intervals", "row-intervals", "bike-hill", "jump-rope"],
      },
      {
        id: "en-5",
        name: "Work Capacity",
        goal: "20-minute mixed-modal circuit without stopping",
        focus: "Chain strength and cardio. Breathe, pace, never fully stop.",
        frequency: "3–4× per week",
        drills: ["burpees", "db-thruster", "mb-slam", "row-sprint", "kb-swing"],
      },
    ],
  },
  {
    id: "pushup",
    name: "Push-Up Mastery",
    tagline: "From knees to one-arm — the complete pressing ladder",
    icon: "🤜",
    color: "#ff9f45",
    equipment: ["pushupbars"],
    weeks: "10–16 weeks",
    stages: [
      { id: "pu2-1", name: "Incline Push-Up", goal: "3×12 on a waist-height surface", focus: "Body rigid from head to heel. Lower the surface as you get stronger.", frequency: "3× per week", drills: ["incline-push-up", "plank", "band-pull-apart", "dead-bug"] },
      { id: "pu2-2", name: "Full Push-Up", goal: "3×10 strict floor push-ups", focus: "Elbows at 45°, chest to the floor, no sagging hips.", frequency: "4× per week", drills: ["push-up", "plank", "incline-push-up", "superman"] },
      { id: "pu2-3", name: "Volume & Variations", goal: "25 unbroken push-ups", focus: "Add diamond and wide variants to hit every angle.", frequency: "4× per week", drills: ["push-up", "diamond-pushup", "wide-pushup", "pike-push-up"] },
      { id: "pu2-4", name: "Decline & Archer", goal: "8 archer push-ups per side", focus: "Shift weight to one arm while the other guides.", frequency: "3× per week", drills: ["archer-pushup", "decline-pushup", "diamond-pushup", "hollow-hold"] },
      { id: "pu2-5", name: "One-Arm Progression", goal: "3 one-arm push-ups per side", focus: "Wide base, brace hard, resist the rotation.", frequency: "3× per week", drills: ["archer-pushup", "pushup-bar-deep", "side-plank", "pallof-press"] },
    ],
  },
  {
    id: "pistol",
    name: "Pistol Squat",
    tagline: "Single-leg strength, balance and deep ankle mobility",
    icon: "🦵",
    color: "#f0695a",
    equipment: ["bench", "suspension"],
    weeks: "12–20 weeks",
    stages: [
      { id: "ps-1", name: "Ankle & Squat Depth", goal: "3-minute deep squat hold, heels down", focus: "Mobility first — a pistol is impossible without ankle range.", frequency: "Daily", drills: ["deep-squat-hold", "ankle-rocks", "squat", "cossack-squat"] },
      { id: "ps-2", name: "Split Squat Strength", goal: "3×12 Bulgarian split squats", focus: "Build single-leg strength before single-leg balance.", frequency: "3× per week", drills: ["bulgarian-split-squat", "reverse-lunge", "step-up", "single-leg-bridge"] },
      { id: "ps-3", name: "Box Pistol", goal: "8 pistols to a low box per side", focus: "Sit back to the box with control, stand without rocking.", frequency: "3× per week", drills: ["step-up", "trx-pistol", "shrimp-squat", "calf-raise-single"] },
      { id: "ps-4", name: "Assisted Pistol", goal: "5 strap-assisted pistols per side", focus: "Use only as much assistance as you truly need.", frequency: "4× per week", drills: ["trx-pistol", "cossack-squat", "sissy-squat", "ankle-rocks"] },
      { id: "ps-5", name: "Full Pistol", goal: "3 unassisted pistol squats per side", focus: "Free leg straight, chest up, controlled both directions.", frequency: "3× per week", drills: ["trx-pistol", "shrimp-squat", "cossack-squat", "single-leg-rdl"] },
    ],
  },
  {
    id: "muscleup",
    name: "Muscle-Up",
    tagline: "The bar classic: explosive pull into a clean transition",
    icon: "💫",
    color: "#cdf83f",
    equipment: ["pullupbar", "dipbars"],
    weeks: "16–28 weeks",
    stages: [
      { id: "mu-1", name: "Pull & Dip Base", goal: "8 strict pull-ups and 10 dips", focus: "You need both halves solid before combining them.", frequency: "4× per week", drills: ["pull-up", "parallel-dip", "chin-up", "scap-pull"] },
      { id: "mu-2", name: "Explosive Pull", goal: "Pull the bar to your lower chest", focus: "Height is everything. Pull fast, not just hard.", frequency: "3× per week", drills: ["pull-up", "scap-pull", "hanging-leg-raise", "kb-swing"] },
      { id: "mu-3", name: "Straight Bar Dip", goal: "8 straight bar dips", focus: "The top half of the muscle-up lives here.", frequency: "3× per week", drills: ["parallel-dip", "ring-dip", "tuck-hold", "push-up"] },
      { id: "mu-4", name: "The Transition", goal: "5 jumping muscle-up transitions", focus: "Roll the wrists over the bar early and lean forward.", frequency: "3× per week", drills: ["pull-up", "parallel-dip", "ring-row", "hollow-hold"] },
      { id: "mu-5", name: "Full Muscle-Up", goal: "1 clean strict muscle-up", focus: "No kipping. Pull high, turn over, press out.", frequency: "3× per week", drills: ["weighted-pullup", "ring-dip", "pull-up", "l-sit"] },
    ],
  },
  {
    id: "running",
    name: "Running Base",
    tagline: "Couch to continuous 5K without wrecking your knees",
    icon: "🏃",
    color: "#5cd6ff",
    equipment: ["treadmill"],
    weeks: "8–12 weeks",
    stages: [
      { id: "rn-1", name: "Walk-Run Intervals", goal: "30 minutes alternating 1 min run / 2 min walk", focus: "Build tendon tolerance slowly — this is the injury window.", frequency: "3× per week", drills: ["tread-incline-walk", "calf-raise", "tibialis-raise", "glute-bridge"] },
      { id: "rn-2", name: "Continuous 10 Minutes", goal: "Run 10 minutes without stopping", focus: "Slow is fine. Conversational pace builds the engine.", frequency: "3× per week", drills: ["tread-steady-run", "single-leg-bridge", "calf-raise-single", "plank"] },
      { id: "rn-3", name: "Twenty Minutes", goal: "Run 20 continuous minutes", focus: "Cadence around 170–180 steps per minute reduces impact.", frequency: "3–4× per week", drills: ["tread-steady-run", "nordic-curl", "step-up", "bird-dog"] },
      { id: "rn-4", name: "Full 5K", goal: "Complete 5 km continuously", focus: "Negative split — run the second half slightly faster.", frequency: "4× per week", drills: ["tread-steady-run", "tread-intervals", "single-leg-rdl", "foam-quads"] },
      { id: "rn-5", name: "Speed & Hills", goal: "6×400m intervals or a sub-30 5K", focus: "Add one quality session a week, keep the rest easy.", frequency: "4× per week", drills: ["tread-intervals", "tread-incline-walk", "box-jump", "nordic-curl"] },
    ],
  },
  {
    id: "core-abs",
    name: "Visible Core",
    tagline: "Deep core strength plus the habits that reveal it",
    icon: "🎯",
    color: "#ffc740",
    equipment: ["abwheel", "mat"],
    weeks: "10–16 weeks",
    stages: [
      { id: "ab-1", name: "Breathing & Bracing", goal: "60-second dead bug without losing position", focus: "Learn to brace before you learn to crunch.", frequency: "4× per week", drills: ["dead-bug", "bird-dog", "box-breathing", "plank"] },
      { id: "ab-2", name: "Anti-Extension", goal: "45-second plank and 10 kneeling rollouts", focus: "Resisting movement builds more core than bending does.", frequency: "4× per week", drills: ["plank", "ab-rollout-knee", "hollow-hold", "slider-pike"] },
      { id: "ab-3", name: "Anti-Rotation", goal: "3×12 Pallof press per side", focus: "Obliques are built by refusing to twist.", frequency: "4× per week", drills: ["pallof-press", "side-plank", "band-woodchop", "copenhagen-plank"] },
      { id: "ab-4", name: "Dynamic Strength", goal: "15 hanging leg raises", focus: "Curl the pelvis — swinging legs doesn't count.", frequency: "4× per week", drills: ["hanging-leg-raise", "v-up", "reverse-crunch", "cable-crunch"] },
      { id: "ab-5", name: "Reveal The Work", goal: "Hold a consistent calorie target for 8 weeks", focus: "Abs are built in the gym and revealed in the kitchen.", frequency: "Daily tracking", drills: ["ab-rollout-stand", "hanging-leg-raise", "tread-incline-walk", "plank"] },
    ],
  },
  {
    id: "posture",
    name: "Desk Posture Fix",
    tagline: "Undo the damage of sitting all day",
    icon: "🪑",
    color: "#7de2a8",
    equipment: ["bands", "foamroller"],
    weeks: "6–12 weeks",
    stages: [
      { id: "po-1", name: "Awareness & Relief", goal: "10 minutes of mobility daily for one week", focus: "Break up long sitting blocks — movement beats stretching.", frequency: "Daily", drills: ["cat-cow", "foam-back", "wall-angel", "thread-needle"] },
      { id: "po-2", name: "Open The Chest", goal: "Lie flat with arms overhead, low back down", focus: "Tight pecs pull the shoulders forward. Open them daily.", frequency: "Daily", drills: ["foam-chest-open", "band-pull-apart", "shoulder-dislocates", "prone-ytw"] },
      { id: "po-3", name: "Strengthen The Back", goal: "3×15 face pulls and Y-T-W raises", focus: "A strong upper back holds good posture without effort.", frequency: "4× per week", drills: ["band-face-pull", "prone-ytw", "band-row", "superman"] },
      { id: "po-4", name: "Hips & Hamstrings", goal: "90-second couch stretch per side", focus: "Sitting shortens the hip flexors — lengthen and strengthen.", frequency: "5× per week", drills: ["couch-stretch", "ninety-ninety", "glute-bridge", "pigeon-stretch"] },
      { id: "po-5", name: "Hold It All Day", goal: "Sit and stand tall without conscious effort", focus: "Posture is endurance. Strength plus frequent movement wins.", frequency: "Ongoing", drills: ["wall-angel", "band-face-pull", "deep-squat-hold", "legs-up-wall"] },
    ],
  },
];

export const SKILL_BY_ID = new Map(SKILLS.map((s) => [s.id, s]));

/* ------------------- Virtual drills not in the main DB ----------------- */

/** Skill-specific practice drills that aren't part of the generator library. */
export const SKILL_DRILLS: Record<
  string,
  { name: string; cue: string; kind: "reps" | "time"; reps?: number; sec?: number; equipment: EquipmentId[] }
> = {
  "shadow-rounds": {
    name: "Shadow Boxing Round",
    cue: "Move, punch, reset. Picture an opponent in front of you.",
    kind: "time",
    sec: 120,
    equipment: ["bodyweight"],
  },
  "wrist-prep": {
    name: "Wrist Prep Circuit",
    cue: "Palm circles, finger pulses, front and back of the wrist. Never skip this.",
    kind: "time",
    sec: 60,
    equipment: ["mat"],
  },
  "hollow-hold": {
    name: "Hollow Body Hold",
    cue: "Low back glued to the floor, arms and legs long.",
    kind: "time",
    sec: 30,
    equipment: ["mat"],
  },
  "wall-handstand": {
    name: "Chest-to-Wall Handstand",
    cue: "Walk the feet up, ribs tucked, push the floor away.",
    kind: "time",
    sec: 30,
    equipment: ["bodyweight"],
  },
  "handstand-kickup": {
    name: "Handstand Kick-Up Practice",
    cue: "Light kick, find the balance point, bail safely to the side.",
    kind: "reps",
    reps: 8,
    equipment: ["bodyweight"],
  },
  "hspu-wall": {
    name: "Wall Handstand Push-Up",
    cue: "Lower under control, press to full lockout.",
    kind: "reps",
    reps: 5,
    equipment: ["bodyweight"],
  },
  "tuck-front-lever": {
    name: "Tuck Front Lever Hold",
    cue: "Pull the bar to your hips, body horizontal, knees tight.",
    kind: "time",
    sec: 15,
    equipment: ["pullupbar"],
  },
  "weighted-pullup": {
    name: "Weighted Pull-Up",
    cue: "Add load via vest or a dumbbell between the feet. Strict only.",
    kind: "reps",
    reps: 5,
    equipment: ["pullupbar"],
  },
  "turkish-getup": {
    name: "Turkish Get-Up",
    cue: "Seven positions, eyes locked on the bell throughout.",
    kind: "reps",
    reps: 3,
    equipment: ["kettlebell"],
  },
};

export interface ResolvedDrill {
  id: string;
  name: string;
  cue: string;
  kind: "reps" | "time";
  reps: number | null;
  sec: number | null;
  equipment: EquipmentId[];
  inLibrary: boolean;
}

export function resolveDrill(id: string): ResolvedDrill | null {
  const ex = EXERCISES.find((e) => e.id === id);
  if (ex) {
    return {
      id: ex.id,
      name: ex.name,
      cue: ex.cue,
      kind: ex.kind,
      reps: ex.kind === "reps" ? (ex.reps ?? 10) : null,
      sec: ex.kind === "time" ? (ex.sec ?? 30) : null,
      equipment: ex.equipment,
      inLibrary: true,
    };
  }
  const v = SKILL_DRILLS[id];
  if (!v) return null;
  return {
    id,
    name: v.name,
    cue: v.cue,
    kind: v.kind,
    reps: v.reps ?? null,
    sec: v.sec ?? null,
    equipment: v.equipment,
    inLibrary: false,
  };
}

/** Stage index you're currently working on (first incomplete). */
export function currentStageIndex(skill: Skill, done: string[]): number {
  const idx = skill.stages.findIndex((s) => !done.includes(s.id));
  return idx === -1 ? skill.stages.length - 1 : idx;
}

export function skillPercent(skill: Skill, done: string[]): number {
  const n = skill.stages.filter((s) => done.includes(s.id)).length;
  return n / skill.stages.length;
}
