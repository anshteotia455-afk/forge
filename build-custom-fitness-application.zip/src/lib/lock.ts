/* --------------------------- App PIN lock ------------------------------ *
 * The PIN guards against casual snooping (photos, notes, logs) on a shared
 * phone. It is not a cryptographic boundary — it lives on the device with
 * the data it protects.
 *
 * Uses WebCrypto SHA-256 where available (HTTPS origins) and falls back to
 * a fast non-crypto hash under file:// (Electron), tagged so verification
 * always knows which scheme to recompute.
 * ---------------------------------------------------------------------- */

async function digest(pin: string): Promise<string> {
  try {
    if (typeof crypto !== "undefined" && crypto.subtle) {
      const buf = await crypto.subtle.digest(
        "SHA-256",
        new TextEncoder().encode(`forge-pin:${pin}`)
      );
      return (
        "sha256:" +
        [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("")
      );
    }
  } catch {
    // fall through to the non-crypto hash
  }
  let h = 5381;
  for (const ch of `forge-pin:${pin}`) h = ((h << 5) + h + ch.charCodeAt(0)) >>> 0;
  return "fnv:" + h.toString(16);
}

export async function hashPin(pin: string): Promise<string> {
  return digest(pin);
}

export async function verifyPin(pin: string, stored: string): Promise<boolean> {
  if (!stored || !pin) return false;
  return (await digest(pin)) === stored;
}
