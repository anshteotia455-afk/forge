"use client";

import { Capacitor, registerPlugin } from "@capacitor/core";

interface ForgeWidgetPlugin {
  update(data: { line1: string; line2: string }): Promise<void>;
}

const Native = registerPlugin<ForgeWidgetPlugin>("ForgeWidget");

export function isAndroidNative(): boolean {
  return Capacitor.isNativePlatform() && Capacitor.getPlatform() === "android";
}

/** Pushes today's summary to the Android home-screen widget (no-op elsewhere). */
export function pushWidget(line1: string, line2: string): void {
  if (!isAndroidNative()) return;
  Native.update({ line1, line2 }).catch(() => undefined);
}
