import { dateKey, personalRecords, streakOf } from "./engine";
import type { MealEntry, MeasureEntry, WeightEntry, WorkoutLog } from "./store";

/* ------------------------------- Ranks -------------------------------- */

export interface Rank {
  id: string;
  name: string;
  tier: string;
  minXp: number;
  color: string;
  glow: string;
}

/**
 * Ascending ladder — each rank unlocks at minXp.
 *
 * Deliberately DENSE early: a consistent beginner promotes several times in
 * the first weeks, so progression feels earned instead of distant. Later
 * tiers stretch out to keep Legend aspirational.
 */
export const RANKS: Rank[] = [
  { id: "rookie", name: "Rookie", tier: "I", minXp: 0, color: "#9aa3ad", glow: "rgba(154,163,173,0.35)" },
  { id: "novice", name: "Novice", tier: "II", minXp: 100, color: "#c58b5c", glow: "rgba(197,139,92,0.35)" },
  { id: "bronze", name: "Iron", tier: "III", minXp: 250, color: "#cd7f32", glow: "rgba(205,127,50,0.4)" },
  { id: "silver", name: "Steel", tier: "IV", minXp: 450, color: "#c0c8d4", glow: "rgba(192,200,212,0.4)" },
  { id: "gold", name: "Forged", tier: "V", minXp: 700, color: "#ffc740", glow: "rgba(255,199,64,0.45)" },
  { id: "tempered", name: "Tempered", tier: "VI", minXp: 1050, color: "#ff9f45", glow: "rgba(255,159,69,0.45)" },
  { id: "platinum", name: "Titan", tier: "VII", minXp: 1450, color: "#5cd6ff", glow: "rgba(92,214,255,0.45)" },
  { id: "blaze", name: "Blazing", tier: "VIII", minXp: 1950, color: "#ff7a2f", glow: "rgba(255,122,47,0.5)" },
  { id: "ascendant", name: "Ascendant", tier: "IX", minXp: 2550, color: "#b98cff", glow: "rgba(185,140,255,0.5)" },
  { id: "diamond", name: "Apex", tier: "X", minXp: 3250, color: "#ff69b4", glow: "rgba(255,105,180,0.45)" },
  { id: "elite", name: "Elite", tier: "XI", minXp: 4100, color: "#7de2a8", glow: "rgba(125,226,168,0.45)" },
  { id: "inferno", name: "Inferno", tier: "XII", minXp: 5200, color: "#ff5252", glow: "rgba(255,82,82,0.5)" },
  { id: "sovereign", name: "Sovereign", tier: "XIII", minXp: 6600, color: "#ffd700", glow: "rgba(255,215,0,0.5)" },
  { id: "immortal", name: "Immortal", tier: "XIV", minXp: 8400, color: "#00e5ff", glow: "rgba(0,229,255,0.5)" },
  { id: "transcendent", name: "Transcendent", tier: "XV", minXp: 10600, color: "#e040fb", glow: "rgba(224,64,251,0.55)" },
  { id: "legend", name: "Legend", tier: "XVI", minXp: 13000, color: "#cdf83f", glow: "rgba(205,248,63,0.55)" },
];

export interface RankState {
  rank: Rank;
  next: Rank | null;
  xp: number;
  intoRank: number;
  rankSpan: number;
  progress: number; // 0..1 toward next rank
  xpToNext: number;
}

export function rankFor(xp: number): RankState {
  let idx = 0;
  for (let i = 0; i < RANKS.length; i++) if (xp >= RANKS[i].minXp) idx = i;
  const rank = RANKS[idx];
  const next = RANKS[idx + 1] ?? null;
  const intoRank = xp - rank.minXp;
  const rankSpan = next ? next.minXp - rank.minXp : 1;
  return {
    rank,
    next,
    xp,
    intoRank,
    rankSpan,
    progress: next ? Math.min(1, intoRank / rankSpan) : 1,
    xpToNext: next ? Math.max(0, next.minXp - xp) : 0,
  };
}

/* -------------------------------- XP ---------------------------------- */

export interface XpBreakdown {
  total: number;
  fromWorkouts: number;
  fromSets: number;
  fromVolume: number;
  fromNutrition: number;
  fromHabits: number;
  fromSkills: number;
  fromAchievements: number;
}

export interface StatsInput {
  logs: WorkoutLog[];
  meals: MealEntry[];
  weights: WeightEntry[];
  measurements: MeasureEntry[];
  water: Record<string, number>;
  /** vessel + goal so "full hydration day" means the user's own target */
  hydration?: { vesselMl: number; goalMl: number };
  /** recovery check-ins, used by the wellbeing achievements */
  checkins?: { sleepHours: number; steps: number }[];
  /** skillId -> completed stage ids */
  skillProgress?: Record<string, string[]>;
}

/** Days where the user hit their own hydration goal. */
export function fullWaterDays(s: StatsInput): number {
  const vesselMl = s.hydration?.vesselMl ?? 250;
  const goalMl = s.hydration?.goalMl ?? 2000;
  const need = vesselMl > 0 ? Math.max(1, Math.ceil(goalMl / vesselMl)) : 8;
  return Object.values(s.water).filter((n) => n >= need).length;
}

/** Total skill stages completed across all skill trees. */
export function stagesCompleted(s: StatsInput): number {
  return Object.values(s.skillProgress ?? {}).reduce((a, v) => a + v.length, 0);
}

/** Skills where every stage is done (all trees have 5 stages). */
export function skillsMastered(s: StatsInput): number {
  return Object.values(s.skillProgress ?? {}).filter((v) => v.length >= 5).length;
}

/**
 * XP is fully derived from your logged history — no hidden counters, so it
 * stays correct across devices and restores perfectly from cloud backup.
 */
export function computeXp(s: StatsInput, unlockedPoints: number): XpBreakdown {
  const fromWorkouts = s.logs.length * 50;
  const fromSets = s.logs.reduce((a, l) => a + l.setsDone, 0) * 2;
  const fromVolume = Math.round(s.logs.reduce((a, l) => a + (l.volumeKg ?? 0), 0) / 100);

  const loggedDays = new Set(s.meals.map((m) => m.date)).size;
  const fromNutrition = loggedDays * 15;

  const weighIns = s.weights.length * 10;
  const measures = s.measurements.length * 15;
  const hydrated = fullWaterDays(s) * 10;
  const fromHabits = weighIns + measures + hydrated;

  const fromSkills = stagesCompleted(s) * 75 + skillsMastered(s) * 150;

  const total =
    fromWorkouts + fromSets + fromVolume + fromNutrition + fromHabits + fromSkills + unlockedPoints;
  return {
    total,
    fromWorkouts,
    fromSets,
    fromVolume,
    fromNutrition,
    fromHabits,
    fromSkills,
    fromAchievements: unlockedPoints,
  };
}

/* ---------------------------- Achievements ----------------------------- */

export type AchCategory =
  | "Training"
  | "Consistency"
  | "Strength"
  | "Nutrition"
  | "Body"
  | "Skills";

export interface AchievementDef {
  id: string;
  name: string;
  desc: string;
  icon: string;
  category: AchCategory;
  points: number;
  /** current progress value and the target to hit */
  progress: (s: StatsInput) => { value: number; target: number };
}

const count = (value: number, target: number) => ({ value, target });

export const ACHIEVEMENTS: AchievementDef[] = [
  /* Training */
  {
    id: "first-blood",
    name: "First Blood",
    desc: "Complete your very first workout",
    icon: "🔥",
    category: "Training",
    points: 50,
    progress: (s) => count(s.logs.length, 1),
  },
  {
    id: "ten-sessions",
    name: "Getting Serious",
    desc: "Log 10 workouts",
    icon: "💪",
    category: "Training",
    points: 100,
    progress: (s) => count(s.logs.length, 10),
  },
  {
    id: "fifty-sessions",
    name: "Iron Habit",
    desc: "Log 50 workouts",
    icon: "⚒️",
    category: "Training",
    points: 300,
    progress: (s) => count(s.logs.length, 50),
  },
  {
    id: "century",
    name: "Century Club",
    desc: "Log 100 workouts",
    icon: "💯",
    category: "Training",
    points: 600,
    progress: (s) => count(s.logs.length, 100),
  },
  {
    id: "thousand-sets",
    name: "Set Machine",
    desc: "Complete 1,000 total sets",
    icon: "🎯",
    category: "Training",
    points: 300,
    progress: (s) => count(s.logs.reduce((a, l) => a + l.setsDone, 0), 1000),
  },
  {
    id: "marathon-session",
    name: "The Long Haul",
    desc: "Finish a session of 60+ minutes",
    icon: "⏱️",
    category: "Training",
    points: 120,
    progress: (s) => count(Math.max(0, ...s.logs.map((l) => l.minutes)), 60),
  },
  {
    id: "calorie-torch",
    name: "Furnace",
    desc: "Burn 10,000 lifetime kcal in workouts",
    icon: "🔋",
    category: "Training",
    points: 250,
    progress: (s) => count(s.logs.reduce((a, l) => a + l.kcal, 0), 10000),
  },
  {
    id: "early-bird",
    name: "Dawn Patrol",
    desc: "Train on 5 different weekends",
    icon: "🌅",
    category: "Training",
    points: 120,
    progress: (s) => {
      const weekends = new Set(
        s.logs
          .filter((l) => {
            const d = new Date(l.date + "T00:00").getDay();
            return d === 0 || d === 6;
          })
          .map((l) => l.date)
      );
      return count(weekends.size, 5);
    },
  },

  /* Consistency */
  {
    id: "streak-3",
    name: "Momentum",
    desc: "Hit a 3-day training streak",
    icon: "⚡",
    category: "Consistency",
    points: 60,
    progress: (s) => count(bestStreak(s.logs), 3),
  },
  {
    id: "streak-7",
    name: "Unbroken",
    desc: "Hit a 7-day training streak",
    icon: "🗓️",
    category: "Consistency",
    points: 150,
    progress: (s) => count(bestStreak(s.logs), 7),
  },
  {
    id: "streak-30",
    name: "Relentless",
    desc: "Hit a 30-day training streak",
    icon: "👑",
    category: "Consistency",
    points: 600,
    progress: (s) => count(bestStreak(s.logs), 30),
  },
  {
    id: "perfect-week",
    name: "Perfect Week",
    desc: "Train 5+ days within one calendar week",
    icon: "🏅",
    category: "Consistency",
    points: 200,
    progress: (s) => count(bestWeekCount(s.logs), 5),
  },
  {
    id: "comeback",
    name: "The Comeback",
    desc: "Train again after a 7+ day break",
    icon: "🔄",
    category: "Consistency",
    points: 100,
    progress: (s) => count(hasComeback(s.logs) ? 1 : 0, 1),
  },

  /* Strength */
  {
    id: "first-pr",
    name: "Personal Best",
    desc: "Record your first weighted PR",
    icon: "🏆",
    category: "Strength",
    points: 80,
    progress: (s) => count(personalRecords(s.logs, 50).length, 1),
  },
  {
    id: "five-prs",
    name: "Record Breaker",
    desc: "Hold PRs in 5 different lifts",
    icon: "📈",
    category: "Strength",
    points: 200,
    progress: (s) => count(personalRecords(s.logs, 50).length, 5),
  },
  {
    id: "tonne",
    name: "One Tonne",
    desc: "Lift 1,000 kg of total volume",
    icon: "🪨",
    category: "Strength",
    points: 150,
    progress: (s) => count(Math.round(s.logs.reduce((a, l) => a + (l.volumeKg ?? 0), 0)), 1000),
  },
  {
    id: "ten-tonne",
    name: "Ten Tonne Titan",
    desc: "Lift 10,000 kg of total volume",
    icon: "🏔️",
    category: "Strength",
    points: 400,
    progress: (s) => count(Math.round(s.logs.reduce((a, l) => a + (l.volumeKg ?? 0), 0)), 10000),
  },
  {
    id: "bodyweight-bench",
    name: "Plate Pusher",
    desc: "Hit an estimated 1RM of 60 kg or more",
    icon: "🥇",
    category: "Strength",
    points: 250,
    progress: (s) => {
      const best = personalRecords(s.logs, 50);
      return count(Math.round(Math.max(0, ...best.map((b) => b.est1rm))), 60);
    },
  },

  /* Nutrition */
  {
    id: "first-meal",
    name: "Fuel Logged",
    desc: "Log your first meal",
    icon: "🍽️",
    category: "Nutrition",
    points: 40,
    progress: (s) => count(s.meals.length, 1),
  },
  {
    id: "meal-days-7",
    name: "Tracking Week",
    desc: "Log food on 7 different days",
    icon: "📒",
    category: "Nutrition",
    points: 120,
    progress: (s) => count(new Set(s.meals.map((m) => m.date)).size, 7),
  },
  {
    id: "meal-days-30",
    name: "Macro Monk",
    desc: "Log food on 30 different days",
    icon: "🧘",
    category: "Nutrition",
    points: 350,
    progress: (s) => count(new Set(s.meals.map((m) => m.date)).size, 30),
  },
  {
    id: "hydrated",
    name: "Hydro Homie",
    desc: "Hit your full water goal on 10 days",
    icon: "💧",
    category: "Nutrition",
    points: 150,
    progress: (s) => count(fullWaterDays(s), 10),
  },
  {
    id: "variety",
    name: "Thali Explorer",
    desc: "Log 40 different foods",
    icon: "🍛",
    category: "Nutrition",
    points: 200,
    progress: (s) => count(new Set(s.meals.map((m) => m.foodId)).size, 40),
  },

  /* Body */
  {
    id: "first-weigh",
    name: "Baseline Set",
    desc: "Log your weight for the first time",
    icon: "⚖️",
    category: "Body",
    points: 40,
    progress: (s) => count(s.weights.length, 1),
  },
  {
    id: "weigh-20",
    name: "Data Driven",
    desc: "Record 20 weigh-ins",
    icon: "📊",
    category: "Body",
    points: 180,
    progress: (s) => count(s.weights.length, 20),
  },
  {
    id: "measured",
    name: "Tape Measure",
    desc: "Log body measurements 5 times",
    icon: "📏",
    category: "Body",
    points: 150,
    progress: (s) => count(s.measurements.length, 5),
  },
  /* Recovery */
  {
    id: "first-checkin",
    name: "Self Aware",
    desc: "Log your first daily check-in",
    icon: "🫀",
    category: "Body",
    points: 40,
    progress: (s) => count(s.checkins?.length ?? 0, 1),
  },
  {
    id: "checkin-14",
    name: "Tuned In",
    desc: "Complete 14 recovery check-ins",
    icon: "📡",
    category: "Body",
    points: 200,
    progress: (s) => count(s.checkins?.length ?? 0, 14),
  },
  {
    id: "well-slept",
    name: "Well Rested",
    desc: "Sleep 8+ hours on 10 logged days",
    icon: "😴",
    category: "Body",
    points: 180,
    progress: (s) => count((s.checkins ?? []).filter((c) => c.sleepHours >= 8).length, 10),
  },
  {
    id: "step-master",
    name: "Step Master",
    desc: "Hit 10,000 steps on 10 days",
    icon: "🚶",
    category: "Body",
    points: 220,
    progress: (s) => count((s.checkins ?? []).filter((c) => c.steps >= 10000).length, 10),
  },

  /* More training */
  {
    id: "two-fifty",
    name: "Quarter Thousand",
    desc: "Log 250 workouts",
    icon: "🏛️",
    category: "Training",
    points: 1200,
    progress: (s) => count(s.logs.length, 250),
  },
  {
    id: "five-thousand-sets",
    name: "Set Legend",
    desc: "Complete 5,000 total sets",
    icon: "♾️",
    category: "Training",
    points: 800,
    progress: (s) => count(s.logs.reduce((a, l) => a + l.setsDone, 0), 5000),
  },
  {
    id: "ten-hours",
    name: "Ten Hour Club",
    desc: "Train for 600 total minutes",
    icon: "⌛",
    category: "Training",
    points: 180,
    progress: (s) => count(s.logs.reduce((a, l) => a + l.minutes, 0), 600),
  },
  {
    id: "hundred-hours",
    name: "Hundred Hours",
    desc: "Train for 6,000 total minutes",
    icon: "🕰️",
    category: "Training",
    points: 700,
    progress: (s) => count(s.logs.reduce((a, l) => a + l.minutes, 0), 6000),
  },
  {
    id: "variety-king",
    name: "Jack of All Lifts",
    desc: "Perform 40 different exercises",
    icon: "🎪",
    category: "Training",
    points: 300,
    progress: (s) => {
      const ids = new Set<string>();
      for (const l of s.logs) for (const d of l.detail ?? []) ids.add(d.exerciseId);
      return count(ids.size, 40);
    },
  },
  {
    id: "double-day",
    name: "Two-a-Day",
    desc: "Log two sessions on the same day",
    icon: "🌗",
    category: "Training",
    points: 150,
    progress: (s) => {
      const byDay = new Map<string, number>();
      for (const l of s.logs) byDay.set(l.date, (byDay.get(l.date) ?? 0) + 1);
      return count(Math.max(0, ...byDay.values()) >= 2 ? 1 : 0, 1);
    },
  },

  /* More strength */
  {
    id: "fifty-tonne",
    name: "Fifty Tonne",
    desc: "Lift 50,000 kg of total volume",
    icon: "🌋",
    category: "Strength",
    points: 900,
    progress: (s) => count(Math.round(s.logs.reduce((a, l) => a + (l.volumeKg ?? 0), 0)), 50000),
  },
  {
    id: "ten-prs",
    name: "Record Collector",
    desc: "Hold PRs in 10 different lifts",
    icon: "🗄️",
    category: "Strength",
    points: 400,
    progress: (s) => count(personalRecords(s.logs, 50).length, 10),
  },
  {
    id: "heavy-single",
    name: "Triple Digits",
    desc: "Reach an estimated 1RM of 100 kg",
    icon: "💥",
    category: "Strength",
    points: 500,
    progress: (s) => {
      const best = personalRecords(s.logs, 50);
      return count(Math.round(Math.max(0, ...best.map((b) => b.est1rm))), 100);
    },
  },

  /* More nutrition */
  {
    id: "meal-days-100",
    name: "Century of Logs",
    desc: "Log food on 100 different days",
    icon: "📔",
    category: "Nutrition",
    points: 800,
    progress: (s) => count(new Set(s.meals.map((m) => m.date)).size, 100),
  },
  {
    id: "protein-hit",
    name: "Protein Precision",
    desc: "Log 500 individual food items",
    icon: "🥩",
    category: "Nutrition",
    points: 300,
    progress: (s) => count(s.meals.length, 500),
  },
  {
    id: "food-explorer-100",
    name: "Culinary Explorer",
    desc: "Try 100 different foods",
    icon: "🌏",
    category: "Nutrition",
    points: 450,
    progress: (s) => count(new Set(s.meals.map((m) => m.foodId)).size, 100),
  },

  /* Skills */
  {
    id: "skill-start",
    name: "Apprentice",
    desc: "Complete your first skill stage",
    icon: "🎓",
    category: "Skills",
    points: 80,
    progress: (s) => count(stagesCompleted(s), 1),
  },
  {
    id: "skill-five",
    name: "Student of the Game",
    desc: "Complete 5 skill stages",
    icon: "📚",
    category: "Skills",
    points: 200,
    progress: (s) => count(stagesCompleted(s), 5),
  },
  {
    id: "skill-master",
    name: "Skill Mastered",
    desc: "Finish every stage of one skill tree",
    icon: "🥋",
    category: "Skills",
    points: 500,
    progress: (s) => count(skillsMastered(s), 1),
  },
  {
    id: "skill-polymath",
    name: "Polymath",
    desc: "Master 3 different skills",
    icon: "🧠",
    category: "Skills",
    points: 900,
    progress: (s) => count(skillsMastered(s), 3),
  },
  {
    id: "transform",
    name: "Transformation",
    desc: "Shift your weight by 3 kg in either direction",
    icon: "✨",
    category: "Body",
    points: 300,
    progress: (s) => {
      if (s.weights.length < 2) return count(0, 3);
      const kgs = s.weights.map((w) => w.kg);
      const swing = Math.max(...kgs) - Math.min(...kgs);
      return count(Math.round(swing * 10) / 10, 3);
    },
  },
];

/* ----------------------------- Helpers -------------------------------- */

function bestStreak(logs: WorkoutLog[]): number {
  const days = [...new Set(logs.map((l) => l.date))].sort();
  if (!days.length) return 0;
  let best = 1;
  let run = 1;
  for (let i = 1; i < days.length; i++) {
    const prev = new Date(days[i - 1] + "T00:00");
    const cur = new Date(days[i] + "T00:00");
    const diff = Math.round((cur.getTime() - prev.getTime()) / 86400000);
    run = diff === 1 ? run + 1 : 1;
    best = Math.max(best, run);
  }
  return Math.max(best, streakOf(logs.map((l) => l.date)));
}

function bestWeekCount(logs: WorkoutLog[]): number {
  const buckets = new Map<string, Set<string>>();
  for (const l of logs) {
    const d = new Date(l.date + "T00:00");
    const monday = new Date(d);
    monday.setDate(d.getDate() - ((d.getDay() + 6) % 7));
    const key = dateKey(monday);
    const set = buckets.get(key) ?? new Set<string>();
    set.add(l.date);
    buckets.set(key, set);
  }
  return Math.max(0, ...[...buckets.values()].map((s) => s.size));
}

function hasComeback(logs: WorkoutLog[]): boolean {
  const days = [...new Set(logs.map((l) => l.date))].sort();
  for (let i = 1; i < days.length; i++) {
    const prev = new Date(days[i - 1] + "T00:00");
    const cur = new Date(days[i] + "T00:00");
    if (Math.round((cur.getTime() - prev.getTime()) / 86400000) >= 8) return true;
  }
  return false;
}

/* --------------------------- Evaluation -------------------------------- */

export interface EvaluatedAchievement extends AchievementDef {
  value: number;
  target: number;
  unlocked: boolean;
  pct: number;
}

export function evaluateAchievements(s: StatsInput): EvaluatedAchievement[] {
  return ACHIEVEMENTS.map((a) => {
    const { value, target } = a.progress(s);
    const unlocked = value >= target;
    return { ...a, value, target, unlocked, pct: Math.min(1, target ? value / target : 0) };
  });
}

export interface ProgressSummary {
  achievements: EvaluatedAchievement[];
  unlocked: EvaluatedAchievement[];
  xp: XpBreakdown;
  rank: RankState;
  nextUp: EvaluatedAchievement[];
}

export function summarize(s: StatsInput): ProgressSummary {
  const achievements = evaluateAchievements(s);
  const unlocked = achievements.filter((a) => a.unlocked);
  const points = unlocked.reduce((sum, a) => sum + a.points, 0);
  const xp = computeXp(s, points);
  const nextUp = achievements
    .filter((a) => !a.unlocked)
    .sort((a, b) => b.pct - a.pct)
    .slice(0, 3);
  return { achievements, unlocked, xp, rank: rankFor(xp.total), nextUp };
}
