/* --------------------------- Plans & pricing --------------------------- */

export type Tier = "free" | "trial" | "pro";
export type PlanId = "monthly" | "annual" | "lifetime";

export interface Plan {
  id: PlanId;
  name: string;
  /** price in paise/cents — integer money, never floats */
  amount: number;
  currency: string;
  /** display helpers */
  priceLabel: string;
  periodLabel: string;
  subLabel?: string;
  badge?: string;
  /** days of access; null = forever */
  durationDays: number | null;
  best?: boolean;
}

export const CURRENCY = "INR";

/** Monetization is intentionally paused while the base app is expanded. */
export const PAYWALL_ENABLED = false;

export const PLANS: Plan[] = [
  {
    id: "monthly",
    name: "Monthly",
    amount: 19900, // ₹199.00
    currency: CURRENCY,
    priceLabel: "₹199",
    periodLabel: "/month",
    subLabel: "Cancel anytime",
    durationDays: 31,
  },
  {
    id: "annual",
    name: "Annual",
    amount: 149900, // ₹1,499.00
    currency: CURRENCY,
    priceLabel: "₹1,499",
    periodLabel: "/year",
    subLabel: "₹125/month — save 37%",
    badge: "Most popular",
    durationDays: 366,
    best: true,
  },
  {
    id: "lifetime",
    name: "Lifetime",
    amount: 349900, // ₹3,499.00
    currency: CURRENCY,
    priceLabel: "₹3,499",
    periodLabel: "once",
    subLabel: "Pay once, keep forever",
    durationDays: null,
  },
];

export const TRIAL_DAYS = 7;

/* ----------------------------- Entitlement ----------------------------- */

export interface Entitlement {
  tier: Tier;
  plan: PlanId | "trial" | "code" | null;
  /** ISO string or null for lifetime */
  expiresAt: string | null;
  trialEndsAt: string | null;
  /** last time the server confirmed this */
  verifiedAt: string | null;
  provider?: string | null;
}

export const FREE_ENTITLEMENT: Entitlement = {
  tier: "free",
  plan: null,
  expiresAt: null,
  trialEndsAt: null,
  verifiedAt: null,
};

/** Grace period so a lapsed card or offline stretch doesn't lock you out mid-session. */
export const OFFLINE_GRACE_DAYS = 14;

export interface AccessState {
  isPro: boolean;
  tier: Tier;
  /** true while the free trial is running */
  inTrial: boolean;
  daysLeft: number | null;
  expired: boolean;
  /** cached entitlement is old but we allow access during grace */
  inGrace: boolean;
  label: string;
}

function daysBetween(from: Date, to: Date): number {
  return Math.ceil((to.getTime() - from.getTime()) / 86400000);
}

/**
 * Resolves what the user can actually do right now. Pure function of the
 * cached entitlement + current time, so it works fully offline.
 */
export function resolveAccess(e: Entitlement | null | undefined, now = new Date()): AccessState {
  const ent = e ?? FREE_ENTITLEMENT;

  // Lifetime
  if (ent.tier === "pro" && ent.expiresAt === null && ent.plan) {
    return {
      isPro: true,
      tier: "pro",
      inTrial: false,
      daysLeft: null,
      expired: false,
      inGrace: false,
      label: ent.plan === "code" ? "Lifetime · licence" : "Lifetime",
    };
  }

  // Paid, time-limited
  if (ent.tier === "pro" && ent.expiresAt) {
    const exp = new Date(ent.expiresAt);
    if (exp > now) {
      return {
        isPro: true,
        tier: "pro",
        inTrial: false,
        daysLeft: daysBetween(now, exp),
        expired: false,
        inGrace: false,
        label: `Pro · ${daysBetween(now, exp)} days left`,
      };
    }
    // Expired — allow a short offline grace window
    const graceEnd = new Date(exp.getTime() + OFFLINE_GRACE_DAYS * 86400000);
    if (graceEnd > now) {
      return {
        isPro: true,
        tier: "pro",
        inTrial: false,
        daysLeft: daysBetween(now, graceEnd),
        expired: true,
        inGrace: true,
        label: "Renew to keep Pro",
      };
    }
    return {
      isPro: false,
      tier: "free",
      inTrial: false,
      daysLeft: 0,
      expired: true,
      inGrace: false,
      label: "Pro expired",
    };
  }

  // Trial
  if (ent.trialEndsAt) {
    const end = new Date(ent.trialEndsAt);
    if (end > now) {
      const d = daysBetween(now, end);
      return {
        isPro: true,
        tier: "trial",
        inTrial: true,
        daysLeft: d,
        expired: false,
        inGrace: false,
        label: d === 1 ? "Trial · last day" : `Trial · ${d} days left`,
      };
    }
    return {
      isPro: false,
      tier: "free",
      inTrial: false,
      daysLeft: 0,
      expired: true,
      inGrace: false,
      label: "Trial ended",
    };
  }

  return {
    isPro: false,
    tier: "free",
    inTrial: false,
    daysLeft: null,
    expired: false,
    inGrace: false,
    label: "Free",
  };
}

/* ---------------------------- Feature gating --------------------------- */

export type ProFeature =
  | "splits"
  | "unlimitedRoutines"
  | "fullFoodDb"
  | "customFoods"
  | "standards"
  | "skills"
  | "photos"
  | "measurements"
  | "export"
  | "cloudSync"
  | "shareCard";

export const FREE_LIMITS = {
  /** routines you can save on the free tier */
  routines: 2,
  /** generated workouts per calendar day */
  generationsPerDay: 3,
  /** foods available before the full database unlocks */
  foodItems: 120,
  /** days of history visible in charts */
  historyDays: 14,
} as const;

export const FEATURE_COPY: Record<ProFeature, { title: string; blurb: string }> = {
  splits: {
    title: "Weekly split templates",
    blurb: "Fill your whole week in one tap with PPL, Upper/Lower and more.",
  },
  unlimitedRoutines: {
    title: "Unlimited routines",
    blurb: `Free saves ${FREE_LIMITS.routines} routines. Go Pro for as many as you like.`,
  },
  fullFoodDb: {
    title: "Full Indian food database",
    blurb: "All 736 dishes — regional curries, combos, street food and sweets.",
  },
  customFoods: {
    title: "Custom foods",
    blurb: "Save your own recipes with exact macros and reuse them any day.",
  },
  standards: {
    title: "Strength standards & ranks",
    blurb: "Rate every lift against bodyweight, track PRs and climb the ladder.",
  },
  skills: {
    title: "Skill roadmaps",
    blurb: "Boxing, handstand, pull-ups, levers — staged plans with drills.",
  },
  photos: {
    title: "Progress photos",
    blurb: "Private on-device check-ins with before/after comparison.",
  },
  measurements: {
    title: "Body measurements",
    blurb: "Waist, chest, arms and body-fat estimates with trend charts.",
  },
  export: {
    title: "Data export",
    blurb: "Download your full training and nutrition history as JSON.",
  },
  cloudSync: {
    title: "Cloud backup",
    blurb: "Restore everything on a new phone without losing a single day.",
  },
  shareCard: {
    title: "Share cards",
    blurb: "Generate workout summary images for WhatsApp and Instagram.",
  },
};

export const PRO_HIGHLIGHTS: string[] = [
  "Unlimited routines & weekly split templates",
  "All 736 Indian foods + your own custom recipes",
  "Strength standards, ranks & personal records",
  "8 skill roadmaps — boxing, handstand, levers",
  "Progress photos, measurements & body-fat tracking",
  "Cloud backup, data export and share cards",
];

/* --------------------------- Account identity -------------------------- */

/** Stable per-install id used as the entitlement key. */
export function newAccountId(): string {
  const rand =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID().replace(/-/g, "").slice(0, 16)
      : Math.random().toString(36).slice(2) + Date.now().toString(36);
  return `fg_${rand}`;
}

/** Normalises user-typed codes: "forge-abc 123" -> "FORGEABC123" */
export function normaliseCode(input: string): string {
  return input.toUpperCase().replace(/[^A-Z0-9]/g, "");
}
