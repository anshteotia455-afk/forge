"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { authHeaders, deviceId } from "./auth";
import { Entitlement, FREE_ENTITLEMENT, newAccountId } from "./billing";
import { EquipmentId, Exercise, EXERCISES, Food, MealType } from "./data";
import type { DailyCheckin } from "./recovery";
import type { BodyType, TrainingGap } from "./readiness-profile";
import type { UnitSystem } from "./units";
import {
  bwFactorOf,
  DEFAULT_HYDRATION,
  dateKey,
  effectiveLoad,
  estimateKcal,
  estimateMinutes,
  ExResult,
  GenItem,
  Goal,
  Hydration,
  isLoadable,
  lastPerformance,
  loadModeOf,
  personalRecords,
  PlannedItem,
  setLoad,
  Sex,
  totalSets,
  uid,
} from "./engine";

/* ------------------------------- Models ------------------------------ */

export interface Profile {
  name: string;
  age: number;
  sex: Sex;
  heightCm: number;
  weightKg: number;
  activity: number;
  goal: Goal;
  onboarded: boolean;
  /** target weight for lose/gain — drives the goal projection */
  goalWeightKg?: number;
  /** how long since their last workout when they set up */
  lastWorkoutGap?: TrainingGap;
  /** date the comeback plan started, so the ramp can progress */
  trainingStartedAt?: string;
  /** somatotype tendency used to tune programming and macros */
  bodyType?: BodyType;
}

export interface Routine {
  id: string;
  name: string;
  items: PlannedItem[];
  createdAt: string;
}

export interface MealEntry {
  id: string;
  date: string; // yyyy-mm-dd
  meal: MealType;
  foodId: string;
  name: string;
  serving: string;
  qty: number;
  cal: number;
  p: number;
  c: number;
  f: number;
}

/** A saved combo of foods reusable with one tap. */
export interface TemplateItem {
  foodId: string;
  name: string;
  serving: string;
  qty: number;
  cal: number;
  p: number;
  c: number;
  f: number;
}

export interface MealTemplate {
  id: string;
  name: string;
  sourceMeal: MealType;
  items: TemplateItem[];
}

/** A rank promotion awaiting the celebration overlay. */
export interface RankUp {
  name: string;
  tier: string;
  color: string;
  xp: number;
}

export type ChallengeMetric =
  | "workouts"
  | "minutes"
  | "sets"
  | "water-days"
  | "protein-days";

export interface Challenge {
  id: string;
  name: string;
  metric: ChallengeMetric;
  target: number;
  /** dateKey the challenge starts */
  start: string;
  /** length in days (7 / 30 / 90) */
  days: number;
}

/** A record broken in the most recent session, shown once as a celebration. */
export interface PrHit {
  exerciseId: string;
  name: string;
  kg: number;
  reps: number;
  est1rm: number;
  added?: boolean;
}

export interface WorkoutLog {
  id: string;
  date: string;
  name: string;
  setsDone: number;
  totalSets: number;
  exercises: number;
  minutes: number;
  kcal: number;
  volumeKg: number;
  /** rate of perceived exertion, 1–10 (optional) */
  rpe?: number;
  detail: ExResult[];
}

export interface WeightEntry {
  id: string;
  date: string;
  kg: number;
}

export interface MeasureEntry {
  id: string;
  date: string;
  waist?: number;
  chest?: number;
  arm?: number;
  thigh?: number;
  neck?: number;
  hip?: number;
}

export interface ReminderPref {
  enabled: boolean;
  time: string; // "HH:MM"
  soundId?: "forge" | "pulse" | "gentle" | "custom";
  soundName?: string;
  vibrate?: boolean;
  snoozeMinutes?: number;
}

/** What you actually own — powers the plate calculator and load suggestions. */
export interface Loadout {
  barKg: number;
  ezBarKg: number;
  /** plate size (kg) -> total number owned */
  plates: Record<string, number>;
  dumbbellKg: number[];
  kettlebellKg: number[];
}

export const DEFAULT_LOADOUT: Loadout = {
  barKg: 20,
  ezBarKg: 7.5,
  plates: { "25": 0, "20": 2, "15": 0, "10": 4, "5": 4, "2.5": 4, "1.25": 2 },
  dumbbellKg: [5, 10, 15],
  kettlebellKg: [12],
};

export interface ActiveItem {
  exerciseId: string;
  name: string;
  cue: string;
  met: number;
  uni: boolean;
  loadable: boolean;
  /** "added" = extra weight on top of bodyweight */
  loadMode: "external" | "added";
  bwFactor: number;
  muscles: string[];
  sets: number;
  reps: number | null;
  sec: number | null;
  rest: number;
  done: boolean[];
  kg: number[];
  group?: number;
}

export interface ActiveWorkout {
  name: string;
  startedAt: number;
  items: ActiveItem[];
}

/** Everything that travels to the cloud. */
export interface Snapshot {
  profile: Profile | null;
  equipment: EquipmentId[];
  routines: Routine[];
  schedule: Record<string, string>; // dateKey -> routineId | "rest"
  meals: MealEntry[];
  customFoods: Food[];
  logs: WorkoutLog[];
  water: Record<string, number>;
  /** vessel size + daily goal, so counts map to real millilitres */
  hydration: Hydration;
  weights: WeightEntry[];
  measurements: MeasureEntry[];
  customExercises: Exercise[];
  reminder: ReminderPref;
  loadout: Loadout;
  /** meal combos reusable with one tap */
  templates: MealTemplate[];
  /** kg/cm vs lb/in display preference */
  unitSystem: UnitSystem;
  /** freshly broken records awaiting the celebration overlay */
  pendingPRs: PrHit[];
  /** last celebrated rank id — drives rank-up detection */
  lastRankId: string | null;
  /** promotion awaiting the celebration overlay */
  pendingRankUp: RankUp | null;
  /** self-set goals with progress bars */
  challenges: Challenge[];
  /** optional PIN gate shown at launch */
  appLock: { enabled: boolean; pinHash: string };
  /** UI language */
  lang: "en" | "hi";
  /** skillId -> completed stage ids */
  skillProgress: Record<string, string[]>;
  /** skills pinned to the dashboard */
  activeSkills: string[];
  /** stable id this install's entitlement is keyed to */
  accountId: string;
  /** cached subscription so gating works offline */
  entitlement: Entitlement;
  /** generator uses per day, retained for backwards compatibility */
  genUsage: Record<string, number>;
  /** sleep, energy, soreness, stress and activity check-ins */
  checkins: DailyCheckin[];
  updatedAt: string;
}

export type SyncStatus = "idle" | "syncing" | "synced" | "offline" | "error";

interface Store extends Snapshot {
  activeWorkout: ActiveWorkout | null;
  lastSyncedAt: string | null;
  syncStatus: SyncStatus;
  /** in-memory only — always false after a restart */
  appUnlocked: boolean;

  setProfile: (p: Profile) => void;
  toggleEquipment: (id: EquipmentId) => void;

  upsertRoutine: (r: Routine) => void;
  deleteRoutine: (id: string) => void;
  assignDay: (dayKey: string, value: string | null) => void;

  addMeal: (m: Omit<MealEntry, "id">) => void;
  removeMeal: (id: string) => void;
  addCustomFood: (f: Omit<Food, "id" | "custom">) => Food;
  saveTemplate: (t: Omit<MealTemplate, "id">) => void;
  deleteTemplate: (id: string) => void;

  setWater: (dayKey: string, count: number) => void;
  setHydration: (patch: Partial<Hydration>) => void;

  logWeight: (dayKey: string, kg: number) => void;
  removeWeight: (id: string) => void;

  logMeasurement: (m: Omit<MeasureEntry, "id">) => void;
  removeMeasurement: (id: string) => void;
  addCustomExercise: (e: Omit<Exercise, "id" | "custom">) => Exercise;
  removeCustomExercise: (id: string) => void;
  setReminder: (pref: Partial<ReminderPref>) => void;
  setLoadout: (patch: Partial<Loadout>) => void;
  setUnitSystem: (sys: UnitSystem) => void;
  toggleStage: (skillId: string, stageId: string) => void;
  toggleSkillActive: (skillId: string) => void;
  setEntitlement: (e: Entitlement) => void;
  ensureAccountId: () => string;
  noteGeneration: () => void;
  upsertCheckin: (entry: Omit<DailyCheckin, "id"> & { id?: string }) => void;
  removeCheckin: (id: string) => void;
  /** Correct a mistyped set anywhere in history — ratings recompute instantly. */
  editLoggedSet: (
    logId: string,
    exerciseId: string,
    setIdx: number,
    patch: { kg?: number | null; reps?: number | null; sec?: number | null }
  ) => void;
  /** Remove one bad set (e.g. a fat-fingered 200 kg). */
  deleteLoggedSet: (logId: string, exerciseId: string, setIdx: number) => void;
  /** Wipe every recorded set of one exercise across all history. */
  clearExerciseHistory: (exerciseId: string) => void;
  clearPendingPRs: () => void;
  setLastRankId: (id: string | null) => void;
  setPendingRankUp: (r: RankUp | null) => void;
  addChallenge: (c: Omit<Challenge, "id">) => void;
  removeChallenge: (id: string) => void;
  setAppLock: (lock: { enabled: boolean; pinHash: string }) => void;
  setLang: (l: "en" | "hi") => void;
  setAppUnlocked: (v: boolean) => void;
  /** Restores a full backup from an exported JSON file. */
  importSnapshot: (data: unknown) => { ok: boolean; error?: string };

  quickLogLift: (input: {
    exerciseId: string;
    name: string;
    sets: {
      kg: number | null;
      reps: number | null;
      sec: number | null;
      mode?: "external" | "added";
      bwf?: number;
    }[];
    dayKey?: string;
    bodyweightKg?: number;
  }) => void;

  startWorkout: (name: string, items: PlannedItem[]) => void;
  startGenerated: (name: string, items: GenItem[]) => void;
  toggleSet: (exIdx: number, setIdx: number) => void;
  setSetDone: (exIdx: number, setIdx: number, done: boolean) => void;
  setSetKg: (exIdx: number, setIdx: number, kg: number) => void;
  finishWorkout: (weightKg: number, rpe?: number) => void;
  cancelWorkout: () => void;

  applySnapshot: (snap: Snapshot) => void;
  snapshot: () => Snapshot;
  setSyncStatus: (s: SyncStatus) => void;
  markSynced: (at: string) => void;
  resetAll: () => void;
}

const touch = () => new Date().toISOString();

const emptyData: Snapshot = {
  profile: null,
  equipment: ["bodyweight", "mat"],
  routines: [],
  schedule: {},
  meals: [],
  customFoods: [],
  logs: [],
  water: {},
  hydration: DEFAULT_HYDRATION,
  weights: [],
  measurements: [],
  customExercises: [],
  reminder: {
    enabled: false,
    time: "07:00",
    soundId: "forge",
    soundName: "Forge Bell",
    vibrate: true,
    snoozeMinutes: 10,
  },
  loadout: DEFAULT_LOADOUT,
  templates: [],
  unitSystem: "metric",
  pendingPRs: [],
  lastRankId: null,
  pendingRankUp: null,
  challenges: [],
  appLock: { enabled: false, pinHash: "" },
  lang: "en",
  skillProgress: {},
  activeSkills: [],
  accountId: "",
  entitlement: FREE_ENTITLEMENT,
  genUsage: {},
  checkins: [],
  updatedAt: touch(),
};

/**
 * Recomputes a session's totals from its detail after an edit or deletion,
 * so volume, set counts and every derived rating stay truthful.
 */
function recalcLog(log: WorkoutLog): WorkoutLog {
  const detail = log.detail ?? [];
  const allSets = detail.flatMap((d) => d.sets);
  const done = allSets.filter((s) => s.done);
  const volumeKg = Math.round(
    done.reduce((a, s) => a + (s.reps ? setLoad(s) * s.reps : 0), 0)
  );
  return {
    ...log,
    detail,
    exercises: detail.length,
    setsDone: done.length,
    totalSets: Math.max(allSets.length, done.length),
    volumeKg,
  };
}

function exerciseMap(custom: Exercise[]): Map<string, Exercise> {
  return new Map([...EXERCISES, ...custom].map((e) => [e.id, e]));
}

function toActiveItems(items: PlannedItem[]): ActiveItem[] {
  const state = useStore.getState();
  const map = exerciseMap(state.customExercises);
  const out: ActiveItem[] = [];
  for (const it of items) {
    const ex = map.get(it.exerciseId);
    if (!ex) continue;
    const prev = lastPerformance(state.logs, ex.id);
    const prevKg = prev?.sets.find((s) => s.kg)?.kg ?? 0;
    out.push({
      exerciseId: ex.id,
      name: ex.name,
      cue: ex.cue,
      met: ex.met,
      uni: Boolean(ex.uni),
      loadable: isLoadable(ex),
      loadMode: loadModeOf(ex),
      bwFactor: bwFactorOf(ex),
      muscles: ex.muscles,
      sets: it.sets,
      reps: it.reps,
      sec: it.sec,
      rest: it.rest,
      done: Array.from({ length: it.sets }, () => false),
      kg: Array.from({ length: it.sets }, () => prevKg),
      group: it.group,
    });
  }
  return out;
}

export const useStore = create<Store>()(
  persist(
    (set, get) => ({
      ...emptyData,
      activeWorkout: null,
      lastSyncedAt: null,
      syncStatus: "idle",
      appUnlocked: false,

      setProfile: (p) => set({ profile: p, updatedAt: touch() }),

      toggleEquipment: (id) =>
        set((s) => {
          if (id === "bodyweight") return { updatedAt: touch() };
          const has = s.equipment.includes(id);
          return {
            equipment: has ? s.equipment.filter((e) => e !== id) : [...s.equipment, id],
            updatedAt: touch(),
          };
        }),

      upsertRoutine: (r) =>
        set((s) => {
          const exists = s.routines.some((x) => x.id === r.id);
          return {
            routines: exists ? s.routines.map((x) => (x.id === r.id ? r : x)) : [r, ...s.routines],
            updatedAt: touch(),
          };
        }),

      deleteRoutine: (id) =>
        set((s) => {
          const schedule = Object.fromEntries(
            Object.entries(s.schedule).filter(([, v]) => v !== id)
          );
          return { routines: s.routines.filter((r) => r.id !== id), schedule, updatedAt: touch() };
        }),

      assignDay: (dayKey, value) =>
        set((s) => {
          const schedule = { ...s.schedule };
          if (value === null) delete schedule[dayKey];
          else schedule[dayKey] = value;
          return { schedule, updatedAt: touch() };
        }),

      addMeal: (m) =>
        set((s) => ({ meals: [...s.meals, { ...m, id: uid() }], updatedAt: touch() })),

      removeMeal: (id) =>
        set((s) => ({ meals: s.meals.filter((m) => m.id !== id), updatedAt: touch() })),

      addCustomFood: (f) => {
        const food: Food = { ...f, id: "c-" + uid(), custom: true };
        set((s) => ({ customFoods: [food, ...s.customFoods], updatedAt: touch() }));
        return food;
      },

      setWater: (dayKey, count) =>
        set((s) => ({
          water: { ...s.water, [dayKey]: Math.max(0, Math.min(60, count)) },
          updatedAt: touch(),
        })),

      setHydration: (patch) =>
        set((s) => ({
          hydration: { ...DEFAULT_HYDRATION, ...s.hydration, ...patch },
          updatedAt: touch(),
        })),

      logWeight: (dayKey, kg) =>
        set((s) => {
          const clean = Math.round(Math.max(20, Math.min(400, kg)) * 10) / 10;
          const existing = s.weights.find((w) => w.date === dayKey);
          const weights = existing
            ? s.weights.map((w) => (w.date === dayKey ? { ...w, kg: clean } : w))
            : [...s.weights, { id: uid(), date: dayKey, kg: clean }];
          weights.sort((a, b) => b.date.localeCompare(a.date));
          return { weights, updatedAt: touch() };
        }),

      removeWeight: (id) =>
        set((s) => ({ weights: s.weights.filter((w) => w.id !== id), updatedAt: touch() })),

      logMeasurement: (m) =>
        set((s) => {
          const entry: MeasureEntry = { ...m, id: uid() };
          const rest = s.measurements.filter((x) => x.date !== m.date);
          return {
            measurements: [entry, ...rest].sort((a, b) => b.date.localeCompare(a.date)),
            updatedAt: touch(),
          };
        }),

      removeMeasurement: (id) =>
        set((s) => ({ measurements: s.measurements.filter((m) => m.id !== id), updatedAt: touch() })),

      addCustomExercise: (e) => {
        const ex: Exercise = { ...e, id: "cx-" + uid(), custom: true };
        set((s) => ({ customExercises: [ex, ...s.customExercises], updatedAt: touch() }));
        return ex;
      },

      removeCustomExercise: (id) =>
        set((s) => ({
          customExercises: s.customExercises.filter((e) => e.id !== id),
          updatedAt: touch(),
        })),

      setReminder: (pref) =>
        set((s) => ({ reminder: { ...s.reminder, ...pref }, updatedAt: touch() })),

      setLoadout: (patch) =>
        set((s) => ({
          loadout: { ...DEFAULT_LOADOUT, ...s.loadout, ...patch },
          updatedAt: touch(),
        })),

      saveTemplate: (t) =>
        set((s) => ({
          templates: [{ ...t, id: uid() }, ...s.templates].slice(0, 30),
          updatedAt: touch(),
        })),

      deleteTemplate: (id) =>
        set((s) => ({ templates: s.templates.filter((x) => x.id !== id), updatedAt: touch() })),

      setUnitSystem: (sys) => set({ unitSystem: sys, updatedAt: touch() }),

      clearPendingPRs: () => set({ pendingPRs: [] }),

      setLastRankId: (id) => set({ lastRankId: id, updatedAt: touch() }),

      setPendingRankUp: (r) => set({ pendingRankUp: r, updatedAt: touch() }),

      addChallenge: (c) =>
        set((s) => ({
          challenges: [{ ...c, id: uid() }, ...s.challenges].slice(0, 20),
          updatedAt: touch(),
        })),

      removeChallenge: (id) =>
        set((s) => ({
          challenges: s.challenges.filter((c) => c.id !== id),
          updatedAt: touch(),
        })),

      setAppLock: (lock) => set({ appLock: lock, updatedAt: touch() }),

      setAppUnlocked: (v) => set({ appUnlocked: v }),

      importSnapshot: (data) => {
        if (!data || typeof data !== "object" || Array.isArray(data)) {
          return { ok: false, error: "That isn't a FORGE backup file." };
        }
        const snap = data as Partial<Snapshot>;
        const hasData = Boolean(
          snap.profile || snap.logs?.length || snap.meals?.length || snap.routines?.length
        );
        if (!hasData) {
          return { ok: false, error: "That file doesn't contain any FORGE data." };
        }
        set({
          ...emptyData,
          ...snap,
          updatedAt: touch(),
          activeWorkout: null,
          lastSyncedAt: null, // force a fresh push to the cloud after import
        });
        return { ok: true };
      },

      setLang: (l) => set({ lang: l, updatedAt: touch() }),

      toggleStage: (skillId, stageId) =>
        set((s) => {
          const cur = s.skillProgress?.[skillId] ?? [];
          const next = cur.includes(stageId)
            ? cur.filter((x) => x !== stageId)
            : [...cur, stageId];
          return {
            skillProgress: { ...s.skillProgress, [skillId]: next },
            activeSkills:
              next.length && !(s.activeSkills ?? []).includes(skillId)
                ? [...(s.activeSkills ?? []), skillId]
                : s.activeSkills,
            updatedAt: touch(),
          };
        }),

      setEntitlement: (e) => set({ entitlement: e, updatedAt: touch() }),

      ensureAccountId: () => {
        const cur = get().accountId;
        if (cur) return cur;
        const id = newAccountId();
        set({ accountId: id, updatedAt: touch() });
        return id;
      },

      noteGeneration: () =>
        set((s) => {
          const k = dateKey();
          return {
            genUsage: { ...s.genUsage, [k]: (s.genUsage?.[k] ?? 0) + 1 },
            updatedAt: touch(),
          };
        }),

      upsertCheckin: (entry) =>
        set((s) => {
          const existing = s.checkins.find((c) => c.date === entry.date);
          const row: DailyCheckin = {
            ...entry,
            id: entry.id ?? existing?.id ?? uid(),
          };
          const checkins = existing
            ? s.checkins.map((c) => (c.date === entry.date ? row : c))
            : [row, ...s.checkins];
          checkins.sort((a, b) => b.date.localeCompare(a.date));
          return { checkins, updatedAt: touch() };
        }),

      removeCheckin: (id) =>
        set((s) => ({ checkins: s.checkins.filter((c) => c.id !== id), updatedAt: touch() })),

      toggleSkillActive: (skillId) =>
        set((s) => {
          const cur = s.activeSkills ?? [];
          return {
            activeSkills: cur.includes(skillId)
              ? cur.filter((x) => x !== skillId)
              : [...cur, skillId],
            updatedAt: touch(),
          };
        }),

      /**
       * Records a lift straight into history without running the player.
       * Feeds PRs, strength standards, volume, XP and achievements.
       */
      editLoggedSet: (logId, exerciseId, setIdx, patch) =>
        set((s) => ({
          logs: s.logs.map((l) =>
            l.id !== logId
              ? l
              : recalcLog({
                  ...l,
                  detail: (l.detail ?? []).map((d) =>
                    d.exerciseId !== exerciseId
                      ? d
                      : {
                          ...d,
                          sets: d.sets.map((st, i) =>
                            i === setIdx ? { ...st, ...patch } : st
                          ),
                        }
                  ),
                })
          ),
          updatedAt: touch(),
        })),

      deleteLoggedSet: (logId, exerciseId, setIdx) =>
        set((s) => {
          const logs = s.logs
            .map((l) => {
              if (l.id !== logId) return l;
              const detail = (l.detail ?? [])
                .map((d) =>
                  d.exerciseId !== exerciseId
                    ? d
                    : { ...d, sets: d.sets.filter((_, i) => i !== setIdx) }
                )
                .filter((d) => d.sets.length > 0);
              return recalcLog({ ...l, detail });
            })
            // drop sessions that no longer contain anything
            .filter((l) => (l.detail ?? []).length > 0 || l.setsDone > 0);
          return { logs, updatedAt: touch() };
        }),

      clearExerciseHistory: (exerciseId) =>
        set((s) => {
          const logs = s.logs
            .map((l) => {
              const detail = (l.detail ?? []).filter((d) => d.exerciseId !== exerciseId);
              if (detail.length === (l.detail ?? []).length) return l;
              return recalcLog({ ...l, detail });
            })
            .filter((l) => (l.detail ?? []).length > 0 || l.setsDone > 0);
          return { logs, updatedAt: touch() };
        }),

      quickLogLift: ({ exerciseId, name, sets, dayKey, bodyweightKg }) =>
        set((s) => {
          const clean = sets.filter((x) => (x.reps ?? 0) > 0 || (x.sec ?? 0) > 0);
          if (!clean.length) return {};
          const beforeBest = new Map(
            personalRecords(s.logs, 100).map((r) => [r.exerciseId, r.est1rm])
          );
          const date = dayKey ?? dateKey();
          const map = exerciseMap(s.customExercises);
          const ex = map.get(exerciseId);
          const detail: ExResult[] = [
            {
              exerciseId,
              name,
              sets: clean.map((x) => ({
                reps: x.reps,
                sec: x.sec,
                kg: x.kg ?? null,
                done: true,
                mode: x.mode ?? "external",
                bwf: x.bwf ?? 0,
                bw: bodyweightKg ?? 70,
              })),
            },
          ];
          const bwNow = bodyweightKg ?? 70;
          const volumeKg = Math.round(
            clean.reduce((a, x) => {
              const load =
                x.mode === "added" ? bwNow * (x.bwf ?? 0) + (x.kg ?? 0) : (x.kg ?? 0);
              return a + load * (x.reps ?? 0);
            }, 0)
          );
          const minutes = Math.max(3, Math.round(clean.length * 2.5));
          const met = ex?.met ?? 6;
          const kcal = Math.round(met * (bodyweightKg ?? 70) * (minutes / 60) * 0.9);

          // Merge into an existing quick-log entry for the same day
          const existing = s.logs.find((l) => l.date === date && l.name === "Quick log");
          if (existing) {
            const merged: WorkoutLog = {
              ...existing,
              setsDone: existing.setsDone + clean.length,
              totalSets: existing.totalSets + clean.length,
              exercises: existing.exercises + 1,
              minutes: existing.minutes + minutes,
              kcal: existing.kcal + kcal,
              volumeKg: (existing.volumeKg ?? 0) + volumeKg,
              detail: [...(existing.detail ?? []), ...detail],
            };
            const nextLogs = s.logs.map((l) => (l.id === existing.id ? merged : l));
            const mergeHits = personalRecords(nextLogs, 100)
              .filter((r) => r.est1rm > (beforeBest.get(r.exerciseId) ?? 0))
              .map((r) => ({
                exerciseId: r.exerciseId,
                name: r.name,
                kg: r.kg,
                reps: r.reps,
                est1rm: r.est1rm,
                added: r.added,
              }));
            return { logs: nextLogs, pendingPRs: mergeHits, updatedAt: touch() };
          }

          const log: WorkoutLog = {
            id: uid(),
            date,
            name: "Quick log",
            setsDone: clean.length,
            totalSets: clean.length,
            exercises: 1,
            minutes,
            kcal,
            volumeKg,
            detail,
          };
          const qlHits = personalRecords([log, ...s.logs], 100)
            .filter((r) => r.est1rm > (beforeBest.get(r.exerciseId) ?? 0))
            .map((r) => ({
              exerciseId: r.exerciseId,
              name: r.name,
              kg: r.kg,
              reps: r.reps,
              est1rm: r.est1rm,
              added: r.added,
            }));
          return { logs: [log, ...s.logs], pendingPRs: qlHits, updatedAt: touch() };
        }),

      startWorkout: (name, items) =>
        set({ activeWorkout: { name, startedAt: Date.now(), items: toActiveItems(items) } }),

      startGenerated: (name, items) =>
        set({
          activeWorkout: {
            name,
            startedAt: Date.now(),
            items: toActiveItems(
              items.map((it) => ({
                exerciseId: it.ex.id,
                sets: it.sets,
                reps: it.reps,
                sec: it.sec,
                rest: it.rest,
              }))
            ),
          },
        }),

      toggleSet: (exIdx, setIdx) =>
        set((s) => {
          if (!s.activeWorkout) return {};
          const items = s.activeWorkout.items.map((it, i) => {
            if (i !== exIdx) return it;
            const done = it.done.slice();
            done[setIdx] = !done[setIdx];
            return { ...it, done };
          });
          return { activeWorkout: { ...s.activeWorkout, items } };
        }),

      setSetDone: (exIdx, setIdx, done) =>
        set((s) => {
          if (!s.activeWorkout) return {};
          const items = s.activeWorkout.items.map((it, i) => {
            if (i !== exIdx) return it;
            const next = it.done.slice();
            next[setIdx] = done;
            return { ...it, done: next };
          });
          return { activeWorkout: { ...s.activeWorkout, items } };
        }),

      setSetKg: (exIdx, setIdx, kg) =>
        set((s) => {
          if (!s.activeWorkout) return {};
          const items = s.activeWorkout.items.map((it, i) => {
            if (i !== exIdx) return it;
            const next = it.kg.slice();
            next[setIdx] = Math.max(0, Math.round(kg * 10) / 10);
            return { ...it, kg: next };
          });
          return { activeWorkout: { ...s.activeWorkout, items } };
        }),

      finishWorkout: (weightKg, rpe) =>
        set((s) => {
          const w = s.activeWorkout;
          if (!w) return {};
          const beforeBest = new Map(
            personalRecords(s.logs, 100).map((r) => [r.exerciseId, r.est1rm])
          );
          const total = totalSets(w.items);
          const setsDone = w.items.reduce((sum, it) => sum + it.done.filter(Boolean).length, 0);
          if (setsDone === 0) return { activeWorkout: null };
          const map = exerciseMap(s.customExercises);
          const genItems: GenItem[] = w.items
            .map((it) => {
              const ex = map.get(it.exerciseId);
              return ex ? { ex, sets: it.sets, reps: it.reps, sec: it.sec, rest: it.rest } : null;
            })
            .filter((x): x is GenItem => x !== null);
          const estMin = estimateMinutes(genItems);
          const minutes = Math.max(1, Math.round(Math.min((Date.now() - w.startedAt) / 60000, estMin * 1.5)));
          const kcal = Math.round(estimateKcal(genItems, weightKg, estMin) * (setsDone / total));
          const detail: ExResult[] = w.items.map((it) => ({
            exerciseId: it.exerciseId,
            name: it.name,
            sets: it.done.map((done, j) => ({
              reps: it.reps,
              sec: it.sec,
              kg: it.loadable ? (it.kg[j] ?? 0) : null,
              done,
              mode: it.loadMode,
              bwf: it.bwFactor,
              bw: weightKg,
            })),
          }));
          const volumeKg = detail.reduce(
            (sum, ex) =>
              sum +
              ex.sets.reduce(
                (ss, st) => ss + (st.done && st.reps ? setLoad(st, weightKg) * st.reps : 0),
                0
              ),
            0
          );
          const log: WorkoutLog = {
            id: uid(),
            date: dateKey(),
            name: w.name,
            setsDone,
            totalSets: total,
            exercises: w.items.length,
            minutes,
            kcal,
            volumeKg: Math.round(volumeKg),
            ...(rpe ? { rpe } : {}),
            detail,
          };
          const hits = personalRecords([log, ...s.logs], 100)
            .filter((r) => r.est1rm > (beforeBest.get(r.exerciseId) ?? 0))
            .map((r) => ({
              exerciseId: r.exerciseId,
              name: r.name,
              kg: r.kg,
              reps: r.reps,
              est1rm: r.est1rm,
              added: r.added,
            }));
          return {
            logs: [log, ...s.logs],
            activeWorkout: null,
            pendingPRs: hits,
            updatedAt: touch(),
          };
        }),

      cancelWorkout: () => set({ activeWorkout: null }),

      applySnapshot: (snap) => set({ ...emptyData, ...snap }),

      snapshot: () => {
        const s = get();
        return {
          profile: s.profile,
          equipment: s.equipment,
          routines: s.routines,
          schedule: s.schedule,
          meals: s.meals,
          customFoods: s.customFoods,
          logs: s.logs,
          water: s.water,
          hydration: s.hydration,
          weights: s.weights,
          measurements: s.measurements,
          customExercises: s.customExercises,
          reminder: s.reminder,
          loadout: s.loadout,
          skillProgress: s.skillProgress,
          activeSkills: s.activeSkills,
          accountId: s.accountId,
          entitlement: s.entitlement,
          genUsage: s.genUsage,
          checkins: s.checkins,
          templates: s.templates,
          unitSystem: s.unitSystem,
          pendingPRs: s.pendingPRs,
          lastRankId: s.lastRankId,
          pendingRankUp: s.pendingRankUp,
          challenges: s.challenges,
          appLock: s.appLock,
          lang: s.lang,
          updatedAt: s.updatedAt,
        };
      },

      setSyncStatus: (st) => set({ syncStatus: st }),
      markSynced: (at) => set({ lastSyncedAt: at, syncStatus: "synced" }),

      resetAll: () => set({ ...emptyData, updatedAt: touch(), activeWorkout: null }),
    }),
    {
      name: "forge@1",
      version: 1,
      partialize: (s) => ({
        profile: s.profile,
        equipment: s.equipment,
        routines: s.routines,
        schedule: s.schedule,
        meals: s.meals,
        customFoods: s.customFoods,
        logs: s.logs,
        water: s.water,
        hydration: s.hydration,
        weights: s.weights,
        measurements: s.measurements,
        customExercises: s.customExercises,
        reminder: s.reminder,
        loadout: s.loadout,
        skillProgress: s.skillProgress,
        activeSkills: s.activeSkills,
        accountId: s.accountId,
        entitlement: s.entitlement,
        genUsage: s.genUsage,
        checkins: s.checkins,
        templates: s.templates,
        unitSystem: s.unitSystem,
        pendingPRs: s.pendingPRs,
        lastRankId: s.lastRankId,
        pendingRankUp: s.pendingRankUp,
        challenges: s.challenges,
        appLock: s.appLock,
        lang: s.lang,
        updatedAt: s.updatedAt,
        activeWorkout: s.activeWorkout,
        lastSyncedAt: s.lastSyncedAt,
      }),
    }
  )
);

/* ---------------------------- Sync engine ---------------------------- */

let syncing = false;

/** Postgres returns "2026-01-01 00:00:00+00" — normalize to a safe ISO instant. */
function toIso(s: string): string {
  const d = new Date(s.includes(" ") && !s.includes("T") ? s.replace(" ", "T") : s);
  return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
}

/**
 * Push the local snapshot to the server (last-write-wins). If the server
 * holds a newer snapshot and we have no local unsynced changes, adopt it.
 */
export async function syncNow(manual = false): Promise<boolean> {
  const store = useStore.getState();
  if (syncing) return false;
  if (typeof navigator !== "undefined" && !navigator.onLine) {
    store.setSyncStatus("offline");
    return false;
  }
  syncing = true;
  useStore.getState().setSyncStatus("syncing");
  try {
    const local = store.snapshot();
    const res = await fetch(`/api/sync?deviceId=${encodeURIComponent(deviceId())}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify({ state: local, updatedAt: local.updatedAt }),
    });
    if (!res.ok) throw new Error("sync failed");
    const data = (await res.json()) as { state: Snapshot; updatedAt: string };
    const s = useStore.getState();
    const serverAt = toIso(String(data.updatedAt ?? new Date().toISOString()));
    const serverNewer = Date.parse(serverAt) > Date.parse(s.updatedAt);
    const localDirty = s.lastSyncedAt !== null && s.updatedAt !== s.lastSyncedAt;
    if (serverNewer && !localDirty && data.state) {
      s.applySnapshot({ ...data.state, updatedAt: serverAt });
    }
    useStore.getState().markSynced(serverAt);
    return true;
  } catch {
    const online = typeof navigator === "undefined" ? true : navigator.onLine;
    useStore.getState().setSyncStatus(online ? (manual ? "error" : "idle") : "offline");
    return false;
  } finally {
    syncing = false;
  }
}
