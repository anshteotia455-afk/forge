import { EquipmentId, Exercise, EXERCISES } from "./data";
import { resolveDrill, Skill } from "./skills";

/* ------------------------------------------------------------------ *
 * Equipment-aware exercise substitution.
 *
 * A movement is doable when the user owns every piece of gear it lists.
 * When it isn't, we look for a substitute that trains the same muscles
 * with what they DO own: curated picks first (human judgement), then a
 * generic fallback ranked by primary muscle and level.
 * ------------------------------------------------------------------ */

export function doableWith(ex: Exercise, available: ReadonlySet<EquipmentId>): boolean {
  return ex.equipment.every((e) => available.has(e));
}

export function missingGear(ex: Exercise, available: ReadonlySet<EquipmentId>): EquipmentId[] {
  return ex.equipment.filter((e) => !available.has(e));
}

/** Ordered substitute candidates for the most common equipment gaps. */
const CURATED: Record<string, string[]> = {
  // pulling
  "pull-up": ["db-row", "band-row", "cable-row"],
  "chin-up": ["db-row", "band-row", "cable-row"],
  "scap-pull": ["band-pull-apart", "superman"],
  "assisted-pullup": ["band-row", "db-row"],
  "ring-row": ["db-row", "band-row", "cable-row"],
  "straight-arm-pulldown": ["band-lat-pulldown", "db-row"],
  "lat-pulldown-machine": ["band-lat-pulldown", "db-row"],
  "cable-pulldown": ["band-lat-pulldown", "db-row"],
  // dipping / pressing
  "parallel-dip": ["chair-dip", "push-up"],
  "ring-dip": ["chair-dip", "push-up"],
  "ring-pushup": ["push-up"],
  "ring-support": ["plank", "tuck-hold"],
  "l-sit": ["hollow-rock", "plank"],
  "tuck-hold": ["hollow-rock", "plank"],
  "captains-raise": ["leg-raise", "reverse-crunch"],
  "hanging-leg-raise": ["leg-raise", "reverse-crunch"],
  "tuck-front-lever": ["leg-raise", "hollow-rock"],
  "weighted-pullup": ["db-row", "band-row"],
  "pullup-bar-deep": ["push-up"],
  "parallette-pushup": ["push-up"],
  "hspu-wall": ["pike-push-up"],
  "wall-handstand": ["pike-push-up"],
  "handstand-kickup": ["pike-push-up"],
  // barbell -> dumbbell / bodyweight
  "bb-squat": ["db-goblet-squat", "squat"],
  "rack-front-squat": ["db-goblet-squat", "squat"],
  "bb-box-squat": ["db-goblet-squat", "squat"],
  "bb-pause-squat": ["db-goblet-squat", "squat"],
  "bb-deadlift": ["db-rdl", "kb-swing", "squat"],
  "bb-rdl": ["db-rdl", "kb-goblet"],
  "bb-sumo-deadlift": ["db-rdl", "squat"],
  "bb-good-morning": ["db-rdl", "single-leg-rdl"],
  "bb-bench": ["db-bench-press", "db-floor-press", "push-up"],
  "bb-floor-press": ["db-floor-press", "push-up"],
  "bb-close-grip-bench": ["db-floor-press", "diamond-pushup"],
  "bb-ohp": ["db-shoulder-press", "pike-push-up"],
  "bb-push-press": ["db-shoulder-press", "pike-push-up"],
  "bb-row": ["db-row", "band-row"],
  "bb-pendlay-row": ["db-row", "band-row"],
  "bb-curl": ["db-curl", "band-curl"],
  "bb-hip-thrust": ["bw-hip-thrust", "glute-bridge"],
  "bb-calf-raise": ["calf-raise", "calf-raise-single"],
  "bb-thruster": ["db-thruster", "db-shoulder-press"],
  "bb-overhead-squat": ["squat", "db-goblet-squat"],
  "bb-hang-clean": ["db-clean", "kb-clean-press"],
  "bb-deficit-deadlift": ["db-rdl", "squat"],
  "bb-shrug": ["db-shrug"],
  "bb-wrist-curl": ["wrist-roller", "gripper-squeeze"],
  // EZ bar
  "ez-curl": ["db-curl", "band-curl"],
  "ez-skullcrusher": ["db-skullcrusher", "band-pushdown"],
  "ez-upright-row": ["db-upright-row", "band-row"],
  "ez-preacher": ["db-concentration-curl", "db-curl"],
  // kettlebell -> dumbbell / bodyweight
  "kb-swing": ["db-rdl", "jump-squat"],
  "kb-single-swing": ["db-rdl", "jump-squat"],
  "kb-snatch": ["db-snatch"],
  "kb-clean-press": ["db-clean"],
  "kb-front-rack-squat": ["db-goblet-squat", "squat"],
  "kb-goblet": ["squat", "db-goblet-squat"],
  "kb-goblet-curl": ["db-curl"],
  "kb-high-pull": ["db-upright-row", "band-row"],
  "kb-windmill": ["side-plank", "dead-bug"],
  "kb-halo": ["wall-angel", "band-pull-apart"],
  "kb-around-world": ["russian-twist-bw", "dead-bug"],
  "kb-figure-eight": ["russian-twist-bw", "bear-crawl"],
  "kb-suitcase-deadlift": ["single-leg-rdl", "squat"],
  "turkish-getup": ["side-plank", "dead-bug"],
  // machines / cable -> free weights or bands
  "leg-press": ["squat", "db-goblet-squat"],
  "leg-press-calf": ["calf-raise", "calf-raise-single"],
  "hack-squat": ["squat", "db-goblet-squat"],
  "leg-extension": ["wall-sit", "squat"],
  "leg-curl": ["nordic-curl", "glute-bridge"],
  "pec-deck": ["db-fly", "push-up"],
  "machine-chest-press": ["db-bench-press", "push-up"],
  "smith-squat": ["db-goblet-squat", "squat"],
  "smith-press": ["db-bench-press", "push-up"],
  "smith-row": ["db-row", "band-row"],
  "smith-calf-raise": ["calf-raise", "calf-raise-single"],
  "smith-shrug": ["db-shrug"],
  "smith-split-squat": ["bulgarian-split-squat", "reverse-lunge"],
  "cable-row": ["db-row", "band-row"],
  "cable-lateral-raise": ["db-lateral-raise", "band-pull-apart"],
  "cable-upright-row": ["db-upright-row", "band-row"],
  "cable-pull-through": ["glute-bridge", "bw-hip-thrust"],
  "cable-kickback": ["donkey-kick", "glute-bridge"],
  "cable-crunch": ["reverse-crunch", "leg-raise"],
  "cable-reverse-fly": ["prone-ytw", "db-rear-delt-fly"],
  "cable-hammer-curl": ["db-hammer-curl", "band-curl"],
  "cable-curl": ["db-curl", "band-curl"],
  "cable-fly": ["db-fly", "push-up"],
  "cable-woodchop": ["band-woodchop", "russian-twist-bw"],
  "cable-face-pull": ["band-face-pull", "prone-ytw"],
  "cable-pushdown": ["band-pushdown", "band-pushdown"],
  "cable-press": ["push-up", "db-bench-press"],
  // boxing bag -> shadow
  "bag-jab-cross": ["shadow-box-rounds"],
  "bag-combos": ["shadow-box-rounds"],
  "bag-hooks": ["shadow-box-rounds"],
  "bag-knees": ["mountain-climbers"],
  "bag-speed-burst": ["shadow-box-rounds"],
  "bag-footwork": ["high-knees", "jump-rope"],
  "bag-body-shots": ["shadow-box-rounds"],
  "bag-slip-counter": ["shadow-box-rounds"],
  "bag-teeps": ["jump-squat"],
  "bag-low-kicks": ["skater-jump"],
  "speedbag-rhythm": ["jump-rope"],
  // ropes / conditioning machines
  "jump-rope": ["jumping-jacks", "high-knees"],
  "rope-intervals": ["high-knees", "mountain-climbers"],
  "rope-double-under": ["jumping-jacks", "star-jump"],
  "rope-single-leg": ["high-knees"],
  "rope-crossover": ["jumping-jacks"],
  "battlerope-alternate-waves": ["mountain-climbers"],
  "rope-alt-waves": ["mountain-climbers", "jumping-jacks"],
  "rope-double-slam": ["burpees", "jump-squat"],
  "rope-circles": ["jumping-jacks", "high-knees"],
  "rope-jump-slam": ["burpees", "star-jump"],
  "tread-intervals": ["high-knees", "jump-rope"],
  "tread-steady-run": ["jump-rope", "high-knees"],
  "tread-incline-walk": ["reverse-lunge", "step-up"],
  "bike-sprints": ["jump-squat", "burpees"],
  "bike-steady": ["jump-rope", "jumping-jacks"],
  "bike-hill": ["squat", "reverse-lunge"],
  "row-intervals": ["mountain-climbers", "burpees"],
  "row-steady": ["jump-rope", "jumping-jacks"],
  "row-sprint": ["burpees", "mountain-climbers"],
  "airbike-sprint": ["burpees", "jump-squat"],
  "airbike-steady": ["jump-rope", "jumping-jacks"],
  "skierg-intervals": ["mountain-climbers", "jumping-jacks"],
  "sled-push": ["reverse-lunge", "jump-squat"],
  "sled-drag": ["wall-sit", "squat"],
  "sled-lateral": ["skater-jump"],
  "elliptical-steady": ["jumping-jacks", "jump-rope"],
  "elliptical-intervals": ["jump-squat", "high-knees"],
  "stair-climb": ["step-up", "jump-rope"],
  // core / stability gear
  "ab-rollout-knee": ["plank", "dead-bug"],
  "ab-rollout-stand": ["plank", "leg-raise"],
  "ab-wheel-oblique": ["side-plank", "russian-twist-bw"],
  "ball-crunch": ["toe-touch-crunch", "bicycle-crunch"],
  "ball-ham-curl": ["glute-bridge", "nordic-curl"],
  "ball-pike": ["plank", "v-up"],
  "ball-plank": ["plank", "hollow-rock"],
  "ball-wall-squat": ["wall-sit", "squat"],
  "foam-chest-open": ["wall-angel", "prone-ytw"],
  "dead-hang": ["plank", "superman"],
  // suspension straps
  "trx-row": ["db-row", "band-row"],
  "trx-press": ["push-up", "db-bench-press"],
  "trx-fallout": ["plank", "dead-bug"],
  "trx-ham-curl": ["glute-bridge", "nordic-curl"],
  "trx-y-fly": ["prone-ytw", "band-pull-apart"],
  "trx-split-squat": ["bulgarian-split-squat", "reverse-lunge"],
  "trx-pistol": ["step-up", "cossack-squat"],
};

/**
 * Finds the best substitute for an exercise the user can't perform.
 * Curated picks first, then generic: same primary muscle, doable with
 * owned gear, same kind (reps/time), closest level.
 */
export function findSubstitute(
  ex: Exercise,
  available: ReadonlySet<EquipmentId>,
  pool: Exercise[] = EXERCISES
): Exercise | null {
  // Curated candidates that exist and are doable.
  for (const id of CURATED[ex.id] ?? []) {
    const c = pool.find((e) => e.id === id);
    if (c && doableWith(c, available)) return c;
  }

  const primary = ex.muscles[0];
  const candidates = pool.filter(
    (e) =>
      e.id !== ex.id &&
      doableWith(e, available) &&
      e.kind === ex.kind &&
      e.muscles.includes(primary) &&
      e.level <= ex.level + 1
  );
  if (!candidates.length) return null;

  candidates.sort((a, b) => {
    // Prefer matching the PRIMARY muscle exactly, then closer level, then similar intensity.
    const pa = a.muscles[0] === primary ? 0 : 1;
    const pb = b.muscles[0] === primary ? 0 : 1;
    if (pa !== pb) return pa - pb;
    const la = Math.abs(a.level - ex.level);
    const lb = Math.abs(b.level - ex.level);
    if (la !== lb) return la - lb;
    return Math.abs(a.met - ex.met);
  });
  return candidates[0];
}

export interface DrillPlanItem {
  /** id to use for the workout (the substitute when adapted) */
  id: string;
  name: string;
  originalId: string;
  originalName: string;
  substituted: boolean;
  /** no substitute exists — cannot be performed with current gear */
  skipped: boolean;
  inLibrary: boolean;
}

/**
 * Adapts a list of skill drills to the user's inventory. Returns the
 * original when doable, a substitute when not, or skipped when neither.
 */
export function planDrills(
  drillIds: string[],
  available: ReadonlySet<EquipmentId>
): DrillPlanItem[] {
  return drillIds.map((id) => {
    const original = resolveDrill(id);
    if (!original) {
      return {
        id,
        name: id,
        originalId: id,
        originalName: id,
        substituted: false,
        skipped: true,
        inLibrary: false,
      };
    }

    const originalDoable = original.equipment.every((e) => available.has(e));
    if (originalDoable) {
      return {
        id,
        name: original.name,
        originalId: id,
        originalName: original.name,
        substituted: false,
        skipped: false,
        inLibrary: original.inLibrary,
      };
    }

    // Curated substitute for this drill id (exercise-backed drills).
    const asExercise = EXERCISES.find((e) => e.id === id);
    if (asExercise) {
      const sub = findSubstitute(asExercise, available);
      if (sub) {
        return {
          id: sub.id,
          name: sub.name,
          originalId: id,
          originalName: original.name,
          substituted: true,
          skipped: false,
          inLibrary: true,
        };
      }
    } else {
      // Virtual drills: try curated id targets directly.
      for (const cand of CURATED[id] ?? []) {
        const c = EXERCISES.find((e) => e.id === cand);
        if (c && doableWith(c, available)) {
          return {
            id: c.id,
            name: c.name,
            originalId: id,
            originalName: original.name,
            substituted: true,
            skipped: false,
            inLibrary: true,
          };
        }
      }
    }

    return {
      id,
      name: original.name,
      originalId: id,
      originalName: original.name,
      substituted: false,
      skipped: true,
      inLibrary: original.inLibrary,
    };
  });
}

/** Gear labels for a list of missing equipment ids. */
export function gearLabels(ids: readonly EquipmentId[], defs: { id: EquipmentId; label: string }[]): string[] {
  return ids.map((id) => defs.find((d) => d.id === id)?.label ?? id);
}

/* ---------------------- Skill-level availability ---------------------- */

export interface SkillFit {
  /** every drill doable exactly as written */
  status: "full" | "adapted" | "partial";
  /** drills swapped for an alternative */
  adapted: number;
  /** drills impossible even with substitutes */
  skipped: number;
  total: number;
  /** gear the skill's drills want that the user doesn't own */
  missing: EquipmentId[];
}

/**
 * Analyzes a whole skill tree against the user's inventory: how many drills
 * run as written, how many adapt, and what gear is absent.
 */
export function skillFit(skill: Skill, available: ReadonlySet<EquipmentId>): SkillFit {
  let adapted = 0;
  let skipped = 0;
  let total = 0;
  const missing = new Set<EquipmentId>();

  for (const stage of skill.stages) {
    for (const drillId of stage.drills) {
      total += 1;
      const original = resolveDrill(drillId);
      if (original) for (const g of original.equipment) if (!available.has(g)) missing.add(g);
      const plan = planDrills([drillId], available)[0];
      if (plan?.skipped) skipped += 1;
      else if (plan?.substituted) adapted += 1;
    }
  }

  const status: SkillFit["status"] =
    skipped > 0 ? "partial" : adapted > 0 ? "adapted" : "full";
  return { status, adapted, skipped, total, missing: [...missing] };
}
