import { boolean, integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

/**
 * FORGE is an offline-first app: the client is the primary store, and
 * Postgres acts as the cloud backup / sync target.
 */
export const syncState = pgTable("sync_state", {
  id: text("id").primaryKey(),
  state: jsonb("state").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true, mode: "string" })
    .notNull()
    .defaultNow(),
});

export type SyncStateRow = typeof syncState.$inferSelect;

/**
 * Accounts. Passwords are stored as scrypt hashes with a per-user salt —
 * never in plain text, and never recoverable from the database.
 */
export const users = pgTable("users", {
  id: text("id").primaryKey(),
  /** lower-cased, trimmed */
  email: text("email").notNull().unique(),
  displayName: text("display_name"),
  passwordHash: text("password_hash").notNull(),
  passwordSalt: text("password_salt").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "string" })
    .notNull()
    .defaultNow(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true, mode: "string" })
    .notNull()
    .defaultNow(),
});

export type UserRow = typeof users.$inferSelect;

/** Opaque bearer tokens. Deleted on logout, expired on a rolling window. */
export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  userId: text("user_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "string" })
    .notNull()
    .defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true, mode: "string" }).notNull(),
});

export type SessionRow = typeof sessions.$inferSelect;

/**
 * Server-side entitlement record. The client caches subscription state for
 * offline use, but this table is the authority — it is what a payment
 * webhook writes to and what the app verifies against when online.
 */
export const entitlements = pgTable("entitlements", {
  /** device/account identifier owned by the client install */
  accountId: text("account_id").primaryKey(),
  /** "free" | "trial" | "pro" */
  tier: text("tier").notNull().default("free"),
  /** "active" | "expired" | "cancelled" | "none" */
  status: text("status").notNull().default("none"),
  /** monthly | annual | lifetime | trial | code */
  plan: text("plan"),
  /** null for lifetime */
  expiresAt: timestamp("expires_at", { withTimezone: true, mode: "string" }),
  trialEndsAt: timestamp("trial_ends_at", { withTimezone: true, mode: "string" }),
  /** payment provider reference, when a real charge happened */
  provider: text("provider"),
  providerRef: text("provider_ref"),
  updatedAt: timestamp("updated_at", { withTimezone: true, mode: "string" })
    .notNull()
    .defaultNow(),
});

export type EntitlementRow = typeof entitlements.$inferSelect;

/**
 * Redeemable licence codes — lets you sell outside an app store, give press
 * or friends access, and run launch promos without a payment provider.
 */
export const licenseCodes = pgTable("license_codes", {
  code: text("code").primaryKey(),
  plan: text("plan").notNull().default("lifetime"),
  /** how many installs may redeem this code */
  maxRedemptions: integer("max_redemptions").notNull().default(1),
  redemptions: integer("redemptions").notNull().default(0),
  /** days of access granted; null/0 = lifetime */
  durationDays: integer("duration_days"),
  active: boolean("active").notNull().default(true),
  note: text("note"),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "string" })
    .notNull()
    .defaultNow(),
});

export type LicenseCodeRow = typeof licenseCodes.$inferSelect;
