package com.forge.fitness;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Pushes today's summary from the web layer to the home-screen widget. */
@CapacitorPlugin(name = "ForgeWidget")
public class ForgeWidgetPlugin extends Plugin {
    @PluginMethod
    public void update(PluginCall call) {
        String line1 = call.getString("line1", "Open FORGE");
        String line2 = call.getString("line2", "Tap to plan today's workout");
        ForgeWidgetProvider.push(getContext(), line1, line2);
        call.resolve();
    }
}
