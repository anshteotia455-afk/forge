package com.forge.fitness;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

/**
 * Home-screen widget: today's workout plus readiness / calorie line.
 * The web layer pushes content through ForgeWidgetPlugin; the widget only
 * reads SharedPreferences, so it keeps working while FORGE is closed.
 */
public class ForgeWidgetProvider extends AppWidgetProvider {
    public static final String PREFS = "forge_widget";

    public static void push(Context context, String line1, String line2) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString("line1", line1)
                .putString("line2", line2)
                .apply();
        refresh(context);
    }

    private static void refresh(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, ForgeWidgetProvider.class));
        if (ids == null || ids.length == 0) return;

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.forge_widget);
        views.setTextViewText(R.id.widget_line1, prefs.getString("line1", "Open FORGE"));
        views.setTextViewText(
                R.id.widget_line2,
                prefs.getString("line2", "Tap to plan today's workout")
        );

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap = PendingIntent.getActivity(
                context,
                2001,
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        views.setOnClickPendingIntent(R.id.widget_root, tap);
        manager.updateAppWidget(ids, views);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        refresh(context);
    }
}
