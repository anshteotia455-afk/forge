package com.forge.fitness;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;
import com.getcapacitor.ProcessedRoute;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(ForgeReminderPlugin.class);
        registerPlugin(ForgeWidgetPlugin.class);

        // Next.js static export keeps one index.html / index.txt per route.
        // Capacitor otherwise answers every clean path with the root index,
        // which sent taps back to Home. This processor resolves:
        //   "/"              -> public/index.html
        //   "/planner/"      -> public/planner/index.html
        //   "/planner"       -> public/planner/index.html
        //   "/planner.txt"   -> public/planner/index.txt   (RSC payload)
        //   "/planner/index.txt", "/_next/...", icons, etc. pass through.
        // basePath is included because the root-load call site uses this
        // return value verbatim as the asset path.
        bridgeBuilder.setRouteProcessor((basePath, requestedPath) -> {
            String root = basePath == null ? "" : basePath;
            String p = requestedPath == null ? "" : requestedPath;

            String mapped;
            if (p.isEmpty() || "/".equals(p)) {
                mapped = "/index.html";
            } else {
                // "/planner/" -> "/planner"
                while (p.length() > 1 && p.endsWith("/")) {
                    p = p.substring(0, p.length() - 1);
                }
                String last = p.substring(p.lastIndexOf('/') + 1);

                if (!last.contains(".")) {
                    // Clean document route -> that route's exported HTML.
                    mapped = p + "/index.html";
                } else if (last.endsWith(".txt") && !last.startsWith("index.") && !last.startsWith("__next")) {
                    // Next fetches RSC as "/planner.txt"; the export writes
                    // "/planner/index.txt". Map one onto the other.
                    mapped = p.substring(0, p.length() - ".txt".length()) + "/index.txt";
                } else {
                    // Real files (index.txt, __next.*.txt, /_next/..., icons…).
                    mapped = p;
                }
            }

            ProcessedRoute route = new ProcessedRoute();
            route.setPath(root + mapped);
            route.setAsset(true);
            route.setIgnoreAssetPath(false);
            return route;
        });

        super.onCreate(savedInstanceState);
    }
}
