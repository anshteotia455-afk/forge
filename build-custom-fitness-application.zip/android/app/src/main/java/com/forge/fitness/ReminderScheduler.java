package com.forge.fitness;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import java.util.Calendar;

/** Shared Android alarm/channel plumbing for the plugin and receivers. */
public final class ReminderScheduler {
    public static final String PREFS = "forge_reminder";
    public static final String ACTION_ALARM = "com.forge.fitness.REMINDER_ALARM";
    public static final String ACTION_SNOOZE = "com.forge.fitness.REMINDER_SNOOZE";
    private static final int DAILY_REQUEST = 9101;
    private static final int SNOOZE_REQUEST = 9102;

    private ReminderScheduler() {}

    public static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String channelId(Context context) {
        String uri = prefs(context).getString("sound_uri", "default");
        return "forge_workout_" + Math.abs(uri.hashCode());
    }

    public static Uri soundUri(Context context) {
        String raw = prefs(context).getString("sound_uri", null);
        return raw == null ? Settings.System.DEFAULT_NOTIFICATION_URI : Uri.parse(raw);
    }

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String id = channelId(context);
        if (manager.getNotificationChannel(id) != null) return;

        NotificationChannel channel = new NotificationChannel(
                id,
                "FORGE workout alarm",
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("Daily workout reminders with your chosen ringtone");
        channel.enableVibration(prefs(context).getBoolean("vibrate", true));
        channel.setVibrationPattern(new long[]{0, 250, 120, 250, 120, 400});
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        channel.setSound(soundUri(context), attrs);
        manager.createNotificationChannel(channel);
    }

    private static PendingIntent alarmIntent(Context context, boolean oneTime) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.setAction(ACTION_ALARM);
        intent.putExtra("one_time", oneTime);
        int request = oneTime ? SNOOZE_REQUEST : DAILY_REQUEST;
        return PendingIntent.getBroadcast(
                context,
                request,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    public static void scheduleDaily(Context context) {
        SharedPreferences p = prefs(context);
        if (!p.getBoolean("enabled", false)) return;
        int hour = p.getInt("hour", 7);
        int minute = p.getInt("minute", 0);

        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, hour);
        next.set(Calendar.MINUTE, minute);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) {
            next.add(Calendar.DAY_OF_YEAR, 1);
        }
        scheduleAt(context, next.getTimeInMillis(), alarmIntent(context, false));
    }

    public static void scheduleSnooze(Context context) {
        int minutes = prefs(context).getInt("snooze", 10);
        long at = System.currentTimeMillis() + Math.max(1, minutes) * 60_000L;
        scheduleAt(context, at, alarmIntent(context, true));
    }

    private static void scheduleAt(Context context, long at, PendingIntent pi) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && manager.canScheduleExactAlarms()) {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } else {
            manager.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    public static void cancel(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        manager.cancel(alarmIntent(context, false));
        manager.cancel(alarmIntent(context, true));
        prefs(context).edit().putBoolean("enabled", false).apply();
    }
}
