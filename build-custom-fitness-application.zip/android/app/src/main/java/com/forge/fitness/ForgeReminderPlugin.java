package com.forge.fitness;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.OpenableColumns;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.getcapacitor.PluginMethod;

/** Capacitor bridge for arbitrary user-selected Android notification sounds. */
@CapacitorPlugin(
        name = "ForgeReminder",
        permissions = {
                @Permission(alias = "notifications", strings = {Manifest.permission.POST_NOTIFICATIONS})
        }
)
public class ForgeReminderPlugin extends Plugin {
    private Ringtone preview;

    @PluginMethod
    public void pickRingtone(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        startActivityForResult(call, intent, "ringtonePicked");
    }

    @ActivityCallback
    private void ringtonePicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null ||
                result.getData().getData() == null) {
            call.reject("No audio file selected");
            return;
        }
        Uri uri = result.getData().getData();
        try {
            int flags = result.getData().getFlags() &
                    (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContext().getContentResolver().takePersistableUriPermission(
                    uri,
                    flags & Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
        } catch (Exception ignored) {
            // Some providers grant a durable read URI without supporting this call.
        }

        String name = displayName(uri);
        SharedPreferences p = ReminderScheduler.prefs(getContext());
        p.edit().putString("sound_uri", uri.toString()).putString("sound_name", name).apply();
        ReminderScheduler.ensureChannel(getContext());

        JSObject out = new JSObject();
        out.put("name", name);
        out.put("uri", uri.toString());
        call.resolve(out);
    }

    private String displayName(Uri uri) {
        String fallback = uri.getLastPathSegment() == null ? "Custom ringtone" : uri.getLastPathSegment();
        try (Cursor cursor = getContext().getContentResolver().query(
                uri,
                new String[]{OpenableColumns.DISPLAY_NAME},
                null,
                null,
                null
        )) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return cursor.getString(idx);
            }
        } catch (Exception ignored) {}
        return fallback;
    }

    @PluginMethod
    public void preview(PluginCall call) {
        try {
            if (preview != null && preview.isPlaying()) preview.stop();
            preview = RingtoneManager.getRingtone(getContext(), ReminderScheduler.soundUri(getContext()));
            if (preview == null) {
                call.reject("This audio file can't be played");
                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) preview.setLooping(false);
            preview.play();
            call.resolve();
        } catch (Exception e) {
            call.reject("Couldn't play the ringtone", e);
        }
    }

    @PluginMethod
    public void schedule(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                getPermissionState("notifications") != PermissionState.GRANTED) {
            requestPermissionForAlias("notifications", call, "notificationPermission");
            return;
        }
        scheduleNow(call);
    }

    @PermissionCallback
    private void notificationPermission(PluginCall call) {
        if (getPermissionState("notifications") != PermissionState.GRANTED) {
            call.reject("Notification permission denied");
            return;
        }
        scheduleNow(call);
    }

    private void scheduleNow(PluginCall call) {
        boolean enabled = call.getBoolean("enabled", true);
        if (!enabled) {
            ReminderScheduler.cancel(getContext());
            JSObject out = new JSObject();
            out.put("scheduled", false);
            call.resolve(out);
            return;
        }

        String soundId = call.getString("soundId", "forge");
        SharedPreferences.Editor editor = ReminderScheduler.prefs(getContext()).edit();
        // Moving back to a built-in tone must stop using the previously picked file.
        if (!"custom".equals(soundId)) editor.remove("sound_uri").remove("sound_name");
        editor.putBoolean("enabled", true)
                .putInt("hour", call.getInt("hour", 7))
                .putInt("minute", call.getInt("minute", 0))
                .putBoolean("vibrate", call.getBoolean("vibrate", true))
                .putInt("snooze", call.getInt("snoozeMinutes", 10))
                .putString("title", call.getString("title", "Time to forge"))
                .putString("body", call.getString(
                        "body",
                        "Today's session is waiting — keep the streak alive."
                ));
        // Snooze is mirrored by the web layer on the next schedule call.
        editor.apply();
        ReminderScheduler.ensureChannel(getContext());
        ReminderScheduler.scheduleDaily(getContext());

        JSObject out = new JSObject();
        out.put("scheduled", true);
        call.resolve(out);
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        ReminderScheduler.cancel(getContext());
        call.resolve();
    }
}
