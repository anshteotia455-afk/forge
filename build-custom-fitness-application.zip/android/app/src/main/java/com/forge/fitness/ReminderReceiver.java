package com.forge.fitness;

import android.Manifest;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

/** Posts the workout notification, then arms tomorrow's alarm. */
public class ReminderReceiver extends BroadcastReceiver {
    private static final int NOTIFICATION_ID = 9240;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (ReminderScheduler.ACTION_SNOOZE.equals(intent.getAction())) {
            ReminderScheduler.scheduleSnooze(context);
            return;
        }

        boolean oneTime = intent.getBooleanExtra("one_time", false);
        if (!ReminderScheduler.prefs(context).getBoolean("enabled", false)) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            if (!oneTime) ReminderScheduler.scheduleDaily(context);
            return;
        }

        ReminderScheduler.ensureChannel(context);
        boolean vibrate = ReminderScheduler.prefs(context).getBoolean("vibrate", true);
        String title = ReminderScheduler.prefs(context).getString("title", "Time to forge");
        String body = ReminderScheduler.prefs(context).getString(
                "body",
                "Today's session is waiting — keep the streak alive."
        );

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openApp = PendingIntent.getActivity(
                context,
                9200,
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent snooze = new Intent(context, ReminderReceiver.class);
        snooze.setAction(ReminderScheduler.ACTION_SNOOZE);
        PendingIntent snoozePi = PendingIntent.getBroadcast(
                context,
                9201,
                snooze,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder notification = new NotificationCompat.Builder(
                context,
                ReminderScheduler.channelId(context)
        )
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(openApp)
                .addAction(0, "Snooze", snoozePi);

        if (vibrate) notification.setVibrate(new long[]{0, 250, 120, 250, 120, 400});
        else notification.setVibrate(new long[]{0});

        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, notification.build());

        // Snoozed alarms are one-shot; the original alarm already armed tomorrow.
        if (!oneTime) ReminderScheduler.scheduleDaily(context);
    }
}
