/* FORGE service worker — offline app-shell + runtime caching */
const VERSION = "forge-v4";
const PAGES = `pages-${VERSION}`;
const ASSETS = `assets-${VERSION}`;

const PRECACHE = [
  "/",
  "/planner/",
  "/generator/",
  "/nutrition/",
  "/profile/",
  "/ranks/",
  "/skills/",
  "/recovery/",
  "/library/",
  "/workout/",
  "/manifest.webmanifest",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(PAGES)
      .then((cache) => Promise.allSettled(PRECACHE.map((url) => cache.add(url))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.filter((k) => k !== PAGES && k !== ASSETS).map((k) => caches.delete(k))
        )
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // API traffic is network-only (sync endpoints)
  if (url.pathname.startsWith("/api/")) return;

  // Page navigations: normalize clean routes to the trailing-slash static
  // export path. Never substitute the home page for a named route.
  if (req.mode === "navigate") {
    const needsSlash =
      url.pathname !== "/" &&
      !url.pathname.endsWith("/") &&
      !url.pathname.split("/").pop().includes(".");
    const normalizedUrl = needsSlash
      ? new URL(url.pathname + "/" + url.search, url.origin).toString()
      : req.url;
    const normalizedReq = new Request(normalizedUrl, req);

    event.respondWith(
      fetch(normalizedReq)
        .then((res) => {
          if (!res.ok) throw new Error(`navigation ${res.status}`);
          const copy = res.clone();
          caches.open(PAGES).then((c) => c.put(normalizedReq, copy));
          return res;
        })
        .catch(() =>
          caches.match(normalizedReq).then((hit) => {
            if (hit) return hit;
            // Root is the only route allowed to fall back to the root shell.
            if (url.pathname === "/") return caches.match("/");
            return new Response("This page is not cached yet. Open it once while online.", {
              status: 503,
              headers: { "Content-Type": "text/plain; charset=utf-8" },
            });
          })
        )
    );
    return;
  }

  // Hashed static assets + icons: cache-first
  if (
    url.pathname.startsWith("/_next/static") ||
    url.pathname.startsWith("/icons") ||
    url.pathname.match(/\.(png|jpg|jpeg|webp|woff2?|svg|ico)$/)
  ) {
    event.respondWith(
      caches.match(req).then(
        (hit) =>
          hit ||
          fetch(req).then((res) => {
            const copy = res.clone();
            caches.open(ASSETS).then((c) => c.put(req, copy));
            return res;
          })
      )
    );
    return;
  }

  // Everything else: stale-while-revalidate
  event.respondWith(
    caches.match(req).then((hit) => {
      const network = fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(ASSETS).then((c) => c.put(req, copy));
          return res;
        })
        .catch(() => hit);
      return hit || network;
    })
  );
});
